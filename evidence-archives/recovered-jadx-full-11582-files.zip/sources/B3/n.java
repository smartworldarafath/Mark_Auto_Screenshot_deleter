package B3;

/* JADX INFO: loaded from: classes.dex */
public final class n extends y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final l f456a;

    public n(l lVar) {
        this.f456a = lVar;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof y)) {
            return false;
        }
        y yVar = (y) obj;
        ((n) yVar).getClass();
        Object obj2 = x.f479t;
        if (obj2.equals(obj2)) {
            return this.f456a.equals(((n) yVar).f456a);
        }
        return false;
    }

    public final int hashCode() {
        return ((x.f479t.hashCode() ^ 1000003) * 1000003) ^ this.f456a.hashCode();
    }

    public final String toString() {
        return "ClientInfo{clientType=" + x.f479t + ", androidClientInfo=" + this.f456a + "}";
    }
}
