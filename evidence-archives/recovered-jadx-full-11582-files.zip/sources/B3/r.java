package B3;

/* JADX INFO: loaded from: classes.dex */
public final class r extends D {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final q f461a;

    public r(q qVar) {
        this.f461a = qVar;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof D)) {
            return false;
        }
        return this.f461a.equals(((r) ((D) obj)).f461a);
    }

    public final int hashCode() {
        return this.f461a.hashCode() ^ 1000003;
    }

    public final String toString() {
        return "ExternalPrivacyContext{prequest=" + this.f461a + "}";
    }
}
