package B3;

/* JADX INFO: renamed from: B3.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0059j implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0059j f433a = new C0059j();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f434b = p172w5.c.b("requestTimeMs");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f435c = p172w5.c.b("requestUptimeMs");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final p172w5.c f436d = p172w5.c.b("clientInfo");

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final p172w5.c f437e = p172w5.c.b("logSource");

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final p172w5.c f438f = p172w5.c.b("logSourceName");

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final p172w5.c f439g = p172w5.c.b("logEvent");

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final p172w5.c f440h = p172w5.c.b("qosTier");

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        p172w5.e eVar = (p172w5.e) obj2;
        t tVar = (t) ((F) obj);
        eVar.b(f434b, tVar.f470a);
        eVar.b(f435c, tVar.f471b);
        eVar.e(f436d, tVar.f472c);
        eVar.e(f437e, tVar.f473d);
        eVar.e(f438f, tVar.f474e);
        eVar.e(f439g, tVar.f475f);
        eVar.e(f440h, J.f395t);
    }
}
