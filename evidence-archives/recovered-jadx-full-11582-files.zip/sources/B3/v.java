package B3;

/* JADX INFO: loaded from: classes.dex */
public final class v extends I {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final H f477a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final G f478b;

    public v(H h9, G g2) {
        this.f477a = h9;
        this.f478b = g2;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof I) {
            I i = (I) obj;
            H h9 = this.f477a;
            if (h9 != null ? h9.equals(((v) i).f477a) : ((v) i).f477a == null) {
                G g2 = this.f478b;
                if (g2 != null ? g2.equals(((v) i).f478b) : ((v) i).f478b == null) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        H h9 = this.f477a;
        int iHashCode = ((h9 == null ? 0 : h9.hashCode()) ^ 1000003) * 1000003;
        G g2 = this.f478b;
        return (g2 != null ? g2.hashCode() : 0) ^ iHashCode;
    }

    public final String toString() {
        return "NetworkConnectionInfo{networkType=" + this.f477a + ", mobileSubtype=" + this.f478b + "}";
    }
}
