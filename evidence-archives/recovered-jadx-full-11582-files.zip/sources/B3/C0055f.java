package B3;

/* JADX INFO: renamed from: B3.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0055f implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0055f f417a = new C0055f();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f418b = p172w5.c.b("clearBlob");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f419c = p172w5.c.b("encryptedBlob");

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        p172w5.e eVar = (p172w5.e) obj2;
        p pVar = (p) ((B) obj);
        eVar.e(f418b, pVar.f458a);
        eVar.e(f419c, pVar.f459b);
    }
}
