package B3;

/* JADX INFO: loaded from: classes.dex */
public final class q extends C {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Integer f460a;

    public q(Integer num) {
        this.f460a = num;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C)) {
            return false;
        }
        Integer num = this.f460a;
        q qVar = (q) ((C) obj);
        if (num == null) {
            return qVar.f460a == null;
        }
        return num.equals(qVar.f460a);
    }

    public final int hashCode() {
        Integer num = this.f460a;
        return (num == null ? 0 : num.hashCode()) ^ 1000003;
    }

    public final String toString() {
        return "ExternalPRequestContext{originAssociatedProductId=" + this.f460a + "}";
    }
}
