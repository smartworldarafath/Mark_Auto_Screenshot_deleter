package B3;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class t extends F {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f470a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f471b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final n f472c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Integer f473d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f474e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ArrayList f475f;

    public t(long j9, long j10, n nVar, Integer num, String str, ArrayList arrayList) {
        J j11 = J.f395t;
        this.f470a = j9;
        this.f471b = j10;
        this.f472c = nVar;
        this.f473d = num;
        this.f474e = str;
        this.f475f = arrayList;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof F)) {
            return false;
        }
        t tVar = (t) ((F) obj);
        if (this.f470a != tVar.f470a) {
            return false;
        }
        tVar.getClass();
        Object obj2 = J.f395t;
        ArrayList arrayList = tVar.f475f;
        String str = tVar.f474e;
        Integer num = tVar.f473d;
        n nVar = tVar.f472c;
        if (this.f471b != tVar.f471b || !this.f472c.equals(nVar)) {
            return false;
        }
        Integer num2 = this.f473d;
        if (num2 == null) {
            if (num != null) {
                return false;
            }
        } else if (!num2.equals(num)) {
            return false;
        }
        String str2 = this.f474e;
        if (str2 == null) {
            if (str != null) {
                return false;
            }
        } else if (!str2.equals(str)) {
            return false;
        }
        return this.f475f.equals(arrayList) && obj2.equals(obj2);
    }

    public final int hashCode() {
        long j9 = this.f470a;
        long j10 = this.f471b;
        int iHashCode = (((((((int) (j9 ^ (j9 >>> 32))) ^ 1000003) * 1000003) ^ ((int) ((j10 >>> 32) ^ j10))) * 1000003) ^ this.f472c.hashCode()) * 1000003;
        Integer num = this.f473d;
        int iHashCode2 = (iHashCode ^ (num == null ? 0 : num.hashCode())) * 1000003;
        String str = this.f474e;
        return ((((iHashCode2 ^ (str != null ? str.hashCode() : 0)) * 1000003) ^ this.f475f.hashCode()) * 1000003) ^ J.f395t.hashCode();
    }

    public final String toString() {
        return "LogRequest{requestTimeMs=" + this.f470a + ", requestUptimeMs=" + this.f471b + ", clientInfo=" + this.f472c + ", logSource=" + this.f473d + ", logSourceName=" + this.f474e + ", logEvents=" + this.f475f + ", qosTier=" + J.f395t + "}";
    }
}
