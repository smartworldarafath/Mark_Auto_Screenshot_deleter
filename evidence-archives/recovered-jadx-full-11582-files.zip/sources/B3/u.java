package B3;

import android.util.JsonReader;
import android.util.JsonToken;
import java.io.BufferedReader;
import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public final class u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f476a;

    public u(long j9) {
        this.f476a = j9;
    }

    public static u a(BufferedReader bufferedReader) throws IOException {
        JsonReader jsonReader = new JsonReader(bufferedReader);
        try {
            jsonReader.beginObject();
            while (jsonReader.hasNext()) {
                if (jsonReader.nextName().equals("nextRequestWaitMillis")) {
                    if (jsonReader.peek() == JsonToken.STRING) {
                        u uVar = new u(Long.parseLong(jsonReader.nextString()));
                        jsonReader.close();
                        return uVar;
                    }
                    u uVar2 = new u(jsonReader.nextLong());
                    jsonReader.close();
                    return uVar2;
                }
                jsonReader.skipValue();
            }
            throw new IOException("Response is missing nextRequestWaitMillis field.");
        } catch (Throwable th) {
            jsonReader.close();
            throw th;
        }
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        return (obj instanceof u) && this.f476a == ((u) obj).f476a;
    }

    public final int hashCode() {
        long j9 = this.f476a;
        return ((int) ((j9 >>> 32) ^ j9)) ^ 1000003;
    }

    public final String toString() {
        return "LogResponse{nextRequestWaitMillis=" + this.f476a + "}";
    }
}
