package B3;

/* JADX INFO: loaded from: classes.dex */
public final class k implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final k f441a = new k();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f442b = p172w5.c.b("networkType");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f443c = p172w5.c.b("mobileSubtype");

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        p172w5.e eVar = (p172w5.e) obj2;
        v vVar = (v) ((I) obj);
        eVar.e(f442b, vVar.f477a);
        eVar.e(f443c, vVar.f478b);
    }
}
