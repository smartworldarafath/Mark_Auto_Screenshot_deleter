package B3;

/* JADX INFO: renamed from: B3.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0057h implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0057h f422a = new C0057h();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f423b = p172w5.c.b("prequest");

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        ((p172w5.e) obj2).e(f423b, ((r) ((D) obj)).f461a);
    }
}
