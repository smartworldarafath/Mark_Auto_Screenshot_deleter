package B3;

/* JADX INFO: loaded from: classes.dex */
public final class l extends AbstractC0050a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Integer f444a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f445b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f446c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f447d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f448e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f449f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final String f450g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final String f451h;
    public final String i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final String f452j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final String f453k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final String f454l;

    public l(Integer num, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11) {
        this.f444a = num;
        this.f445b = str;
        this.f446c = str2;
        this.f447d = str3;
        this.f448e = str4;
        this.f449f = str5;
        this.f450g = str6;
        this.f451h = str7;
        this.i = str8;
        this.f452j = str9;
        this.f453k = str10;
        this.f454l = str11;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof AbstractC0050a) {
            AbstractC0050a abstractC0050a = (AbstractC0050a) obj;
            Integer num = this.f444a;
            if (num != null ? num.equals(((l) abstractC0050a).f444a) : ((l) abstractC0050a).f444a == null) {
                String str = this.f445b;
                if (str != null ? str.equals(((l) abstractC0050a).f445b) : ((l) abstractC0050a).f445b == null) {
                    String str2 = this.f446c;
                    if (str2 != null ? str2.equals(((l) abstractC0050a).f446c) : ((l) abstractC0050a).f446c == null) {
                        String str3 = this.f447d;
                        if (str3 != null ? str3.equals(((l) abstractC0050a).f447d) : ((l) abstractC0050a).f447d == null) {
                            String str4 = this.f448e;
                            if (str4 != null ? str4.equals(((l) abstractC0050a).f448e) : ((l) abstractC0050a).f448e == null) {
                                String str5 = this.f449f;
                                if (str5 != null ? str5.equals(((l) abstractC0050a).f449f) : ((l) abstractC0050a).f449f == null) {
                                    String str6 = this.f450g;
                                    if (str6 != null ? str6.equals(((l) abstractC0050a).f450g) : ((l) abstractC0050a).f450g == null) {
                                        String str7 = this.f451h;
                                        if (str7 != null ? str7.equals(((l) abstractC0050a).f451h) : ((l) abstractC0050a).f451h == null) {
                                            String str8 = this.i;
                                            if (str8 != null ? str8.equals(((l) abstractC0050a).i) : ((l) abstractC0050a).i == null) {
                                                String str9 = this.f452j;
                                                if (str9 != null ? str9.equals(((l) abstractC0050a).f452j) : ((l) abstractC0050a).f452j == null) {
                                                    String str10 = this.f453k;
                                                    if (str10 != null ? str10.equals(((l) abstractC0050a).f453k) : ((l) abstractC0050a).f453k == null) {
                                                        String str11 = this.f454l;
                                                        if (str11 != null ? str11.equals(((l) abstractC0050a).f454l) : ((l) abstractC0050a).f454l == null) {
                                                            return true;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        Integer num = this.f444a;
        int iHashCode = ((num == null ? 0 : num.hashCode()) ^ 1000003) * 1000003;
        String str = this.f445b;
        int iHashCode2 = (iHashCode ^ (str == null ? 0 : str.hashCode())) * 1000003;
        String str2 = this.f446c;
        int iHashCode3 = (iHashCode2 ^ (str2 == null ? 0 : str2.hashCode())) * 1000003;
        String str3 = this.f447d;
        int iHashCode4 = (iHashCode3 ^ (str3 == null ? 0 : str3.hashCode())) * 1000003;
        String str4 = this.f448e;
        int iHashCode5 = (iHashCode4 ^ (str4 == null ? 0 : str4.hashCode())) * 1000003;
        String str5 = this.f449f;
        int iHashCode6 = (iHashCode5 ^ (str5 == null ? 0 : str5.hashCode())) * 1000003;
        String str6 = this.f450g;
        int iHashCode7 = (iHashCode6 ^ (str6 == null ? 0 : str6.hashCode())) * 1000003;
        String str7 = this.f451h;
        int iHashCode8 = (iHashCode7 ^ (str7 == null ? 0 : str7.hashCode())) * 1000003;
        String str8 = this.i;
        int iHashCode9 = (iHashCode8 ^ (str8 == null ? 0 : str8.hashCode())) * 1000003;
        String str9 = this.f452j;
        int iHashCode10 = (iHashCode9 ^ (str9 == null ? 0 : str9.hashCode())) * 1000003;
        String str10 = this.f453k;
        int iHashCode11 = (iHashCode10 ^ (str10 == null ? 0 : str10.hashCode())) * 1000003;
        String str11 = this.f454l;
        return (str11 != null ? str11.hashCode() : 0) ^ iHashCode11;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("AndroidClientInfo{sdkVersion=");
        sb.append(this.f444a);
        sb.append(", model=");
        sb.append(this.f445b);
        sb.append(", hardware=");
        sb.append(this.f446c);
        sb.append(", device=");
        sb.append(this.f447d);
        sb.append(", product=");
        sb.append(this.f448e);
        sb.append(", osBuild=");
        sb.append(this.f449f);
        sb.append(", manufacturer=");
        sb.append(this.f450g);
        sb.append(", fingerprint=");
        sb.append(this.f451h);
        sb.append(", locale=");
        sb.append(this.i);
        sb.append(", country=");
        sb.append(this.f452j);
        sb.append(", mccMnc=");
        sb.append(this.f453k);
        sb.append(", applicationBuild=");
        return X3.b.m(sb, this.f454l, "}");
    }
}
