package B3;

/* JADX INFO: renamed from: B3.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0056g implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0056g f420a = new C0056g();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f421b = p172w5.c.b("originAssociatedProductId");

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        ((p172w5.e) obj2).e(f421b, ((q) ((C) obj)).f460a);
    }
}
