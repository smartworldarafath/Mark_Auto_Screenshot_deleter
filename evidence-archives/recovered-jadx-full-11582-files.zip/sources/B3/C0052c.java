package B3;

/* JADX INFO: renamed from: B3.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0052c implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0052c f409a = new C0052c();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f410b = p172w5.c.b("logRequest");

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        ((p172w5.e) obj2).e(f410b, ((m) ((w) obj)).f455a);
    }
}
