package B3;

/* JADX INFO: renamed from: B3.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0058i implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0058i f424a = new C0058i();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f425b = p172w5.c.b("eventTimeMs");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f426c = p172w5.c.b("eventCode");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final p172w5.c f427d = p172w5.c.b("complianceData");

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final p172w5.c f428e = p172w5.c.b("eventUptimeMs");

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final p172w5.c f429f = p172w5.c.b("sourceExtension");

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final p172w5.c f430g = p172w5.c.b("sourceExtensionJsonProto3");

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final p172w5.c f431h = p172w5.c.b("timezoneOffsetSeconds");
    public static final p172w5.c i = p172w5.c.b("networkConnectionInfo");

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final p172w5.c f432j = p172w5.c.b("experimentIds");

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        p172w5.e eVar = (p172w5.e) obj2;
        s sVar = (s) ((E) obj);
        eVar.b(f425b, sVar.f462a);
        eVar.e(f426c, sVar.f463b);
        eVar.e(f427d, sVar.f464c);
        eVar.b(f428e, sVar.f465d);
        eVar.e(f429f, sVar.f466e);
        eVar.e(f430g, sVar.f467f);
        eVar.b(f431h, sVar.f468g);
        eVar.e(i, sVar.f469h);
        eVar.e(f432j, sVar.i);
    }
}
