package B3;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class s extends E {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f462a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Integer f463b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final A f464c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f465d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final byte[] f466e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f467f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final long f468g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final I f469h;
    public final B i;

    public s(long j9, Integer num, A a9, long j10, byte[] bArr, String str, long j11, I i, B b9) {
        this.f462a = j9;
        this.f463b = num;
        this.f464c = a9;
        this.f465d = j10;
        this.f466e = bArr;
        this.f467f = str;
        this.f468g = j11;
        this.f469h = i;
        this.i = b9;
    }

    public final boolean equals(Object obj) {
        Integer num;
        A a9;
        String str;
        I i;
        B b9;
        if (obj == this) {
            return true;
        }
        if (obj instanceof E) {
            E e4 = (E) obj;
            if (this.f462a == ((s) e4).f462a && ((num = this.f463b) != null ? num.equals(((s) e4).f463b) : ((s) e4).f463b == null) && ((a9 = this.f464c) != null ? a9.equals(((s) e4).f464c) : ((s) e4).f464c == null)) {
                s sVar = (s) e4;
                B b10 = sVar.i;
                I i4 = sVar.f469h;
                String str2 = sVar.f467f;
                if (this.f465d == sVar.f465d) {
                    if (Arrays.equals(this.f466e, e4 instanceof s ? ((s) e4).f466e : sVar.f466e) && ((str = this.f467f) != null ? str.equals(str2) : str2 == null) && this.f468g == sVar.f468g && ((i = this.f469h) != null ? i.equals(i4) : i4 == null) && ((b9 = this.i) != null ? b9.equals(b10) : b10 == null)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        long j9 = this.f462a;
        int i = (((int) (j9 ^ (j9 >>> 32))) ^ 1000003) * 1000003;
        Integer num = this.f463b;
        int iHashCode = (i ^ (num == null ? 0 : num.hashCode())) * 1000003;
        A a9 = this.f464c;
        int iHashCode2 = (iHashCode ^ (a9 == null ? 0 : a9.hashCode())) * 1000003;
        long j10 = this.f465d;
        int iHashCode3 = (((iHashCode2 ^ ((int) (j10 ^ (j10 >>> 32)))) * 1000003) ^ Arrays.hashCode(this.f466e)) * 1000003;
        String str = this.f467f;
        int iHashCode4 = (iHashCode3 ^ (str == null ? 0 : str.hashCode())) * 1000003;
        long j11 = this.f468g;
        int i4 = (iHashCode4 ^ ((int) (j11 ^ (j11 >>> 32)))) * 1000003;
        I i9 = this.f469h;
        int iHashCode5 = (i4 ^ (i9 == null ? 0 : i9.hashCode())) * 1000003;
        B b9 = this.i;
        return iHashCode5 ^ (b9 != null ? b9.hashCode() : 0);
    }

    public final String toString() {
        return "LogEvent{eventTimeMs=" + this.f462a + ", eventCode=" + this.f463b + ", complianceData=" + this.f464c + ", eventUptimeMs=" + this.f465d + ", sourceExtension=" + Arrays.toString(this.f466e) + ", sourceExtensionJsonProto3=" + this.f467f + ", timezoneOffsetSeconds=" + this.f468g + ", networkConnectionInfo=" + this.f469h + ", experimentIds=" + this.i + "}";
    }
}
