package B3;

/* JADX INFO: renamed from: B3.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0051b implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0051b f397a = new C0051b();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f398b = p172w5.c.b("sdkVersion");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f399c = p172w5.c.b("model");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final p172w5.c f400d = p172w5.c.b("hardware");

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final p172w5.c f401e = p172w5.c.b("device");

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final p172w5.c f402f = p172w5.c.b("product");

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final p172w5.c f403g = p172w5.c.b("osBuild");

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final p172w5.c f404h = p172w5.c.b("manufacturer");
    public static final p172w5.c i = p172w5.c.b("fingerprint");

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final p172w5.c f405j = p172w5.c.b("locale");

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final p172w5.c f406k = p172w5.c.b("country");

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final p172w5.c f407l = p172w5.c.b("mccMnc");

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final p172w5.c f408m = p172w5.c.b("applicationBuild");

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        p172w5.e eVar = (p172w5.e) obj2;
        l lVar = (l) ((AbstractC0050a) obj);
        eVar.e(f398b, lVar.f444a);
        eVar.e(f399c, lVar.f445b);
        eVar.e(f400d, lVar.f446c);
        eVar.e(f401e, lVar.f447d);
        eVar.e(f402f, lVar.f448e);
        eVar.e(f403g, lVar.f449f);
        eVar.e(f404h, lVar.f450g);
        eVar.e(i, lVar.f451h);
        eVar.e(f405j, lVar.i);
        eVar.e(f406k, lVar.f452j);
        eVar.e(f407l, lVar.f453k);
        eVar.e(f408m, lVar.f454l);
    }
}
