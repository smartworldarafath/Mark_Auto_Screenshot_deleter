package B3;

/* JADX INFO: renamed from: B3.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0053d implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0053d f411a = new C0053d();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f412b = p172w5.c.b("clientType");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f413c = p172w5.c.b("androidClientInfo");

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        p172w5.e eVar = (p172w5.e) obj2;
        n nVar = (n) ((y) obj);
        nVar.getClass();
        eVar.e(f412b, x.f479t);
        eVar.e(f413c, nVar.f456a);
    }
}
