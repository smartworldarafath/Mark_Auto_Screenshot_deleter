package B3;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class p extends B {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final byte[] f458a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final byte[] f459b;

    public p(byte[] bArr, byte[] bArr2) {
        this.f458a = bArr;
        this.f459b = bArr2;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof B) {
            B b9 = (B) obj;
            boolean z8 = b9 instanceof p;
            if (Arrays.equals(this.f458a, z8 ? ((p) b9).f458a : ((p) b9).f458a)) {
                if (Arrays.equals(this.f459b, z8 ? ((p) b9).f459b : ((p) b9).f459b)) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((Arrays.hashCode(this.f458a) ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f459b);
    }

    public final String toString() {
        return "ExperimentIds{clearBlob=" + Arrays.toString(this.f458a) + ", encryptedBlob=" + Arrays.toString(this.f459b) + "}";
    }
}
