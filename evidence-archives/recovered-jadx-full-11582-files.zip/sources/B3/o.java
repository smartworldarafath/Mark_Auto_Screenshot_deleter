package B3;

/* JADX INFO: loaded from: classes.dex */
public final class o extends A {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final r f457a;

    public o(r rVar) {
        z zVar = z.f481t;
        this.f457a = rVar;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof A)) {
            return false;
        }
        A a9 = (A) obj;
        if (!this.f457a.equals(((o) a9).f457a)) {
            return false;
        }
        Object obj2 = z.f481t;
        ((o) a9).getClass();
        return obj2.equals(obj2);
    }

    public final int hashCode() {
        return ((this.f457a.hashCode() ^ 1000003) * 1000003) ^ z.f481t.hashCode();
    }

    public final String toString() {
        return "ComplianceData{privacyContext=" + this.f457a + ", productIdOrigin=" + z.f481t + "}";
    }
}
