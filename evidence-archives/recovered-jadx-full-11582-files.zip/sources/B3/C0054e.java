package B3;

/* JADX INFO: renamed from: B3.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0054e implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0054e f414a = new C0054e();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f415b = p172w5.c.b("privacyContext");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f416c = p172w5.c.b("productIdOrigin");

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        p172w5.e eVar = (p172w5.e) obj2;
        eVar.e(f415b, ((o) ((A) obj)).f457a);
        eVar.e(f416c, z.f481t);
    }
}
