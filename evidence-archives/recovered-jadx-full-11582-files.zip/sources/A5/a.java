package A5;

/* JADX INFO: loaded from: classes.dex */
public interface a {
}
