package C;

import D7.AbstractC0094y;
import E.C0120y;
import E.U;
import J0.X;
import J0.Y;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class s implements U {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f664a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f665b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final p095m0.d f666c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final j1.m f667d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f668e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f669f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f670g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long f671h;
    public final Object i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Object f672j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final androidx.compose.foundation.lazy.layout.b f673k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final long f674l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f675m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f676n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f677o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f678p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f679q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f680r = Integer.MIN_VALUE;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f681s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f682t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final int[] f683u;

    public s(int i, List list, p095m0.d dVar, j1.m mVar, int i4, int i9, int i10, long j9, Object obj, Object obj2, androidx.compose.foundation.lazy.layout.b bVar, long j10) {
        this.f664a = i;
        this.f665b = list;
        this.f666c = dVar;
        this.f667d = mVar;
        this.f668e = i4;
        this.f669f = i9;
        this.f670g = i10;
        this.f671h = j9;
        this.i = obj;
        this.f672j = obj2;
        this.f673k = bVar;
        this.f674l = j10;
        int size = list.size();
        int i11 = 0;
        int iMax = 0;
        for (int i12 = 0; i12 < size; i12++) {
            Y y8 = (Y) list.get(i12);
            i11 += y8.f5564u;
            iMax = Math.max(iMax, y8.f5563t);
        }
        this.f676n = i11;
        int i13 = i11 + this.f670g;
        this.f677o = i13 >= 0 ? i13 : 0;
        this.f678p = iMax;
        this.f683u = new int[this.f665b.size() * 2];
    }

    public final void a(X x, boolean z8) {
        if (this.f680r == Integer.MIN_VALUE) {
            p191z.a.a("position() should be called first");
        }
        List list = this.f665b;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            Y y8 = (Y) list.get(i);
            int i4 = this.f681s - y8.f5564u;
            int i9 = this.f682t;
            long jI = i(i);
            E.C cA = this.f673k.a(i, this.i);
            p167w0.b bVar = null;
            if (cA != null) {
                if (z8) {
                    cA.f1234r = jI;
                } else {
                    if (!j1.j.b(cA.f1234r, E.C.f1216s)) {
                        jI = cA.f1234r;
                    }
                    long jD = j1.j.d(jI, ((j1.j) cA.f1233q.getValue()).f27647a);
                    int i10 = (int) (jI & 4294967295L);
                    if (((i10 <= i4 && ((int) (jD & 4294967295L)) <= i4) || (i10 >= i9 && ((int) (jD & 4294967295L)) >= i9)) && ((Boolean) cA.f1225h.getValue()).booleanValue()) {
                        AbstractC0094y.x(cA.f1218a, null, null, new C0120y(cA, null), 3);
                    }
                    jI = jD;
                }
                bVar = cA.f1230n;
            }
            long jD2 = j1.j.d(jI, this.f671h);
            if (!z8 && cA != null) {
                cA.f1229m = jD2;
            }
            if (bVar != null) {
                x.getClass();
                X.b(x, y8);
                y8.h0(j1.j.d(jD2, y8.x), 0.0f, bVar);
            } else {
                X.t(x, y8, jD2);
            }
        }
    }

    @Override // E.U
    public final int b() {
        return this.f665b.size();
    }

    @Override // E.U
    public final int c() {
        return this.f677o;
    }

    @Override // E.U
    public final int d() {
        return 1;
    }

    @Override // E.U
    public final Object e(int i) {
        return ((Y) this.f665b.get(i)).G();
    }

    @Override // E.U
    public final long f() {
        return this.f674l;
    }

    @Override // E.U
    public final boolean g() {
        return true;
    }

    @Override // E.U
    public final int getIndex() {
        return this.f664a;
    }

    @Override // E.U
    public final Object getKey() {
        return this.i;
    }

    @Override // E.U
    public final void h() {
        this.f679q = true;
    }

    @Override // E.U
    public final long i(int i) {
        int i4;
        long j9;
        if (i == 0 && this.f665b.size() == 0) {
            i4 = this.f675m;
            j9 = 0;
        } else {
            int i9 = i * 2;
            int[] iArr = this.f683u;
            int i10 = iArr[i9];
            i4 = iArr[i9 + 1];
            j9 = i10;
        }
        return (4294967295L & ((long) i4)) | (j9 << 32);
    }

    @Override // E.U
    public final int j() {
        return 0;
    }

    @Override // E.U
    public final void k(int i, int i4, int i9, int i10) {
        l(i, i9, i10);
    }

    public final void l(int i, int i4, int i9) {
        this.f675m = i;
        this.f680r = i9;
        List list = this.f665b;
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            Y y8 = (Y) list.get(i10);
            int i11 = i10 * 2;
            p095m0.d dVar = this.f666c;
            if (dVar == null) {
                p191z.a.b("null horizontalAlignment when isVertical == true");
                throw new A2.c();
            }
            int iA = dVar.a(y8.f5563t, i4, this.f667d);
            int[] iArr = this.f683u;
            iArr[i11] = iA;
            iArr[i11 + 1] = i;
            i += y8.f5564u;
        }
        this.f681s = -this.f668e;
        this.f682t = this.f680r + this.f669f;
    }
}
