package C;

import E.I;

/* JADX INFO: loaded from: classes.dex */
public final class g extends I {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final D4.f f597c = new D4.f(1, (byte) 0);

    public g(p137r7.c cVar) {
        cVar.g(this);
    }

    @Override // E.I
    public final D4.f k() {
        return this.f597c;
    }
}
