package C;

import p166w.C0;

/* JADX INFO: loaded from: classes.dex */
public final class y implements p095m0.p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f697a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C0 f698b;

    public /* synthetic */ y(C0 c9, int i) {
        this.f697a = i;
        this.f698b = c9;
    }
}
