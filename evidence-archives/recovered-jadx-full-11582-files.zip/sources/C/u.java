package C;

import E4.AbstractC0253w;
import p166w.F0;
import p166w.I0;
import p166w.InterfaceC5999l0;
import u.m0;

/* JADX INFO: loaded from: classes.dex */
public final class u implements InterfaceC5999l0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f690a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f691b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f692c;

    public /* synthetic */ u(int i, Object obj, Object obj2) {
        this.f690a = i;
        this.f692c = obj2;
        this.f691b = obj;
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [java.lang.Object, java.util.List] */
    /* JADX WARN: Type inference failed for: r5v6, types: [java.lang.Object, java.util.Collection, java.util.List] */
    public static int b(u uVar) {
        Object obj;
        r rVarG = ((B) uVar.f692c).g();
        if (!rVarG.f657k.isEmpty()) {
            int iC = uVar.c();
            if (uVar.d() < 0 || iC > 0) {
                return ((0 - uVar.c()) * AbstractC0253w.a(rVarG)) - ((B) uVar.f692c).f558e.f686c.h();
            }
            ?? r8 = rVarG.f657k;
            int size = r8.size();
            int i = 0;
            while (true) {
                if (i >= size) {
                    obj = null;
                    break;
                }
                obj = r8.get(i);
                if (((s) obj).f664a == 0) {
                    break;
                }
                i++;
            }
            s sVar = (s) obj;
            if (sVar != null) {
                return sVar.f675m;
            }
        }
        return 0;
    }

    @Override // p166w.InterfaceC5999l0
    public final float a(float f4) {
        switch (this.f690a) {
            case 0:
                return ((InterfaceC5999l0) this.f691b).a(f4);
            default:
                I0 i4 = (I0) this.f691b;
                boolean zBooleanValue = ((Boolean) i4.f32021h.a()).booleanValue();
                if (Math.abs(f4) == 0.0f || zBooleanValue) {
                    return i4.d(i4.g(((F0) this.f692c).a(2, i4.e(i4.h(f4)))));
                }
                throw new m0("The fling animation was cancelled", 2);
        }
    }

    public int c() {
        return ((B) this.f692c).f558e.f685b.h();
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Object, java.util.List] */
    public int d() {
        s sVar = (s) p040e7.l.C(((B) this.f692c).g().f657k);
        if (sVar != null) {
            return sVar.f664a;
        }
        return 0;
    }
}
