package C;

import p001a0.C1316e0;

/* JADX INFO: renamed from: C.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0062c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public C1316e0 f590a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public C1316e0 f591b;
}
