package C;

import E.X;
import p001a0.C1316e0;

/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f684a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C1316e0 f685b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C1316e0 f686c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f687d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f688e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final X f689f;

    public t(int i, int i4, int i9) {
        this.f684a = i9;
        switch (i9) {
            case 1:
                this.f685b = new C1316e0(i);
                this.f686c = new C1316e0(i4);
                this.f689f = new X(i, 90, 200);
                break;
            default:
                this.f685b = new C1316e0(i);
                this.f686c = new C1316e0(i4);
                this.f689f = new X(i, 30, 100);
                break;
        }
    }

    public final void a(int i, int i4) {
        switch (this.f684a) {
            case 0:
                if (i < 0.0f) {
                    p191z.a.a("Index should be non-negative (" + i + ')');
                }
                this.f685b.i(i);
                this.f689f.b(i);
                this.f686c.i(i4);
                break;
            default:
                if (i < 0.0f) {
                    p191z.a.a("Index should be non-negative");
                }
                this.f685b.i(i);
                this.f689f.b(i);
                this.f686c.i(i4);
                break;
        }
    }
}
