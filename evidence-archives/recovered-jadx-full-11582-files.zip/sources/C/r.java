package C;

import D7.InterfaceC0091v;
import J0.N;
import java.util.List;
import java.util.Map;
import p166w.EnumC5991h0;

/* JADX INFO: loaded from: classes.dex */
public final class r implements N {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final s f648a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f649b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f650c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f651d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final N f652e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final float f653f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f654g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final InterfaceC0091v f655h;
    public final j1.c i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final long f656j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Object f657k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final int f658l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f659m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f660n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final EnumC5991h0 f661o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f662p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f663q;

    public r(s sVar, int i, boolean z8, float f4, N n8, float f9, boolean z9, InterfaceC0091v interfaceC0091v, j1.c cVar, long j9, List list, int i4, int i9, int i10, EnumC5991h0 enumC5991h0, int i11, int i12) {
        this.f648a = sVar;
        this.f649b = i;
        this.f650c = z8;
        this.f651d = f4;
        this.f652e = n8;
        this.f653f = f9;
        this.f654g = z9;
        this.f655h = interfaceC0091v;
        this.i = cVar;
        this.f656j = j9;
        this.f657k = list;
        this.f658l = i4;
        this.f659m = i9;
        this.f660n = i10;
        this.f661o = enumC5991h0;
        this.f662p = i11;
        this.f663q = i12;
    }

    /* JADX WARN: Type inference failed for: r15v0, types: [java.lang.Object, java.util.Collection, java.util.List] */
    public final r a(int i, boolean z8) {
        s sVar;
        if (this.f654g) {
            return null;
        }
        ?? r15 = this.f657k;
        if (r15.isEmpty() || (sVar = this.f648a) == null) {
            return null;
        }
        int i4 = sVar.f677o;
        int i9 = this.f649b - i;
        if (i9 < 0 || i9 >= i4) {
            return null;
        }
        s sVar2 = (s) p040e7.l.v(r15);
        s sVar3 = (s) p040e7.l.B(r15);
        if (sVar2.f679q || sVar3.f679q) {
            return null;
        }
        int i10 = this.f659m;
        int i11 = this.f658l;
        if (i < 0) {
            if (Math.min((sVar2.f675m + sVar2.f677o) - i11, (sVar3.f675m + sVar3.f677o) - i10) <= (-i)) {
                return null;
            }
        } else if (Math.min(i11 - sVar2.f675m, i10 - sVar3.f675m) <= i) {
            return null;
        }
        int size = r15.size();
        for (int i12 = 0; i12 < size; i12++) {
            s sVar4 = (s) r15.get(i12);
            sVar4.getClass();
            int[] iArr = sVar4.f683u;
            if (!sVar4.f679q) {
                sVar4.f675m += i;
                int length = iArr.length;
                for (int i13 = 0; i13 < length; i13++) {
                    if ((i13 & 1) != 0) {
                        iArr[i13] = iArr[i13] + i;
                    }
                }
                if (z8) {
                    int size2 = sVar4.f665b.size();
                    for (int i14 = 0; i14 < size2; i14++) {
                        E.C cA = sVar4.f673k.a(i14, sVar4.i);
                        if (cA != null) {
                            long j9 = cA.f1228l;
                            cA.f1228l = (((long) ((int) (j9 >> 32))) << 32) | (((long) (((int) (j9 & 4294967295L)) + i)) & 4294967295L);
                        }
                    }
                }
            }
        }
        return new r(this.f648a, i9, this.f650c || i > 0, i, this.f652e, this.f653f, this.f654g, this.f655h, this.i, this.f656j, r15, this.f658l, this.f659m, this.f660n, this.f661o, this.f662p, this.f663q);
    }

    @Override // J0.N
    public final Map b() {
        return this.f652e.b();
    }

    @Override // J0.N
    public final void c() {
        this.f652e.c();
    }

    @Override // J0.N
    public final p137r7.c d() {
        return this.f652e.d();
    }

    public final long e() {
        N n8 = this.f652e;
        return (((long) n8.getWidth()) << 32) | (((long) n8.getHeight()) & 4294967295L);
    }

    @Override // J0.N
    public final int getHeight() {
        return this.f652e.getHeight();
    }

    @Override // J0.N
    public final int getWidth() {
        return this.f652e.getWidth();
    }
}
