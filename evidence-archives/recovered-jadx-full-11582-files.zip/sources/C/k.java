package C;

import E.P;
import E4.B3;
import J0.InterfaceC0898v;
import com.google.android.gms.internal.ads.V7;
import java.util.List;
import p001a0.Z;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class k implements p137r7.a {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f609t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Z f610u;

    public /* synthetic */ k(Z z8, int i) {
        this.f609t = i;
        this.f610u = z8;
    }

    @Override // p137r7.a
    public final Object a() {
        switch (this.f609t) {
            case 0:
                return new g((p137r7.c) this.f610u.getValue());
            case 1:
                return new D.h((p137r7.c) this.f610u.getValue());
            case 2:
                return (P) ((p137r7.a) this.f610u.getValue()).a();
            case 3:
                Z z8 = this.f610u;
                z8.setValue(Boolean.valueOf(!((Boolean) z8.getValue()).booleanValue()));
                return p032d7.z.f26831a;
            case 4:
                Z z9 = this.f610u;
                if (z9 != null) {
                    return (List) z9.getValue();
                }
                return null;
            case 5:
                Boolean bool = (Boolean) this.f610u.getValue();
                bool.booleanValue();
                return bool;
            case 6:
                this.f610u.setValue(Boolean.FALSE);
                return p032d7.z.f26831a;
            case 7:
                this.f610u.setValue(null);
                return p032d7.z.f26831a;
            case 8:
                this.f610u.setValue(Boolean.FALSE);
                return p032d7.z.f26831a;
            case 9:
                B3.g(this.f610u, true);
                return p032d7.z.f26831a;
            case 10:
                B3.g(this.f610u, false);
                return p032d7.z.f26831a;
            case 11:
                this.f610u.setValue(Boolean.TRUE);
                p122p6.b.c("screenshot_details_viewed_bottom_sheet", p040e7.u.f26996t);
                return p032d7.z.f26831a;
            case 12:
                this.f610u.setValue(Boolean.FALSE);
                return p032d7.z.f26831a;
            case 13:
                this.f610u.setValue(Boolean.FALSE);
                return p032d7.z.f26831a;
            case 14:
                this.f610u.setValue(Boolean.FALSE);
                return p032d7.z.f26831a;
            case 15:
                this.f610u.setValue(Boolean.TRUE);
                p122p6.b.c("easter_egg_game_opened", p040e7.u.f26996t);
                return p032d7.z.f26831a;
            case 16:
                this.f610u.setValue(null);
                return p032d7.z.f26831a;
            case 17:
                this.f610u.setValue(null);
                return p032d7.z.f26831a;
            case 18:
                InterfaceC0898v interfaceC0898v = (InterfaceC0898v) this.f610u.getValue();
                if (interfaceC0898v != null) {
                    return interfaceC0898v;
                }
                p191z.a.d("Required value was null.");
                throw new A2.c();
            case 19:
                InterfaceC0898v interfaceC0898v2 = (InterfaceC0898v) this.f610u.getValue();
                if (interfaceC0898v2 != null) {
                    return interfaceC0898v2;
                }
                p191z.a.d("Required value was null.");
                throw new A2.c();
            case 20:
                this.f610u.setValue(Boolean.FALSE);
                return p032d7.z.f26831a;
            case V7.zzm /* 21 */:
                this.f610u.setValue(Boolean.TRUE);
                return p032d7.z.f26831a;
            case 22:
                InterfaceC0898v interfaceC0898v3 = (InterfaceC0898v) this.f610u.getValue();
                if (interfaceC0898v3 != null) {
                    return interfaceC0898v3;
                }
                p191z.a.d("Required value was null.");
                throw new A2.c();
            case 23:
                return (W.f) this.f610u.getValue();
            default:
                this.f610u.setValue(Boolean.TRUE);
                return p032d7.z.f26831a;
        }
    }
}
