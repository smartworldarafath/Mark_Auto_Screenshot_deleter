package C;

import I.L;

/* JADX INFO: loaded from: classes.dex */
public final class f implements E.r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final L f594a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final I6.m f595b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final p063i0.d f596c;

    public f(L l8, I6.m mVar, p063i0.d dVar) {
        this.f594a = l8;
        this.f595b = mVar;
        this.f596c = dVar;
    }

    @Override // E.r
    public final p137r7.c getKey() {
        return this.f594a;
    }

    @Override // E.r
    public final p137r7.c getType() {
        return this.f595b;
    }
}
