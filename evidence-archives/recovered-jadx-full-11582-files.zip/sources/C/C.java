package C;

import J0.N;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class C implements N {
    @Override // J0.N
    public final Map b() {
        return p040e7.u.f26996t;
    }

    @Override // J0.N
    public final void c() {
    }

    @Override // J0.N
    public final int getHeight() {
        return 0;
    }

    @Override // J0.N
    public final int getWidth() {
        return 0;
    }
}
