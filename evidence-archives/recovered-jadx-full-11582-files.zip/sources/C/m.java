package C;

import p001a0.W0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class m extends p146s7.p implements p190y7.d, p137r7.a {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final /* synthetic */ int f615A;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ m(int i, int i4, Class cls, Object obj, String str, String str2) {
        super(obj, cls, str, str2, i);
        this.f615A = i4;
    }

    @Override // p137r7.a
    public final Object a() {
        return h();
    }

    @Override // p146s7.c
    public final p190y7.a b() {
        p146s7.v.f31262a.getClass();
        return this;
    }

    public final Object h() {
        switch (this.f615A) {
            case 0:
                return ((W0) this.f31243u).getValue();
            case 1:
                return ((W0) this.f31243u).getValue();
            case 2:
                return this.f31243u.getClass().getSimpleName();
            default:
                return ((W0) this.f31243u).getValue();
        }
    }
}
