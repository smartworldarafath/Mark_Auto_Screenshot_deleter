package B1;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class a extends ClickableSpan {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f375t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final g f376u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int f377v;

    public a(int i, g gVar, int i4) {
        this.f375t = i;
        this.f376u = gVar;
        this.f377v = i4;
    }

    @Override // android.text.style.ClickableSpan
    public final void onClick(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.f375t);
        this.f376u.f387a.performAction(this.f377v, bundle);
    }
}
