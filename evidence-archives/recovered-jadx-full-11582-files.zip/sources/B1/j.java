package B1;

import E4.AbstractC0212p;

/* JADX INFO: loaded from: classes.dex */
public abstract class j extends AbstractC0212p {
}
