package B1;

import E4.AbstractC0212p;

/* JADX INFO: loaded from: classes.dex */
public abstract class k extends AbstractC0212p {
}
