package B0;

/* JADX INFO: loaded from: classes.dex */
public interface a {
    void a(int i);
}
