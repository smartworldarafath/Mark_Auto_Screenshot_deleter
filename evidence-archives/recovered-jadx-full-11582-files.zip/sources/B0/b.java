package B0;

import M0.C1076x;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class b implements a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f373a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final View f374b;

    public /* synthetic */ b(View view, int i) {
        this.f373a = i;
        this.f374b = view;
    }

    @Override // B0.a
    public final void a(int i) {
        switch (this.f373a) {
            case 0:
                C1076x c1076x = (C1076x) this.f374b;
                if (i == 16) {
                    c1076x.performHapticFeedback(16);
                } else if (i == 6) {
                    c1076x.performHapticFeedback(6);
                } else if (i == 13) {
                    c1076x.performHapticFeedback(13);
                } else if (i == 23) {
                    c1076x.performHapticFeedback(23);
                } else if (i == 3) {
                    c1076x.performHapticFeedback(3);
                } else if (i == 0) {
                    c1076x.performHapticFeedback(0);
                } else if (i == 17) {
                    c1076x.performHapticFeedback(17);
                } else if (i == 27) {
                    c1076x.performHapticFeedback(27);
                } else if (i == 26) {
                    c1076x.performHapticFeedback(26);
                } else if (i == 9) {
                    c1076x.performHapticFeedback(9);
                } else if (i == 22) {
                    c1076x.performHapticFeedback(22);
                } else if (i == 21) {
                    c1076x.performHapticFeedback(21);
                } else if (i == 1) {
                    c1076x.performHapticFeedback(1);
                }
                break;
            default:
                View view = this.f374b;
                if (i == 16) {
                    view.performHapticFeedback(16);
                } else if (i == 6) {
                    view.performHapticFeedback(6);
                } else if (i == 13) {
                    view.performHapticFeedback(13);
                } else if (i == 23) {
                    view.performHapticFeedback(23);
                } else if (i == 3) {
                    view.performHapticFeedback(3);
                } else if (i == 0) {
                    view.performHapticFeedback(0);
                } else if (i == 17) {
                    view.performHapticFeedback(17);
                } else if (i == 27) {
                    view.performHapticFeedback(27);
                } else if (i == 26) {
                    view.performHapticFeedback(26);
                } else if (i == 9) {
                    view.performHapticFeedback(9);
                } else if (i == 22) {
                    view.performHapticFeedback(22);
                } else if (i == 21) {
                    view.performHapticFeedback(21);
                } else if (i == 1) {
                    view.performHapticFeedback(1);
                }
                break;
        }
    }
}
