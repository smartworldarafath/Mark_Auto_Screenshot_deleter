package a8;

import F4.B4;
import V2.n;
import V7.p;
import i8.B;
import i8.InterfaceC5740i;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public final class f extends n {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final String f12851t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final long f12852u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final B f12853v;

    public f(String str, long j9, B b9) {
        this.f12851t = str;
        this.f12852u = j9;
        this.f12853v = b9;
    }

    @Override // V2.n
    public final long c() {
        return this.f12852u;
    }

    @Override // V2.n
    public final p f() {
        String str = this.f12851t;
        if (str == null) {
            return null;
        }
        Pattern pattern = p.f10240b;
        try {
            return B4.a(str);
        } catch (IllegalArgumentException unused) {
            return null;
        }
    }

    @Override // V2.n
    public final InterfaceC5740i n() {
        return this.f12853v;
    }
}
