package B4;

import O4.h;
import S4.j;
import android.app.PendingIntent;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.measurement.AbstractC5061q1;
import com.google.android.gms.internal.play_billing.AbstractC5624d;
import p170w3.n;

/* JADX INFO: loaded from: classes.dex */
public abstract class b extends Binder implements IInterface {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f486t;

    @Override // android.os.IInterface
    public IBinder asBinder() {
        int i = this.f486t;
        return this;
    }

    public abstract boolean e1(int i, Parcel parcel, Parcel parcel2);

    public boolean f1(int i, Parcel parcel, Parcel parcel2) {
        return false;
    }

    @Override // android.os.Binder
    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i4) {
        int i9 = 0;
        switch (this.f486t) {
            case 0:
                if (i <= 16777215) {
                    parcel.enforceInterface(getInterfaceDescriptor());
                } else if (super.onTransact(i, parcel, parcel2, i4)) {
                    return true;
                }
                return e1(i, parcel, parcel2);
            case 1:
                if (i <= 16777215) {
                    parcel.enforceInterface(getInterfaceDescriptor());
                } else if (super.onTransact(i, parcel, parcel2, i4)) {
                    return true;
                }
                return f1(i, parcel, parcel2);
            case 2:
            default:
                return super.onTransact(i, parcel, parcel2, i4);
            case 3:
                if (i > 16777215) {
                    if (!super.onTransact(i, parcel, parcel2, i4)) {
                    }
                    return true;
                }
                parcel.enforceInterface(getInterfaceDescriptor());
                R4.f fVar = (R4.f) this;
                if (i != 2) {
                    return false;
                }
                Parcelable.Creator creator = Bundle.CREATOR;
                int i10 = S4.a.f9173a;
                Bundle bundle = (Bundle) (parcel.readInt() == 0 ? null : (Parcelable) creator.createFromParcel(parcel));
                int iDataAvail = parcel.dataAvail();
                if (iDataAvail > 0) {
                    throw new BadParcelableException(AbstractC5061q1.j(iDataAvail, "Parcel data not fully consumed, unread size: "));
                }
                j jVar = fVar.f8807w.f8809a;
                if (jVar != null) {
                    h hVar = fVar.f8806v;
                    synchronized (jVar.f9191f) {
                        jVar.f9190e.remove(hVar);
                        break;
                    }
                    jVar.a().post(new S4.h(i9, jVar));
                }
                fVar.f8805u.g("onGetLaunchReviewFlowInfo", new Object[0]);
                fVar.f8806v.d(new R4.c((PendingIntent) bundle.get("confirmation_intent"), bundle.getBoolean("is_review_no_op")));
                return true;
            case 4:
                if (i > 16777215) {
                    if (!super.onTransact(i, parcel, parcel2, i4)) {
                    }
                    return true;
                }
                parcel.enforceInterface(getInterfaceDescriptor());
                n nVar = (n) this;
                if (i != 1) {
                    return false;
                }
                int i11 = parcel.readInt();
                int i12 = AbstractC5624d.f26262a;
                int iDataAvail2 = parcel.dataAvail();
                if (iDataAvail2 > 0) {
                    throw new BadParcelableException(AbstractC5061q1.j(iDataAvail2, "Parcel data not fully consumed, unread size: "));
                }
                nVar.f32448u.a(Integer.valueOf(i11));
                return true;
        }
    }

    public b(String str, int i) {
        this.f486t = i;
        switch (i) {
            case 1:
                attachInterface(this, str);
                break;
            default:
                attachInterface(this, str);
                break;
        }
    }
}
