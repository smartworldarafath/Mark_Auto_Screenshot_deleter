package B4;

import android.os.Build;

/* JADX INFO: loaded from: classes.dex */
public abstract class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int f492a;

    static {
        f492a = Build.VERSION.SDK_INT >= 31 ? 33554432 : 0;
    }
}
