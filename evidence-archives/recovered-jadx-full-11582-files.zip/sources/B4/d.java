package B4;

/* JADX INFO: loaded from: classes.dex */
public abstract class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final p099m4.d f488a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p099m4.d[] f489b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p099m4.d f490c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final p099m4.d[] f491d;

    static {
        p099m4.d dVar = new p099m4.d("CLIENT_TELEMETRY", 1L);
        f488a = dVar;
        f489b = new p099m4.d[]{dVar};
        p099m4.d dVar2 = new p099m4.d("moduleinstall", 7L);
        f490c = dVar2;
        f491d = new p099m4.d[]{dVar2};
    }
}
