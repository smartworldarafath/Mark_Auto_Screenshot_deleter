package A2;

import E4.AbstractC0218q;
import android.content.Context;
import android.os.Bundle;
import android.os.Trace;
import com.markOne.ss_app.R;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static volatile a f292d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Object f293e = new Object();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Context f296c;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashSet f295b = new HashSet();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f294a = new HashMap();

    public a(Context context) {
        this.f296c = context.getApplicationContext();
    }

    public static a c(Context context) {
        if (f292d == null) {
            synchronized (f293e) {
                try {
                    if (f292d == null) {
                        f292d = new a(context);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return f292d;
    }

    public final void a(Bundle bundle) {
        HashSet hashSet;
        String string = this.f296c.getString(R.string.androidx_startup);
        if (bundle != null) {
            try {
                HashSet hashSet2 = new HashSet();
                Iterator<String> it = bundle.keySet().iterator();
                while (true) {
                    boolean zHasNext = it.hasNext();
                    hashSet = this.f295b;
                    if (!zHasNext) {
                        break;
                    }
                    String next = it.next();
                    if (string.equals(bundle.getString(next, null))) {
                        Class<?> cls = Class.forName(next);
                        if (b.class.isAssignableFrom(cls)) {
                            hashSet.add(cls);
                        }
                    }
                }
                Iterator it2 = hashSet.iterator();
                while (it2.hasNext()) {
                    b((Class) it2.next(), hashSet2);
                }
            } catch (ClassNotFoundException e4) {
                throw new c(e4);
            }
        }
    }

    public final Object b(Class cls, HashSet hashSet) {
        Object objCreate;
        HashMap map = this.f294a;
        if (AbstractC0218q.b()) {
            try {
                Trace.beginSection(AbstractC0218q.c(cls.getSimpleName()));
            } catch (Throwable th) {
                Trace.endSection();
                throw th;
            }
        }
        if (hashSet.contains(cls)) {
            throw new IllegalStateException("Cannot initialize " + cls.getName() + ". Cycle detected.");
        }
        if (map.containsKey(cls)) {
            objCreate = map.get(cls);
        } else {
            hashSet.add(cls);
            try {
                b bVar = (b) cls.getDeclaredConstructor(null).newInstance(null);
                List<Class> listA = bVar.a();
                if (!listA.isEmpty()) {
                    for (Class cls2 : listA) {
                        if (!map.containsKey(cls2)) {
                            b(cls2, hashSet);
                        }
                    }
                }
                objCreate = bVar.create(this.f296c);
                hashSet.remove(cls);
                map.put(cls, objCreate);
            } catch (Throwable th2) {
                throw new c(th2);
            }
        }
        Trace.endSection();
        return objCreate;
    }
}
