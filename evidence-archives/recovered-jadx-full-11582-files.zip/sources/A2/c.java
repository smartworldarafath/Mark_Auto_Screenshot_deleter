package A2;

import com.google.android.gms.internal.measurement.AbstractC5061q1;

/* JADX INFO: loaded from: classes.dex */
public class c extends RuntimeException {
    public c() {
        super("An operation is not implemented");
    }

    public c(int i) {
        super(AbstractC5061q1.k(i, "r: ", new StringBuilder(String.valueOf(i).length() + 3)));
    }
}
