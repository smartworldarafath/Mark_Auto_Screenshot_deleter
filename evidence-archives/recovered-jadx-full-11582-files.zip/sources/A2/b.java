package A2;

import android.content.Context;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public interface b {
    List a();

    Object create(Context context);
}
