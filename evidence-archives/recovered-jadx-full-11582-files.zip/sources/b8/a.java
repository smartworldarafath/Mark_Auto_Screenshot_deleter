package b8;

import i8.C5738g;
import i8.H;
import i8.InterfaceC5740i;
import i8.J;
import i8.p;
import java.io.IOException;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
public abstract class a implements H {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final p f13773t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f13774u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ E5.a f13775v;

    public a(E5.a aVar) {
        this.f13775v = aVar;
        this.f13773t = new p(((InterfaceC5740i) aVar.f1897d).a());
    }

    @Override // i8.H
    public long F(long j9, C5738g c5738g) throws IOException {
        E5.a aVar = this.f13775v;
        j.e(c5738g, "sink");
        try {
            return ((InterfaceC5740i) aVar.f1897d).F(j9, c5738g);
        } catch (IOException e4) {
            ((Z7.j) aVar.f1896c).k();
            c();
            throw e4;
        }
    }

    @Override // i8.H
    public final J a() {
        return this.f13773t;
    }

    public final void c() {
        E5.a aVar = this.f13775v;
        int i = aVar.f1894a;
        if (i == 6) {
            return;
        }
        if (i != 5) {
            throw new IllegalStateException("state: " + aVar.f1894a);
        }
        p pVar = this.f13773t;
        J j9 = pVar.f27549e;
        pVar.f27549e = J.f27506d;
        j9.a();
        j9.b();
        aVar.f1894a = 6;
    }
}
