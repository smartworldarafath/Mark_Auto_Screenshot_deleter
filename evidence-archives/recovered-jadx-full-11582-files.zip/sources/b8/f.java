package b8;

import i8.C5738g;
import java.io.IOException;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
public final class f extends a {

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f13786w;

    @Override // b8.a, i8.H
    public final long F(long j9, C5738g c5738g) throws IOException {
        j.e(c5738g, "sink");
        if (j9 < 0) {
            throw new IllegalArgumentException(C3.a.j("byteCount < 0: ", j9).toString());
        }
        if (this.f13774u) {
            throw new IllegalStateException("closed");
        }
        if (this.f13786w) {
            return -1L;
        }
        long jF = super.F(j9, c5738g);
        if (jF != -1) {
            return jF;
        }
        this.f13786w = true;
        c();
        return -1L;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        if (this.f13774u) {
            return;
        }
        if (!this.f13786w) {
            c();
        }
        this.f13774u = true;
    }
}
