package C3;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class h implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final h f722a = new h();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f723b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f724c;

    static {
        p197z5.a aVar = new p197z5.a(1);
        HashMap map = new HashMap();
        map.put(p197z5.c.class, aVar);
        f723b = new p172w5.c("startMs", a.o(map));
        p197z5.a aVar2 = new p197z5.a(2);
        HashMap map2 = new HashMap();
        map2.put(p197z5.c.class, aVar2);
        f724c = new p172w5.c("endMs", a.o(map2));
    }

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        F3.g gVar = (F3.g) obj;
        p172w5.e eVar = (p172w5.e) obj2;
        eVar.b(f723b, gVar.f2115a);
        eVar.b(f724c, gVar.f2116b);
    }
}
