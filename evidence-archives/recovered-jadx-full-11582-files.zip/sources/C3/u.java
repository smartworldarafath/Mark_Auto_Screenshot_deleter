package C3;

import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class u implements p195z3.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Set f762a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final k f763b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final w f764c;

    public u(Set set, k kVar, w wVar) {
        this.f762a = set;
        this.f763b = kVar;
        this.f764c = wVar;
    }

    public final v a(String str, p195z3.b bVar, p195z3.d dVar) {
        Set set = this.f762a;
        if (set.contains(bVar)) {
            return new v(this.f763b, str, bVar, dVar, this.f764c);
        }
        throw new IllegalArgumentException(String.format("%s is not supported byt this factory. Supported encodings are: %s.", bVar, set));
    }
}
