package C3;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f735a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Integer f736b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final o f737c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f738d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f739e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Map f740f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Integer f741g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final String f742h;
    public final byte[] i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final byte[] f743j;

    public j(String str, Integer num, o oVar, long j9, long j10, HashMap map, Integer num2, String str2, byte[] bArr, byte[] bArr2) {
        this.f735a = str;
        this.f736b = num;
        this.f737c = oVar;
        this.f738d = j9;
        this.f739e = j10;
        this.f740f = map;
        this.f741g = num2;
        this.f742h = str2;
        this.i = bArr;
        this.f743j = bArr2;
    }

    public final String a(String str) {
        String str2 = (String) this.f740f.get(str);
        return str2 == null ? "" : str2;
    }

    public final int b(String str) {
        String str2 = (String) this.f740f.get(str);
        if (str2 == null) {
            return 0;
        }
        return Integer.valueOf(str2).intValue();
    }

    public final i c() {
        i iVar = new i();
        String str = this.f735a;
        if (str == null) {
            throw new NullPointerException("Null transportName");
        }
        iVar.f726b = str;
        iVar.f728d = this.f736b;
        iVar.f729e = this.f741g;
        iVar.f727c = this.f742h;
        iVar.f733j = this.i;
        iVar.f734k = this.f743j;
        o oVar = this.f737c;
        if (oVar == null) {
            throw new NullPointerException("Null encodedPayload");
        }
        iVar.f730f = oVar;
        iVar.f731g = Long.valueOf(this.f738d);
        iVar.f732h = Long.valueOf(this.f739e);
        iVar.i = new HashMap(this.f740f);
        return iVar;
    }

    public final boolean equals(Object obj) {
        Integer num;
        Integer num2;
        String str;
        if (obj == this) {
            return true;
        }
        if (obj instanceof j) {
            j jVar = (j) obj;
            String str2 = jVar.f735a;
            String str3 = jVar.f742h;
            Integer num3 = jVar.f741g;
            Integer num4 = jVar.f736b;
            if (this.f735a.equals(str2) && ((num = this.f736b) != null ? num.equals(num4) : num4 == null) && this.f737c.equals(jVar.f737c) && this.f738d == jVar.f738d && this.f739e == jVar.f739e && this.f740f.equals(jVar.f740f) && ((num2 = this.f741g) != null ? num2.equals(num3) : num3 == null) && ((str = this.f742h) != null ? str.equals(str3) : str3 == null) && Arrays.equals(this.i, jVar.i) && Arrays.equals(this.f743j, jVar.f743j)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int iHashCode = (this.f735a.hashCode() ^ 1000003) * 1000003;
        Integer num = this.f736b;
        int iHashCode2 = (((iHashCode ^ (num == null ? 0 : num.hashCode())) * 1000003) ^ this.f737c.hashCode()) * 1000003;
        long j9 = this.f738d;
        int i = (iHashCode2 ^ ((int) (j9 ^ (j9 >>> 32)))) * 1000003;
        long j10 = this.f739e;
        int iHashCode3 = (((i ^ ((int) (j10 ^ (j10 >>> 32)))) * 1000003) ^ this.f740f.hashCode()) * 1000003;
        Integer num2 = this.f741g;
        int iHashCode4 = (iHashCode3 ^ (num2 == null ? 0 : num2.hashCode())) * 1000003;
        String str = this.f742h;
        return ((((iHashCode4 ^ (str != null ? str.hashCode() : 0)) * 1000003) ^ Arrays.hashCode(this.i)) * 1000003) ^ Arrays.hashCode(this.f743j);
    }

    public final String toString() {
        return "EventInternal{transportName=" + this.f735a + ", code=" + this.f736b + ", encodedPayload=" + this.f737c + ", eventMillis=" + this.f738d + ", uptimeMillis=" + this.f739e + ", autoMetadata=" + this.f740f + ", productId=" + this.f741g + ", pseudonymousId=" + this.f742h + ", experimentIdsClear=" + Arrays.toString(this.i) + ", experimentIdsEncrypted=" + Arrays.toString(this.f743j) + "}";
    }
}
