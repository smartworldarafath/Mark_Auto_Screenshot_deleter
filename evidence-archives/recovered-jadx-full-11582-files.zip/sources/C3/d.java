package C3;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class d implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final d f712a = new d();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f713b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f714c;

    static {
        p197z5.a aVar = new p197z5.a(1);
        HashMap map = new HashMap();
        map.put(p197z5.c.class, aVar);
        f713b = new p172w5.c("eventsDroppedCount", a.o(map));
        p197z5.a aVar2 = new p197z5.a(3);
        HashMap map2 = new HashMap();
        map2.put(p197z5.c.class, aVar2);
        f714c = new p172w5.c("reason", a.o(map2));
    }

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        F3.d dVar = (F3.d) obj;
        p172w5.e eVar = (p172w5.e) obj2;
        eVar.b(f713b, dVar.f2108a);
        eVar.e(f714c, dVar.f2109b);
    }
}
