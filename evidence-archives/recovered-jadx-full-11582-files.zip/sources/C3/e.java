package C3;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class e implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final e f715a = new e();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f716b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f717c;

    static {
        p197z5.a aVar = new p197z5.a(1);
        HashMap map = new HashMap();
        map.put(p197z5.c.class, aVar);
        f716b = new p172w5.c("logSource", a.o(map));
        p197z5.a aVar2 = new p197z5.a(2);
        HashMap map2 = new HashMap();
        map2.put(p197z5.c.class, aVar2);
        f717c = new p172w5.c("logEventDropped", a.o(map2));
    }

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        F3.e eVar = (F3.e) obj;
        p172w5.e eVar2 = (p172w5.e) obj2;
        eVar2.e(f716b, eVar.f2111a);
        eVar2.e(f717c, eVar.f2112b);
    }
}
