package C3;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;

/* JADX INFO: loaded from: classes.dex */
public final class q implements E3.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f756a;

    @Override // p025c7.a
    public final Object get() {
        switch (this.f756a) {
            case 0:
                return new t(0, Executors.newSingleThreadExecutor());
            default:
                U5.a aVar = new U5.a(2);
                HashMap map = new HashMap();
                Set set = Collections.EMPTY_SET;
                if (set == null) {
                    throw new NullPointerException("Null flags");
                }
                map.put(p195z3.c.f32823t, new I3.c(30000L, 86400000L, set));
                if (set == null) {
                    throw new NullPointerException("Null flags");
                }
                map.put(p195z3.c.f32825v, new I3.c(1000L, 86400000L, set));
                if (set == null) {
                    throw new NullPointerException("Null flags");
                }
                Set setUnmodifiableSet = Collections.unmodifiableSet(new HashSet(Arrays.asList(I3.e.f5232u)));
                if (setUnmodifiableSet == null) {
                    throw new NullPointerException("Null flags");
                }
                map.put(p195z3.c.f32824u, new I3.c(86400000L, 86400000L, setUnmodifiableSet));
                if (map.keySet().size() < p195z3.c.values().length) {
                    throw new IllegalStateException("Not all priorities have been configured");
                }
                new HashMap();
                return new I3.b(aVar, map);
        }
    }
}
