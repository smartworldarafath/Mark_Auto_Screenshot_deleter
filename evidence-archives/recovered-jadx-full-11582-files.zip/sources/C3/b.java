package C3;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class b implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final b f705a = new b();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f706b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f707c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final p172w5.c f708d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final p172w5.c f709e;

    static {
        p197z5.a aVar = new p197z5.a(1);
        HashMap map = new HashMap();
        map.put(p197z5.c.class, aVar);
        f706b = new p172w5.c("window", a.o(map));
        p197z5.a aVar2 = new p197z5.a(2);
        HashMap map2 = new HashMap();
        map2.put(p197z5.c.class, aVar2);
        f707c = new p172w5.c("logSourceMetrics", a.o(map2));
        p197z5.a aVar3 = new p197z5.a(3);
        HashMap map3 = new HashMap();
        map3.put(p197z5.c.class, aVar3);
        f708d = new p172w5.c("globalMetrics", a.o(map3));
        p197z5.a aVar4 = new p197z5.a(4);
        HashMap map4 = new HashMap();
        map4.put(p197z5.c.class, aVar4);
        f709e = new p172w5.c("appNamespace", a.o(map4));
    }

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        F3.a aVar = (F3.a) obj;
        p172w5.e eVar = (p172w5.e) obj2;
        eVar.e(f706b, aVar.f2095a);
        eVar.e(f707c, aVar.f2096b);
        eVar.e(f708d, aVar.f2097c);
        eVar.e(f709e, aVar.f2098d);
    }
}
