package C3;

import A1.RunnableC0042s;
import android.content.Context;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class w {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static volatile m f770e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final L3.a f771a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final L3.a f772b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final H3.c f773c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final I3.k f774d;

    public w(L3.a aVar, L3.a aVar2, H3.c cVar, I3.k kVar, I3.m mVar) {
        this.f771a = aVar;
        this.f772b = aVar2;
        this.f773c = cVar;
        this.f774d = kVar;
        mVar.f5267a.execute(new RunnableC0042s(3, mVar));
    }

    public static w a() {
        m mVar = f770e;
        if (mVar != null) {
            return (w) mVar.f752y.get();
        }
        throw new IllegalStateException("Not initialized!");
    }

    public static void b(Context context) {
        if (f770e == null) {
            synchronized (w.class) {
                try {
                    if (f770e == null) {
                        l lVar = new l();
                        context.getClass();
                        lVar.f747a = context;
                        f770e = lVar.b();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    public final u c(n nVar) {
        byte[] bytes;
        Set setUnmodifiableSet = nVar != null ? Collections.unmodifiableSet(A3.a.f298d) : Collections.singleton(new p195z3.b("proto"));
        A4.f fVarA = k.a();
        nVar.getClass();
        fVarA.f322u = "cct";
        A3.a aVar = (A3.a) nVar;
        String str = aVar.f301a;
        String str2 = aVar.f302b;
        if (str2 == null && str == null) {
            bytes = null;
        } else {
            if (str2 == null) {
                str2 = "";
            }
            bytes = ("1$" + str + "\\" + str2).getBytes(Charset.forName("UTF-8"));
        }
        fVarA.f323v = bytes;
        return new u(setUnmodifiableSet, fVarA.h(), this);
    }
}
