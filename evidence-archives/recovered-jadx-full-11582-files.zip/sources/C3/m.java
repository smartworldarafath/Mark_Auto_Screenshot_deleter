package C3;

import java.io.Closeable;

/* JADX INFO: loaded from: classes.dex */
public final class m implements Closeable {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public p025c7.a f748t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public D3.e f749u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public p025c7.a f750v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public J3.e f751w;
    public p025c7.a x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public p025c7.a f752y;

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        ((J3.i) ((J3.d) this.x.get())).close();
    }
}
