package C3;

import E4.C0122a;
import E4.E4;
import E4.H;
import F4.C0456u;
import H4.D;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.media.MediaDrm;
import android.media.MediaMetadataRetriever;
import android.os.Parcel;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class a {
    public static final boolean a(int i) {
        return i == 3 || i == 4 || i == 6;
    }

    public static int b(int i, int i4) {
        return String.valueOf(i).length() + i4;
    }

    public static int c(int i, String str) {
        return String.valueOf(str).length() + i;
    }

    public static int d(int i, String str, int i4) {
        return (str.hashCode() + i) * i4;
    }

    public static C0122a e(HashMap map, int i) {
        Collections.unmodifiableMap(new HashMap(map));
        return new C0122a(i);
    }

    public static C0456u f(HashMap map, int i) {
        Collections.unmodifiableMap(new HashMap(map));
        return new C0456u(i);
    }

    public static D g(HashMap map, int i) {
        Collections.unmodifiableMap(new HashMap(map));
        return new D(i);
    }

    public static String h(char c9, String str, String str2) {
        return str + str2 + c9;
    }

    public static String i(p001a0.r rVar, int i, int i4, p001a0.r rVar2, boolean z8) {
        rVar.V(i);
        String strA = E4.a(i4, rVar2);
        rVar.p(z8);
        return strA;
    }

    public static String j(String str, long j9) {
        return str + j9;
    }

    public static String k(StringBuilder sb, String str, String str2, String str3) {
        sb.append(str);
        sb.append(str2);
        sb.append(str3);
        return sb.toString();
    }

    public static HashMap l(Class cls, C0122a c0122a) {
        HashMap map = new HashMap();
        map.put(cls, c0122a);
        return map;
    }

    public static HashMap m(Class cls, C0456u c0456u) {
        HashMap map = new HashMap();
        map.put(cls, c0456u);
        return map;
    }

    public static HashMap n(Class cls, D d2) {
        HashMap map = new HashMap();
        map.put(cls, d2);
        return map;
    }

    public static Map o(HashMap map) {
        return Collections.unmodifiableMap(new HashMap(map));
    }

    public static p178x4.a p(Parcel parcel) {
        p178x4.a aVarB1 = p178x4.b.B1(parcel.readStrongBinder());
        parcel.recycle();
        return aVarB1;
    }

    public static void q(int i, int i4, int i9, int i10, int i11) {
        H.a(i);
        H.a(i4);
        H.a(i9);
        H.a(i10);
        H.a(i11);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ void r(Cursor cursor) throws Exception {
        boolean zIsTerminated;
        if (cursor instanceof AutoCloseable) {
            cursor.close();
            return;
        }
        if (!(cursor instanceof ExecutorService)) {
            if (cursor instanceof TypedArray) {
                ((TypedArray) cursor).recycle();
                return;
            } else if (cursor instanceof MediaMetadataRetriever) {
                ((MediaMetadataRetriever) cursor).release();
                return;
            } else {
                if (!(cursor instanceof MediaDrm)) {
                    throw new IllegalArgumentException();
                }
                ((MediaDrm) cursor).release();
                return;
            }
        }
        ExecutorService executorService = (ExecutorService) cursor;
        if (executorService == ForkJoinPool.commonPool() || (zIsTerminated = executorService.isTerminated())) {
            return;
        }
        executorService.shutdown();
        boolean z8 = false;
        while (!zIsTerminated) {
            try {
                zIsTerminated = executorService.awaitTermination(1L, TimeUnit.DAYS);
            } catch (InterruptedException unused) {
                if (!z8) {
                    executorService.shutdownNow();
                    z8 = true;
                }
            }
        }
        if (z8) {
            Thread.currentThread().interrupt();
        }
    }

    public static /* synthetic */ void s(Object obj) {
        if (obj != null) {
            throw new ClassCastException();
        }
    }

    public static void t(StringBuilder sb, String str, int i, String str2, int i4) {
        sb.append(str);
        sb.append(i);
        sb.append(str2);
        sb.append(i4);
    }

    public static void u(HashMap map) {
        Collections.unmodifiableMap(new HashMap(map));
    }

    public static /* synthetic */ String v(int i) {
        switch (i) {
            case 1:
                return "NOT_REQUIRED";
            case 2:
                return "CONNECTED";
            case 3:
                return "UNMETERED";
            case 4:
                return "NOT_ROAMING";
            case 5:
                return "METERED";
            case 6:
                return "TEMPORARILY_UNMETERED";
            default:
                return "null";
        }
    }

    public static /* synthetic */ String w(int i) {
        switch (i) {
            case 1:
                return "ENQUEUED";
            case 2:
                return "RUNNING";
            case 3:
                return "SUCCEEDED";
            case 4:
                return "FAILED";
            case 5:
                return "BLOCKED";
            case 6:
                return "CANCELLED";
            default:
                return "null";
        }
    }
}
