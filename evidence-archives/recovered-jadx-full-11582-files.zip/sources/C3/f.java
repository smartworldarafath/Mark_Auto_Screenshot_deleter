package C3;

/* JADX INFO: loaded from: classes.dex */
public final class f implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final f f718a = new f();

    static {
        p172w5.c.b("clientMetrics");
    }

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        if (obj != null) {
            throw new ClassCastException();
        }
        throw null;
    }
}
