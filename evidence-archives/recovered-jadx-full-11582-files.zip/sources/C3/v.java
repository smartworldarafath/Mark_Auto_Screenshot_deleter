package C3;

import H2.RunnableC0553i;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k f765a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f766b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final p195z3.b f767c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p195z3.d f768d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final w f769e;

    public v(k kVar, String str, p195z3.b bVar, p195z3.d dVar, w wVar) {
        this.f765a = kVar;
        this.f766b = str;
        this.f767c = bVar;
        this.f768d = dVar;
        this.f769e = wVar;
    }

    public final void a(p195z3.a aVar, p195z3.f fVar) {
        p195z3.d dVar = this.f768d;
        if (dVar == null) {
            throw new NullPointerException("Null transformer");
        }
        w wVar = this.f769e;
        H3.c cVar = wVar.f773c;
        k kVarB = this.f765a.b(aVar.f32821b);
        i iVar = new i();
        iVar.i = new HashMap();
        iVar.f731g = Long.valueOf(wVar.f771a.c());
        iVar.f732h = Long.valueOf(wVar.f772b.c());
        iVar.f726b = this.f766b;
        iVar.f730f = new o(this.f767c, (byte[]) dVar.apply(aVar.f32820a));
        iVar.f728d = null;
        H3.a aVar2 = (H3.a) cVar;
        aVar2.f3452b.execute(new RunnableC0553i(aVar2, kVarB, fVar, iVar.c(), 1));
    }
}
