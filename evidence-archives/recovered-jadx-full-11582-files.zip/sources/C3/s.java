package C3;

import E4.AbstractC0126a3;

/* JADX INFO: loaded from: classes.dex */
public final class s implements Runnable {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f758t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Runnable f759u;

    public /* synthetic */ s(Runnable runnable, int i) {
        this.f758t = i;
        this.f759u = runnable;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f758t) {
            case 0:
                try {
                    this.f759u.run();
                } catch (Exception e4) {
                    AbstractC0126a3.b("Executor", "Background execution failure.", e4);
                    return;
                }
                break;
            default:
                this.f759u.run();
                break;
        }
    }

    public String toString() {
        switch (this.f758t) {
            case 1:
                return this.f759u.toString();
            default:
                return super.toString();
        }
    }
}
