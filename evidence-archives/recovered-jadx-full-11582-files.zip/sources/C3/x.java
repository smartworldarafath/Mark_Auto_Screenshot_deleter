package C3;

import android.content.Context;

/* JADX INFO: loaded from: classes.dex */
public final class x implements E3.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f775a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p025c7.a f776b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final p025c7.a f777c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final E3.b f778d;

    public /* synthetic */ x(p025c7.a aVar, p025c7.a aVar2, E3.b bVar, int i) {
        this.f775a = i;
        this.f776b = aVar;
        this.f777c = aVar2;
        this.f778d = bVar;
    }

    @Override // p025c7.a
    public final Object get() {
        switch (this.f775a) {
            case 0:
                int i = 2;
                return new w(new U5.a(i), new T5.b(i), (H3.c) ((H3.b) this.f776b).get(), (I3.k) ((I3.l) this.f777c).get(), (I3.m) ((I3.n) this.f778d).get());
            default:
                return new I3.d((Context) this.f776b.get(), (J3.d) this.f777c.get(), (I3.b) ((q) this.f778d).get());
        }
    }
}
