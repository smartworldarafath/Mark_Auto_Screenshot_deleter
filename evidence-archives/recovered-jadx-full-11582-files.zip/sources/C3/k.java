package C3;

import android.util.Base64;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f744a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final byte[] f745b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final p195z3.c f746c;

    public k(String str, byte[] bArr, p195z3.c cVar) {
        this.f744a = str;
        this.f745b = bArr;
        this.f746c = cVar;
    }

    public static A4.f a() {
        A4.f fVar = new A4.f(3, false);
        fVar.f324w = p195z3.c.f32823t;
        return fVar;
    }

    public final k b(p195z3.c cVar) {
        A4.f fVarA = a();
        fVarA.u(this.f744a);
        if (cVar == null) {
            throw new NullPointerException("Null priority");
        }
        fVarA.f324w = cVar;
        fVarA.f323v = this.f745b;
        return fVarA.h();
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof k) {
            k kVar = (k) obj;
            if (this.f744a.equals(kVar.f744a) && Arrays.equals(this.f745b, kVar.f745b) && this.f746c.equals(kVar.f746c)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((((this.f744a.hashCode() ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f745b)) * 1000003) ^ this.f746c.hashCode();
    }

    public final String toString() {
        byte[] bArr = this.f745b;
        String strEncodeToString = bArr == null ? "" : Base64.encodeToString(bArr, 2);
        StringBuilder sb = new StringBuilder("TransportContext(");
        sb.append(this.f744a);
        sb.append(", ");
        sb.append(this.f746c);
        sb.append(", ");
        return X3.b.m(sb, strEncodeToString, ")");
    }
}
