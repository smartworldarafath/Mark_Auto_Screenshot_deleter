package C3;

import L4.C0988j0;
import L4.C0997m0;
import L4.Q0;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final class t implements Executor {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f760t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Object f761u;

    public /* synthetic */ t(int i, Object obj) {
        this.f760t = i;
        this.f761u = obj;
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        switch (this.f760t) {
            case 0:
                ((Executor) this.f761u).execute(new s(runnable, 0));
                break;
            case 1:
                C0988j0 c0988j0 = ((C0997m0) ((Q0) this.f761u).f1283u).f7170z;
                C0997m0.l(c0988j0);
                c0988j0.R(runnable);
                break;
            case 2:
                ((B4.f) this.f761u).post(runnable);
                break;
            default:
                ((Handler) ((P2.n) this.f761u).f8242w).post(runnable);
                break;
        }
    }

    public t() {
        this.f760t = 2;
        B4.f fVar = new B4.f(Looper.getMainLooper(), 3, false);
        Looper.getMainLooper();
        this.f761u = fVar;
    }
}
