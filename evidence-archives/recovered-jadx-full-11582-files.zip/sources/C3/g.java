package C3;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class g implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final g f719a = new g();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f720b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p172w5.c f721c;

    static {
        p197z5.a aVar = new p197z5.a(1);
        HashMap map = new HashMap();
        map.put(p197z5.c.class, aVar);
        f720b = new p172w5.c("currentCacheSizeBytes", a.o(map));
        p197z5.a aVar2 = new p197z5.a(2);
        HashMap map2 = new HashMap();
        map2.put(p197z5.c.class, aVar2);
        f721c = new p172w5.c("maxCacheSizeBytes", a.o(map2));
    }

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        F3.f fVar = (F3.f) obj;
        p172w5.e eVar = (p172w5.e) obj2;
        eVar.b(f720b, fVar.f2113a);
        eVar.b(f721c, fVar.f2114b);
    }
}
