package C3;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p195z3.b f753a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final byte[] f754b;

    public o(p195z3.b bVar, byte[] bArr) {
        if (bVar == null) {
            throw new NullPointerException("encoding is null");
        }
        if (bArr == null) {
            throw new NullPointerException("bytes is null");
        }
        this.f753a = bVar;
        this.f754b = bArr;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof o)) {
            return false;
        }
        o oVar = (o) obj;
        if (this.f753a.equals(oVar.f753a)) {
            return Arrays.equals(this.f754b, oVar.f754b);
        }
        return false;
    }

    public final int hashCode() {
        return ((this.f753a.hashCode() ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f754b);
    }

    public final String toString() {
        return "EncodedPayload{encoding=" + this.f753a + ", bytes=[...]}";
    }
}
