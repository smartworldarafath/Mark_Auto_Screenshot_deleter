package C3;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class c implements p172w5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final c f710a = new c();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p172w5.c f711b;

    static {
        p197z5.a aVar = new p197z5.a(1);
        HashMap map = new HashMap();
        map.put(p197z5.c.class, aVar);
        f711b = new p172w5.c("storageMetrics", a.o(map));
    }

    @Override // p172w5.a
    public final void a(Object obj, Object obj2) {
        ((p172w5.e) obj2).e(f711b, ((F3.b) obj).f2099a);
    }
}
