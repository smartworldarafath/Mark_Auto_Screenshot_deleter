package A;

import L0.C0942h;
import L0.C0943i;
import L0.F0;
import L0.InterfaceC0944j;
import java.util.List;
import p001a0.C1309b;
import p001a0.InterfaceC1334n0;

/* JADX INFO: renamed from: A.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0003d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0002c f70a = new C0002c(0);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C0002c f71b = new C0002c(1);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final K0.g f72c = new K0.g(new l0(0));

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int f73d = 9;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final int f74e = 6;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final int f75f = 10;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final int f76g = 5;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final int f77h = 15;

    public static final void a(p001a0.r rVar, p095m0.r rVar2) {
        C0014o c0014o = C0014o.f137c;
        int iHashCode = Long.hashCode(rVar.f12654T);
        p095m0.r rVarC = p095m0.a.c(rVar, rVar2);
        InterfaceC1334n0 interfaceC1334n0L = rVar.l();
        InterfaceC0944j.f6430b.getClass();
        L0.C c9 = C0943i.f6424b;
        F0 f4 = rVar.f12655a;
        rVar.Z();
        if (rVar.f12653S) {
            rVar.k(c9);
        } else {
            rVar.j0();
        }
        C1309b.y(rVar, c0014o, C0943i.f6427e);
        C1309b.y(rVar, interfaceC1334n0L, C0943i.f6426d);
        C1309b.y(rVar, rVarC, C0943i.f6425c);
        C0942h c0942h = C0943i.f6428f;
        if (rVar.f12653S || !p146s7.j.a(rVar.K(), Integer.valueOf(iHashCode))) {
            p127q3.h.n(iHashCode, rVar, iHashCode, c0942h);
        }
        rVar.p(true);
    }

    public static final Y c(J0.L l8) {
        Object objG = l8.G();
        if (objG instanceof Y) {
            return (Y) objG;
        }
        return null;
    }

    public static final float d(Y y8) {
        if (y8 != null) {
            return y8.f53a;
        }
        return 0.0f;
    }

    public static J0.N e(X x, int i, int i4, int i9, int i10, int i11, J0.O o5, List list, J0.Y[] yArr, int i12) {
        int i13;
        float f4;
        int i14;
        int i15;
        int i16;
        List list2 = list;
        long j9 = i11;
        int[] iArr = new int[i12];
        int iMax = 0;
        int i17 = 0;
        int i18 = 0;
        int i19 = 0;
        int iMin = 0;
        float f9 = 0.0f;
        while (i17 < i12) {
            J0.L l8 = (J0.L) list2.get(i17);
            float fD = d(c(l8));
            if (fD > 0.0f) {
                f9 += fD;
                i18++;
                i14 = i17;
            } else {
                int i20 = i9 - i19;
                J0.Y yD = yArr[i17];
                if (yD == null) {
                    if (i9 == Integer.MAX_VALUE) {
                        i14 = i17;
                        i15 = i18;
                        i16 = Integer.MAX_VALUE;
                    } else {
                        i14 = i17;
                        i15 = i18;
                        i16 = i20 < 0 ? 0 : i20;
                    }
                    yD = l8.D(x.b(0, i16, i10, false));
                } else {
                    i14 = i17;
                    i15 = i18;
                }
                J0.Y y8 = yD;
                int iA = x.a(y8);
                int i21 = x.i(y8);
                iArr[i14] = iA;
                int i22 = i20 - iA;
                if (i22 < 0) {
                    i22 = 0;
                }
                iMin = Math.min(i11, i22);
                i19 += iA + iMin;
                iMax = Math.max(iMax, i21);
                yArr[i14] = y8;
                i18 = i15;
            }
            i17 = i14 + 1;
            j9 = j9;
        }
        long j10 = j9;
        int i23 = i18;
        if (i23 == 0) {
            i19 -= iMin;
            i13 = 0;
        } else {
            long j11 = ((long) (i23 - 1)) * j10;
            long jRound = ((long) ((i9 != Integer.MAX_VALUE ? i9 : i) - i19)) - j11;
            if (jRound < 0) {
                jRound = 0;
            }
            float f10 = jRound / f9;
            for (int i24 = 0; i24 < i12; i24++) {
                jRound -= (long) Math.round(d(c((J0.L) list2.get(i24))) * f10);
            }
            int i25 = iMax;
            int i26 = 0;
            int i27 = 0;
            while (i26 < i12) {
                if (yArr[i26] == null) {
                    J0.L l9 = (J0.L) list2.get(i26);
                    Y yC = c(l9);
                    float fD2 = d(yC);
                    if (fD2 <= 0.0f) {
                        B.a.b("All weights <= 0 should have placeables");
                    }
                    f4 = f10;
                    int iSignum = Long.signum(jRound);
                    jRound -= (long) iSignum;
                    int iMax2 = Math.max(0, Math.round(fD2 * f4) + iSignum);
                    J0.Y yD2 = l9.D(x.b((!(yC != null ? yC.f54b : true) || iMax2 == Integer.MAX_VALUE) ? 0 : iMax2, iMax2, i10, true));
                    int iA2 = x.a(yD2);
                    int i28 = x.i(yD2);
                    iArr[i26] = iA2;
                    i27 += iA2;
                    int iMax3 = Math.max(i25, i28);
                    yArr[i26] = yD2;
                    i25 = iMax3;
                } else {
                    f4 = f10;
                }
                i26++;
                list2 = list;
                f10 = f4;
            }
            i13 = (int) (((long) i27) + j11);
            int i29 = i9 - i19;
            if (i13 < 0) {
                i13 = 0;
            }
            if (i13 > i29) {
                i13 = i29;
            }
            iMax = i25;
        }
        int i30 = i13 + i19;
        if (i30 < 0) {
            i30 = 0;
        }
        int iMax4 = Math.max(i30, i);
        int iMax5 = Math.max(iMax, Math.max(i4, 0));
        int[] iArr2 = new int[i12];
        x.f(iMax4, o5, iArr, iArr2);
        return x.j(yArr, o5, iArr2, iMax4, iMax5);
    }

    public static final p095m0.r f(p095m0.r rVar) {
        return p095m0.a.a(rVar, new n0(2));
    }

    public static final J g(t1.b bVar) {
        return new J(bVar.f31354a, bVar.f31355b, bVar.f31356c, bVar.f31357d);
    }

    public static final void h(String str, StringBuilder sb) {
        if (sb.length() > 0) {
            sb.append('+');
        }
        sb.append(str);
    }

    public abstract int b(int i, j1.m mVar);
}
