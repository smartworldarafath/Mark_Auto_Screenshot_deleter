package A;

/* JADX INFO: loaded from: classes.dex */
public final class e0 implements i0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i0 f84a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final i0 f85b;

    public e0(i0 i0Var, i0 i0Var2) {
        this.f84a = i0Var;
        this.f85b = i0Var2;
    }

    @Override // A.i0
    public final int a(j1.c cVar, j1.m mVar) {
        return Math.max(this.f84a.a(cVar, mVar), this.f85b.a(cVar, mVar));
    }

    @Override // A.i0
    public final int b(j1.c cVar, j1.m mVar) {
        return Math.max(this.f84a.b(cVar, mVar), this.f85b.b(cVar, mVar));
    }

    @Override // A.i0
    public final int c(j1.c cVar) {
        return Math.max(this.f84a.c(cVar), this.f85b.c(cVar));
    }

    @Override // A.i0
    public final int d(j1.c cVar) {
        return Math.max(this.f84a.d(cVar), this.f85b.d(cVar));
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof e0)) {
            return false;
        }
        e0 e0Var = (e0) obj;
        return p146s7.j.a(e0Var.f84a, this.f84a) && p146s7.j.a(e0Var.f85b, this.f85b);
    }

    public final int hashCode() {
        return (this.f85b.hashCode() * 31) + this.f84a.hashCode();
    }

    public final String toString() {
        return "(" + this.f84a + " ∪ " + this.f85b + ')';
    }
}
