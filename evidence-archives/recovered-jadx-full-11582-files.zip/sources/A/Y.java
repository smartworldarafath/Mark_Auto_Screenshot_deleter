package A;

/* JADX INFO: loaded from: classes.dex */
public final class Y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f53a = 0.0f;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f54b = true;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public AbstractC0003d f55c = null;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Y)) {
            return false;
        }
        Y y8 = (Y) obj;
        return Float.compare(this.f53a, y8.f53a) == 0 && this.f54b == y8.f54b && p146s7.j.a(this.f55c, y8.f55c);
    }

    public final int hashCode() {
        int iE = p127q3.h.e(Float.hashCode(this.f53a) * 31, 31, this.f54b);
        AbstractC0003d abstractC0003d = this.f55c;
        return (iE + (abstractC0003d == null ? 0 : abstractC0003d.hashCode())) * 31;
    }

    public final String toString() {
        return "RowColumnParentData(weight=" + this.f53a + ", fill=" + this.f54b + ", crossAxisAlignment=" + this.f55c + ", flowLayoutData=null)";
    }
}
