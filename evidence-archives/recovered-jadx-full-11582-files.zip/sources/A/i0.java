package A;

/* JADX INFO: loaded from: classes.dex */
public interface i0 {
    int a(j1.c cVar, j1.m mVar);

    int b(j1.c cVar, j1.m mVar);

    int c(j1.c cVar);

    int d(j1.c cVar);
}
