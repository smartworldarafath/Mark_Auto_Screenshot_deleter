package A;

import I.AbstractC0835s;
import com.google.android.gms.internal.ads.V7;
import java.util.Locale;
import p001a0.C1309b;
import p001a0.X0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class l0 implements p137r7.a {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f127t;

    public /* synthetic */ l0(int i) {
        this.f127t = i;
    }

    @Override // p137r7.a
    public final Object a() {
        switch (this.f127t) {
            case 0:
                return new D();
            case 1:
                return new C.B(0, 0);
            case 2:
                return new D.A(0, 0);
            case 3:
                return p032d7.z.f26831a;
            case 4:
                return C1309b.u(Boolean.FALSE);
            case 5:
                return C1309b.u(v6.d.f31936y);
            case 6:
                return C1309b.u("");
            case 7:
                return C1309b.u(Boolean.FALSE);
            case 8:
                X0 x8 = AbstractC0835s.f4887a;
                return null;
            case 9:
                return new j1.j(0L);
            case 10:
                return new j1.j(0L);
            case 11:
                p001a0.B b9 = P.f.f8205a;
                return null;
            case 12:
                return new P6.b();
            case 13:
                P7.j jVar = P7.j.f8553e;
                P7.f[] fVarArr = new P7.f[0];
                if (A7.n.B("kotlin.Unit")) {
                    throw new IllegalArgumentException("Blank serial names are prohibited");
                }
                if (jVar.equals(P7.j.f8550b)) {
                    throw new IllegalArgumentException("For StructureKind.CLASS please use 'buildClassSerialDescriptor' instead");
                }
                P7.a aVar = new P7.a("kotlin.Unit");
                return new P7.g("kotlin.Unit", jVar, aVar.f8521b.size(), p040e7.k.y(fVarArr), aVar);
            case 14:
                Locale locale = Locale.getDefault();
                p146s7.j.d(locale, "getDefault(...)");
                return locale;
            case 15:
                Locale locale2 = Locale.KOREAN;
                p146s7.j.d(locale2, "KOREAN");
                return locale2;
            case 16:
                Locale locale3 = Locale.ENGLISH;
                p146s7.j.d(locale3, "ENGLISH");
                return locale3;
            case 17:
                return new Locale("in");
            case 18:
                Locale locale4 = Locale.JAPANESE;
                p146s7.j.d(locale4, "JAPANESE");
                return locale4;
            case 19:
                Locale localeForLanguageTag = Locale.forLanguageTag("tr");
                p146s7.j.d(localeForLanguageTag, "forLanguageTag(...)");
                return localeForLanguageTag;
            case 20:
                Locale localeForLanguageTag2 = Locale.forLanguageTag("vi");
                p146s7.j.d(localeForLanguageTag2, "forLanguageTag(...)");
                return localeForLanguageTag2;
            case V7.zzm /* 21 */:
                Locale locale5 = Locale.ITALIAN;
                p146s7.j.d(locale5, "ITALIAN");
                return locale5;
            case 22:
                Locale localeForLanguageTag3 = Locale.forLanguageTag("th");
                p146s7.j.d(localeForLanguageTag3, "forLanguageTag(...)");
                return localeForLanguageTag3;
            case 23:
                Locale localeForLanguageTag4 = Locale.forLanguageTag("pl");
                p146s7.j.d(localeForLanguageTag4, "forLanguageTag(...)");
                return localeForLanguageTag4;
            case 24:
                Locale localeForLanguageTag5 = Locale.forLanguageTag("uk");
                p146s7.j.d(localeForLanguageTag5, "forLanguageTag(...)");
                return localeForLanguageTag5;
            case 25:
                Locale localeForLanguageTag6 = Locale.forLanguageTag("ar");
                p146s7.j.d(localeForLanguageTag6, "forLanguageTag(...)");
                return localeForLanguageTag6;
            case 26:
                Locale localeForLanguageTag7 = Locale.forLanguageTag("nl");
                p146s7.j.d(localeForLanguageTag7, "forLanguageTag(...)");
                return localeForLanguageTag7;
            case 27:
                Locale localeForLanguageTag8 = Locale.forLanguageTag("fa");
                p146s7.j.d(localeForLanguageTag8, "forLanguageTag(...)");
                return localeForLanguageTag8;
            case 28:
                Locale localeForLanguageTag9 = Locale.forLanguageTag("es");
                p146s7.j.d(localeForLanguageTag9, "forLanguageTag(...)");
                return localeForLanguageTag9;
            default:
                Locale locale6 = Locale.FRENCH;
                p146s7.j.d(locale6, "FRENCH");
                return locale6;
        }
    }
}
