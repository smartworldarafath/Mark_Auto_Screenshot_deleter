package A;

/* JADX INFO: renamed from: A.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0022x implements K0.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p137r7.c f170a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public i0 f171b;

    public C0022x(p137r7.c cVar) {
        this.f170a = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C0022x) && ((C0022x) obj).f170a == this.f170a;
    }

    @Override // K0.c
    public final void f(K0.f fVar) {
        i0 i0Var = (i0) fVar.e(AbstractC0003d.f72c);
        if (p146s7.j.a(i0Var, this.f171b)) {
            return;
        }
        this.f171b = i0Var;
        this.f170a.g(i0Var);
    }

    public final int hashCode() {
        return this.f170a.hashCode();
    }
}
