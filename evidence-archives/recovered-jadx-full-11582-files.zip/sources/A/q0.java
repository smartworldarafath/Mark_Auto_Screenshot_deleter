package A;

import H4.Z5;
import L0.InterfaceC0959z;

/* JADX INFO: loaded from: classes.dex */
public final class q0 extends p095m0.q implements InterfaceC0959z {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public A f153H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public p137r7.e f154I;

    @Override // L0.InterfaceC0959z
    public final J0.N c(final J0.O o5, J0.L l8, long j9) {
        final J0.Y yD = l8.D(j1.b.a(this.f153H != A.f0t ? 0 : j1.a.j(j9), j1.a.h(j9), this.f153H == A.f1u ? j1.a.i(j9) : 0, j1.a.g(j9)));
        final int iC = Z5.c(yD.f5563t, j1.a.j(j9), j1.a.h(j9));
        final int iC2 = Z5.c(yD.f5564u, j1.a.i(j9), j1.a.g(j9));
        return o5.p(iC, iC2, p040e7.u.f26996t, new p137r7.c() { // from class: A.p0
            @Override // p137r7.c
            public final Object g(Object obj) {
                p137r7.e eVar = this.f144t.f154I;
                J0.Y y8 = yD;
                J0.X.k((J0.X) obj, y8, ((j1.j) eVar.j(new j1.l((((long) (iC - y8.f5563t)) << 32) | (((long) (iC2 - y8.f5564u)) & 4294967295L)), o5.getLayoutDirection())).f27647a);
                return p032d7.z.f26831a;
            }
        });
    }
}
