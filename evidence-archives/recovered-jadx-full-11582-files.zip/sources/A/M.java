package A;

import L0.InterfaceC0959z;

/* JADX INFO: loaded from: classes.dex */
public abstract class M extends p095m0.q implements InterfaceC0959z {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final /* synthetic */ int f30H;

    public abstract long K0(J0.L l8, long j9);

    public abstract boolean L0();

    public int S(L0.S s8, J0.L l8, int i) {
        switch (this.f30H) {
            case 0:
                break;
        }
        return l8.U(i);
    }

    @Override // L0.InterfaceC0959z
    public J0.N c(J0.O o5, J0.L l8, long j9) {
        long jK0 = K0(l8, j9);
        if (L0()) {
            jK0 = j1.b.e(j9, jK0);
        }
        J0.Y yD = l8.D(jK0);
        return o5.p(yD.f5563t, yD.f5564u, p040e7.u.f26996t, new C0010k(yD, 2));
    }

    @Override // L0.InterfaceC0959z
    public int m0(L0.S s8, J0.L l8, int i) {
        switch (this.f30H) {
            case 0:
                break;
        }
        return l8.A(i);
    }

    public int w(L0.S s8, J0.L l8, int i) {
        switch (this.f30H) {
            case 0:
                break;
        }
        return l8.c(i);
    }

    @Override // L0.InterfaceC0959z
    public int w0(L0.S s8, J0.L l8, int i) {
        switch (this.f30H) {
            case 0:
                break;
        }
        return l8.w(i);
    }
}
