package A;

import L0.t0;

/* JADX INFO: loaded from: classes.dex */
public final class h0 extends p095m0.q implements t0 {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public p095m0.i f95H;

    @Override // L0.t0
    public final Object A(j1.c cVar, Object obj) {
        Y y8 = obj instanceof Y ? (Y) obj : null;
        if (y8 == null) {
            y8 = new Y();
        }
        y8.f55c = new C0024z(this.f95H);
        return y8;
    }
}
