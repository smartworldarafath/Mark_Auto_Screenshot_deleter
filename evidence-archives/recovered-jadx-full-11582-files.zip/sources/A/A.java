package A;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class A {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final A f0t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final A f1u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final A f2v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final /* synthetic */ A[] f3w;

    static {
        A a9 = new A("Vertical", 0);
        f0t = a9;
        A a10 = new A("Horizontal", 1);
        f1u = a10;
        A a11 = new A("Both", 2);
        f2v = a11;
        f3w = new A[]{a9, a10, a11};
    }

    public static A valueOf(String str) {
        return (A) Enum.valueOf(A.class, str);
    }

    public static A[] values() {
        return (A[]) f3w.clone();
    }
}
