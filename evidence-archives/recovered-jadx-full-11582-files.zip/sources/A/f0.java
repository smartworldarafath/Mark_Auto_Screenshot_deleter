package A;

import L0.InterfaceC0959z;

/* JADX INFO: loaded from: classes.dex */
public final class f0 extends p095m0.q implements InterfaceC0959z {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public float f88H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public float f89I;

    @Override // L0.InterfaceC0959z
    public final int S(L0.S s8, J0.L l8, int i) {
        int iU = l8.U(i);
        int iJ0 = !Float.isNaN(this.f89I) ? s8.j0(this.f89I) : 0;
        return iU < iJ0 ? iJ0 : iU;
    }

    @Override // L0.InterfaceC0959z
    public final J0.N c(J0.O o5, J0.L l8, long j9) {
        int iJ;
        int i;
        if (Float.isNaN(this.f88H) || j1.a.j(j9) != 0) {
            iJ = j1.a.j(j9);
        } else {
            int iJ0 = o5.j0(this.f88H);
            iJ = j1.a.h(j9);
            if (iJ0 < 0) {
                iJ0 = 0;
            }
            if (iJ0 <= iJ) {
                iJ = iJ0;
            }
        }
        int iH = j1.a.h(j9);
        if (Float.isNaN(this.f89I) || j1.a.i(j9) != 0) {
            i = j1.a.i(j9);
        } else {
            int iJ1 = o5.j0(this.f89I);
            i = j1.a.g(j9);
            int i4 = iJ1 >= 0 ? iJ1 : 0;
            if (i4 <= i) {
                i = i4;
            }
        }
        J0.Y yD = l8.D(j1.b.a(iJ, iH, i, j1.a.g(j9)));
        return o5.p(yD.f5563t, yD.f5564u, p040e7.u.f26996t, new C0010k(yD, 4));
    }

    @Override // L0.InterfaceC0959z
    public final int m0(L0.S s8, J0.L l8, int i) {
        int iA = l8.A(i);
        int iJ0 = !Float.isNaN(this.f88H) ? s8.j0(this.f88H) : 0;
        return iA < iJ0 ? iJ0 : iA;
    }

    @Override // L0.InterfaceC0959z
    public final int w(L0.S s8, J0.L l8, int i) {
        int iC = l8.c(i);
        int iJ0 = !Float.isNaN(this.f89I) ? s8.j0(this.f89I) : 0;
        return iC < iJ0 ? iJ0 : iC;
    }

    @Override // L0.InterfaceC0959z
    public final int w0(L0.S s8, J0.L l8, int i) {
        int iW = l8.w(i);
        int iJ0 = !Float.isNaN(this.f88H) ? s8.j0(this.f88H) : 0;
        return iW < iJ0 ? iJ0 : iW;
    }
}
