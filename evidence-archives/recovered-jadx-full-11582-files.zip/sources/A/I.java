package A;

/* JADX INFO: loaded from: classes.dex */
public final class I implements U {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i0 f19a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final j1.c f20b;

    public I(i0 i0Var, j1.c cVar) {
        this.f19a = i0Var;
        this.f20b = cVar;
    }

    @Override // A.U
    public final float a() {
        i0 i0Var = this.f19a;
        j1.c cVar = this.f20b;
        return cVar.M(i0Var.d(cVar));
    }

    @Override // A.U
    public final float b(j1.m mVar) {
        i0 i0Var = this.f19a;
        j1.c cVar = this.f20b;
        return cVar.M(i0Var.b(cVar, mVar));
    }

    @Override // A.U
    public final float c(j1.m mVar) {
        i0 i0Var = this.f19a;
        j1.c cVar = this.f20b;
        return cVar.M(i0Var.a(cVar, mVar));
    }

    @Override // A.U
    public final float d() {
        i0 i0Var = this.f19a;
        j1.c cVar = this.f20b;
        return cVar.M(i0Var.c(cVar));
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof I)) {
            return false;
        }
        I i = (I) obj;
        return p146s7.j.a(this.f19a, i.f19a) && p146s7.j.a(this.f20b, i.f20b);
    }

    public final int hashCode() {
        return this.f20b.hashCode() + (this.f19a.hashCode() * 31);
    }

    public final String toString() {
        return "InsetsPaddingValues(insets=" + this.f19a + ", density=" + this.f20b + ')';
    }
}
