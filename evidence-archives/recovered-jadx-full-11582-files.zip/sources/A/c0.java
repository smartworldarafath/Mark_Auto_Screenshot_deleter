package A;

import androidx.compose.foundation.layout.LayoutWeightElement;

/* JADX INFO: loaded from: classes.dex */
public final class c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final c0 f69a = new c0();

    public static p095m0.r a() {
        if (1.0f <= 0.0d) {
            B.a.a("invalid weight; must be greater than zero");
        }
        return new LayoutWeightElement(1.0f, true);
    }
}
