package A;

/* JADX INFO: renamed from: A.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0006g {
    default float a() {
        return 0;
    }

    void c(j1.c cVar, int i, int[] iArr, j1.m mVar, int[] iArr2);
}
