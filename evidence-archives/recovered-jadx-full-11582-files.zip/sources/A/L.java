package A;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class L {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final L f27t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final L f28u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final /* synthetic */ L[] f29v;

    static {
        L l8 = new L("Min", 0);
        f27t = l8;
        L l9 = new L("Max", 1);
        f28u = l9;
        f29v = new L[]{l8, l9};
    }

    public static L valueOf(String str) {
        return (L) Enum.valueOf(L.class, str);
    }

    public static L[] values() {
        return (L[]) f29v.clone();
    }
}
