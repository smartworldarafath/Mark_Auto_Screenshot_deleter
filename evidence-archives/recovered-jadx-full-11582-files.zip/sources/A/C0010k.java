package A;

/* JADX INFO: renamed from: A.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0010k implements p137r7.c {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f103t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ J0.Y f104u;

    public /* synthetic */ C0010k(J0.Y y8, int i) {
        this.f103t = i;
        this.f104u = y8;
    }

    @Override // p137r7.c
    public final Object g(Object obj) {
        J0.X x = (J0.X) obj;
        switch (this.f103t) {
            case 0:
                J0.X.l(x, this.f104u, 0, 0);
                break;
            case 1:
                J0.X.l(x, this.f104u, 0, 0);
                break;
            case 2:
                j1.m mVarE = x.e();
                j1.m mVar = j1.m.f27654t;
                J0.Y y8 = this.f104u;
                if (mVarE == mVar || x.g() == 0) {
                    J0.X.b(x, y8);
                    y8.g0(j1.j.d(0L, y8.x), 0.0f, null);
                } else {
                    int i = (int) 0;
                    long jG = ((long) ((x.g() - y8.f5563t) - i)) << 32;
                    J0.X.b(x, y8);
                    y8.g0(j1.j.d((((long) i) & 4294967295L) | jG, y8.x), 0.0f, null);
                }
                return p032d7.z.f26831a;
            case 3:
                J0.X.l(x, this.f104u, 0, 0);
                break;
            case 4:
                J0.X.l(x, this.f104u, 0, 0);
                break;
            case 5:
                x.h(this.f104u, 0, 0, 0.0f);
                break;
            case 6:
                J0.X.l(x, this.f104u, 0, 0);
                break;
            case 7:
                x.h(this.f104u, 0, 0, 0.0f);
                break;
            default:
                x.h(this.f104u, 0, 0, 0.0f);
                break;
        }
        return p032d7.z.f26831a;
    }
}
