package A;

import L0.InterfaceC0959z;

/* JADX INFO: renamed from: A.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0011l extends p095m0.q implements InterfaceC0959z {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public float f126H;

    public final long K0(boolean z8, long j9) {
        int iRound;
        int iG = j1.a.g(j9);
        if (iG == Integer.MAX_VALUE || (iRound = Math.round(iG * this.f126H)) <= 0) {
            return 0L;
        }
        if (!z8 || androidx.compose.foundation.layout.a.g(iRound, iG, j9)) {
            return (((long) iRound) << 32) | (((long) iG) & 4294967295L);
        }
        return 0L;
    }

    public final long L0(boolean z8, long j9) {
        int iRound;
        int iH = j1.a.h(j9);
        if (iH == Integer.MAX_VALUE || (iRound = Math.round(iH / this.f126H)) <= 0) {
            return 0L;
        }
        if (!z8 || androidx.compose.foundation.layout.a.g(iH, iRound, j9)) {
            return (((long) iH) << 32) | (((long) iRound) & 4294967295L);
        }
        return 0L;
    }

    public final long M0(boolean z8, long j9) {
        int i = j1.a.i(j9);
        int iRound = Math.round(i * this.f126H);
        if (iRound <= 0) {
            return 0L;
        }
        if (!z8 || androidx.compose.foundation.layout.a.g(iRound, i, j9)) {
            return (((long) iRound) << 32) | (((long) i) & 4294967295L);
        }
        return 0L;
    }

    public final long N0(boolean z8, long j9) {
        int iJ = j1.a.j(j9);
        int iRound = Math.round(iJ / this.f126H);
        if (iRound <= 0) {
            return 0L;
        }
        if (!z8 || androidx.compose.foundation.layout.a.g(iJ, iRound, j9)) {
            return (((long) iJ) << 32) | (((long) iRound) & 4294967295L);
        }
        return 0L;
    }

    @Override // L0.InterfaceC0959z
    public final int S(L0.S s8, J0.L l8, int i) {
        return i != Integer.MAX_VALUE ? Math.round(i / this.f126H) : l8.U(i);
    }

    @Override // L0.InterfaceC0959z
    public final J0.N c(J0.O o5, J0.L l8, long j9) {
        long jL0 = L0(true, j9);
        if (j1.l.a(jL0, 0L)) {
            jL0 = K0(true, j9);
            if (j1.l.a(jL0, 0L)) {
                jL0 = N0(true, j9);
                if (j1.l.a(jL0, 0L)) {
                    jL0 = M0(true, j9);
                    if (j1.l.a(jL0, 0L)) {
                        jL0 = L0(false, j9);
                        if (j1.l.a(jL0, 0L)) {
                            jL0 = K0(false, j9);
                            if (j1.l.a(jL0, 0L)) {
                                jL0 = N0(false, j9);
                                if (j1.l.a(jL0, 0L)) {
                                    jL0 = M0(false, j9);
                                    if (j1.l.a(jL0, 0L)) {
                                        jL0 = 0;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (!j1.l.a(jL0, 0L)) {
            int i = (int) (jL0 >> 32);
            int i4 = (int) (jL0 & 4294967295L);
            if (!((i4 >= 0) & (i >= 0))) {
                j1.i.a("width and height must be >= 0");
            }
            j9 = j1.b.h(i, i, i4, i4);
        }
        J0.Y yD = l8.D(j9);
        return o5.p(yD.f5563t, yD.f5564u, p040e7.u.f26996t, new C0010k(yD, 0));
    }

    @Override // L0.InterfaceC0959z
    public final int m0(L0.S s8, J0.L l8, int i) {
        return i != Integer.MAX_VALUE ? Math.round(i * this.f126H) : l8.A(i);
    }

    @Override // L0.InterfaceC0959z
    public final int w(L0.S s8, J0.L l8, int i) {
        return i != Integer.MAX_VALUE ? Math.round(i / this.f126H) : l8.c(i);
    }

    @Override // L0.InterfaceC0959z
    public final int w0(L0.S s8, J0.L l8, int i) {
        return i != Integer.MAX_VALUE ? Math.round(i * this.f126H) : l8.w(i);
    }
}
