package A;

/* JADX INFO: renamed from: A.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0005f implements InterfaceC0006g, InterfaceC0008i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f86a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f87b;

    public C0005f(int i) {
        this.f86a = i;
        switch (i) {
            case 1:
                this.f87b = 0;
                break;
            case 2:
                this.f87b = 0;
                break;
            case 3:
                this.f87b = 0;
                break;
            case 4:
                break;
            default:
                this.f87b = 0;
                break;
        }
    }

    @Override // A.InterfaceC0006g, A.InterfaceC0008i
    public float a() {
        switch (this.f86a) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
        }
        return this.f87b;
    }

    @Override // A.InterfaceC0008i
    public void b(int i, J0.O o5, int[] iArr, int[] iArr2) {
        switch (this.f86a) {
            case 0:
                AbstractC0009j.a(i, iArr, iArr2, false);
                break;
            case 1:
                AbstractC0009j.d(i, iArr, iArr2, false);
                break;
            case 2:
                AbstractC0009j.e(i, iArr, iArr2, false);
                break;
            default:
                AbstractC0009j.f(i, iArr, iArr2, false);
                break;
        }
    }

    @Override // A.InterfaceC0006g
    public void c(j1.c cVar, int i, int[] iArr, j1.m mVar, int[] iArr2) {
        switch (this.f86a) {
            case 0:
                if (mVar != j1.m.f27654t) {
                    AbstractC0009j.a(i, iArr, iArr2, true);
                } else {
                    AbstractC0009j.a(i, iArr, iArr2, false);
                }
                break;
            case 1:
                if (mVar != j1.m.f27654t) {
                    AbstractC0009j.d(i, iArr, iArr2, true);
                } else {
                    AbstractC0009j.d(i, iArr, iArr2, false);
                }
                break;
            case 2:
                if (mVar != j1.m.f27654t) {
                    AbstractC0009j.e(i, iArr, iArr2, true);
                } else {
                    AbstractC0009j.e(i, iArr, iArr2, false);
                }
                break;
            default:
                if (mVar != j1.m.f27654t) {
                    AbstractC0009j.f(i, iArr, iArr2, true);
                } else {
                    AbstractC0009j.f(i, iArr, iArr2, false);
                }
                break;
        }
    }

    public String toString() {
        switch (this.f86a) {
            case 0:
                return "Arrangement#Center";
            case 1:
                return "Arrangement#SpaceAround";
            case 2:
                return "Arrangement#SpaceBetween";
            case 3:
                return "Arrangement#SpaceEvenly";
            default:
                return super.toString();
        }
    }
}
