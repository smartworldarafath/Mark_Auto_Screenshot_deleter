package A;

/* JADX INFO: loaded from: classes.dex */
public interface X {
    int a(J0.Y y8);

    long b(int i, int i4, int i9, boolean z8);

    void f(int i, J0.O o5, int[] iArr, int[] iArr2);

    int i(J0.Y y8);

    J0.N j(J0.Y[] yArr, J0.O o5, int[] iArr, int i, int i4);
}
