package A;

import L0.t0;

/* JADX INFO: renamed from: A.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0012m extends p095m0.q implements t0 {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public p095m0.j f128H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public boolean f129I;

    @Override // L0.t0
    public final Object A(j1.c cVar, Object obj) {
        return this;
    }
}
