package A;

/* JADX INFO: loaded from: classes.dex */
public final class D implements i0 {
    @Override // A.i0
    public final int a(j1.c cVar, j1.m mVar) {
        return 0;
    }

    @Override // A.i0
    public final int b(j1.c cVar, j1.m mVar) {
        return 0;
    }

    @Override // A.i0
    public final int c(j1.c cVar) {
        return 0;
    }

    @Override // A.i0
    public final int d(j1.c cVar) {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof D)) {
            return false;
        }
        ((D) obj).getClass();
        return true;
    }

    public final int hashCode() {
        return 0;
    }

    public final String toString() {
        return "Insets(left=0, top=0, right=0, bottom=0)";
    }
}
