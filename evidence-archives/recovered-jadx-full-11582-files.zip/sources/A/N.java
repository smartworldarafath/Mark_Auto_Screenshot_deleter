package A;

/* JADX INFO: loaded from: classes.dex */
public final class N extends M {

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public L f31I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public boolean f32J;

    @Override // A.M
    public final long K0(J0.L l8, long j9) {
        int iW = this.f31I == L.f27t ? l8.w(j1.a.g(j9)) : l8.A(j1.a.g(j9));
        if (iW < 0) {
            iW = 0;
        }
        if (iW < 0) {
            j1.i.a("width must be >= 0");
        }
        return j1.b.h(iW, iW, 0, Integer.MAX_VALUE);
    }

    @Override // A.M
    public final boolean L0() {
        return this.f32J;
    }

    @Override // A.M, L0.InterfaceC0959z
    public final int m0(L0.S s8, J0.L l8, int i) {
        return this.f31I == L.f27t ? l8.w(i) : l8.A(i);
    }

    @Override // A.M, L0.InterfaceC0959z
    public final int w0(L0.S s8, J0.L l8, int i) {
        return this.f31I == L.f27t ? l8.w(i) : l8.A(i);
    }
}
