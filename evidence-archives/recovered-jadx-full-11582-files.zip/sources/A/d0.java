package A;

import L0.InterfaceC0959z;

/* JADX INFO: loaded from: classes.dex */
public final class d0 extends p095m0.q implements InterfaceC0959z {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public float f78H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public float f79I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public float f80J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public float f81K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public boolean f82L;

    /* JADX WARN: Code duplicated, block: B:23:0x0041  */
    public final long K0(J0.O o5) {
        int iJ0;
        int iJ1;
        int iJ2;
        int i = 0;
        if (Float.isNaN(this.f80J)) {
            iJ0 = Integer.MAX_VALUE;
        } else {
            iJ0 = o5.j0(this.f80J);
            if (iJ0 < 0) {
                iJ0 = 0;
            }
        }
        if (Float.isNaN(this.f81K)) {
            iJ1 = Integer.MAX_VALUE;
        } else {
            iJ1 = o5.j0(this.f81K);
            if (iJ1 < 0) {
                iJ1 = 0;
            }
        }
        if (Float.isNaN(this.f78H)) {
            iJ2 = 0;
        } else {
            iJ2 = o5.j0(this.f78H);
            if (iJ2 < 0) {
                iJ2 = 0;
            }
            if (iJ2 > iJ0) {
                iJ2 = iJ0;
            }
            if (iJ2 == Integer.MAX_VALUE) {
                iJ2 = 0;
            }
        }
        if (!Float.isNaN(this.f79I)) {
            int iJ3 = o5.j0(this.f79I);
            if (iJ3 < 0) {
                iJ3 = 0;
            }
            if (iJ3 > iJ1) {
                iJ3 = iJ1;
            }
            if (iJ3 != Integer.MAX_VALUE) {
                i = iJ3;
            }
        }
        return j1.b.a(iJ2, iJ0, i, iJ1);
    }

    @Override // L0.InterfaceC0959z
    public final int S(L0.S s8, J0.L l8, int i) {
        long jK0 = K0(s8);
        if (j1.a.e(jK0)) {
            return j1.a.g(jK0);
        }
        if (!this.f82L) {
            i = j1.b.g(i, jK0);
        }
        return j1.b.f(l8.U(i), jK0);
    }

    @Override // L0.InterfaceC0959z
    public final J0.N c(J0.O o5, J0.L l8, long j9) {
        int iJ;
        int iH;
        int i;
        int iG;
        long jA;
        long jK0 = K0(o5);
        if (this.f82L) {
            jA = j1.b.e(j9, jK0);
        } else {
            if (Float.isNaN(this.f78H)) {
                iJ = j1.a.j(j9);
                int iH2 = j1.a.h(jK0);
                if (iJ > iH2) {
                    iJ = iH2;
                }
            } else {
                iJ = j1.a.j(jK0);
            }
            if (Float.isNaN(this.f80J)) {
                iH = j1.a.h(j9);
                int iJ2 = j1.a.j(jK0);
                if (iH < iJ2) {
                    iH = iJ2;
                }
            } else {
                iH = j1.a.h(jK0);
            }
            if (Float.isNaN(this.f79I)) {
                i = j1.a.i(j9);
                int iG2 = j1.a.g(jK0);
                if (i > iG2) {
                    i = iG2;
                }
            } else {
                i = j1.a.i(jK0);
            }
            if (Float.isNaN(this.f81K)) {
                iG = j1.a.g(j9);
                int i4 = j1.a.i(jK0);
                if (iG < i4) {
                    iG = i4;
                }
            } else {
                iG = j1.a.g(jK0);
            }
            jA = j1.b.a(iJ, iH, i, iG);
        }
        J0.Y yD = l8.D(jA);
        return o5.p(yD.f5563t, yD.f5564u, p040e7.u.f26996t, new C0010k(yD, 3));
    }

    @Override // L0.InterfaceC0959z
    public final int m0(L0.S s8, J0.L l8, int i) {
        long jK0 = K0(s8);
        if (j1.a.f(jK0)) {
            return j1.a.h(jK0);
        }
        if (!this.f82L) {
            i = j1.b.f(i, jK0);
        }
        return j1.b.g(l8.A(i), jK0);
    }

    @Override // L0.InterfaceC0959z
    public final int w(L0.S s8, J0.L l8, int i) {
        long jK0 = K0(s8);
        if (j1.a.e(jK0)) {
            return j1.a.g(jK0);
        }
        if (!this.f82L) {
            i = j1.b.g(i, jK0);
        }
        return j1.b.f(l8.c(i), jK0);
    }

    @Override // L0.InterfaceC0959z
    public final int w0(L0.S s8, J0.L l8, int i) {
        long jK0 = K0(s8);
        if (j1.a.f(jK0)) {
            return j1.a.h(jK0);
        }
        if (!this.f82L) {
            i = j1.b.f(i, jK0);
        }
        return j1.b.g(l8.w(i), jK0);
    }
}
