package A;

/* JADX INFO: loaded from: classes.dex */
public final class J {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f21a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f22b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f23c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f24d;

    public J(int i, int i4, int i9, int i10) {
        this.f21a = i;
        this.f22b = i4;
        this.f23c = i9;
        this.f24d = i10;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof J)) {
            return false;
        }
        J j9 = (J) obj;
        return this.f21a == j9.f21a && this.f22b == j9.f22b && this.f23c == j9.f23c && this.f24d == j9.f24d;
    }

    public final int hashCode() {
        return (((((this.f21a * 31) + this.f22b) * 31) + this.f23c) * 31) + this.f24d;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("InsetsValues(left=");
        sb.append(this.f21a);
        sb.append(", top=");
        sb.append(this.f22b);
        sb.append(", right=");
        sb.append(this.f23c);
        sb.append(", bottom=");
        return X3.b.k(sb, this.f24d, ')');
    }
}
