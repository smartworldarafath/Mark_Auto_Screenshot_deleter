package A;

/* JADX INFO: renamed from: A.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0004e implements InterfaceC0008i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f83a = 1;

    @Override // A.InterfaceC0008i
    public final void b(int i, J0.O o5, int[] iArr, int[] iArr2) {
        switch (this.f83a) {
            case 0:
                AbstractC0009j.c(i, iArr, iArr2, false);
                break;
            default:
                AbstractC0009j.b(iArr, iArr2, false);
                break;
        }
    }

    public final String toString() {
        switch (this.f83a) {
            case 0:
                return "Arrangement#Bottom";
            default:
                return "Arrangement#Top";
        }
    }
}
