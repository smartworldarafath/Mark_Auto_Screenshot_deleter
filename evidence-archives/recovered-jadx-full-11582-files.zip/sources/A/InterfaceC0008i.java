package A;

/* JADX INFO: renamed from: A.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0008i {
    default float a() {
        return 0;
    }

    void b(int i, J0.O o5, int[] iArr, int[] iArr2);
}
