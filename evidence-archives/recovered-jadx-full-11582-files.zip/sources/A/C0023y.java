package A;

/* JADX INFO: renamed from: A.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0023y extends AbstractC0003d {
    public final p095m0.d i;

    public C0023y(p095m0.h hVar) {
        this.i = hVar;
    }

    @Override // A.AbstractC0003d
    public final int b(int i, j1.m mVar) {
        return this.i.a(0, i, mVar);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C0023y) && p146s7.j.a(this.i, ((C0023y) obj).i);
    }

    public final int hashCode() {
        return this.i.hashCode();
    }

    public final String toString() {
        return "HorizontalCrossAxisAlignment(horizontal=" + this.i + ')';
    }
}
