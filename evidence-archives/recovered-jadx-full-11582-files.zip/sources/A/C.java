package A;

import L0.InterfaceC0959z;

/* JADX INFO: loaded from: classes.dex */
public final class C extends p095m0.q implements InterfaceC0959z {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public A f6H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public float f7I;

    @Override // L0.InterfaceC0959z
    public final J0.N c(J0.O o5, J0.L l8, long j9) {
        int iJ;
        int iH;
        int iG;
        int iG2;
        if (!j1.a.d(j9) || this.f6H == A.f0t) {
            iJ = j1.a.j(j9);
            iH = j1.a.h(j9);
        } else {
            int iRound = Math.round(j1.a.h(j9) * this.f7I);
            int iJ2 = j1.a.j(j9);
            iJ = j1.a.h(j9);
            if (iRound < iJ2) {
                iRound = iJ2;
            }
            if (iRound <= iJ) {
                iJ = iRound;
            }
            iH = iJ;
        }
        if (!j1.a.c(j9) || this.f6H == A.f1u) {
            int i = j1.a.i(j9);
            iG = j1.a.g(j9);
            iG2 = i;
        } else {
            int iRound2 = Math.round(j1.a.g(j9) * this.f7I);
            int i4 = j1.a.i(j9);
            iG2 = j1.a.g(j9);
            if (iRound2 < i4) {
                iRound2 = i4;
            }
            if (iRound2 <= iG2) {
                iG2 = iRound2;
            }
            iG = iG2;
        }
        J0.Y yD = l8.D(j1.b.a(iJ, iH, iG2, iG));
        return o5.p(yD.f5563t, yD.f5564u, p040e7.u.f26996t, new C0010k(yD, 1));
    }
}
