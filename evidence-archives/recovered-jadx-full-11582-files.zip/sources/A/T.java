package A;

import L0.InterfaceC0959z;

/* JADX INFO: loaded from: classes.dex */
public final class T extends p095m0.q implements InterfaceC0959z {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public float f43H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public float f44I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public float f45J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public float f46K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public boolean f47L;

    @Override // L0.InterfaceC0959z
    public final J0.N c(J0.O o5, J0.L l8, long j9) {
        int iJ0 = o5.j0(this.f45J) + o5.j0(this.f43H);
        int iJ1 = o5.j0(this.f46K) + o5.j0(this.f44I);
        J0.Y yD = l8.D(j1.b.i(-iJ0, -iJ1, j9));
        return o5.p(j1.b.g(yD.f5563t + iJ0, j9), j1.b.f(yD.f5564u + iJ1, j9), p040e7.u.f26996t, new Q(1, this, yD));
    }
}
