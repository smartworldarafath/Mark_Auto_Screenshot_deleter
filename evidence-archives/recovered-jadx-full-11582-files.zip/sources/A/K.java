package A;

/* JADX INFO: loaded from: classes.dex */
public final class K extends M {

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public L f25I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public boolean f26J;

    @Override // A.M
    public final long K0(J0.L l8, long j9) {
        int iU = this.f25I == L.f27t ? l8.U(j1.a.h(j9)) : l8.c(j1.a.h(j9));
        if (iU < 0) {
            iU = 0;
        }
        if (iU < 0) {
            j1.i.a("height must be >= 0");
        }
        return j1.b.h(0, Integer.MAX_VALUE, iU, iU);
    }

    @Override // A.M
    public final boolean L0() {
        return this.f26J;
    }

    @Override // A.M, L0.InterfaceC0959z
    public final int S(L0.S s8, J0.L l8, int i) {
        return this.f25I == L.f27t ? l8.U(i) : l8.c(i);
    }

    @Override // A.M, L0.InterfaceC0959z
    public final int w(L0.S s8, J0.L l8, int i) {
        return this.f25I == L.f27t ? l8.U(i) : l8.c(i);
    }
}
