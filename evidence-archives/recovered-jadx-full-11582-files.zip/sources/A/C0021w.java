package A;

import androidx.compose.foundation.layout.LayoutWeightElement;

/* JADX INFO: renamed from: A.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0021w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0021w f169a = new C0021w();

    public static p095m0.r a(p095m0.r rVar) {
        if (1.0f <= 0.0d) {
            B.a.a("invalid weight; must be greater than zero");
        }
        return rVar.e(new LayoutWeightElement(1.0f, true));
    }
}
