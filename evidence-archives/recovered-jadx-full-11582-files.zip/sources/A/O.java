package A;

import L0.t0;

/* JADX INFO: loaded from: classes.dex */
public final class O extends p095m0.q implements t0 {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public float f33H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public boolean f34I;

    @Override // L0.t0
    public final Object A(j1.c cVar, Object obj) {
        Y y8 = obj instanceof Y ? (Y) obj : null;
        if (y8 == null) {
            y8 = new Y();
        }
        y8.f53a = this.f33H;
        y8.f54b = this.f34I;
        return y8;
    }
}
