package A;

/* JADX INFO: renamed from: A.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0024z extends AbstractC0003d {
    public final p095m0.i i;

    public C0024z(p095m0.i iVar) {
        this.i = iVar;
    }

    @Override // A.AbstractC0003d
    public final int b(int i, j1.m mVar) {
        return this.i.a(0, i);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C0024z) && p146s7.j.a(this.i, ((C0024z) obj).i);
    }

    public final int hashCode() {
        return Float.hashCode(this.i.f28586a);
    }

    public final String toString() {
        return "VerticalCrossAxisAlignment(vertical=" + this.i + ')';
    }
}
