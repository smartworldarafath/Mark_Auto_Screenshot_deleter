package A;

/* JADX INFO: loaded from: classes.dex */
public final class P implements i0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i0 f35a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f36b;

    public P(i0 i0Var, int i) {
        this.f35a = i0Var;
        this.f36b = i;
    }

    @Override // A.i0
    public final int a(j1.c cVar, j1.m mVar) {
        if (((mVar == j1.m.f27654t ? 8 : 2) & this.f36b) != 0) {
            return this.f35a.a(cVar, mVar);
        }
        return 0;
    }

    @Override // A.i0
    public final int b(j1.c cVar, j1.m mVar) {
        if (((mVar == j1.m.f27654t ? 4 : 1) & this.f36b) != 0) {
            return this.f35a.b(cVar, mVar);
        }
        return 0;
    }

    @Override // A.i0
    public final int c(j1.c cVar) {
        if ((this.f36b & 16) != 0) {
            return this.f35a.c(cVar);
        }
        return 0;
    }

    @Override // A.i0
    public final int d(j1.c cVar) {
        if ((this.f36b & 32) != 0) {
            return this.f35a.d(cVar);
        }
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof P)) {
            return false;
        }
        P p7 = (P) obj;
        return p146s7.j.a(this.f35a, p7.f35a) && this.f36b == p7.f36b;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f36b) + (this.f35a.hashCode() * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("(");
        sb.append(this.f35a);
        sb.append(" only ");
        StringBuilder sb2 = new StringBuilder("WindowInsetsSides(");
        StringBuilder sb3 = new StringBuilder();
        int i = AbstractC0003d.f73d;
        int i4 = this.f36b;
        if ((i4 & i) == i) {
            AbstractC0003d.h("Start", sb3);
        }
        int i9 = AbstractC0003d.f75f;
        if ((i4 & i9) == i9) {
            AbstractC0003d.h("Left", sb3);
        }
        if ((i4 & 16) == 16) {
            AbstractC0003d.h("Top", sb3);
        }
        int i10 = AbstractC0003d.f74e;
        if ((i4 & i10) == i10) {
            AbstractC0003d.h("End", sb3);
        }
        int i11 = AbstractC0003d.f76g;
        if ((i4 & i11) == i11) {
            AbstractC0003d.h("Right", sb3);
        }
        if ((i4 & 32) == 32) {
            AbstractC0003d.h("Bottom", sb3);
        }
        String string = sb3.toString();
        p146s7.j.d(string, "toString(...)");
        sb2.append(string);
        sb2.append(')');
        sb.append((Object) sb2.toString());
        sb.append(')');
        return sb.toString();
    }
}
