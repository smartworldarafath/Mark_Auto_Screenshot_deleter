package A;

import L0.InterfaceC0959z;

/* JADX INFO: loaded from: classes.dex */
public final class W extends p095m0.q implements InterfaceC0959z {

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public U f52H;

    @Override // L0.InterfaceC0959z
    public final J0.N c(J0.O o5, J0.L l8, long j9) {
        float fC = this.f52H.c(o5.getLayoutDirection());
        float fD = this.f52H.d();
        float fB = this.f52H.b(o5.getLayoutDirection());
        float fA = this.f52H.a();
        float f4 = 0;
        if (!((Float.compare(fA, f4) >= 0) & (Float.compare(fC, f4) >= 0) & (Float.compare(fD, f4) >= 0) & (Float.compare(fB, f4) >= 0))) {
            B.a.a("Padding must be non-negative");
        }
        int iJ0 = o5.j0(fC);
        int iJ1 = o5.j0(fB) + iJ0;
        int iJ2 = o5.j0(fD);
        int iJ3 = o5.j0(fA) + iJ2;
        J0.Y yD = l8.D(j1.b.i(-iJ1, -iJ3, j9));
        return o5.p(j1.b.g(yD.f5563t + iJ1, j9), j1.b.f(yD.f5564u + iJ3, j9), p040e7.u.f26996t, new G(yD, iJ0, iJ2, 1));
    }
}
