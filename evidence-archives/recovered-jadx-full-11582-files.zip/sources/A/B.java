package A;

/* JADX INFO: loaded from: classes.dex */
public final class B implements i0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i0 f4a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final i0 f5b;

    public B(i0 i0Var, i0 i0Var2) {
        this.f4a = i0Var;
        this.f5b = i0Var2;
    }

    @Override // A.i0
    public final int a(j1.c cVar, j1.m mVar) {
        int iA = this.f4a.a(cVar, mVar) - this.f5b.a(cVar, mVar);
        if (iA < 0) {
            return 0;
        }
        return iA;
    }

    @Override // A.i0
    public final int b(j1.c cVar, j1.m mVar) {
        int iB = this.f4a.b(cVar, mVar) - this.f5b.b(cVar, mVar);
        if (iB < 0) {
            return 0;
        }
        return iB;
    }

    @Override // A.i0
    public final int c(j1.c cVar) {
        int iC = this.f4a.c(cVar) - this.f5b.c(cVar);
        if (iC < 0) {
            return 0;
        }
        return iC;
    }

    @Override // A.i0
    public final int d(j1.c cVar) {
        int iD = this.f4a.d(cVar) - this.f5b.d(cVar);
        if (iD < 0) {
            return 0;
        }
        return iD;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof B)) {
            return false;
        }
        B b9 = (B) obj;
        return p146s7.j.a(b9.f4a, this.f4a) && p146s7.j.a(b9.f5b, this.f5b);
    }

    public final int hashCode() {
        return this.f5b.hashCode() + (this.f4a.hashCode() * 31);
    }

    public final String toString() {
        return "(" + this.f4a + " - " + this.f5b + ')';
    }
}
