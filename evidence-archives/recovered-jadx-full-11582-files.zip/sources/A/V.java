package A;

/* JADX INFO: loaded from: classes.dex */
public final class V implements U {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f48a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f49b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f50c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f51d;

    public V(float f4, float f9, float f10, float f11) {
        this.f48a = f4;
        this.f49b = f9;
        this.f50c = f10;
        this.f51d = f11;
        if (!((f4 >= 0.0f) & (f9 >= 0.0f) & (f10 >= 0.0f)) || !(f11 >= 0.0f)) {
            B.a.a("Padding must be non-negative");
        }
    }

    @Override // A.U
    public final float a() {
        return this.f51d;
    }

    @Override // A.U
    public final float b(j1.m mVar) {
        return mVar == j1.m.f27654t ? this.f50c : this.f48a;
    }

    @Override // A.U
    public final float c(j1.m mVar) {
        return mVar == j1.m.f27654t ? this.f48a : this.f50c;
    }

    @Override // A.U
    public final float d() {
        return this.f49b;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof V)) {
            return false;
        }
        V v5 = (V) obj;
        return j1.f.a(this.f48a, v5.f48a) && j1.f.a(this.f49b, v5.f49b) && j1.f.a(this.f50c, v5.f50c) && j1.f.a(this.f51d, v5.f51d);
    }

    public final int hashCode() {
        return Float.hashCode(this.f51d) + p127q3.h.b(this.f50c, p127q3.h.b(this.f49b, Float.hashCode(this.f48a) * 31, 31), 31);
    }

    public final String toString() {
        return "PaddingValues(start=" + ((Object) j1.f.b(this.f48a)) + ", top=" + ((Object) j1.f.b(this.f49b)) + ", end=" + ((Object) j1.f.b(this.f50c)) + ", bottom=" + ((Object) j1.f.b(this.f51d)) + ')';
    }
}
