package androidx.browser.browseractions;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import com.markOne.ss_app.R;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
public class BrowserActionsFallbackMenuView extends LinearLayout {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f12992t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final int f12993u;

    public BrowserActionsFallbackMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f12992t = getResources().getDimensionPixelOffset(R.dimen.browser_actions_context_menu_min_padding);
        this.f12993u = getResources().getDimensionPixelOffset(R.dimen.browser_actions_context_menu_max_width);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i, int i4) {
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(Math.min(getResources().getDisplayMetrics().widthPixels - (this.f12992t * 2), this.f12993u), 1073741824), i4);
    }
}
