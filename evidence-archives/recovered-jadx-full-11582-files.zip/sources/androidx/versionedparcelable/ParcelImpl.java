package androidx.versionedparcelable;

import D2.a;
import D2.c;
import D2.d;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new a(0);

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final d f13563t;

    public ParcelImpl(Parcel parcel) {
        this.f13563t = new c(parcel).g();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        new c(parcel).i(this.f13563t);
    }
}
