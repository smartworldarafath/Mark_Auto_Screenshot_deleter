package androidx.versionedparcelable;

import D2.d;

/* JADX INFO: loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements d {
}
