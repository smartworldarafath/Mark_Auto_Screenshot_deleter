package androidx.lifecycle;

import E4.X2;
import android.os.Looper;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class D {
    public static final Object i = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f13453a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p103n.f f13454b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile Object f13455c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public volatile Object f13456d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f13457e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f13458f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f13459g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final B f13460h;

    public D(int i4) {
        G2.C c9 = G2.y.f3175c;
        this.f13453a = new Object();
        this.f13454b = new p103n.f();
        this.f13456d = i;
        this.f13460h = new B(this);
        this.f13455c = c9;
        this.f13457e = 0;
    }

    public static void a(String str) {
        p094m.a.a().f28559a.getClass();
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException(p127q3.h.i("Cannot invoke ", str, " on a background thread"));
        }
    }

    public final void b(C c9) {
        c9.getClass();
    }

    public final void c(C c9) {
        if (this.f13458f) {
            this.f13459g = true;
            return;
        }
        this.f13458f = true;
        do {
            this.f13459g = false;
            p103n.f fVar = this.f13454b;
            fVar.getClass();
            p103n.d dVar = new p103n.d(fVar);
            fVar.f29383v.put(dVar, Boolean.FALSE);
            while (dVar.hasNext()) {
                b((C) ((Map.Entry) dVar.next()).getValue());
                if (this.f13459g) {
                    break;
                }
            }
        } while (this.f13459g);
        this.f13458f = false;
    }

    public final void d(X2 x8) {
        boolean z8;
        synchronized (this.f13453a) {
            z8 = this.f13456d == i;
            this.f13456d = x8;
        }
        if (z8) {
            p094m.a aVarA = p094m.a.a();
            B b9 = this.f13460h;
            p094m.b bVar = aVarA.f28559a;
            if (bVar.f28562c == null) {
                synchronized (bVar.f28560a) {
                    try {
                        if (bVar.f28562c == null) {
                            bVar.f28562c = p094m.b.a(Looper.getMainLooper());
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            }
            bVar.f28562c.post(b9);
        }
    }

    public D() {
        this.f13453a = new Object();
        this.f13454b = new p103n.f();
        Object obj = i;
        this.f13456d = obj;
        this.f13460h = new B(this);
        this.f13455c = obj;
        this.f13457e = -1;
    }
}
