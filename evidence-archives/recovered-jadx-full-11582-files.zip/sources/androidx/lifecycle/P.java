package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public class P extends Fragment {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final /* synthetic */ int f13491u = 0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public e0 f13492t;

    public static final class a implements Application.ActivityLifecycleCallbacks {
        public static final O Companion = new O();

        public static final void registerIn(Activity activity) {
            Companion.getClass();
            p146s7.j.e(activity, "activity");
            activity.registerActivityLifecycleCallbacks(new a());
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            p146s7.j.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
            p146s7.j.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            p146s7.j.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostCreated(Activity activity, Bundle bundle) {
            p146s7.j.e(activity, "activity");
            int i = P.f13491u;
            N.a(activity, EnumC1404o.ON_CREATE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            p146s7.j.e(activity, "activity");
            int i = P.f13491u;
            N.a(activity, EnumC1404o.ON_RESUME);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            p146s7.j.e(activity, "activity");
            int i = P.f13491u;
            N.a(activity, EnumC1404o.ON_START);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreDestroyed(Activity activity) {
            p146s7.j.e(activity, "activity");
            int i = P.f13491u;
            N.a(activity, EnumC1404o.ON_DESTROY);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPrePaused(Activity activity) {
            p146s7.j.e(activity, "activity");
            int i = P.f13491u;
            N.a(activity, EnumC1404o.ON_PAUSE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreStopped(Activity activity) {
            p146s7.j.e(activity, "activity");
            int i = P.f13491u;
            N.a(activity, EnumC1404o.ON_STOP);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
            p146s7.j.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
            p146s7.j.e(activity, "activity");
            p146s7.j.e(bundle, "bundle");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
            p146s7.j.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
            p146s7.j.e(activity, "activity");
        }
    }

    public final void a(EnumC1404o enumC1404o) {
        if (Build.VERSION.SDK_INT < 29) {
            Activity activity = getActivity();
            p146s7.j.d(activity, "getActivity(...)");
            N.a(activity, enumC1404o);
        }
    }

    @Override // android.app.Fragment
    public final void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        a(EnumC1404o.ON_CREATE);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        a(EnumC1404o.ON_DESTROY);
        this.f13492t = null;
    }

    @Override // android.app.Fragment
    public final void onPause() {
        super.onPause();
        a(EnumC1404o.ON_PAUSE);
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        e0 e0Var = this.f13492t;
        if (e0Var != null) {
            ((H) e0Var.f13532a).b();
        }
        a(EnumC1404o.ON_RESUME);
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        e0 e0Var = this.f13492t;
        if (e0Var != null) {
            H h9 = (H) e0Var.f13532a;
            int i = h9.f13463t + 1;
            h9.f13463t = i;
            if (i == 1 && h9.f13466w) {
                h9.f13467y.L(EnumC1404o.ON_START);
                h9.f13466w = false;
            }
        }
        a(EnumC1404o.ON_START);
    }

    @Override // android.app.Fragment
    public final void onStop() {
        super.onStop();
        a(EnumC1404o.ON_STOP);
    }
}
