package androidx.lifecycle;

import java.util.HashMap;

/* JADX INFO: renamed from: androidx.lifecycle.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1394e implements InterfaceC1409u {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f13529t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Object f13530u;

    public /* synthetic */ C1394e(int i, Object obj) {
        this.f13529t = i;
        this.f13530u = obj;
    }

    @Override // androidx.lifecycle.InterfaceC1409u
    public final void l(InterfaceC1411w interfaceC1411w, EnumC1404o enumC1404o) {
        switch (this.f13529t) {
            case 0:
                new HashMap();
                InterfaceC1399j[] interfaceC1399jArr = (InterfaceC1399j[]) this.f13530u;
                if (interfaceC1399jArr.length > 0) {
                    InterfaceC1399j interfaceC1399j = interfaceC1399jArr[0];
                    throw null;
                }
                if (interfaceC1399jArr.length <= 0) {
                    return;
                }
                InterfaceC1399j interfaceC1399j2 = interfaceC1399jArr[0];
                throw null;
            default:
                if (enumC1404o == EnumC1404o.ON_CREATE) {
                    interfaceC1411w.g().z(this);
                    ((V) this.f13530u).b();
                    return;
                } else {
                    throw new IllegalStateException(("Next event must be ON_CREATE, it was " + enumC1404o).toString());
                }
        }
    }
}
