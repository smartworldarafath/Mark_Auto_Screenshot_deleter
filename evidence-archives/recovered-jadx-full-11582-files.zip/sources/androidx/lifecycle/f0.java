package androidx.lifecycle;

import java.util.Iterator;
import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class f0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f13533a = new LinkedHashMap();

    public final void a() {
        LinkedHashMap linkedHashMap = this.f13533a;
        Iterator it = linkedHashMap.values().iterator();
        while (it.hasNext()) {
            ((a0) it.next()).b();
        }
        linkedHashMap.clear();
    }
}
