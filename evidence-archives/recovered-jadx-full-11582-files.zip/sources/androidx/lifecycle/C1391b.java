package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: renamed from: androidx.lifecycle.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1391b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f13518a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f13519b;

    public C1391b(HashMap map) {
        this.f13519b = map;
        for (Map.Entry entry : map.entrySet()) {
            EnumC1404o enumC1404o = (EnumC1404o) entry.getValue();
            List arrayList = (List) this.f13518a.get(enumC1404o);
            if (arrayList == null) {
                arrayList = new ArrayList();
                this.f13518a.put(enumC1404o, arrayList);
            }
            arrayList.add((C1392c) entry.getKey());
        }
    }

    public static void a(List list, InterfaceC1411w interfaceC1411w, EnumC1404o enumC1404o, Object obj) {
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                C1392c c1392c = (C1392c) list.get(size);
                Method method = c1392c.f13524b;
                try {
                    int i = c1392c.f13523a;
                    if (i == 0) {
                        method.invoke(obj, null);
                    } else if (i == 1) {
                        method.invoke(obj, interfaceC1411w);
                    } else if (i == 2) {
                        method.invoke(obj, interfaceC1411w, enumC1404o);
                    }
                } catch (IllegalAccessException e4) {
                    throw new RuntimeException(e4);
                } catch (InvocationTargetException e9) {
                    throw new RuntimeException("Failed to call observer method", e9.getCause());
                }
            }
        }
    }
}
