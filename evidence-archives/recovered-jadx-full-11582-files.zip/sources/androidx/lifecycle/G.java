package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class G extends AbstractC1398i {
    final /* synthetic */ H this$0;

    public static final class a extends AbstractC1398i {
        final /* synthetic */ H this$0;

        public a(H h9) {
            this.this$0 = h9;
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            p146s7.j.e(activity, "activity");
            this.this$0.b();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            p146s7.j.e(activity, "activity");
            H h9 = this.this$0;
            int i = h9.f13463t + 1;
            h9.f13463t = i;
            if (i == 1 && h9.f13466w) {
                h9.f13467y.L(EnumC1404o.ON_START);
                h9.f13466w = false;
            }
        }
    }

    public G(H h9) {
        this.this$0 = h9;
    }

    @Override // androidx.lifecycle.AbstractC1398i, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        p146s7.j.e(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i = P.f13491u;
            Fragment fragmentFindFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            p146s7.j.c(fragmentFindFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((P) fragmentFindFragmentByTag).f13492t = this.this$0.f13462A;
        }
    }

    @Override // androidx.lifecycle.AbstractC1398i, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        p146s7.j.e(activity, "activity");
        H h9 = this.this$0;
        int i = h9.f13464u - 1;
        h9.f13464u = i;
        if (i == 0) {
            Handler handler = h9.x;
            p146s7.j.b(handler);
            handler.postDelayed(h9.f13468z, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        p146s7.j.e(activity, "activity");
        F.a(activity, new a(this.this$0));
    }

    @Override // androidx.lifecycle.AbstractC1398i, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        p146s7.j.e(activity, "activity");
        H h9 = this.this$0;
        int i = h9.f13463t - 1;
        h9.f13463t = i;
        if (i == 0 && h9.f13465v) {
            h9.f13467y.L(EnumC1404o.ON_STOP);
            h9.f13466w = true;
        }
    }
}
