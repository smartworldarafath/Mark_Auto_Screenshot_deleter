package androidx.lifecycle;

import H4.L4;

/* JADX INFO: loaded from: classes.dex */
public interface c0 {
    default a0 a(Class cls) {
        throw new UnsupportedOperationException("`Factory.create(String, CreationExtras)` is not implemented. You may need to override the method and provide a custom implementation. Note that using `Factory.create(String)` is not supported and considered an error.");
    }

    default a0 b(Class cls, Y1.d dVar) {
        return a(cls);
    }

    default a0 c(p146s7.e eVar, Y1.d dVar) {
        return b(L4.a(eVar), dVar);
    }
}
