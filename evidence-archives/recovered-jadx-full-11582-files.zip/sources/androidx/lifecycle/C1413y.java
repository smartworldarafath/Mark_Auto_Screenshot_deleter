package androidx.lifecycle;

import android.os.Looper;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: renamed from: androidx.lifecycle.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1413y extends E.V {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public boolean f13550A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public boolean f13551B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final ArrayList f13552C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final G7.g0 f13553D;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final boolean f13554v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public p103n.a f13555w;
    public EnumC1405p x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final WeakReference f13556y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f13557z;

    public C1413y(InterfaceC1411w interfaceC1411w, boolean z8) {
        super(5);
        this.f13554v = z8;
        this.f13555w = new p103n.a();
        EnumC1405p enumC1405p = EnumC1405p.f13540u;
        this.x = enumC1405p;
        this.f13552C = new ArrayList();
        this.f13556y = new WeakReference(interfaceC1411w);
        this.f13553D = G7.W.b(enumC1405p);
    }

    public final EnumC1405p J(InterfaceC1410v interfaceC1410v) {
        HashMap map = this.f13555w.x;
        p103n.c cVar = map.containsKey(interfaceC1410v) ? ((p103n.c) map.get(interfaceC1410v)).f29377w : null;
        EnumC1405p enumC1405p = cVar != null ? ((C1412x) cVar.f29375u).f13548a : null;
        ArrayList arrayList = this.f13552C;
        EnumC1405p enumC1405p2 = arrayList.isEmpty() ? null : (EnumC1405p) arrayList.get(arrayList.size() - 1);
        EnumC1405p enumC1405p3 = this.x;
        p146s7.j.e(enumC1405p3, "state1");
        if (enumC1405p == null || enumC1405p.compareTo(enumC1405p3) >= 0) {
            enumC1405p = enumC1405p3;
        }
        return (enumC1405p2 == null || enumC1405p2.compareTo(enumC1405p) >= 0) ? enumC1405p : enumC1405p2;
    }

    public final void K(String str) {
        if (this.f13554v) {
            p094m.a.a().f28559a.getClass();
            if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
                throw new IllegalStateException(p127q3.h.i("Method ", str, " must be called on the main thread").toString());
            }
        }
    }

    public final void L(EnumC1404o enumC1404o) {
        p146s7.j.e(enumC1404o, "event");
        K("handleLifecycleEvent");
        M(enumC1404o.a());
    }

    public final void M(EnumC1405p enumC1405p) {
        if (this.x == enumC1405p) {
            return;
        }
        InterfaceC1411w interfaceC1411w = (InterfaceC1411w) this.f13556y.get();
        EnumC1405p enumC1405p2 = this.x;
        p146s7.j.e(enumC1405p2, "current");
        p146s7.j.e(enumC1405p, "next");
        EnumC1405p enumC1405p3 = EnumC1405p.f13540u;
        EnumC1405p enumC1405p4 = EnumC1405p.f13539t;
        if (enumC1405p2 == enumC1405p3 && enumC1405p == enumC1405p4) {
            throw new IllegalStateException(("State must be at least '" + EnumC1405p.f13541v + "' to be moved to '" + enumC1405p + "' in component " + interfaceC1411w).toString());
        }
        if (enumC1405p2 == enumC1405p4 && enumC1405p2 != enumC1405p) {
            throw new IllegalStateException(("State is '" + enumC1405p4 + "' and cannot be moved to `" + enumC1405p + "` in component " + interfaceC1411w).toString());
        }
        this.x = enumC1405p;
        if (this.f13550A || this.f13557z != 0) {
            this.f13551B = true;
            return;
        }
        this.f13550A = true;
        O();
        this.f13550A = false;
        if (this.x == enumC1405p4) {
            this.f13555w = new p103n.a();
        }
    }

    public final void N(EnumC1405p enumC1405p) {
        p146s7.j.e(enumC1405p, "state");
        K("setCurrentState");
        M(enumC1405p);
    }

    public final void O() {
        EnumC1404o enumC1404o;
        EnumC1404o enumC1404o2;
        InterfaceC1411w interfaceC1411w = (InterfaceC1411w) this.f13556y.get();
        if (interfaceC1411w == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
        while (true) {
            p103n.a aVar = this.f13555w;
            if (aVar.f29384w != 0) {
                p103n.c cVar = aVar.f29381t;
                p146s7.j.b(cVar);
                EnumC1405p enumC1405p = ((C1412x) cVar.f29375u).f13548a;
                p103n.c cVar2 = this.f13555w.f29382u;
                p146s7.j.b(cVar2);
                EnumC1405p enumC1405p2 = ((C1412x) cVar2.f29375u).f13548a;
                if (enumC1405p == enumC1405p2 && this.x == enumC1405p2) {
                    break;
                }
                this.f13551B = false;
                EnumC1405p enumC1405p3 = this.x;
                p103n.c cVar3 = this.f13555w.f29381t;
                p146s7.j.b(cVar3);
                if (enumC1405p3.compareTo(((C1412x) cVar3.f29375u).f13548a) < 0) {
                    p103n.a aVar2 = this.f13555w;
                    p103n.b bVar = new p103n.b(aVar2.f29382u, aVar2.f29381t, 1);
                    aVar2.f29383v.put(bVar, Boolean.FALSE);
                    while (bVar.hasNext() && !this.f13551B) {
                        Map.Entry entry = (Map.Entry) bVar.next();
                        p146s7.j.b(entry);
                        InterfaceC1410v interfaceC1410v = (InterfaceC1410v) entry.getKey();
                        C1412x c1412x = (C1412x) entry.getValue();
                        while (c1412x.f13548a.compareTo(this.x) > 0 && !this.f13551B && this.f13555w.x.containsKey(interfaceC1410v)) {
                            C1402m c1402m = EnumC1404o.Companion;
                            EnumC1405p enumC1405p4 = c1412x.f13548a;
                            c1402m.getClass();
                            p146s7.j.e(enumC1405p4, "state");
                            int iOrdinal = enumC1405p4.ordinal();
                            if (iOrdinal == 2) {
                                enumC1404o2 = EnumC1404o.ON_DESTROY;
                            } else if (iOrdinal != 3) {
                                enumC1404o2 = iOrdinal != 4 ? null : EnumC1404o.ON_PAUSE;
                            } else {
                                enumC1404o2 = EnumC1404o.ON_STOP;
                            }
                            if (enumC1404o2 == null) {
                                throw new IllegalStateException("no event down from " + c1412x.f13548a);
                            }
                            this.f13552C.add(enumC1404o2.a());
                            c1412x.a(interfaceC1411w, enumC1404o2);
                            ArrayList arrayList = this.f13552C;
                            arrayList.remove(arrayList.size() - 1);
                        }
                    }
                }
                p103n.c cVar4 = this.f13555w.f29382u;
                if (!this.f13551B && cVar4 != null && this.x.compareTo(((C1412x) cVar4.f29375u).f13548a) > 0) {
                    p103n.a aVar3 = this.f13555w;
                    aVar3.getClass();
                    p103n.d dVar = new p103n.d(aVar3);
                    aVar3.f29383v.put(dVar, Boolean.FALSE);
                    while (dVar.hasNext() && !this.f13551B) {
                        Map.Entry entry2 = (Map.Entry) dVar.next();
                        InterfaceC1410v interfaceC1410v2 = (InterfaceC1410v) entry2.getKey();
                        C1412x c1412x2 = (C1412x) entry2.getValue();
                        while (c1412x2.f13548a.compareTo(this.x) < 0 && !this.f13551B && this.f13555w.x.containsKey(interfaceC1410v2)) {
                            this.f13552C.add(c1412x2.f13548a);
                            C1402m c1402m2 = EnumC1404o.Companion;
                            EnumC1405p enumC1405p5 = c1412x2.f13548a;
                            c1402m2.getClass();
                            p146s7.j.e(enumC1405p5, "state");
                            int iOrdinal2 = enumC1405p5.ordinal();
                            if (iOrdinal2 == 1) {
                                enumC1404o = EnumC1404o.ON_CREATE;
                            } else if (iOrdinal2 != 2) {
                                enumC1404o = iOrdinal2 != 3 ? null : EnumC1404o.ON_RESUME;
                            } else {
                                enumC1404o = EnumC1404o.ON_START;
                            }
                            if (enumC1404o == null) {
                                throw new IllegalStateException("no event up from " + c1412x2.f13548a);
                            }
                            c1412x2.a(interfaceC1411w, enumC1404o);
                            ArrayList arrayList2 = this.f13552C;
                            arrayList2.remove(arrayList2.size() - 1);
                        }
                    }
                }
            } else {
                break;
            }
        }
        this.f13551B = false;
        this.f13553D.i(this.x);
    }

    @Override // E.V
    public final void l(InterfaceC1410v interfaceC1410v) {
        InterfaceC1409u c1397h;
        Object obj;
        InterfaceC1411w interfaceC1411w;
        EnumC1404o enumC1404o;
        p146s7.j.e(interfaceC1410v, "observer");
        K("addObserver");
        EnumC1405p enumC1405p = this.x;
        EnumC1405p enumC1405p2 = EnumC1405p.f13539t;
        if (enumC1405p != enumC1405p2) {
            enumC1405p2 = EnumC1405p.f13540u;
        }
        C1412x c1412x = new C1412x();
        HashMap map = A.f13449a;
        boolean z8 = interfaceC1410v instanceof InterfaceC1409u;
        boolean z9 = interfaceC1410v instanceof InterfaceC1395f;
        int i = 0;
        if (z8 && z9) {
            c1397h = new C1397h((InterfaceC1395f) interfaceC1410v, (InterfaceC1409u) interfaceC1410v);
        } else if (z9) {
            c1397h = new C1397h((InterfaceC1395f) interfaceC1410v, (InterfaceC1409u) null);
        } else if (z8) {
            c1397h = (InterfaceC1409u) interfaceC1410v;
        } else {
            Class<?> cls = interfaceC1410v.getClass();
            if (A.b(cls) == 2) {
                Object obj2 = A.f13450b.get(cls);
                p146s7.j.b(obj2);
                List list = (List) obj2;
                if (list.size() == 1) {
                    A.a((Constructor) list.get(0), interfaceC1410v);
                    throw null;
                }
                int size = list.size();
                InterfaceC1399j[] interfaceC1399jArr = new InterfaceC1399j[size];
                if (size > 0) {
                    A.a((Constructor) list.get(0), interfaceC1410v);
                    throw null;
                }
                c1397h = new C1394e(i, interfaceC1399jArr);
            } else {
                c1397h = new C1397h(interfaceC1410v);
            }
        }
        c1412x.f13549b = c1397h;
        c1412x.f13548a = enumC1405p2;
        p103n.a aVar = this.f13555w;
        p103n.c cVarB = aVar.b(interfaceC1410v);
        if (cVarB != null) {
            obj = cVarB.f29375u;
        } else {
            HashMap map2 = aVar.x;
            p103n.c cVar = new p103n.c(interfaceC1410v, c1412x);
            aVar.f29384w++;
            p103n.c cVar2 = aVar.f29382u;
            if (cVar2 == null) {
                aVar.f29381t = cVar;
                aVar.f29382u = cVar;
            } else {
                cVar2.f29376v = cVar;
                cVar.f29377w = cVar2;
                aVar.f29382u = cVar;
            }
            map2.put(interfaceC1410v, cVar);
            obj = null;
        }
        if (((C1412x) obj) == null && (interfaceC1411w = (InterfaceC1411w) this.f13556y.get()) != null) {
            i = (this.f13557z != 0 || this.f13550A) ? 1 : 0;
            EnumC1405p enumC1405pJ = J(interfaceC1410v);
            this.f13557z++;
            while (c1412x.f13548a.compareTo(enumC1405pJ) < 0 && this.f13555w.x.containsKey(interfaceC1410v)) {
                EnumC1405p enumC1405p3 = c1412x.f13548a;
                ArrayList arrayList = this.f13552C;
                arrayList.add(enumC1405p3);
                C1402m c1402m = EnumC1404o.Companion;
                EnumC1405p enumC1405p4 = c1412x.f13548a;
                c1402m.getClass();
                p146s7.j.e(enumC1405p4, "state");
                int iOrdinal = enumC1405p4.ordinal();
                if (iOrdinal == 1) {
                    enumC1404o = EnumC1404o.ON_CREATE;
                } else if (iOrdinal != 2) {
                    enumC1404o = iOrdinal != 3 ? null : EnumC1404o.ON_RESUME;
                } else {
                    enumC1404o = EnumC1404o.ON_START;
                }
                if (enumC1404o == null) {
                    throw new IllegalStateException("no event up from " + c1412x.f13548a);
                }
                c1412x.a(interfaceC1411w, enumC1404o);
                arrayList.remove(arrayList.size() - 1);
                enumC1405pJ = J(interfaceC1410v);
            }
            if (i == 0) {
                O();
            }
            this.f13557z--;
        }
    }

    @Override // E.V
    public final EnumC1405p s() {
        return this.x;
    }

    @Override // E.V
    public final void z(InterfaceC1410v interfaceC1410v) {
        p146s7.j.e(interfaceC1410v, "observer");
        K("removeObserver");
        this.f13555w.c(interfaceC1410v);
    }
}
