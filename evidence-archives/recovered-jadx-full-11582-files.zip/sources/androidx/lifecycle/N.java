package androidx.lifecycle;

import android.app.Activity;
import android.app.FragmentManager;
import android.os.Build;

/* JADX INFO: loaded from: classes.dex */
public abstract class N {
    /* JADX WARN: Multi-variable type inference failed */
    public static void a(Activity activity, EnumC1404o enumC1404o) {
        p146s7.j.e(enumC1404o, "event");
        if (activity instanceof InterfaceC1411w) {
            E.V vG = ((InterfaceC1411w) activity).g();
            if (vG instanceof C1413y) {
                ((C1413y) vG).L(enumC1404o);
            }
        }
    }

    public static void b(Activity activity) {
        if (Build.VERSION.SDK_INT >= 29) {
            P.a.Companion.getClass();
            activity.registerActivityLifecycleCallbacks(new P.a());
        }
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new P(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }
}
