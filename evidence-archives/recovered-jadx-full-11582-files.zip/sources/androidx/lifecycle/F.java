package androidx.lifecycle;

import android.app.Activity;

/* JADX INFO: loaded from: classes.dex */
public abstract class F {
    public static final void a(Activity activity, G.a aVar) {
        activity.registerActivityLifecycleCallbacks(aVar);
    }
}
