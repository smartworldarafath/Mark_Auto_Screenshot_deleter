package androidx.lifecycle;

import F4.Z6;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public abstract class A {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final HashMap f13449a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final HashMap f13450b = new HashMap();

    public static void a(Constructor constructor, InterfaceC1410v interfaceC1410v) {
        try {
            p146s7.j.b(constructor.newInstance(interfaceC1410v));
            throw new ClassCastException();
        } catch (IllegalAccessException e4) {
            throw new RuntimeException(e4);
        } catch (InstantiationException e9) {
            throw new RuntimeException(e9);
        } catch (InvocationTargetException e10) {
            throw new RuntimeException(e10);
        }
    }

    /* JADX WARN: Code duplicated, block: B:61:0x010f  */
    /* JADX WARN: Code duplicated, block: B:66:0x011f  */
    /* JADX WARN: Code duplicated, block: B:72:0x012d A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:73:0x012f  */
    /* JADX WARN: Code duplicated, block: B:76:0x0143  */
    /* JADX WARN: Code duplicated, block: B:86:0x0123 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:88:0x0148 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:90:0x0109 A[SYNTHETIC] */
    public static int b(Class cls) {
        Constructor<?> declaredConstructor;
        boolean zBooleanValue;
        P7.h hVarI;
        Class cls2;
        boolean z8;
        HashMap map = f13449a;
        Integer num = (Integer) map.get(cls);
        if (num != null) {
            return num.intValue();
        }
        int i = 1;
        if (cls.getCanonicalName() != null) {
            ArrayList arrayList = null;
            try {
                Package r8 = cls.getPackage();
                String canonicalName = cls.getCanonicalName();
                String name = r8 != null ? r8.getName() : "";
                p146s7.j.b(name);
                if (name.length() != 0) {
                    p146s7.j.b(canonicalName);
                    canonicalName = canonicalName.substring(name.length() + 1);
                    p146s7.j.d(canonicalName, "substring(...)");
                }
                p146s7.j.b(canonicalName);
                String strConcat = A7.v.l(canonicalName, ".", "_").concat("_LifecycleAdapter");
                if (name.length() != 0) {
                    strConcat = name + '.' + strConcat;
                }
                declaredConstructor = Class.forName(strConcat).getDeclaredConstructor(cls);
                if (!declaredConstructor.isAccessible()) {
                    declaredConstructor.setAccessible(true);
                }
            } catch (ClassNotFoundException unused) {
                declaredConstructor = null;
            } catch (NoSuchMethodException e4) {
                throw new RuntimeException(e4);
            }
            HashMap map2 = f13450b;
            if (declaredConstructor != null) {
                map2.put(cls, Z6.c(declaredConstructor));
            } else {
                C1393d c1393d = C1393d.f13525c;
                HashMap map3 = c1393d.f13527b;
                Boolean bool = (Boolean) map3.get(cls);
                if (bool != null) {
                    zBooleanValue = bool.booleanValue();
                } else {
                    try {
                        Method[] declaredMethods = cls.getDeclaredMethods();
                        int length = declaredMethods.length;
                        int i4 = 0;
                        while (true) {
                            if (i4 >= length) {
                                map3.put(cls, Boolean.FALSE);
                                zBooleanValue = false;
                                break;
                            }
                            if (((E) declaredMethods[i4].getAnnotation(E.class)) != null) {
                                c1393d.a(cls, declaredMethods);
                                zBooleanValue = true;
                                break;
                            }
                            i4++;
                        }
                    } catch (NoClassDefFoundError e9) {
                        throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e9);
                    }
                }
                if (!zBooleanValue) {
                    Class superclass = cls.getSuperclass();
                    if (superclass != null && InterfaceC1410v.class.isAssignableFrom(superclass)) {
                        p146s7.j.b(superclass);
                        if (b(superclass) != 1) {
                            Object obj = map2.get(superclass);
                            p146s7.j.b(obj);
                            arrayList = new ArrayList((Collection) obj);
                            hVarI = p146s7.j.i(cls.getInterfaces());
                            while (hVarI.hasNext()) {
                                cls2 = (Class) hVarI.next();
                                if (cls2 == null && InterfaceC1410v.class.isAssignableFrom(cls2)) {
                                    z8 = true;
                                } else {
                                    z8 = false;
                                }
                                if (!z8) {
                                    p146s7.j.b(cls2);
                                    if (b(cls2) == 1) {
                                        if (arrayList == null) {
                                            arrayList = new ArrayList();
                                        }
                                        Object obj2 = map2.get(cls2);
                                        p146s7.j.b(obj2);
                                        arrayList.addAll((Collection) obj2);
                                    }
                                }
                            }
                            if (arrayList != null) {
                                map2.put(cls, arrayList);
                            }
                        }
                    } else {
                        hVarI = p146s7.j.i(cls.getInterfaces());
                        while (hVarI.hasNext()) {
                            cls2 = (Class) hVarI.next();
                            if (cls2 == null) {
                                z8 = false;
                            } else {
                                z8 = false;
                            }
                            if (!z8) {
                                p146s7.j.b(cls2);
                                if (b(cls2) == 1) {
                                    if (arrayList == null) {
                                        arrayList = new ArrayList();
                                    }
                                    Object obj3 = map2.get(cls2);
                                    p146s7.j.b(obj3);
                                    arrayList.addAll((Collection) obj3);
                                }
                            }
                        }
                        if (arrayList != null) {
                            map2.put(cls, arrayList);
                        }
                    }
                }
            }
            i = 2;
        }
        map.put(cls, Integer.valueOf(i));
        return i;
    }
}
