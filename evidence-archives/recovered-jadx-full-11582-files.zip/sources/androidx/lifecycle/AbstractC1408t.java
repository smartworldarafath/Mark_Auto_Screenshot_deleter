package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: renamed from: androidx.lifecycle.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1408t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final AtomicBoolean f13547a = new AtomicBoolean(false);
}
