package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class B implements Runnable {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ D f13451t;

    public B(D d2) {
        this.f13451t = d2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        synchronized (this.f13451t.f13453a) {
            obj = this.f13451t.f13456d;
            this.f13451t.f13456d = D.i;
        }
        D d2 = this.f13451t;
        D.a("setValue");
        d2.f13457e++;
        d2.f13455c = obj;
        d2.c(null);
    }
}
