package androidx.lifecycle;

/* JADX INFO: renamed from: androidx.lifecycle.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1395f extends InterfaceC1410v {
    default void c(InterfaceC1411w interfaceC1411w) {
        p146s7.j.e(interfaceC1411w, "owner");
    }

    default void n(InterfaceC1411w interfaceC1411w) {
    }

    default void onStart(InterfaceC1411w interfaceC1411w) {
        p146s7.j.e(interfaceC1411w, "owner");
    }

    default void onStop(InterfaceC1411w interfaceC1411w) {
    }
}
