package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: androidx.lifecycle.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC1404o {
    private static final /* synthetic */ p084k7.a $ENTRIES;
    private static final /* synthetic */ EnumC1404o[] $VALUES;
    public static final C1402m Companion;
    public static final EnumC1404o ON_ANY;
    public static final EnumC1404o ON_CREATE;
    public static final EnumC1404o ON_DESTROY;
    public static final EnumC1404o ON_PAUSE;
    public static final EnumC1404o ON_RESUME;
    public static final EnumC1404o ON_START;
    public static final EnumC1404o ON_STOP;

    static {
        EnumC1404o enumC1404o = new EnumC1404o("ON_CREATE", 0);
        ON_CREATE = enumC1404o;
        EnumC1404o enumC1404o2 = new EnumC1404o("ON_START", 1);
        ON_START = enumC1404o2;
        EnumC1404o enumC1404o3 = new EnumC1404o("ON_RESUME", 2);
        ON_RESUME = enumC1404o3;
        EnumC1404o enumC1404o4 = new EnumC1404o("ON_PAUSE", 3);
        ON_PAUSE = enumC1404o4;
        EnumC1404o enumC1404o5 = new EnumC1404o("ON_STOP", 4);
        ON_STOP = enumC1404o5;
        EnumC1404o enumC1404o6 = new EnumC1404o("ON_DESTROY", 5);
        ON_DESTROY = enumC1404o6;
        EnumC1404o enumC1404o7 = new EnumC1404o("ON_ANY", 6);
        ON_ANY = enumC1404o7;
        EnumC1404o[] enumC1404oArr = {enumC1404o, enumC1404o2, enumC1404o3, enumC1404o4, enumC1404o5, enumC1404o6, enumC1404o7};
        $VALUES = enumC1404oArr;
        $ENTRIES = new p084k7.b(enumC1404oArr);
        Companion = new C1402m();
    }

    public static EnumC1404o valueOf(String str) {
        return (EnumC1404o) Enum.valueOf(EnumC1404o.class, str);
    }

    public static EnumC1404o[] values() {
        return (EnumC1404o[]) $VALUES.clone();
    }

    public final EnumC1405p a() {
        switch (AbstractC1403n.f13538a[ordinal()]) {
            case 1:
            case 2:
                return EnumC1405p.f13541v;
            case 3:
            case 4:
                return EnumC1405p.f13542w;
            case 5:
                return EnumC1405p.x;
            case 6:
                return EnumC1405p.f13539t;
            case 7:
                throw new IllegalArgumentException(this + " has no target state");
            default:
                throw new A2.c();
        }
    }
}
