package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class T implements c0 {
    @Override // androidx.lifecycle.c0
    public final a0 c(p146s7.e eVar, Y1.d dVar) {
        return new W();
    }
}
