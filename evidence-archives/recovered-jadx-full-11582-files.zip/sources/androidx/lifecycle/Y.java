package androidx.lifecycle;

import F4.Z6;
import android.app.Application;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class Y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final List f13512a = p040e7.m.g(Application.class, Q.class);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final List f13513b = Z6.c(Q.class);

    public static final Constructor a(Class cls, List list) {
        p146s7.j.e(list, "signature");
        P7.h hVarI = p146s7.j.i(cls.getConstructors());
        while (hVarI.hasNext()) {
            Constructor constructor = (Constructor) hVarI.next();
            Class<?>[] parameterTypes = constructor.getParameterTypes();
            p146s7.j.d(parameterTypes, "getParameterTypes(...)");
            List listY = p040e7.k.y(parameterTypes);
            if (list.equals(listY)) {
                return constructor;
            }
            if (list.size() == listY.size() && listY.containsAll(list)) {
                throw new UnsupportedOperationException("Class " + cls.getSimpleName() + " must have parameters in the proper order: " + list);
            }
        }
        return null;
    }

    public static final a0 b(Class cls, Constructor constructor, Object... objArr) {
        try {
            return (a0) constructor.newInstance(Arrays.copyOf(objArr, objArr.length));
        } catch (IllegalAccessException e4) {
            throw new RuntimeException("Failed to access " + cls, e4);
        } catch (InstantiationException e9) {
            throw new RuntimeException("A " + cls + " cannot be instantiated.", e9);
        } catch (InvocationTargetException e10) {
            throw new RuntimeException("An exception happened in constructor of " + cls, e10.getCause());
        }
    }
}
