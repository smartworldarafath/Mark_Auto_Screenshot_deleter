package androidx.lifecycle;

import H4.AbstractC0642j5;
import H4.P5;
import M0.C1071u0;
import android.os.Bundle;
import java.util.Arrays;
import java.util.Map;
import p032d7.AbstractC5727a;

/* JADX INFO: loaded from: classes.dex */
public final class V implements p141s2.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p076j6.d f13502a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f13503b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Bundle f13504c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p032d7.p f13505d;

    public V(p076j6.d dVar, g0 g0Var) {
        p146s7.j.e(dVar, "savedStateRegistry");
        this.f13502a = dVar;
        this.f13505d = AbstractC5727a.d(new E.F(25, g0Var));
    }

    @Override // p141s2.d
    public final Bundle a() {
        Bundle bundleA = P5.a((p032d7.k[]) Arrays.copyOf(new p032d7.k[0], 0));
        Bundle bundle = this.f13504c;
        if (bundle != null) {
            bundleA.putAll(bundle);
        }
        for (Map.Entry entry : ((W) this.f13505d.getValue()).f13506b.entrySet()) {
            String str = (String) entry.getKey();
            Bundle bundleA2 = ((C1071u0) ((Q) entry.getValue()).f13494b.f3780y).a();
            if (!bundleA2.isEmpty()) {
                AbstractC0642j5.a(bundleA, str, bundleA2);
            }
        }
        this.f13503b = false;
        return bundleA;
    }

    public final void b() {
        if (this.f13503b) {
            return;
        }
        Bundle bundleE = this.f13502a.e("androidx.lifecycle.internal.SavedStateHandlesProvider");
        Bundle bundleA = P5.a((p032d7.k[]) Arrays.copyOf(new p032d7.k[0], 0));
        Bundle bundle = this.f13504c;
        if (bundle != null) {
            bundleA.putAll(bundle);
        }
        if (bundleE != null) {
            bundleA.putAll(bundleE);
        }
        this.f13504c = bundleA;
        this.f13503b = true;
    }
}
