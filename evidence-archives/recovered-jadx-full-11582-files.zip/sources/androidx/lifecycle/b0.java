package androidx.lifecycle;

import F4.AbstractC0375j5;
import android.app.Application;
import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: classes.dex */
public final class b0 extends d0 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static b0 f13520c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final T5.q f13521d = new T5.q(5);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Application f13522b;

    public b0(Application application) {
        this.f13522b = application;
    }

    @Override // androidx.lifecycle.d0, androidx.lifecycle.c0
    public final a0 a(Class cls) {
        Application application = this.f13522b;
        if (application != null) {
            return d(cls, application);
        }
        throw new UnsupportedOperationException("AndroidViewModelFactory constructed with empty constructor works only with create(modelClass: Class<T>, extras: CreationExtras).");
    }

    @Override // androidx.lifecycle.d0, androidx.lifecycle.c0
    public final a0 b(Class cls, Y1.d dVar) {
        if (this.f13522b != null) {
            return a(cls);
        }
        Application application = (Application) dVar.f11918a.get(f13521d);
        if (application != null) {
            return d(cls, application);
        }
        if (AbstractC1390a.class.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("CreationExtras must have an application by `APPLICATION_KEY`");
        }
        return AbstractC0375j5.a(cls);
    }

    public final a0 d(Class cls, Application application) {
        if (!AbstractC1390a.class.isAssignableFrom(cls)) {
            return AbstractC0375j5.a(cls);
        }
        try {
            a0 a0Var = (a0) cls.getConstructor(Application.class).newInstance(application);
            p146s7.j.b(a0Var);
            return a0Var;
        } catch (IllegalAccessException e4) {
            throw new RuntimeException("Cannot create an instance of " + cls, e4);
        } catch (InstantiationException e9) {
            throw new RuntimeException("Cannot create an instance of " + cls, e9);
        } catch (NoSuchMethodException e10) {
            throw new RuntimeException("Cannot create an instance of " + cls, e10);
        } catch (InvocationTargetException e11) {
            throw new RuntimeException("Cannot create an instance of " + cls, e11);
        }
    }
}
