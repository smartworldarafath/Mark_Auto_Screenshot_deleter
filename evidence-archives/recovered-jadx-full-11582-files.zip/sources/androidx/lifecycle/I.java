package androidx.lifecycle;

import D7.InterfaceC0091v;
import p032d7.AbstractC5727a;

/* JADX INFO: loaded from: classes.dex */
public final class I extends j7.i implements p137r7.e {
    public int x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public /* synthetic */ Object f13469y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final /* synthetic */ p137r7.e f13470z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public I(p137r7.e eVar, p062h7.c cVar) {
        super(2, cVar);
        this.f13470z = eVar;
    }

    @Override // p137r7.e
    public final Object j(Object obj, Object obj2) {
        return ((I) n((p062h7.c) obj2, (InterfaceC0091v) obj)).p(p032d7.z.f26831a);
    }

    @Override // j7.a
    public final p062h7.c n(p062h7.c cVar, Object obj) {
        I i = new I(this.f13470z, cVar);
        i.f13469y = obj;
        return i;
    }

    @Override // j7.a
    public final Object p(Object obj) {
        int i = this.x;
        if (i == 0) {
            AbstractC5727a.e(obj);
            InterfaceC0091v interfaceC0091v = (InterfaceC0091v) this.f13469y;
            this.x = 1;
            Object objJ = this.f13470z.j(interfaceC0091v, this);
            p069i7.a aVar = p069i7.a.f27481t;
            if (objJ == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC5727a.e(obj);
        }
        return p032d7.z.f26831a;
    }
}
