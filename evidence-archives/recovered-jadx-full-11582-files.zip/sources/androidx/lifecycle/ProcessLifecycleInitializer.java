package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements A2.b {
    @Override // A2.b
    public final List a() {
        return p040e7.t.f26995t;
    }

    @Override // A2.b
    public final Object create(Context context) {
        p146s7.j.e(context, "context");
        A2.a aVarC = A2.a.c(context);
        p146s7.j.d(aVarC, "getInstance(...)");
        if (!aVarC.f295b.contains(ProcessLifecycleInitializer.class)) {
            throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
        }
        if (!AbstractC1408t.f13547a.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            p146s7.j.c(applicationContext, "null cannot be cast to non-null type android.app.Application");
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new C1407s());
        }
        H h9 = H.f13461B;
        h9.getClass();
        h9.x = new Handler();
        h9.f13467y.L(EnumC1404o.ON_CREATE);
        Context applicationContext2 = context.getApplicationContext();
        p146s7.j.c(applicationContext2, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext2).registerActivityLifecycleCallbacks(new G(h9));
        return h9;
    }
}
