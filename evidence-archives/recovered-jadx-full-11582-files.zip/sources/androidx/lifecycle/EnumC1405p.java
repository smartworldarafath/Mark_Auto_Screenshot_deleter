package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: androidx.lifecycle.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC1405p {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final EnumC1405p f13539t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final EnumC1405p f13540u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final EnumC1405p f13541v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final EnumC1405p f13542w;
    public static final EnumC1405p x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final /* synthetic */ EnumC1405p[] f13543y;

    static {
        EnumC1405p enumC1405p = new EnumC1405p("DESTROYED", 0);
        f13539t = enumC1405p;
        EnumC1405p enumC1405p2 = new EnumC1405p("INITIALIZED", 1);
        f13540u = enumC1405p2;
        EnumC1405p enumC1405p3 = new EnumC1405p("CREATED", 2);
        f13541v = enumC1405p3;
        EnumC1405p enumC1405p4 = new EnumC1405p("STARTED", 3);
        f13542w = enumC1405p4;
        EnumC1405p enumC1405p5 = new EnumC1405p("RESUMED", 4);
        x = enumC1405p5;
        f13543y = new EnumC1405p[]{enumC1405p, enumC1405p2, enumC1405p3, enumC1405p4, enumC1405p5};
    }

    public static EnumC1405p valueOf(String str) {
        return (EnumC1405p) Enum.valueOf(EnumC1405p.class, str);
    }

    public static EnumC1405p[] values() {
        return (EnumC1405p[]) f13543y.clone();
    }
}
