package androidx.lifecycle;

import A1.RunnableC0042s;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class H implements InterfaceC1411w {

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public static final H f13461B = new H();

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f13463t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f13464u;
    public Handler x;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f13465v = true;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f13466w = true;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final C1413y f13467y = new C1413y(this, true);

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final RunnableC0042s f13468z = new RunnableC0042s(9, this);

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final e0 f13462A = new e0(this);

    public final void b() {
        int i = this.f13464u + 1;
        this.f13464u = i;
        if (i == 1) {
            if (this.f13465v) {
                this.f13467y.L(EnumC1404o.ON_RESUME);
                this.f13465v = false;
            } else {
                Handler handler = this.x;
                p146s7.j.b(handler);
                handler.removeCallbacks(this.f13468z);
            }
        }
    }

    @Override // androidx.lifecycle.InterfaceC1411w
    public final E.V g() {
        return this.f13467y;
    }
}
