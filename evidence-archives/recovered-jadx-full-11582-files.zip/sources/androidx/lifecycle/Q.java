package androidx.lifecycle;

import H4.C0660l5;
import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class Q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f13493a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0660l5 f13494b;

    public Q(p048f7.e eVar) {
        this.f13493a = new LinkedHashMap();
        this.f13494b = new C0660l5(eVar);
    }

    public Q() {
        this.f13493a = new LinkedHashMap();
        this.f13494b = new C0660l5(p040e7.u.f26996t);
    }
}
