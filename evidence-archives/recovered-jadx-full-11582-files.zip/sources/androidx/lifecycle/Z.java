package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class Z implements Runnable {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final C1413y f13514t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final EnumC1404o f13515u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f13516v;

    public Z(C1413y c1413y, EnumC1404o enumC1404o) {
        p146s7.j.e(c1413y, "registry");
        p146s7.j.e(enumC1404o, "event");
        this.f13514t = c1413y;
        this.f13515u = enumC1404o;
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.f13516v) {
            return;
        }
        this.f13514t.L(this.f13515u);
        this.f13516v = true;
    }
}
