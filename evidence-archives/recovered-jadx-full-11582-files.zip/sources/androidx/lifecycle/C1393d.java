package androidx.lifecycle;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: renamed from: androidx.lifecycle.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1393d {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C1393d f13525c = new C1393d();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f13526a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f13527b = new HashMap();

    public static void b(HashMap map, C1392c c1392c, EnumC1404o enumC1404o, Class cls) {
        EnumC1404o enumC1404o2 = (EnumC1404o) map.get(c1392c);
        if (enumC1404o2 == null || enumC1404o == enumC1404o2) {
            if (enumC1404o2 == null) {
                map.put(c1392c, enumC1404o);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Method " + c1392c.f13524b.getName() + " in " + cls.getName() + " already declared with different @OnLifecycleEvent value: previous value " + enumC1404o2 + ", new value " + enumC1404o);
    }

    public final C1391b a(Class cls, Method[] methodArr) {
        int i;
        Class superclass = cls.getSuperclass();
        HashMap map = new HashMap();
        HashMap map2 = this.f13526a;
        if (superclass != null) {
            C1391b c1391bA = (C1391b) map2.get(superclass);
            if (c1391bA == null) {
                c1391bA = a(superclass, null);
            }
            map.putAll(c1391bA.f13519b);
        }
        for (Class<?> cls2 : cls.getInterfaces()) {
            C1391b c1391bA2 = (C1391b) map2.get(cls2);
            if (c1391bA2 == null) {
                c1391bA2 = a(cls2, null);
            }
            for (Map.Entry entry : c1391bA2.f13519b.entrySet()) {
                b(map, (C1392c) entry.getKey(), (EnumC1404o) entry.getValue(), cls);
            }
        }
        if (methodArr == null) {
            try {
                methodArr = cls.getDeclaredMethods();
            } catch (NoClassDefFoundError e4) {
                throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e4);
            }
        }
        boolean z8 = false;
        for (Method method : methodArr) {
            E e9 = (E) method.getAnnotation(E.class);
            if (e9 != null) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i = 0;
                } else {
                    if (!InterfaceC1411w.class.isAssignableFrom(parameterTypes[0])) {
                        throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                    }
                    i = 1;
                }
                EnumC1404o enumC1404oValue = e9.value();
                if (parameterTypes.length > 1) {
                    if (!EnumC1404o.class.isAssignableFrom(parameterTypes[1])) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    }
                    if (enumC1404oValue != EnumC1404o.ON_ANY) {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                    i = 2;
                }
                if (parameterTypes.length > 2) {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
                b(map, new C1392c(i, method), enumC1404oValue, cls);
                z8 = true;
            }
        }
        C1391b c1391b = new C1391b(map);
        map2.put(cls, c1391b);
        this.f13527b.put(cls, Boolean.valueOf(z8));
        return c1391b;
    }
}
