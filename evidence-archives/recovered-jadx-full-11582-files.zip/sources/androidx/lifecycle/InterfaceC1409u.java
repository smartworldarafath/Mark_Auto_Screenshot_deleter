package androidx.lifecycle;

/* JADX INFO: renamed from: androidx.lifecycle.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1409u extends InterfaceC1410v {
    void l(InterfaceC1411w interfaceC1411w, EnumC1404o enumC1404o);
}
