package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface g0 {
    f0 e();
}
