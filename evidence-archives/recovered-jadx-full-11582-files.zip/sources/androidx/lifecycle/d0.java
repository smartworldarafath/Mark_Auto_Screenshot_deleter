package androidx.lifecycle;

import F4.AbstractC0375j5;
import H4.L4;

/* JADX INFO: loaded from: classes.dex */
public class d0 implements c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static d0 f13528a;

    @Override // androidx.lifecycle.c0
    public a0 a(Class cls) {
        return AbstractC0375j5.a(cls);
    }

    @Override // androidx.lifecycle.c0
    public a0 b(Class cls, Y1.d dVar) {
        return a(cls);
    }

    @Override // androidx.lifecycle.c0
    public final a0 c(p146s7.e eVar, Y1.d dVar) {
        return b(L4.a(eVar), dVar);
    }
}
