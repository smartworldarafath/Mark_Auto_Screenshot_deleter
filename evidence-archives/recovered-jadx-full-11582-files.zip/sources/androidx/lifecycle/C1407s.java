package androidx.lifecycle;

import android.app.Activity;
import android.os.Bundle;

/* JADX INFO: renamed from: androidx.lifecycle.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1407s extends AbstractC1398i {
    @Override // androidx.lifecycle.AbstractC1398i, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        p146s7.j.e(activity, "activity");
        int i = P.f13491u;
        N.b(activity);
    }
}
