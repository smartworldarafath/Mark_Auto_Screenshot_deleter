package androidx.lifecycle;

import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public abstract class a0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p003a2.d f13517a = new p003a2.d();

    public final void a(String str, AutoCloseable autoCloseable) {
        AutoCloseable autoCloseable2;
        p003a2.d dVar = this.f13517a;
        if (dVar != null) {
            if (dVar.f12841d) {
                p003a2.d.a(autoCloseable);
                return;
            }
            synchronized (dVar.f12838a) {
                autoCloseable2 = (AutoCloseable) dVar.f12839b.put(str, autoCloseable);
            }
            p003a2.d.a(autoCloseable2);
        }
    }

    public final void b() {
        p003a2.d dVar = this.f13517a;
        if (dVar != null && !dVar.f12841d) {
            dVar.f12841d = true;
            synchronized (dVar.f12838a) {
                try {
                    Iterator it = dVar.f12839b.values().iterator();
                    while (it.hasNext()) {
                        p003a2.d.a((AutoCloseable) it.next());
                    }
                    Iterator it2 = dVar.f12840c.iterator();
                    while (it2.hasNext()) {
                        p003a2.d.a((AutoCloseable) it2.next());
                    }
                    dVar.f12840c.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        d();
    }

    public final AutoCloseable c(String str) {
        AutoCloseable autoCloseable;
        p003a2.d dVar = this.f13517a;
        if (dVar == null) {
            return null;
        }
        synchronized (dVar.f12838a) {
            autoCloseable = (AutoCloseable) dVar.f12839b.get(str);
        }
        return autoCloseable;
    }

    public void d() {
    }
}
