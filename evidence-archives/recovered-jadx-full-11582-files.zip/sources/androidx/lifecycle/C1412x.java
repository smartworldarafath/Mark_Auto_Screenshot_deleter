package androidx.lifecycle;

/* JADX INFO: renamed from: androidx.lifecycle.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1412x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public EnumC1405p f13548a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public InterfaceC1409u f13549b;

    public final void a(InterfaceC1411w interfaceC1411w, EnumC1404o enumC1404o) {
        EnumC1405p enumC1405pA = enumC1404o.a();
        EnumC1405p enumC1405p = this.f13548a;
        p146s7.j.e(enumC1405p, "state1");
        if (enumC1405pA.compareTo(enumC1405p) < 0) {
            enumC1405p = enumC1405pA;
        }
        this.f13548a = enumC1405p;
        this.f13549b.l(interfaceC1411w, enumC1404o);
        this.f13548a = enumC1405pA;
    }
}
