package androidx.lifecycle;

import java.lang.reflect.Method;

/* JADX INFO: renamed from: androidx.lifecycle.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1392c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f13523a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Method f13524b;

    public C1392c(int i, Method method) {
        this.f13523a = i;
        this.f13524b = method;
        method.setAccessible(true);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C1392c)) {
            return false;
        }
        C1392c c1392c = (C1392c) obj;
        return this.f13523a == c1392c.f13523a && this.f13524b.getName().equals(c1392c.f13524b.getName());
    }

    public final int hashCode() {
        return this.f13524b.getName().hashCode() + (this.f13523a * 31);
    }
}
