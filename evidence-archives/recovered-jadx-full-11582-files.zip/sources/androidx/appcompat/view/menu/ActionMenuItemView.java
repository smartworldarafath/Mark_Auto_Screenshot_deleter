package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import p077k.a;
import p077k.b;
import p077k.g;
import p077k.h;
import p077k.i;
import p077k.o;
import p085l.C5767z;
import p085l.InterfaceC5752j;
import p085l.w0;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuItemView extends C5767z implements o, View.OnClickListener, InterfaceC5752j {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public i f12854A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public CharSequence f12855B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public Drawable f12856C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public g f12857D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public a f12858E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public b f12859F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public boolean f12860G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public boolean f12861H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final int f12862I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public int f12863J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final int f12864K;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.f12860G = l();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p055h.a.f27201c, 0, 0);
        this.f12862I = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.f12864K = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f12863J = -1;
        setSaveEnabled(false);
    }

    @Override // p085l.InterfaceC5752j
    public final boolean b() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // p085l.InterfaceC5752j
    public final boolean c() {
        return !TextUtils.isEmpty(getText()) && this.f12854A.getIcon() == null;
    }

    @Override // p077k.o
    public final void d(i iVar) {
        this.f12854A = iVar;
        setIcon(iVar.getIcon());
        setTitle(iVar.getTitleCondensed());
        setId(iVar.f27901a);
        setVisibility(iVar.isVisible() ? 0 : 8);
        setEnabled(iVar.isEnabled());
        if (iVar.hasSubMenu() && this.f12858E == null) {
            this.f12858E = new a(this);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // p077k.o
    public i getItemData() {
        return this.f12854A;
    }

    public final boolean l() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        int i4 = configuration.screenHeightDp;
        if (i < 480) {
            return (i >= 640 && i4 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    public final void n() {
        boolean z8 = true;
        boolean z9 = !TextUtils.isEmpty(this.f12855B);
        if (this.f12856C != null && ((this.f12854A.f27923y & 4) != 4 || (!this.f12860G && !this.f12861H))) {
            z8 = false;
        }
        boolean z10 = z9 & z8;
        setText(z10 ? this.f12855B : null);
        CharSequence charSequence = this.f12854A.f27916q;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z10 ? null : this.f12854A.f27905e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f12854A.f27917r;
        if (TextUtils.isEmpty(charSequence2)) {
            w0.a(this, z10 ? null : this.f12854A.f27905e);
        } else {
            w0.a(this, charSequence2);
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        g gVar = this.f12857D;
        if (gVar != null) {
            gVar.a(this.f12854A);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f12860G = l();
        n();
    }

    @Override // p085l.C5767z, android.widget.TextView, android.view.View
    public final void onMeasure(int i, int i4) {
        int i9;
        boolean zIsEmpty = TextUtils.isEmpty(getText());
        if (!zIsEmpty && (i9 = this.f12863J) >= 0) {
            super.setPadding(i9, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i4);
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        int i10 = this.f12862I;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i10) : i10;
        if (mode != 1073741824 && i10 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i4);
        }
        if (!zIsEmpty || this.f12856C == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f12856C.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        a aVar;
        if (this.f12854A.hasSubMenu() && (aVar = this.f12858E) != null && aVar.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z8) {
    }

    public void setChecked(boolean z8) {
    }

    public void setExpandedFormat(boolean z8) {
        if (this.f12861H != z8) {
            this.f12861H = z8;
            i iVar = this.f12854A;
            if (iVar != null) {
                h hVar = iVar.f27913n;
                hVar.f27888k = true;
                hVar.o(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f12856C = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i = this.f12864K;
            if (intrinsicWidth > i) {
                intrinsicHeight = (int) (intrinsicHeight * (i / intrinsicWidth));
                intrinsicWidth = i;
            }
            if (intrinsicHeight > i) {
                intrinsicWidth = (int) (intrinsicWidth * (i / intrinsicHeight));
            } else {
                i = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i);
        }
        setCompoundDrawables(drawable, null, null, null);
        n();
    }

    public void setItemInvoker(g gVar) {
        this.f12857D = gVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i, int i4, int i9, int i10) {
        this.f12863J = i;
        super.setPadding(i, i4, i9, i10);
    }

    public void setPopupCallback(b bVar) {
        this.f12859F = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f12855B = charSequence;
        n();
    }
}
