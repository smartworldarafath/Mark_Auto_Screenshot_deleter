package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import com.google.android.gms.internal.play_billing.C5641l;
import p077k.g;
import p077k.i;

/* JADX INFO: loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements g, AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final int[] f12865t = {R.attr.background, R.attr.divider};

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        C5641l c5641lP = C5641l.p(context, attributeSet, f12865t, R.attr.listViewStyle);
        TypedArray typedArray = (TypedArray) c5641lP.f26296v;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(c5641lP.j(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(c5641lP.j(1));
        }
        c5641lP.q();
    }

    @Override // p077k.g
    public final boolean a(i iVar) {
        throw null;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i, long j9) {
        throw null;
    }
}
