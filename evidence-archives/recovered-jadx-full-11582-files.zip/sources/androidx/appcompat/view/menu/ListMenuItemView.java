package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import com.google.android.gms.internal.play_billing.C5641l;
import com.markOne.ss_app.R;
import p055h.a;
import p077k.h;
import p077k.i;
import p077k.o;

/* JADX INFO: loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements o, AbsListView.SelectionBoundsAdjuster {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public ImageView f12866A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public LinearLayout f12867B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final Drawable f12868C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final int f12869D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final Context f12870E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public boolean f12871F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final Drawable f12872G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final boolean f12873H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public LayoutInflater f12874I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public boolean f12875J;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public i f12876t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public ImageView f12877u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public RadioButton f12878v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public TextView f12879w;
    public CheckBox x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public TextView f12880y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public ImageView f12881z;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C5641l c5641lP = C5641l.p(getContext(), attributeSet, a.f27211n, R.attr.listMenuViewStyle);
        this.f12868C = c5641lP.j(5);
        TypedArray typedArray = (TypedArray) c5641lP.f26296v;
        this.f12869D = typedArray.getResourceId(1, -1);
        this.f12871F = typedArray.getBoolean(7, false);
        this.f12870E = context;
        this.f12872G = c5641lP.j(8);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{android.R.attr.divider}, R.attr.dropDownListViewStyle, 0);
        this.f12873H = typedArrayObtainStyledAttributes.hasValue(0);
        c5641lP.q();
        typedArrayObtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f12874I == null) {
            this.f12874I = LayoutInflater.from(getContext());
        }
        return this.f12874I;
    }

    private void setSubMenuArrowVisible(boolean z8) {
        ImageView imageView = this.f12881z;
        if (imageView != null) {
            imageView.setVisibility(z8 ? 0 : 8);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f12866A;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f12866A.getLayoutParams();
        rect.top = this.f12866A.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0037  */
    /* JADX WARN: Code duplicated, block: B:25:0x005a  */
    /* JADX WARN: Code duplicated, block: B:28:0x005e  */
    @Override // p077k.o
    public final void d(i iVar) {
        boolean z8;
        int i;
        String string;
        boolean z9;
        this.f12876t = iVar;
        setVisibility(iVar.isVisible() ? 0 : 8);
        setTitle(iVar.f27905e);
        setCheckable(iVar.isCheckable());
        if (iVar.f27913n.n()) {
            if ((iVar.f27913n.m() ? iVar.f27909j : iVar.f27908h) != 0) {
                z8 = true;
            } else {
                z8 = false;
            }
        } else {
            z8 = false;
        }
        iVar.f27913n.m();
        if (z8) {
            i iVar2 = this.f12876t;
            if (iVar2.f27913n.n()) {
                if ((iVar2.f27913n.m() ? iVar2.f27909j : iVar2.f27908h) != 0) {
                    z9 = true;
                } else {
                    z9 = false;
                }
            } else {
                z9 = false;
            }
            i = z9 ? 0 : 8;
        }
        if (i == 0) {
            TextView textView = this.f12880y;
            i iVar3 = this.f12876t;
            h hVar = iVar3.f27913n;
            Context context = hVar.f27879a;
            char c9 = hVar.m() ? iVar3.f27909j : iVar3.f27908h;
            if (c9 == 0) {
                string = "";
            } else {
                Resources resources = context.getResources();
                StringBuilder sb = new StringBuilder();
                if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
                    sb.append(resources.getString(R.string.abc_prepend_shortcut_label));
                }
                int i4 = hVar.m() ? iVar3.f27910k : iVar3.i;
                i.a(sb, i4, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label));
                i.a(sb, i4, 4096, resources.getString(R.string.abc_menu_ctrl_shortcut_label));
                i.a(sb, i4, 2, resources.getString(R.string.abc_menu_alt_shortcut_label));
                i.a(sb, i4, 1, resources.getString(R.string.abc_menu_shift_shortcut_label));
                i.a(sb, i4, 4, resources.getString(R.string.abc_menu_sym_shortcut_label));
                i.a(sb, i4, 8, resources.getString(R.string.abc_menu_function_shortcut_label));
                if (c9 == '\b') {
                    sb.append(resources.getString(R.string.abc_menu_delete_shortcut_label));
                } else if (c9 == '\n') {
                    sb.append(resources.getString(R.string.abc_menu_enter_shortcut_label));
                } else if (c9 != ' ') {
                    sb.append(c9);
                } else {
                    sb.append(resources.getString(R.string.abc_menu_space_shortcut_label));
                }
                string = sb.toString();
            }
            textView.setText(string);
        }
        if (this.f12880y.getVisibility() != i) {
            this.f12880y.setVisibility(i);
        }
        setIcon(iVar.getIcon());
        setEnabled(iVar.isEnabled());
        setSubMenuArrowVisible(iVar.hasSubMenu());
        setContentDescription(iVar.f27916q);
    }

    @Override // p077k.o
    public i getItemData() {
        return this.f12876t;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.f12868C);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f12879w = textView;
        int i = this.f12869D;
        if (i != -1) {
            textView.setTextAppearance(this.f12870E, i);
        }
        this.f12880y = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f12881z = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f12872G);
        }
        this.f12866A = (ImageView) findViewById(R.id.group_divider);
        this.f12867B = (LinearLayout) findViewById(R.id.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i, int i4) {
        if (this.f12877u != null && this.f12871F) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f12877u.getLayoutParams();
            int i9 = layoutParams.height;
            if (i9 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i9;
            }
        }
        super.onMeasure(i, i4);
    }

    public void setCheckable(boolean z8) {
        CompoundButton compoundButton;
        View view;
        if (!z8 && this.f12878v == null && this.x == null) {
            return;
        }
        if ((this.f12876t.x & 4) != 0) {
            if (this.f12878v == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f12878v = radioButton;
                LinearLayout linearLayout = this.f12867B;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f12878v;
            view = this.x;
        } else {
            if (this.x == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.x = checkBox;
                LinearLayout linearLayout2 = this.f12867B;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.x;
            view = this.f12878v;
        }
        if (z8) {
            compoundButton.setChecked(this.f12876t.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.x;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f12878v;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z8) {
        CompoundButton compoundButton;
        if ((this.f12876t.x & 4) != 0) {
            if (this.f12878v == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f12878v = radioButton;
                LinearLayout linearLayout = this.f12867B;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f12878v;
        } else {
            if (this.x == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.x = checkBox;
                LinearLayout linearLayout2 = this.f12867B;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.x;
        }
        compoundButton.setChecked(z8);
    }

    public void setForceShowIcon(boolean z8) {
        this.f12875J = z8;
        this.f12871F = z8;
    }

    public void setGroupDividerEnabled(boolean z8) {
        ImageView imageView = this.f12866A;
        if (imageView != null) {
            imageView.setVisibility((this.f12873H || !z8) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        h hVar = this.f12876t.f27913n;
        boolean z8 = this.f12875J;
        if (z8 || this.f12871F) {
            ImageView imageView = this.f12877u;
            if (imageView == null && drawable == null && !this.f12871F) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.f12877u = imageView2;
                LinearLayout linearLayout = this.f12867B;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f12871F) {
                this.f12877u.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f12877u;
            if (!z8) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f12877u.getVisibility() != 0) {
                this.f12877u.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f12879w.getVisibility() != 8) {
                this.f12879w.setVisibility(8);
            }
        } else {
            this.f12879w.setText(charSequence);
            if (this.f12879w.getVisibility() != 0) {
                this.f12879w.setVisibility(0);
            }
        }
    }
}
