package androidx.appcompat.widget;

import A1.J;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import com.markOne.ss_app.R;
import java.lang.reflect.Field;
import p055h.a;

/* JADX INFO: loaded from: classes.dex */
public class ButtonBarLayout extends LinearLayout {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f12938t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f12939u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f12940v;

    public ButtonBarLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f12940v = -1;
        int[] iArr = a.i;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr);
        J.c(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, 0);
        this.f12938t = typedArrayObtainStyledAttributes.getBoolean(0, true);
        typedArrayObtainStyledAttributes.recycle();
        if (getOrientation() == 1) {
            setStacked(this.f12938t);
        }
    }

    private void setStacked(boolean z8) {
        if (this.f12939u != z8) {
            if (!z8 || this.f12938t) {
                this.f12939u = z8;
                setOrientation(z8 ? 1 : 0);
                setGravity(z8 ? 8388613 : 80);
                View viewFindViewById = findViewById(R.id.spacer);
                if (viewFindViewById != null) {
                    viewFindViewById.setVisibility(z8 ? 8 : 4);
                }
                for (int childCount = getChildCount() - 2; childCount >= 0; childCount--) {
                    bringChildToFront(getChildAt(childCount));
                }
            }
        }
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i, int i4) {
        int iMakeMeasureSpec;
        boolean z8;
        int i9;
        int size = View.MeasureSpec.getSize(i);
        int paddingBottom = 0;
        if (this.f12938t) {
            if (size > this.f12940v && this.f12939u) {
                setStacked(false);
            }
            this.f12940v = size;
        }
        if (this.f12939u || View.MeasureSpec.getMode(i) != 1073741824) {
            iMakeMeasureSpec = i;
            z8 = false;
        } else {
            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(size, Integer.MIN_VALUE);
            z8 = true;
        }
        super.onMeasure(iMakeMeasureSpec, i4);
        if (this.f12938t && !this.f12939u && (getMeasuredWidthAndState() & (-16777216)) == 16777216) {
            setStacked(true);
            z8 = true;
        }
        if (z8) {
            super.onMeasure(i, i4);
        }
        int childCount = getChildCount();
        int i10 = 0;
        while (true) {
            i9 = -1;
            if (i10 >= childCount) {
                i10 = -1;
                break;
            } else if (getChildAt(i10).getVisibility() == 0) {
                break;
            } else {
                i10++;
            }
        }
        if (i10 >= 0) {
            View childAt = getChildAt(i10);
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight() + getPaddingTop() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (this.f12939u) {
                int childCount2 = getChildCount();
                for (int i11 = i10 + 1; i11 < childCount2; i11++) {
                    if (getChildAt(i11).getVisibility() == 0) {
                        i9 = i11;
                        break;
                    }
                }
                paddingBottom = i9 >= 0 ? getChildAt(i9).getPaddingTop() + ((int) (getResources().getDisplayMetrics().density * 16.0f)) + measuredHeight : measuredHeight;
            } else {
                paddingBottom = getPaddingBottom() + measuredHeight;
            }
        }
        Field field = J.f187a;
        if (getMinimumHeight() != paddingBottom) {
            setMinimumHeight(paddingBottom);
            if (i4 == 0) {
                super.onMeasure(i, i4);
            }
        }
    }

    public void setAllowStacking(boolean z8) {
        if (this.f12938t != z8) {
            this.f12938t = z8;
            if (!z8 && this.f12939u) {
                setStacked(false);
            }
            requestLayout();
        }
    }
}
