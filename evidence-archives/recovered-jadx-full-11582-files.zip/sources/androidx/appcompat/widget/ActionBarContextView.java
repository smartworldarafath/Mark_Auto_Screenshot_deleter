package androidx.appcompat.widget;

import A1.J;
import F4.t7;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.markOne.ss_app.R;
import p055h.a;
import p085l.z0;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContextView extends ViewGroup {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public TextView f12890A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public TextView f12891B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final int f12892C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final int f12893D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public boolean f12894E;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f12895t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f12896u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f12897v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public CharSequence f12898w;
    public CharSequence x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public View f12899y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public LinearLayout f12900z;

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        int resourceId;
        super(context, attributeSet, R.attr.actionModeStyle);
        TypedValue typedValue = new TypedValue();
        if (context.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true) && typedValue.resourceId != 0) {
            new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f27202d, R.attr.actionModeStyle, 0);
        setBackground((!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(0) : t7.b(context, resourceId));
        this.f12892C = typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f12893D = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        this.f12895t = typedArrayObtainStyledAttributes.getLayoutDimension(3, 0);
        typedArrayObtainStyledAttributes.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static int b(View view, int i, int i4, int i9, boolean z8) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i10 = ((i9 - measuredHeight) / 2) + i4;
        if (z8) {
            view.layout(i - measuredWidth, i10, i, measuredHeight + i10);
        } else {
            view.layout(i, i10, i + measuredWidth, measuredHeight + i10);
        }
        return z8 ? -measuredWidth : measuredWidth;
    }

    public final void a() {
        if (this.f12900z == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f12900z = linearLayout;
            this.f12890A = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.f12891B = (TextView) this.f12900z.findViewById(R.id.action_bar_subtitle);
            int i = this.f12892C;
            if (i != 0) {
                this.f12890A.setTextAppearance(getContext(), i);
            }
            int i4 = this.f12893D;
            if (i4 != 0) {
                this.f12891B.setTextAppearance(getContext(), i4);
            }
        }
        this.f12890A.setText(this.f12898w);
        this.f12891B.setText(this.x);
        boolean zIsEmpty = TextUtils.isEmpty(this.f12898w);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.x);
        this.f12891B.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.f12900z.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.f12900z.getParent() == null) {
            addView(this.f12900z);
        }
    }

    @Override // android.view.View
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public final void setVisibility(int i) {
        if (i != getVisibility()) {
            super.setVisibility(i);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        return getVisibility();
    }

    public int getContentHeight() {
        return this.f12895t;
    }

    public CharSequence getSubtitle() {
        return this.x;
    }

    public CharSequence getTitle() {
        return this.f12898w;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, a.f27199a, R.attr.actionBarStyle, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(13, 0));
        typedArrayObtainStyledAttributes.recycle();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f12897v = false;
        }
        if (!this.f12897v) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f12897v = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f12897v = false;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z8, int i, int i4, int i9, int i10) {
        boolean z9 = z0.f28405a;
        boolean z10 = getLayoutDirection() == 1;
        int paddingRight = z10 ? (i9 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i10 - i4) - getPaddingTop()) - getPaddingBottom();
        LinearLayout linearLayout = this.f12900z;
        if (linearLayout != null && this.f12899y == null && linearLayout.getVisibility() != 8) {
            paddingRight += b(this.f12900z, paddingRight, paddingTop, paddingTop2, z10);
        }
        View view = this.f12899y;
        if (view != null) {
            b(view, paddingRight, paddingTop, paddingTop2, z10);
        }
        if (z10) {
            getPaddingLeft();
        } else {
            getPaddingRight();
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i4) {
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
        }
        if (View.MeasureSpec.getMode(i4) == 0) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
        }
        int size = View.MeasureSpec.getSize(i);
        int size2 = this.f12895t;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i4);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingBottom;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        LinearLayout linearLayout = this.f12900z;
        if (linearLayout != null && this.f12899y == null) {
            if (this.f12894E) {
                this.f12900z.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f12900z.getMeasuredWidth();
                boolean z8 = measuredWidth <= paddingLeft;
                if (z8) {
                    paddingLeft -= measuredWidth;
                }
                this.f12900z.setVisibility(z8 ? 0 : 8);
            } else {
                linearLayout.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, Integer.MIN_VALUE), iMakeMeasureSpec);
                paddingLeft = Math.max(0, paddingLeft - linearLayout.getMeasuredWidth());
            }
        }
        View view = this.f12899y;
        if (view != null) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            int i9 = layoutParams.width;
            int i10 = i9 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i9 >= 0) {
                paddingLeft = Math.min(i9, paddingLeft);
            }
            int i11 = layoutParams.height;
            int i12 = i11 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i11 >= 0) {
                iMin = Math.min(i11, iMin);
            }
            this.f12899y.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i10), View.MeasureSpec.makeMeasureSpec(iMin, i12));
        }
        if (this.f12895t > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i13 = 0;
        for (int i14 = 0; i14 < childCount; i14++) {
            int measuredHeight = getChildAt(i14).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i13) {
                i13 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i13);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f12896u = false;
        }
        if (!this.f12896u) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f12896u = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f12896u = false;
        return true;
    }

    public void setContentHeight(int i) {
        this.f12895t = i;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f12899y;
        if (view2 != null) {
            removeView(view2);
        }
        this.f12899y = view;
        if (view != null && (linearLayout = this.f12900z) != null) {
            removeView(linearLayout);
            this.f12900z = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.x = charSequence;
        a();
    }

    public void setTitle(CharSequence charSequence) {
        this.f12898w = charSequence;
        a();
        J.e(this, charSequence);
    }

    public void setTitleOptional(boolean z8) {
        if (z8 != this.f12894E) {
            requestLayout();
        }
        this.f12894E = z8;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
