package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import p085l.F;

/* JADX INFO: loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public TypedValue f12941t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public TypedValue f12942u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public TypedValue f12943v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public TypedValue f12944w;
    public TypedValue x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public TypedValue f12945y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final Rect f12946z;

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f12946z = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.x == null) {
            this.x = new TypedValue();
        }
        return this.x;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f12945y == null) {
            this.f12945y = new TypedValue();
        }
        return this.f12945y;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f12943v == null) {
            this.f12943v = new TypedValue();
        }
        return this.f12943v;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f12944w == null) {
            this.f12944w = new TypedValue();
        }
        return this.f12944w;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f12941t == null) {
            this.f12941t = new TypedValue();
        }
        return this.f12941t;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f12942u == null) {
            this.f12942u = new TypedValue();
        }
        return this.f12942u;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    /* JADX WARN: Code duplicated, block: B:21:0x004e  */
    /* JADX WARN: Code duplicated, block: B:22:0x0062  */
    /* JADX WARN: Code duplicated, block: B:37:0x008a  */
    /* JADX WARN: Code duplicated, block: B:38:0x009d  */
    /* JADX WARN: Code duplicated, block: B:55:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:57:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:58:0x00de  */
    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i4) {
        int iMakeMeasureSpec;
        boolean z8;
        int iMakeMeasureSpec2;
        int i9;
        int i10;
        float fraction;
        int i11;
        int i12;
        float fraction2;
        int i13;
        int i14;
        float fraction3;
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        boolean z9 = true;
        boolean z10 = displayMetrics.widthPixels < displayMetrics.heightPixels;
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i4);
        Rect rect = this.f12946z;
        if (mode != Integer.MIN_VALUE) {
            iMakeMeasureSpec = i;
            z8 = false;
        } else {
            TypedValue typedValue = z10 ? this.f12944w : this.f12943v;
            if (typedValue == null || (i13 = typedValue.type) == 0) {
                iMakeMeasureSpec = i;
                z8 = false;
            } else {
                if (i13 == 5) {
                    fraction3 = typedValue.getDimension(displayMetrics);
                } else {
                    if (i13 == 6) {
                        int i15 = displayMetrics.widthPixels;
                        fraction3 = typedValue.getFraction(i15, i15);
                    } else {
                        i14 = 0;
                    }
                    if (i14 > 0) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i14 - (rect.left + rect.right), View.MeasureSpec.getSize(i)), 1073741824);
                        z8 = true;
                    } else {
                        iMakeMeasureSpec = i;
                        z8 = false;
                    }
                }
                i14 = (int) fraction3;
                if (i14 > 0) {
                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i14 - (rect.left + rect.right), View.MeasureSpec.getSize(i)), 1073741824);
                    z8 = true;
                } else {
                    iMakeMeasureSpec = i;
                    z8 = false;
                }
            }
        }
        if (mode2 != Integer.MIN_VALUE) {
            iMakeMeasureSpec2 = i4;
        } else {
            TypedValue typedValue2 = z10 ? this.x : this.f12945y;
            if (typedValue2 == null || (i11 = typedValue2.type) == 0) {
                iMakeMeasureSpec2 = i4;
            } else {
                if (i11 == 5) {
                    fraction2 = typedValue2.getDimension(displayMetrics);
                } else {
                    if (i11 == 6) {
                        int i16 = displayMetrics.heightPixels;
                        fraction2 = typedValue2.getFraction(i16, i16);
                    } else {
                        i12 = 0;
                    }
                    if (i12 > 0) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i12 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i4)), 1073741824);
                    } else {
                        iMakeMeasureSpec2 = i4;
                    }
                }
                i12 = (int) fraction2;
                if (i12 > 0) {
                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i12 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i4)), 1073741824);
                } else {
                    iMakeMeasureSpec2 = i4;
                }
            }
        }
        super.onMeasure(iMakeMeasureSpec, iMakeMeasureSpec2);
        int measuredWidth = getMeasuredWidth();
        int iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredWidth, 1073741824);
        if (z8 || mode != Integer.MIN_VALUE) {
            z9 = false;
        } else {
            TypedValue typedValue3 = z10 ? this.f12942u : this.f12941t;
            if (typedValue3 == null || (i9 = typedValue3.type) == 0) {
                z9 = false;
            } else {
                if (i9 == 5) {
                    fraction = typedValue3.getDimension(displayMetrics);
                } else {
                    if (i9 == 6) {
                        int i17 = displayMetrics.widthPixels;
                        fraction = typedValue3.getFraction(i17, i17);
                    } else {
                        i10 = 0;
                    }
                    if (i10 > 0) {
                        i10 -= rect.left + rect.right;
                    }
                    if (measuredWidth < i10) {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i10, 1073741824);
                    } else {
                        z9 = false;
                    }
                }
                i10 = (int) fraction;
                if (i10 > 0) {
                    i10 -= rect.left + rect.right;
                }
                if (measuredWidth < i10) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i10, 1073741824);
                } else {
                    z9 = false;
                }
            }
        }
        if (z9) {
            super.onMeasure(iMakeMeasureSpec3, iMakeMeasureSpec2);
        }
    }

    public void setAttachListener(F f4) {
    }
}
