package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import com.markOne.ss_app.R;
import p055h.a;
import p085l.C5743a;
import p085l.k0;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public boolean f12882A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final int f12883B;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f12884t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public View f12885u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public View f12886v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Drawable f12887w;
    public Drawable x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public Drawable f12888y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final boolean f12889z;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBackground(new C5743a(this));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f27199a);
        boolean z8 = false;
        this.f12887w = typedArrayObtainStyledAttributes.getDrawable(0);
        this.x = typedArrayObtainStyledAttributes.getDrawable(2);
        this.f12883B = typedArrayObtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.f12889z = true;
            this.f12888y = typedArrayObtainStyledAttributes.getDrawable(1);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.f12889z ? !(this.f12887w != null || this.x != null) : this.f12888y == null) {
            z8 = true;
        }
        setWillNotDraw(z8);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f12887w;
        if (drawable != null && drawable.isStateful()) {
            this.f12887w.setState(getDrawableState());
        }
        Drawable drawable2 = this.x;
        if (drawable2 != null && drawable2.isStateful()) {
            this.x.setState(getDrawableState());
        }
        Drawable drawable3 = this.f12888y;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f12888y.setState(getDrawableState());
    }

    public View getTabContainer() {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f12887w;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.x;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f12888y;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f12885u = findViewById(R.id.action_bar);
        this.f12886v = findViewById(R.id.action_context_bar);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f12884t || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z8, int i, int i4, int i9, int i10) {
        super.onLayout(z8, i, i4, i9, i10);
        boolean z9 = true;
        if (this.f12889z) {
            Drawable drawable = this.f12888y;
            if (drawable != null) {
                drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z9 = false;
            }
        } else {
            if (this.f12887w == null) {
                z9 = false;
            } else if (this.f12885u.getVisibility() == 0) {
                this.f12887w.setBounds(this.f12885u.getLeft(), this.f12885u.getTop(), this.f12885u.getRight(), this.f12885u.getBottom());
            } else {
                View view = this.f12886v;
                if (view == null || view.getVisibility() != 0) {
                    this.f12887w.setBounds(0, 0, 0, 0);
                } else {
                    this.f12887w.setBounds(this.f12886v.getLeft(), this.f12886v.getTop(), this.f12886v.getRight(), this.f12886v.getBottom());
                }
            }
            this.f12882A = false;
        }
        if (z9) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i4) {
        int i9;
        if (this.f12885u == null && View.MeasureSpec.getMode(i4) == Integer.MIN_VALUE && (i9 = this.f12883B) >= 0) {
            i4 = View.MeasureSpec.makeMeasureSpec(Math.min(i9, View.MeasureSpec.getSize(i4)), Integer.MIN_VALUE);
        }
        super.onMeasure(i, i4);
        if (this.f12885u == null) {
            return;
        }
        View.MeasureSpec.getMode(i4);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f12887w;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f12887w);
        }
        this.f12887w = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f12885u;
            if (view != null) {
                this.f12887w.setBounds(view.getLeft(), this.f12885u.getTop(), this.f12885u.getRight(), this.f12885u.getBottom());
            }
        }
        boolean z8 = false;
        if (!this.f12889z ? !(this.f12887w != null || this.x != null) : this.f12888y == null) {
            z8 = true;
        }
        setWillNotDraw(z8);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f12888y;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f12888y);
        }
        this.f12888y = drawable;
        boolean z8 = this.f12889z;
        boolean z9 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z8 && (drawable2 = this.f12888y) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z8 ? !(this.f12887w != null || this.x != null) : this.f12888y == null) {
            z9 = true;
        }
        setWillNotDraw(z9);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.x;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.x);
        }
        this.x = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f12882A && this.x != null) {
                throw null;
            }
        }
        boolean z8 = false;
        if (!this.f12889z ? !(this.f12887w != null || this.x != null) : this.f12888y == null) {
            z8 = true;
        }
        setWillNotDraw(z8);
        invalidate();
        invalidateOutline();
    }

    public void setTabContainer(k0 k0Var) {
    }

    public void setTransitioning(boolean z8) {
        this.f12884t = z8;
        setDescendantFocusability(z8 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z8 = i == 0;
        Drawable drawable = this.f12887w;
        if (drawable != null) {
            drawable.setVisible(z8, false);
        }
        Drawable drawable2 = this.x;
        if (drawable2 != null) {
            drawable2.setVisible(z8, false);
        }
        Drawable drawable3 = this.f12888y;
        if (drawable3 != null) {
            drawable3.setVisible(z8, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.f12887w;
        boolean z8 = this.f12889z;
        if (drawable == drawable2 && !z8) {
            return true;
        }
        if (drawable == this.x && this.f12882A) {
            return true;
        }
        return (drawable == this.f12888y && z8) || super.verifyDrawable(drawable);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i) {
        if (i != 0) {
            return super.startActionModeForChild(view, callback, i);
        }
        return null;
    }
}
