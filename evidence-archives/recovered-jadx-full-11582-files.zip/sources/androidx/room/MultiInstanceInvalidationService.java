package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.util.LinkedHashMap;
import p097m2.BinderC5776i;
import p097m2.RemoteCallbackListC5777j;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
public final class MultiInstanceInvalidationService extends Service {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f13559t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final LinkedHashMap f13560u = new LinkedHashMap();

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final RemoteCallbackListC5777j f13561v = new RemoteCallbackListC5777j(this);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final BinderC5776i f13562w = new BinderC5776i(this);

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        j.e(intent, "intent");
        return this.f13562w;
    }
}
