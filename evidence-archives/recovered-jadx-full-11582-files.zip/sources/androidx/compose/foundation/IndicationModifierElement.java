package androidx.compose.foundation;

import L0.AbstractC0933c0;
import L0.InterfaceC0946l;
import p095m0.q;
import p182y.j;
import u.f0;
import u.g0;

/* JADX INFO: loaded from: classes.dex */
final class IndicationModifierElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j f13029a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g0 f13030b;

    public IndicationModifierElement(j jVar, g0 g0Var) {
        this.f13029a = jVar;
        this.f13030b = g0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof IndicationModifierElement)) {
            return false;
        }
        IndicationModifierElement indicationModifierElement = (IndicationModifierElement) obj;
        return p146s7.j.a(this.f13029a, indicationModifierElement.f13029a) && p146s7.j.a(this.f13030b, indicationModifierElement.f13030b);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        InterfaceC0946l interfaceC0946lA = this.f13030b.a(this.f13029a);
        f0 f0Var = new f0();
        f0Var.f31526J = interfaceC0946lA;
        f0Var.K0(interfaceC0946lA);
        return f0Var;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        f0 f0Var = (f0) qVar;
        InterfaceC0946l interfaceC0946lA = this.f13030b.a(this.f13029a);
        f0Var.L0(f0Var.f31526J);
        f0Var.f31526J = interfaceC0946lA;
        f0Var.K0(interfaceC0946lA);
    }

    public final int hashCode() {
        return this.f13030b.hashCode() + (this.f13029a.hashCode() * 31);
    }
}
