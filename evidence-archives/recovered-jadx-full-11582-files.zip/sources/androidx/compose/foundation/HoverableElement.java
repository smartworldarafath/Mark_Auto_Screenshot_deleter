package androidx.compose.foundation;

import L0.AbstractC0933c0;
import p095m0.q;
import p182y.j;
import u.Z;

/* JADX INFO: loaded from: classes.dex */
final class HoverableElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j f13028a;

    public HoverableElement(j jVar) {
        this.f13028a = jVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof HoverableElement) && p146s7.j.a(((HoverableElement) obj).f13028a, this.f13028a);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        Z z8 = new Z();
        z8.f31498H = this.f13028a;
        return z8;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        Z z8 = (Z) qVar;
        j jVar = z8.f31498H;
        j jVar2 = this.f13028a;
        if (p146s7.j.a(jVar, jVar2)) {
            return;
        }
        z8.M0();
        z8.f31498H = jVar2;
    }

    public final int hashCode() {
        return this.f13028a.hashCode() * 31;
    }
}
