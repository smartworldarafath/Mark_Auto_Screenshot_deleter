package androidx.compose.foundation.text.contextmenu.modifier;

import L0.AbstractC0933c0;
import O.g;
import T.T;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
final class TextContextMenuGestureElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final T f13139a;

    public TextContextMenuGestureElement(T t8) {
        this.f13139a = t8;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof TextContextMenuGestureElement) {
            return this.f13139a == ((TextContextMenuGestureElement) obj).f13139a;
        }
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return new g(this.f13139a);
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((g) qVar).f8072J = this.f13139a;
    }

    public final int hashCode() {
        return this.f13139a.hashCode();
    }
}
