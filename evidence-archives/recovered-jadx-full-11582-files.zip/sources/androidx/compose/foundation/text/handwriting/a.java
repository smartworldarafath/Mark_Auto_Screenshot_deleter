package androidx.compose.foundation.text.handwriting;

import L0.C0948n;
import Q.c;
import androidx.compose.ui.input.pointer.StylusHoverIconModifierElement;
import p095m0.o;
import p095m0.r;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0948n f13145a;

    static {
        float f4 = 40;
        float f9 = 10;
        f13145a = new C0948n(f9, f4, f9, f4);
    }

    public static final r a(boolean z8, boolean z9, p137r7.a aVar) {
        r stylusHoverIconModifierElement = o.f28594a;
        if (!z8 || !c.f8561a) {
            return stylusHoverIconModifierElement;
        }
        if (z9) {
            stylusHoverIconModifierElement = new StylusHoverIconModifierElement(f13145a);
        }
        return stylusHoverIconModifierElement.e(new StylusHandwritingElement(aVar));
    }
}
