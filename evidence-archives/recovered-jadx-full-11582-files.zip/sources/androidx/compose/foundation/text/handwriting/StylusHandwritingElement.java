package androidx.compose.foundation.text.handwriting;

import L0.AbstractC0933c0;
import Q.b;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
final class StylusHandwritingElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p137r7.a f13144a;

    public StylusHandwritingElement(p137r7.a aVar) {
        this.f13144a = aVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof StylusHandwritingElement) {
            return this.f13144a == ((StylusHandwritingElement) obj).f13144a;
        }
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return new b(this.f13144a);
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((b) qVar).f8558J = this.f13144a;
    }

    public final int hashCode() {
        return this.f13144a.hashCode();
    }
}
