package androidx.compose.foundation.lazy.layout;

import E.C0108l;
import L0.AbstractC0933c0;
import p095m0.q;
import p138s.C5908g0;

/* JADX INFO: loaded from: classes.dex */
public final class LazyLayoutAnimateItemElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C5908g0 f13096a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C5908g0 f13097b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C5908g0 f13098c;

    public LazyLayoutAnimateItemElement(C5908g0 c5908g0, C5908g0 c5908g1, C5908g0 c5908g2) {
        this.f13096a = c5908g0;
        this.f13097b = c5908g1;
        this.f13098c = c5908g2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LazyLayoutAnimateItemElement)) {
            return false;
        }
        LazyLayoutAnimateItemElement lazyLayoutAnimateItemElement = (LazyLayoutAnimateItemElement) obj;
        return this.f13096a.equals(lazyLayoutAnimateItemElement.f13096a) && this.f13097b.equals(lazyLayoutAnimateItemElement.f13097b) && this.f13098c.equals(lazyLayoutAnimateItemElement.f13098c);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        C0108l c0108l = new C0108l();
        c0108l.f1364H = this.f13096a;
        c0108l.f1365I = this.f13097b;
        c0108l.f1366J = this.f13098c;
        return c0108l;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        C0108l c0108l = (C0108l) qVar;
        c0108l.f1364H = this.f13096a;
        c0108l.f1365I = this.f13097b;
        c0108l.f1366J = this.f13098c;
    }

    public final int hashCode() {
        return this.f13098c.hashCode() + ((this.f13097b.hashCode() + (this.f13096a.hashCode() * 31)) * 31);
    }

    public final String toString() {
        return "LazyLayoutAnimateItemElement(fadeInSpec=" + this.f13096a + ", placementSpec=" + this.f13097b + ", fadeOutSpec=" + this.f13098c + ')';
    }
}
