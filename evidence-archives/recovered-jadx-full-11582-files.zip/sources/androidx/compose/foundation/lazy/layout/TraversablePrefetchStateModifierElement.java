package androidx.compose.foundation.lazy.layout;

import E.A0;
import E.d0;
import L0.AbstractC0933c0;
import p095m0.q;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
final class TraversablePrefetchStateModifierElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d0 f13107a;

    public TraversablePrefetchStateModifierElement(d0 d0Var) {
        this.f13107a = d0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof TraversablePrefetchStateModifierElement) && j.a(this.f13107a, ((TraversablePrefetchStateModifierElement) obj).f13107a);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        A0 a9 = new A0();
        a9.f1214H = this.f13107a;
        return a9;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((A0) qVar).f1214H = this.f13107a;
    }

    public final int hashCode() {
        return this.f13107a.hashCode();
    }

    public final String toString() {
        return "TraversablePrefetchStateModifierElement(prefetchState=" + this.f13107a + ')';
    }
}
