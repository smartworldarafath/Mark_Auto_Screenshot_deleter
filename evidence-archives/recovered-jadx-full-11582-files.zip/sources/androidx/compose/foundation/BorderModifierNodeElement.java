package androidx.compose.foundation;

import L0.AbstractC0933c0;
import j1.f;
import p095m0.q;
import p146s7.j;
import p148t0.H;
import p148t0.J;
import u.C5974y;

/* JADX INFO: loaded from: classes.dex */
public final class BorderModifierNodeElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f13013a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final J f13014b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final H f13015c;

    public BorderModifierNodeElement(float f4, J j9, H h9) {
        this.f13013a = f4;
        this.f13014b = j9;
        this.f13015c = h9;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof BorderModifierNodeElement)) {
            return false;
        }
        BorderModifierNodeElement borderModifierNodeElement = (BorderModifierNodeElement) obj;
        return f.a(this.f13013a, borderModifierNodeElement.f13013a) && this.f13014b.equals(borderModifierNodeElement.f13014b) && j.a(this.f13015c, borderModifierNodeElement.f13015c);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return new C5974y(this.f13013a, this.f13014b, this.f13015c);
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        C5974y c5974y = (C5974y) qVar;
        float f4 = c5974y.f31644K;
        p124q0.b bVar = c5974y.f31647N;
        float f9 = this.f13013a;
        if (!f.a(f4, f9)) {
            c5974y.f31644K = f9;
            bVar.K0();
        }
        J j9 = c5974y.f31645L;
        J j10 = this.f13014b;
        if (!j.a(j9, j10)) {
            c5974y.f31645L = j10;
            bVar.K0();
        }
        H h9 = c5974y.f31646M;
        H h10 = this.f13015c;
        if (j.a(h9, h10)) {
            return;
        }
        c5974y.f31646M = h10;
        bVar.K0();
    }

    public final int hashCode() {
        return this.f13015c.hashCode() + ((this.f13014b.hashCode() + (Float.hashCode(this.f13013a) * 31)) * 31);
    }

    public final String toString() {
        return "BorderModifierNodeElement(width=" + ((Object) f.b(this.f13013a)) + ", brush=" + this.f13014b + ", shape=" + this.f13015c + ')';
    }
}
