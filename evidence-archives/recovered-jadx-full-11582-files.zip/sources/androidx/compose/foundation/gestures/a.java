package androidx.compose.foundation.gestures;

import I.B0;
import j7.c;
import p032d7.AbstractC5727a;
import p138s.E0;
import p139s0.b;
import p146s7.r;
import p166w.C6003n0;
import p166w.C6005o0;
import p166w.C6007p0;
import p166w.C6009q0;
import p166w.C6010r0;
import p166w.EnumC5991h0;
import p166w.I0;
import p182y.j;
import u.l0;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final E0 f13058a = new E0(21);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C6005o0 f13059b = new C6005o0();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C6003n0 f13060c = new C6003n0();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final C6007p0 f13061d = new C6007p0();

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object a(I0 i4, long j9, c cVar) {
        C6009q0 c6009q0;
        r rVar;
        I0 i9;
        if (cVar instanceof C6009q0) {
            c6009q0 = (C6009q0) cVar;
            int i = c6009q0.f32224z;
            if ((i & Integer.MIN_VALUE) != 0) {
                c6009q0.f32224z = i - Integer.MIN_VALUE;
            } else {
                c6009q0 = new C6009q0(cVar);
            }
        } else {
            c6009q0 = new C6009q0(cVar);
        }
        Object obj = c6009q0.f32223y;
        int i10 = c6009q0.f32224z;
        if (i10 == 0) {
            AbstractC5727a.e(obj);
            rVar = new r();
            C6010r0 c6010r0 = new C6010r0(i4, j9, rVar, null);
            c6009q0.f32222w = i4;
            c6009q0.x = rVar;
            c6009q0.f32224z = 1;
            Object objF = i4.f(l0.f31557t, c6010r0, c6009q0);
            p069i7.a aVar = p069i7.a.f27481t;
            if (objF == aVar) {
                return aVar;
            }
            i9 = i4;
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            r rVar2 = c6009q0.x;
            I0 i11 = c6009q0.f32222w;
            AbstractC5727a.e(obj);
            rVar = rVar2;
            i9 = i11;
        }
        return new b(i9.h(rVar.f31258t));
    }

    public static p095m0.r b(B0 b9, EnumC5991h0 enumC5991h0, boolean z8, boolean z9, j jVar) {
        return new ScrollableElement(b9, enumC5991h0, z8, z9, jVar);
    }
}
