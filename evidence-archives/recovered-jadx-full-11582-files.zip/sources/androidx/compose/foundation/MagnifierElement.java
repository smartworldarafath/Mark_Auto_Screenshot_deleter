package androidx.compose.foundation;

import L0.AbstractC0933c0;
import L0.AbstractC0938f;
import T.i0;
import T.j0;
import T0.v;
import android.view.View;
import j1.f;
import p095m0.q;
import p127q3.h;
import p146s7.j;
import u.k0;
import u.w0;

/* JADX INFO: loaded from: classes.dex */
public final class MagnifierElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j0 f13031a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final i0 f13032b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final w0 f13033c;

    public MagnifierElement(j0 j0Var, i0 i0Var, w0 w0Var) {
        this.f13031a = j0Var;
        this.f13032b = i0Var;
        this.f13033c = w0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MagnifierElement)) {
            return false;
        }
        j0 j0Var = ((MagnifierElement) obj).f13031a;
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return new u.j0(this.f13031a, this.f13032b, this.f13033c);
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        u.j0 j0Var = (u.j0) qVar;
        j0Var.getClass();
        w0 w0Var = j0Var.f31543J;
        View view = j0Var.f31544K;
        j1.c cVar = j0Var.f31545L;
        j0Var.f31541H = this.f13031a;
        j0Var.f31542I = this.f13032b;
        w0 w0Var2 = this.f13033c;
        j0Var.f31543J = w0Var2;
        View viewX = AbstractC0938f.x(j0Var);
        j1.c cVar2 = AbstractC0938f.v(j0Var).f6215Q;
        if (j0Var.f31546M != null) {
            v vVar = k0.f31554a;
            if (((!Float.isNaN(Float.NaN) || !Float.isNaN(Float.NaN)) && !w0Var2.a()) || !f.a(Float.NaN, Float.NaN) || !f.a(Float.NaN, Float.NaN) || !w0Var2.equals(w0Var) || !viewX.equals(view) || !j.a(cVar2, cVar)) {
                j0Var.L0();
            }
        }
        j0Var.M0();
    }

    public final int hashCode() {
        return this.f13033c.hashCode() + ((this.f13032b.hashCode() + h.e(h.b(Float.NaN, h.b(Float.NaN, h.d(h.e(h.b(Float.NaN, this.f13031a.hashCode() * 961, 31), 31, true), 31, 9205357640488583168L), 31), 31), 31, true)) * 31);
    }
}
