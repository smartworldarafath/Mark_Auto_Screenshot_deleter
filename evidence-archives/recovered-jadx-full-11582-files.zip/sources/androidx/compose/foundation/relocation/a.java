package androidx.compose.foundation.relocation;

import F.b;
import p095m0.r;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final r a(r rVar, b bVar) {
        return rVar.e(new BringIntoViewRequesterElement(bVar));
    }
}
