package androidx.compose.foundation.relocation;

import F.b;
import F.c;
import L0.AbstractC0933c0;
import p095m0.q;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
final class BringIntoViewRequesterElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f13122a;

    public BringIntoViewRequesterElement(b bVar) {
        this.f13122a = bVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof BringIntoViewRequesterElement) {
            return j.a(this.f13122a, ((BringIntoViewRequesterElement) obj).f13122a);
        }
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        c cVar = new c();
        cVar.f1933H = this.f13122a;
        return cVar;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        c cVar = (c) qVar;
        b bVar = cVar.f1933H;
        if (bVar != null) {
            bVar.f1932a.l(cVar);
        }
        b bVar2 = this.f13122a;
        if (bVar2 != null) {
            bVar2.f1932a.b(cVar);
        }
        cVar.f1933H = bVar2;
    }

    public final int hashCode() {
        return this.f13122a.hashCode();
    }
}
