package androidx.compose.foundation.layout;

import A.C0012m;
import L0.AbstractC0933c0;
import p095m0.j;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
final class BoxChildDataElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j f13062a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f13063b;

    public BoxChildDataElement(j jVar, boolean z8) {
        this.f13062a = jVar;
        this.f13063b = z8;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        BoxChildDataElement boxChildDataElement = obj instanceof BoxChildDataElement ? (BoxChildDataElement) obj : null;
        return boxChildDataElement != null && this.f13062a.equals(boxChildDataElement.f13062a) && this.f13063b == boxChildDataElement.f13063b;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        C0012m c0012m = new C0012m();
        c0012m.f128H = this.f13062a;
        c0012m.f129I = this.f13063b;
        return c0012m;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        C0012m c0012m = (C0012m) qVar;
        c0012m.f128H = this.f13062a;
        c0012m.f129I = this.f13063b;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f13063b) + (this.f13062a.hashCode() * 31);
    }
}
