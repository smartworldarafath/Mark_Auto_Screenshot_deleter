package androidx.compose.foundation.layout;

import A.C0011l;
import L0.AbstractC0933c0;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
final class AspectRatioElement extends AbstractC0933c0 {
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof AspectRatioElement ? (AspectRatioElement) obj : null) == null) {
            return false;
        }
        ((AspectRatioElement) obj).getClass();
        return true;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        C0011l c0011l = new C0011l();
        c0011l.f126H = 1.0f;
        return c0011l;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((C0011l) qVar).f126H = 1.0f;
    }

    public final int hashCode() {
        return Boolean.hashCode(false) + (Float.hashCode(1.0f) * 31);
    }
}
