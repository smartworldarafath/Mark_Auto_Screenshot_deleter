package androidx.compose.foundation.layout;

import A.U;
import A.V;
import j1.m;
import p095m0.r;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static V a(int i, float f4) {
        if ((i & 1) != 0) {
            f4 = 0;
        }
        float f9 = 0;
        return new V(f4, f9, f4, f9);
    }

    public static final V b(float f4, float f9, float f10, float f11) {
        return new V(f4, f9, f10, f11);
    }

    public static r c(r rVar) {
        return rVar.e(new AspectRatioElement());
    }

    public static final float d(U u8, m mVar) {
        return mVar == m.f27654t ? u8.b(mVar) : u8.c(mVar);
    }

    public static final float e(U u8, m mVar) {
        return mVar == m.f27654t ? u8.c(mVar) : u8.b(mVar);
    }

    public static final r f(r rVar) {
        return rVar.e(new IntrinsicHeightElement());
    }

    public static final boolean g(int i, int i4, long j9) {
        int iJ = j1.a.j(j9);
        if (i > j1.a.h(j9) || iJ > i) {
            return false;
        }
        return i4 <= j1.a.g(j9) && j1.a.i(j9) <= i4;
    }

    public static r h(r rVar, float f4) {
        return rVar.e(new OffsetElement(0, f4));
    }

    public static final r i(r rVar, U u8) {
        return rVar.e(new PaddingValuesElement(u8));
    }

    public static final r j(r rVar, float f4) {
        return rVar.e(new PaddingElement(f4, f4, f4, f4));
    }

    public static final r k(r rVar, float f4, float f9) {
        return rVar.e(new PaddingElement(f4, f9, f4, f9));
    }

    public static r l(r rVar, float f4, float f9, int i) {
        if ((i & 1) != 0) {
            f4 = 0;
        }
        if ((i & 2) != 0) {
            f9 = 0;
        }
        return k(rVar, f4, f9);
    }

    public static final r m(r rVar, float f4, float f9, float f10, float f11) {
        return rVar.e(new PaddingElement(f4, f9, f10, f11));
    }

    public static r n(r rVar, float f4, float f9, float f10, float f11, int i) {
        if ((i & 1) != 0) {
            f4 = 0;
        }
        if ((i & 2) != 0) {
            f9 = 0;
        }
        if ((i & 4) != 0) {
            f10 = 0;
        }
        if ((i & 8) != 0) {
            f11 = 0;
        }
        return m(rVar, f4, f9, f10, f11);
    }

    public static final r o(r rVar) {
        return rVar.e(new IntrinsicWidthElement());
    }
}
