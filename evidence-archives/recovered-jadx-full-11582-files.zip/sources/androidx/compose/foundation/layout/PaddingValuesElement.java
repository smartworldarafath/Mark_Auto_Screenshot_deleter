package androidx.compose.foundation.layout;

import A.U;
import A.W;
import L0.AbstractC0933c0;
import p095m0.q;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
final class PaddingValuesElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final U f13075a;

    public PaddingValuesElement(U u8) {
        this.f13075a = u8;
    }

    public final boolean equals(Object obj) {
        PaddingValuesElement paddingValuesElement = obj instanceof PaddingValuesElement ? (PaddingValuesElement) obj : null;
        if (paddingValuesElement == null) {
            return false;
        }
        return j.a(this.f13075a, paddingValuesElement.f13075a);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        W w6 = new W();
        w6.f52H = this.f13075a;
        return w6;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((W) qVar).f52H = this.f13075a;
    }

    public final int hashCode() {
        return this.f13075a.hashCode();
    }
}
