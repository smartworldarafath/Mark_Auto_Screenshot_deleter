package androidx.compose.foundation.layout;

import A.f0;
import L0.AbstractC0933c0;
import j1.f;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
final class UnspecifiedConstraintsElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f13081a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f13082b;

    public UnspecifiedConstraintsElement(float f4, float f9) {
        this.f13081a = f4;
        this.f13082b = f9;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof UnspecifiedConstraintsElement)) {
            return false;
        }
        UnspecifiedConstraintsElement unspecifiedConstraintsElement = (UnspecifiedConstraintsElement) obj;
        return f.a(this.f13081a, unspecifiedConstraintsElement.f13081a) && f.a(this.f13082b, unspecifiedConstraintsElement.f13082b);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        f0 f0Var = new f0();
        f0Var.f88H = this.f13081a;
        f0Var.f89I = this.f13082b;
        return f0Var;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        f0 f0Var = (f0) qVar;
        f0Var.f88H = this.f13081a;
        f0Var.f89I = this.f13082b;
    }

    public final int hashCode() {
        return Float.hashCode(this.f13082b) + (Float.hashCode(this.f13081a) * 31);
    }
}
