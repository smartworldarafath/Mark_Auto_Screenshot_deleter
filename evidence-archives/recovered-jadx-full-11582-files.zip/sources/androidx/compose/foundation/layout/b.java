package androidx.compose.foundation.layout;

import p095m0.j;
import p095m0.r;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final b f13087a = new b();

    public final r a(r rVar, j jVar) {
        return rVar.e(new BoxChildDataElement(jVar, false));
    }

    public final r b() {
        return new BoxChildDataElement(p095m0.c.x, true);
    }
}
