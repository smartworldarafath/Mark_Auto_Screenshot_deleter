package androidx.compose.foundation.layout;

import A.K;
import A.L;
import L0.AbstractC0933c0;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
final class IntrinsicHeightElement extends AbstractC0933c0 {
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof IntrinsicHeightElement ? (IntrinsicHeightElement) obj : null) != null;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        K k4 = new K(0);
        k4.f25I = L.f27t;
        k4.f26J = true;
        return k4;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        K k4 = (K) qVar;
        k4.f25I = L.f27t;
        k4.f26J = true;
    }

    public final int hashCode() {
        return Boolean.hashCode(true) + (L.f27t.hashCode() * 31);
    }
}
