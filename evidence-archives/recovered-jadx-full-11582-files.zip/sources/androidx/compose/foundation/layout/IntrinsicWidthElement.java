package androidx.compose.foundation.layout;

import A.L;
import A.N;
import L0.AbstractC0933c0;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
final class IntrinsicWidthElement extends AbstractC0933c0 {
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof IntrinsicWidthElement ? (IntrinsicWidthElement) obj : null) != null;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        N n8 = new N(0);
        n8.f31I = L.f28u;
        n8.f32J = true;
        return n8;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        N n8 = (N) qVar;
        n8.f31I = L.f28u;
        n8.f32J = true;
    }

    public final int hashCode() {
        return Boolean.hashCode(true) + (L.f28u.hashCode() * 31);
    }
}
