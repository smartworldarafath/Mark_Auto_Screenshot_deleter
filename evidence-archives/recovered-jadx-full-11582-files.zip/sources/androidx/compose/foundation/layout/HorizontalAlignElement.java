package androidx.compose.foundation.layout;

import A.E;
import L0.AbstractC0933c0;
import p095m0.h;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
public final class HorizontalAlignElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final h f13066a;

    public HorizontalAlignElement(h hVar) {
        this.f13066a = hVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        HorizontalAlignElement horizontalAlignElement = obj instanceof HorizontalAlignElement ? (HorizontalAlignElement) obj : null;
        if (horizontalAlignElement == null) {
            return false;
        }
        return this.f13066a.equals(horizontalAlignElement.f13066a);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        E e4 = new E();
        e4.f8H = this.f13066a;
        return e4;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((E) qVar).f8H = this.f13066a;
    }

    public final int hashCode() {
        return Float.hashCode(this.f13066a.f28585a);
    }
}
