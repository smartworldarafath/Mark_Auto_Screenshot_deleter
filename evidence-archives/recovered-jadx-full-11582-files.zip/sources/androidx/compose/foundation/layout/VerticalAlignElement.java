package androidx.compose.foundation.layout;

import A.h0;
import L0.AbstractC0933c0;
import p095m0.i;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
public final class VerticalAlignElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i f13083a;

    public VerticalAlignElement(i iVar) {
        this.f13083a = iVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        VerticalAlignElement verticalAlignElement = obj instanceof VerticalAlignElement ? (VerticalAlignElement) obj : null;
        if (verticalAlignElement == null) {
            return false;
        }
        return this.f13083a.equals(verticalAlignElement.f13083a);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        h0 h0Var = new h0();
        h0Var.f95H = this.f13083a;
        return h0Var;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((h0) qVar).f95H = this.f13083a;
    }

    public final int hashCode() {
        return Float.hashCode(this.f13083a.f28586a);
    }
}
