package androidx.compose.foundation.layout;

import A.d0;
import L0.AbstractC0933c0;
import j1.f;
import p095m0.q;
import p127q3.h;

/* JADX INFO: loaded from: classes.dex */
final class SizeElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f13076a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f13077b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f13078c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f13079d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f13080e;

    public SizeElement(float f4, float f9, float f10, float f11, boolean z8) {
        this.f13076a = f4;
        this.f13077b = f9;
        this.f13078c = f10;
        this.f13079d = f11;
        this.f13080e = z8;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SizeElement)) {
            return false;
        }
        SizeElement sizeElement = (SizeElement) obj;
        return f.a(this.f13076a, sizeElement.f13076a) && f.a(this.f13077b, sizeElement.f13077b) && f.a(this.f13078c, sizeElement.f13078c) && f.a(this.f13079d, sizeElement.f13079d) && this.f13080e == sizeElement.f13080e;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        d0 d0Var = new d0();
        d0Var.f78H = this.f13076a;
        d0Var.f79I = this.f13077b;
        d0Var.f80J = this.f13078c;
        d0Var.f81K = this.f13079d;
        d0Var.f82L = this.f13080e;
        return d0Var;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        d0 d0Var = (d0) qVar;
        d0Var.f78H = this.f13076a;
        d0Var.f79I = this.f13077b;
        d0Var.f80J = this.f13078c;
        d0Var.f81K = this.f13079d;
        d0Var.f82L = this.f13080e;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f13080e) + h.b(this.f13079d, h.b(this.f13078c, h.b(this.f13077b, Float.hashCode(this.f13076a) * 31, 31), 31), 31);
    }

    public /* synthetic */ SizeElement(float f4, float f9, float f10, float f11, int i) {
        this((i & 1) != 0 ? Float.NaN : f4, (i & 2) != 0 ? Float.NaN : f9, (i & 4) != 0 ? Float.NaN : f10, (i & 8) != 0 ? Float.NaN : f11, true);
    }
}
