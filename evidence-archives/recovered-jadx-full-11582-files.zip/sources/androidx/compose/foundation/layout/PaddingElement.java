package androidx.compose.foundation.layout;

import A.T;
import L0.AbstractC0933c0;
import j1.f;
import p095m0.q;
import p127q3.h;

/* JADX INFO: loaded from: classes.dex */
final class PaddingElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f13071a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f13072b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f13073c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f13074d;

    public PaddingElement(float f4, float f9, float f10, float f11) {
        this.f13071a = f4;
        this.f13072b = f9;
        this.f13073c = f10;
        this.f13074d = f11;
        boolean z8 = true;
        boolean z9 = (f4 >= 0.0f || Float.isNaN(f4)) & (f9 >= 0.0f || Float.isNaN(f9)) & (f10 >= 0.0f || Float.isNaN(f10));
        if (f11 < 0.0f && !Float.isNaN(f11)) {
            z8 = false;
        }
        if (!z9 || !z8) {
            B.a.a("Padding must be non-negative");
        }
    }

    public final boolean equals(Object obj) {
        PaddingElement paddingElement = obj instanceof PaddingElement ? (PaddingElement) obj : null;
        return paddingElement != null && f.a(this.f13071a, paddingElement.f13071a) && f.a(this.f13072b, paddingElement.f13072b) && f.a(this.f13073c, paddingElement.f13073c) && f.a(this.f13074d, paddingElement.f13074d);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        T t8 = new T();
        t8.f43H = this.f13071a;
        t8.f44I = this.f13072b;
        t8.f45J = this.f13073c;
        t8.f46K = this.f13074d;
        t8.f47L = true;
        return t8;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        T t8 = (T) qVar;
        t8.f43H = this.f13071a;
        t8.f44I = this.f13072b;
        t8.f45J = this.f13073c;
        t8.f46K = this.f13074d;
        t8.f47L = true;
    }

    public final int hashCode() {
        return Boolean.hashCode(true) + h.b(this.f13074d, h.b(this.f13073c, h.b(this.f13072b, Float.hashCode(this.f13071a) * 31, 31), 31), 31);
    }
}
