package androidx.compose.foundation.layout;

import A.A;
import A.q0;
import L0.AbstractC0933c0;
import p095m0.q;
import p127q3.h;
import p137r7.e;

/* JADX INFO: loaded from: classes.dex */
final class WrapContentElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final A f13084a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final e f13085b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f13086c;

    public WrapContentElement(A a9, e eVar, Object obj) {
        this.f13084a = a9;
        this.f13085b = eVar;
        this.f13086c = obj;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || WrapContentElement.class != obj.getClass()) {
            return false;
        }
        WrapContentElement wrapContentElement = (WrapContentElement) obj;
        return this.f13084a == wrapContentElement.f13084a && this.f13086c.equals(wrapContentElement.f13086c);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        q0 q0Var = new q0();
        q0Var.f153H = this.f13084a;
        q0Var.f154I = this.f13085b;
        return q0Var;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        q0 q0Var = (q0) qVar;
        q0Var.f153H = this.f13084a;
        q0Var.f154I = this.f13085b;
    }

    public final int hashCode() {
        return this.f13086c.hashCode() + h.e(this.f13084a.hashCode() * 31, 31, false);
    }
}
