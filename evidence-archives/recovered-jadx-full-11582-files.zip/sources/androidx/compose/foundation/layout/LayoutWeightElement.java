package androidx.compose.foundation.layout;

import A.O;
import L0.AbstractC0933c0;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
public final class LayoutWeightElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f13067a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f13068b;

    public LayoutWeightElement(float f4, boolean z8) {
        this.f13067a = f4;
        this.f13068b = z8;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        LayoutWeightElement layoutWeightElement = obj instanceof LayoutWeightElement ? (LayoutWeightElement) obj : null;
        return layoutWeightElement != null && this.f13067a == layoutWeightElement.f13067a && this.f13068b == layoutWeightElement.f13068b;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        O o5 = new O();
        o5.f33H = this.f13067a;
        o5.f34I = this.f13068b;
        return o5;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        O o5 = (O) qVar;
        o5.f33H = this.f13067a;
        o5.f34I = this.f13068b;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f13068b) + (Float.hashCode(this.f13067a) * 31);
    }
}
