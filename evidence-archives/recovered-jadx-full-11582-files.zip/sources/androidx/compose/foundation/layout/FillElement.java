package androidx.compose.foundation.layout;

import A.A;
import A.C;
import L0.AbstractC0933c0;
import p095m0.q;

/* JADX INFO: Access modifiers changed from: package-private */
/* JADX INFO: loaded from: classes.dex */
public final class FillElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final A f13064a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f13065b;

    public FillElement(A a9, float f4) {
        this.f13064a = a9;
        this.f13065b = f4;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FillElement)) {
            return false;
        }
        FillElement fillElement = (FillElement) obj;
        return this.f13064a == fillElement.f13064a && this.f13065b == fillElement.f13065b;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        C c9 = new C();
        c9.f6H = this.f13064a;
        c9.f7I = this.f13065b;
        return c9;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        C c9 = (C) qVar;
        c9.f6H = this.f13064a;
        c9.f7I = this.f13065b;
    }

    public final int hashCode() {
        return Float.hashCode(this.f13065b) + (this.f13064a.hashCode() * 31);
    }
}
