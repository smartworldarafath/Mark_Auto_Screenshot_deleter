package androidx.compose.material3.internal;

import D7.AbstractC0094y;
import P2.u;
import Y.C1294c;
import Y.C1295d;
import Y.C1296e;
import Y.C1299h;
import j7.c;
import j7.i;
import p032d7.AbstractC5727a;
import p032d7.z;
import p095m0.r;
import p137r7.e;
import u.l0;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object a(p137r7.a aVar, e eVar, c cVar) {
        C1296e c1296e;
        if (cVar instanceof C1296e) {
            c1296e = (C1296e) cVar;
            int i = c1296e.x;
            if ((i & Integer.MIN_VALUE) != 0) {
                c1296e.x = i - Integer.MIN_VALUE;
            } else {
                c1296e = new C1296e(cVar);
            }
        } else {
            c1296e = new C1296e(cVar);
        }
        Object obj = c1296e.f11841w;
        int i4 = c1296e.x;
        try {
            if (i4 == 0) {
                AbstractC5727a.e(obj);
                C1299h c1299h = new C1299h(aVar, eVar, null);
                c1296e.x = 1;
                Object objJ = AbstractC0094y.j(c1299h, c1296e);
                p069i7.a aVar2 = p069i7.a.f27481t;
                if (objJ == aVar2) {
                    return aVar2;
                }
            } else {
                if (i4 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC5727a.e(obj);
            }
        } catch (C1294c unused) {
        }
        return z.f26831a;
    }

    public static final Object b(u uVar, Object obj, float f4, i iVar) throws Throwable {
        Object objC = uVar.c(obj, l0.f31557t, new C1295d(uVar, f4, null), iVar);
        return objC == p069i7.a.f27481t ? objC : z.f26831a;
    }

    public static final r c(r rVar, u uVar, e eVar) {
        return rVar.e(new DraggableAnchorsElement(uVar, eVar));
    }
}
