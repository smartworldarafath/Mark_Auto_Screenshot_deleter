package androidx.compose.material3;

import L0.AbstractC0933c0;
import X.C1258o0;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
public final class MinimumInteractiveModifier extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final MinimumInteractiveModifier f13176a = new MinimumInteractiveModifier();

    private MinimumInteractiveModifier() {
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return new C1258o0();
    }

    @Override // L0.AbstractC0933c0
    public final /* bridge */ /* synthetic */ void h(q qVar) {
    }

    public final int hashCode() {
        return System.identityHashCode(this);
    }
}
