package androidx.compose.ui;

import L0.AbstractC0933c0;
import p095m0.q;
import p095m0.v;

/* JADX INFO: loaded from: classes.dex */
public final class ZIndexElement extends AbstractC0933c0 {
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ZIndexElement)) {
            return false;
        }
        ((ZIndexElement) obj).getClass();
        return Float.compare(1.0f, 1.0f) == 0;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        v vVar = new v();
        vVar.f28614H = 1.0f;
        return vVar;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((v) qVar).f28614H = 1.0f;
    }

    public final int hashCode() {
        return Float.hashCode(1.0f);
    }

    public final String toString() {
        return "ZIndexElement(zIndex=1.0)";
    }
}
