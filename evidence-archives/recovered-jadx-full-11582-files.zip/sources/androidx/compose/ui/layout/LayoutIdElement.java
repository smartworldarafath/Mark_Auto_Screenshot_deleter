package androidx.compose.ui.layout;

import J0.C0899w;
import L0.AbstractC0933c0;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
final class LayoutIdElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f13225a;

    public LayoutIdElement(String str) {
        this.f13225a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof LayoutIdElement) && this.f13225a.equals(((LayoutIdElement) obj).f13225a);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        C0899w c0899w = new C0899w();
        c0899w.f5667H = this.f13225a;
        return c0899w;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((C0899w) qVar).f5667H = this.f13225a;
    }

    public final int hashCode() {
        return this.f13225a.hashCode();
    }

    public final String toString() {
        return "LayoutIdElement(layoutId=" + ((Object) this.f13225a) + ')';
    }
}
