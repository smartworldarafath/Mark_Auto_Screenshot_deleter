package androidx.compose.ui.layout;

import J0.C0899w;
import J0.L;
import p095m0.r;
import p137r7.c;
import p137r7.f;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final Object a(L l8) {
        Object objG = l8.G();
        C0899w c0899w = objG instanceof C0899w ? (C0899w) objG : null;
        if (c0899w != null) {
            return c0899w.f5667H;
        }
        return null;
    }

    public static final r b(r rVar, f fVar) {
        return rVar.e(new LayoutElement(fVar));
    }

    public static final r c(r rVar, String str) {
        return rVar.e(new LayoutIdElement(str));
    }

    public static final r d(r rVar, c cVar) {
        return rVar.e(new OnGloballyPositionedElement(cVar));
    }

    public static final r e(r rVar, c cVar) {
        return rVar.e(new OnSizeChangedModifier(cVar));
    }
}
