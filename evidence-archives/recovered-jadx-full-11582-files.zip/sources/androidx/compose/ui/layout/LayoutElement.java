package androidx.compose.ui.layout;

import J0.C0901y;
import L0.AbstractC0933c0;
import p095m0.q;
import p137r7.f;

/* JADX INFO: loaded from: classes.dex */
final class LayoutElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f f13224a;

    public LayoutElement(f fVar) {
        this.f13224a = fVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof LayoutElement) {
            return this.f13224a == ((LayoutElement) obj).f13224a;
        }
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        C0901y c0901y = new C0901y();
        c0901y.f5668H = this.f13224a;
        return c0901y;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((C0901y) qVar).f5668H = this.f13224a;
    }

    public final int hashCode() {
        return this.f13224a.hashCode();
    }
}
