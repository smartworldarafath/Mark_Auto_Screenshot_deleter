package androidx.compose.ui.layout;

import J0.U;
import L0.AbstractC0933c0;
import p095m0.q;
import p137r7.c;

/* JADX INFO: loaded from: classes.dex */
final class OnSizeChangedModifier extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f13227a;

    public OnSizeChangedModifier(c cVar) {
        this.f13227a = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof OnSizeChangedModifier) {
            return this.f13227a == ((OnSizeChangedModifier) obj).f13227a;
        }
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        U u8 = new U();
        u8.f5559H = this.f13227a;
        long j9 = Integer.MIN_VALUE;
        u8.f5560I = (j9 & 4294967295L) | (j9 << 32);
        return u8;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        U u8 = (U) qVar;
        u8.f5559H = this.f13227a;
        long j9 = Integer.MIN_VALUE;
        u8.f5560I = (j9 & 4294967295L) | (j9 << 32);
    }

    public final int hashCode() {
        return this.f13227a.hashCode();
    }
}
