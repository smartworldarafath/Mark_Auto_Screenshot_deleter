package androidx.compose.ui.layout;

import J0.T;
import L0.AbstractC0933c0;
import p095m0.q;
import p137r7.c;

/* JADX INFO: loaded from: classes.dex */
final class OnGloballyPositionedElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f13226a;

    public OnGloballyPositionedElement(c cVar) {
        this.f13226a = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof OnGloballyPositionedElement) {
            return this.f13226a == ((OnGloballyPositionedElement) obj).f13226a;
        }
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        T t8 = new T();
        t8.f5558H = this.f13226a;
        return t8;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((T) qVar).f5558H = this.f13226a;
    }

    public final int hashCode() {
        return this.f13226a.hashCode();
    }
}
