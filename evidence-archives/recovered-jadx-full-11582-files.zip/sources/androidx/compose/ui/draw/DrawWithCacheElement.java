package androidx.compose.ui.draw;

import L0.AbstractC0933c0;
import p095m0.q;
import p124q0.b;
import p137r7.c;

/* JADX INFO: loaded from: classes.dex */
final class DrawWithCacheElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f13190a;

    public DrawWithCacheElement(c cVar) {
        this.f13190a = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof DrawWithCacheElement) {
            return this.f13190a == ((DrawWithCacheElement) obj).f13190a;
        }
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return new b(new p124q0.c(), this.f13190a);
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        b bVar = (b) qVar;
        bVar.f30237J = this.f13190a;
        bVar.K0();
    }

    public final int hashCode() {
        return this.f13190a.hashCode();
    }
}
