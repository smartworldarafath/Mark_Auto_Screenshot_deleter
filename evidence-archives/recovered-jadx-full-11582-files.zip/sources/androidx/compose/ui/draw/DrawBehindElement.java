package androidx.compose.ui.draw;

import L0.AbstractC0933c0;
import p095m0.q;
import p124q0.d;
import p137r7.c;

/* JADX INFO: loaded from: classes.dex */
final class DrawBehindElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f13189a;

    public DrawBehindElement(c cVar) {
        this.f13189a = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof DrawBehindElement) {
            return this.f13189a == ((DrawBehindElement) obj).f13189a;
        }
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        d dVar = new d();
        dVar.f30240H = this.f13189a;
        return dVar;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((d) qVar).f30240H = this.f13189a;
    }

    public final int hashCode() {
        return this.f13189a.hashCode();
    }
}
