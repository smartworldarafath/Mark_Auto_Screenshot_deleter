package androidx.compose.ui.draw;

import L0.AbstractC0933c0;
import p095m0.q;
import p124q0.e;
import p137r7.c;

/* JADX INFO: loaded from: classes.dex */
final class DrawWithContentElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f13191a;

    public DrawWithContentElement(c cVar) {
        this.f13191a = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof DrawWithContentElement) {
            return this.f13191a == ((DrawWithContentElement) obj).f13191a;
        }
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        e eVar = new e();
        eVar.f30241H = this.f13191a;
        return eVar;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((e) qVar).f30241H = this.f13191a;
    }

    public final int hashCode() {
        return this.f13191a.hashCode();
    }
}
