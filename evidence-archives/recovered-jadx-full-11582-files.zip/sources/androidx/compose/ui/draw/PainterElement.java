package androidx.compose.ui.draw;

import J0.S;
import L0.AbstractC0933c0;
import L0.AbstractC0938f;
import p095m0.e;
import p095m0.q;
import p124q0.g;
import p127q3.h;
import p146s7.j;
import p148t0.C5945k;
import p183y0.b;

/* JADX INFO: loaded from: classes.dex */
final class PainterElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f13192a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final e f13193b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final S f13194c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f13195d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C5945k f13196e;

    public PainterElement(b bVar, e eVar, S s8, float f4, C5945k c5945k) {
        this.f13192a = bVar;
        this.f13193b = eVar;
        this.f13194c = s8;
        this.f13195d = f4;
        this.f13196e = c5945k;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof PainterElement)) {
            return false;
        }
        PainterElement painterElement = (PainterElement) obj;
        return j.a(this.f13192a, painterElement.f13192a) && j.a(this.f13193b, painterElement.f13193b) && this.f13194c.equals(painterElement.f13194c) && Float.compare(this.f13195d, painterElement.f13195d) == 0 && j.a(this.f13196e, painterElement.f13196e);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        g gVar = new g();
        gVar.f30245H = this.f13192a;
        gVar.f30246I = true;
        gVar.f30247J = this.f13193b;
        gVar.f30248K = this.f13194c;
        gVar.f30249L = this.f13195d;
        gVar.f30250M = this.f13196e;
        return gVar;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        g gVar = (g) qVar;
        boolean z8 = gVar.f30246I;
        b bVar = this.f13192a;
        boolean z9 = (z8 && p139s0.e.a(gVar.f30245H.h(), bVar.h())) ? false : true;
        gVar.f30245H = bVar;
        gVar.f30246I = true;
        gVar.f30247J = this.f13193b;
        gVar.f30248K = this.f13194c;
        gVar.f30249L = this.f13195d;
        gVar.f30250M = this.f13196e;
        if (z9) {
            AbstractC0938f.m(gVar);
        }
        AbstractC0938f.l(gVar);
    }

    public final int hashCode() {
        int iB = h.b(this.f13195d, (this.f13194c.hashCode() + ((this.f13193b.hashCode() + h.e(this.f13192a.hashCode() * 31, 31, true)) * 31)) * 31, 31);
        C5945k c5945k = this.f13196e;
        return iB + (c5945k == null ? 0 : c5945k.hashCode());
    }

    public final String toString() {
        return "PainterElement(painter=" + this.f13192a + ", sizeToIntrinsics=true, alignment=" + this.f13193b + ", contentScale=" + this.f13194c + ", alpha=" + this.f13195d + ", colorFilter=" + this.f13196e + ')';
    }
}
