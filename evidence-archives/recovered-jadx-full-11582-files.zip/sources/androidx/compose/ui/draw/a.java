package androidx.compose.ui.draw;

import J0.S;
import p095m0.j;
import p095m0.r;
import p137r7.c;
import p148t0.C5945k;
import p183y0.b;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final r a(r rVar, c cVar) {
        return rVar.e(new DrawBehindElement(cVar));
    }

    public static final r b(r rVar, c cVar) {
        return rVar.e(new DrawWithCacheElement(cVar));
    }

    public static final r c(r rVar, c cVar) {
        return rVar.e(new DrawWithContentElement(cVar));
    }

    public static r d(r rVar, b bVar, S s8, float f4, C5945k c5945k, int i) {
        j jVar = p095m0.c.x;
        if ((i & 16) != 0) {
            f4 = 1.0f;
        }
        return rVar.e(new PainterElement(bVar, jVar, s8, f4, c5945k));
    }
}
