package androidx.compose.ui.graphics;

import p095m0.r;
import p137r7.c;
import p148t0.D;
import p148t0.H;
import p148t0.K;
import p148t0.u;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final r a(r rVar, c cVar) {
        return rVar.e(new BlockGraphicsLayerElement(cVar));
    }

    public static final r b(r rVar, float f4, float f9, float f10, float f11, float f12, long j9, H h9, boolean z8, long j10, long j11) {
        return rVar.e(new GraphicsLayerElement(f4, f9, f10, f11, f12, j9, h9, z8, j10, j11));
    }

    public static r c(r rVar, float f4, float f9, float f10, float f11, H h9, int i) {
        float f12 = (i & 1) != 0 ? 1.0f : f4;
        float f13 = (i & 2) != 0 ? 1.0f : f9;
        float f14 = (i & 4) != 0 ? 1.0f : f10;
        float f15 = (i & 256) != 0 ? 0.0f : f11;
        long j9 = K.f31307b;
        H h10 = (i & 2048) != 0 ? D.f31267a : h9;
        boolean z8 = (i & 4096) == 0;
        long j10 = u.f31346a;
        return b(rVar, f12, f13, f14, 0.0f, f15, j9, h10, z8, j10, j10);
    }
}
