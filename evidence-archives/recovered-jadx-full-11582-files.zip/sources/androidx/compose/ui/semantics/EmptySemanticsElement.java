package androidx.compose.ui.semantics;

import L0.AbstractC0933c0;
import T0.d;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
public final class EmptySemanticsElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d f13241a;

    public EmptySemanticsElement(d dVar) {
        this.f13241a = dVar;
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return this.f13241a;
    }

    @Override // L0.AbstractC0933c0
    public final /* bridge */ /* synthetic */ void h(q qVar) {
    }

    public final int hashCode() {
        return System.identityHashCode(this);
    }
}
