package androidx.compose.ui.semantics;

import L0.AbstractC0933c0;
import p095m0.p;
import p095m0.q;
import p137r7.c;

/* JADX INFO: loaded from: classes.dex */
public final class AppendedSemanticsElement extends AbstractC0933c0 implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f13239a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f13240b;

    public AppendedSemanticsElement(c cVar, boolean z8) {
        this.f13239a = z8;
        this.f13240b = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AppendedSemanticsElement)) {
            return false;
        }
        AppendedSemanticsElement appendedSemanticsElement = (AppendedSemanticsElement) obj;
        return this.f13239a == appendedSemanticsElement.f13239a && this.f13240b == appendedSemanticsElement.f13240b;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        T0.c cVar = new T0.c();
        cVar.f9453H = this.f13239a;
        cVar.f9454I = this.f13240b;
        return cVar;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        T0.c cVar = (T0.c) qVar;
        cVar.f9453H = this.f13239a;
        cVar.f9454I = this.f13240b;
    }

    public final int hashCode() {
        return this.f13240b.hashCode() + (Boolean.hashCode(this.f13239a) * 31);
    }
}
