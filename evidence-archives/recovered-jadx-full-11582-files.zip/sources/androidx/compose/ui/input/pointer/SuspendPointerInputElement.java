package androidx.compose.ui.input.pointer;

import F0.O;
import I.InterfaceC0828m0;
import L0.AbstractC0933c0;
import p095m0.q;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
public final class SuspendPointerInputElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f13221a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f13222b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final PointerInputEventHandler f13223c;

    public SuspendPointerInputElement(Object obj, InterfaceC0828m0 interfaceC0828m0, PointerInputEventHandler pointerInputEventHandler, int i) {
        interfaceC0828m0 = (i & 2) != 0 ? null : interfaceC0828m0;
        this.f13221a = obj;
        this.f13222b = interfaceC0828m0;
        this.f13223c = pointerInputEventHandler;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SuspendPointerInputElement)) {
            return false;
        }
        SuspendPointerInputElement suspendPointerInputElement = (SuspendPointerInputElement) obj;
        return j.a(this.f13221a, suspendPointerInputElement.f13221a) && j.a(this.f13222b, suspendPointerInputElement.f13222b) && this.f13223c == suspendPointerInputElement.f13223c;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return new O(this.f13221a, this.f13222b, this.f13223c);
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        O o5 = (O) qVar;
        Object obj = o5.f1977H;
        Object obj2 = this.f13221a;
        boolean z8 = !j.a(obj, obj2);
        o5.f1977H = obj2;
        Object obj3 = o5.f1978I;
        Object obj4 = this.f13222b;
        if (!j.a(obj3, obj4)) {
            z8 = true;
        }
        o5.f1978I = obj4;
        Class<?> cls = o5.f1979J.getClass();
        PointerInputEventHandler pointerInputEventHandler = this.f13223c;
        if (cls == pointerInputEventHandler.getClass() ? z8 : true) {
            o5.M0();
        }
        o5.f1979J = pointerInputEventHandler;
    }

    public final int hashCode() {
        Object obj = this.f13221a;
        int iHashCode = (obj != null ? obj.hashCode() : 0) * 31;
        Object obj2 = this.f13222b;
        return this.f13223c.hashCode() + ((iHashCode + (obj2 != null ? obj2.hashCode() : 0)) * 961);
    }
}
