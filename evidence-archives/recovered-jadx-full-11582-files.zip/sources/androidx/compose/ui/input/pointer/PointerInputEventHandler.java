package androidx.compose.ui.input.pointer;

import F0.y;
import p062h7.c;

/* JADX INFO: loaded from: classes.dex */
public interface PointerInputEventHandler {
    Object invoke(y yVar, c cVar);
}
