package androidx.compose.ui.input.pointer;

import F0.C0277a;
import F0.G;
import I.W;
import L0.AbstractC0933c0;
import L0.C0948n;
import p095m0.q;
import p127q3.h;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
public final class StylusHoverIconModifierElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0948n f13220a;

    public StylusHoverIconModifierElement(C0948n c0948n) {
        this.f13220a = c0948n;
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof StylusHoverIconModifierElement)) {
            return false;
        }
        StylusHoverIconModifierElement stylusHoverIconModifierElement = (StylusHoverIconModifierElement) obj;
        C0277a c0277a = W.f4706b;
        stylusHoverIconModifierElement.getClass();
        return c0277a.equals(c0277a) && j.a(this.f13220a, stylusHoverIconModifierElement.f13220a);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return new G(W.f4706b, this.f13220a);
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        G g2 = (G) qVar;
        C0277a c0277a = W.f4706b;
        if (!j.a(g2.f2006I, c0277a)) {
            g2.f2006I = c0277a;
            if (g2.f2007J) {
                g2.M0();
            }
        }
        g2.f2005H = this.f13220a;
    }

    public final int hashCode() {
        int iE = h.e(1022 * 31, 31, false);
        C0948n c0948n = this.f13220a;
        return iE + (c0948n != null ? c0948n.hashCode() : 0);
    }

    public final String toString() {
        return "StylusHoverIconModifierElement(icon=" + W.f4706b + ", overrideDescendants=false, touchBoundsExpansion=" + this.f13220a + ')';
    }
}
