package androidx.compose.ui.input.key;

import p095m0.r;
import p137r7.c;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final r a(c cVar) {
        return new KeyInputElement(cVar, null);
    }

    public static final r b(r rVar, c cVar) {
        return rVar.e(new KeyInputElement(null, cVar));
    }
}
