package androidx.compose.ui.input.key;

import D0.e;
import L0.AbstractC0933c0;
import p095m0.q;
import p137r7.c;

/* JADX INFO: loaded from: classes.dex */
final class KeyInputElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f13215a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f13216b;

    public KeyInputElement(c cVar, c cVar2) {
        this.f13215a = cVar;
        this.f13216b = cVar2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof KeyInputElement)) {
            return false;
        }
        KeyInputElement keyInputElement = (KeyInputElement) obj;
        return this.f13215a == keyInputElement.f13215a && this.f13216b == keyInputElement.f13216b;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        e eVar = new e();
        eVar.f983H = this.f13215a;
        eVar.f984I = this.f13216b;
        return eVar;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        e eVar = (e) qVar;
        eVar.f983H = this.f13215a;
        eVar.f984I = this.f13216b;
    }

    public final int hashCode() {
        c cVar = this.f13215a;
        int iHashCode = (cVar != null ? cVar.hashCode() : 0) * 31;
        c cVar2 = this.f13216b;
        return iHashCode + (cVar2 != null ? cVar2.hashCode() : 0);
    }
}
