package androidx.compose.ui.input.nestedscroll;

import E0.b;
import E0.e;
import E0.h;
import L0.AbstractC0933c0;
import p095m0.q;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
final class NestedScrollElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final E0.a f13217a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final e f13218b;

    public NestedScrollElement(E0.a aVar, e eVar) {
        this.f13217a = aVar;
        this.f13218b = eVar;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof NestedScrollElement)) {
            return false;
        }
        NestedScrollElement nestedScrollElement = (NestedScrollElement) obj;
        return j.a(nestedScrollElement.f13217a, this.f13217a) && j.a(nestedScrollElement.f13218b, this.f13218b);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return new h(this.f13217a, this.f13218b);
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        h hVar = (h) qVar;
        hVar.f1460H = this.f13217a;
        e eVar = hVar.f1461I;
        if (eVar.f1449a == hVar) {
            eVar.f1449a = null;
        }
        e eVar2 = this.f13218b;
        if (eVar2 == null) {
            hVar.f1461I = new e();
        } else if (!eVar2.equals(eVar)) {
            hVar.f1461I = eVar2;
        }
        if (hVar.f28601G) {
            e eVar3 = hVar.f1461I;
            eVar3.f1449a = hVar;
            eVar3.f1450b = null;
            hVar.f1462J = null;
            eVar3.f1451c = new b(1, hVar);
            eVar3.f1452d = hVar.y0();
        }
    }

    public final int hashCode() {
        int iHashCode = this.f13217a.hashCode() * 31;
        e eVar = this.f13218b;
        return iHashCode + (eVar != null ? eVar.hashCode() : 0);
    }
}
