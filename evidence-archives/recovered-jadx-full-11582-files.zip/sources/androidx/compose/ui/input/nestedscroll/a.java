package androidx.compose.ui.input.nestedscroll;

import E0.e;
import p095m0.r;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final r a(r rVar, E0.a aVar, e eVar) {
        return rVar.e(new NestedScrollElement(aVar, eVar));
    }
}
