package androidx.compose.ui.input.rotary;

import p095m0.r;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final r a() {
        return new RotaryInputElement();
    }
}
