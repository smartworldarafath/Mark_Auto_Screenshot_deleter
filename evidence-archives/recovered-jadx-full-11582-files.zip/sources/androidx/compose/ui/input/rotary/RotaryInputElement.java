package androidx.compose.ui.input.rotary;

import L0.AbstractC0933c0;
import M0.C1061p;
import p095m0.q;

/* JADX INFO: loaded from: classes.dex */
final class RotaryInputElement extends AbstractC0933c0 {
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof RotaryInputElement)) {
            return false;
        }
        ((RotaryInputElement) obj).getClass();
        return true;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        C1061p c1061p = C1061p.x;
        H0.a aVar = new H0.a();
        aVar.f3338H = c1061p;
        return aVar;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((H0.a) qVar).f3338H = C1061p.x;
    }

    public final int hashCode() {
        return C1061p.x.hashCode() * 31;
    }
}
