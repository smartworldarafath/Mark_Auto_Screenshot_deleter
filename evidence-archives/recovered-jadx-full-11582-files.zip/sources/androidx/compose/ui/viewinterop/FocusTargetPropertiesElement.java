package androidx.compose.ui.viewinterop;

import L0.AbstractC0933c0;
import p095m0.q;
import p096m1.p;

/* JADX INFO: loaded from: classes.dex */
final class FocusTargetPropertiesElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final FocusTargetPropertiesElement f13243a = new FocusTargetPropertiesElement();

    private FocusTargetPropertiesElement() {
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        return new p();
    }

    @Override // L0.AbstractC0933c0
    public final /* bridge */ /* synthetic */ void h(q qVar) {
    }

    public final int hashCode() {
        return -659549572;
    }
}
