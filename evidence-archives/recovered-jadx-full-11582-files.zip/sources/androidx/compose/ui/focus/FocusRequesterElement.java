package androidx.compose.ui.focus;

import L0.AbstractC0933c0;
import p095m0.q;
import p130r0.o;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
final class FocusRequesterElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final o f13203a;

    public FocusRequesterElement(o oVar) {
        this.f13203a = oVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof FocusRequesterElement) && j.a(this.f13203a, ((FocusRequesterElement) obj).f13203a);
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        p130r0.q qVar = new p130r0.q();
        qVar.f30570H = this.f13203a;
        return qVar;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        p130r0.q qVar2 = (p130r0.q) qVar;
        qVar2.f30570H.f30569a.l(qVar2);
        o oVar = this.f13203a;
        qVar2.f30570H = oVar;
        oVar.f30569a.b(qVar2);
    }

    public final int hashCode() {
        return this.f13203a.hashCode();
    }

    public final String toString() {
        return "FocusRequesterElement(focusRequester=" + this.f13203a + ')';
    }
}
