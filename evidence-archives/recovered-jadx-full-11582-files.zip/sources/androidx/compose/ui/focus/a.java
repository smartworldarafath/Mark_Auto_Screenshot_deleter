package androidx.compose.ui.focus;

import p095m0.r;
import p130r0.o;
import p137r7.c;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final r a(r rVar, o oVar) {
        return rVar.e(new FocusRequesterElement(oVar));
    }

    public static final r b(r rVar, c cVar) {
        return rVar.e(new FocusChangedElement(cVar));
    }
}
