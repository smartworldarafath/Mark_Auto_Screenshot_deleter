package androidx.compose.ui.focus;

import L0.AbstractC0933c0;
import p095m0.q;
import p137r7.c;

/* JADX INFO: loaded from: classes.dex */
final class FocusChangedElement extends AbstractC0933c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f13201a;

    public FocusChangedElement(c cVar) {
        this.f13201a = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof FocusChangedElement) {
            return this.f13201a == ((FocusChangedElement) obj).f13201a;
        }
        return false;
    }

    @Override // L0.AbstractC0933c0
    public final q g() {
        p130r0.c cVar = new p130r0.c();
        cVar.f30535H = this.f13201a;
        return cVar;
    }

    @Override // L0.AbstractC0933c0
    public final void h(q qVar) {
        ((p130r0.c) qVar).f30535H = this.f13201a;
    }

    public final int hashCode() {
        return this.f13201a.hashCode();
    }
}
