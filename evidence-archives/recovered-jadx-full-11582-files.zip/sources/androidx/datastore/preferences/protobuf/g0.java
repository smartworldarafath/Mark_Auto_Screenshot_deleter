package androidx.datastore.preferences.protobuf;

import sun.misc.Unsafe;

/* JADX INFO: loaded from: classes.dex */
public final class g0 extends i0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f13373b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ g0(Unsafe unsafe, int i) {
        super(unsafe);
        this.f13373b = i;
    }

    @Override // androidx.datastore.preferences.protobuf.i0
    public final boolean c(long j9, Object obj) {
        switch (this.f13373b) {
            case 0:
                return j0.f13394g ? j0.b(j9, obj) : j0.c(j9, obj);
            default:
                return j0.f13394g ? j0.b(j9, obj) : j0.c(j9, obj);
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i0
    public final double d(long j9, Object obj) {
        switch (this.f13373b) {
            case 0:
                break;
        }
        return Double.longBitsToDouble(g(j9, obj));
    }

    @Override // androidx.datastore.preferences.protobuf.i0
    public final float e(long j9, Object obj) {
        switch (this.f13373b) {
            case 0:
                break;
        }
        return Float.intBitsToFloat(f(j9, obj));
    }

    @Override // androidx.datastore.preferences.protobuf.i0
    public final void j(Object obj, long j9, boolean z8) {
        switch (this.f13373b) {
            case 0:
                if (!j0.f13394g) {
                    j0.l(obj, j9, z8 ? (byte) 1 : (byte) 0);
                } else {
                    j0.k(obj, j9, z8 ? (byte) 1 : (byte) 0);
                }
                break;
            default:
                if (!j0.f13394g) {
                    j0.l(obj, j9, z8 ? (byte) 1 : (byte) 0);
                } else {
                    j0.k(obj, j9, z8 ? (byte) 1 : (byte) 0);
                }
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i0
    public final void k(Object obj, long j9, byte b9) {
        switch (this.f13373b) {
            case 0:
                if (!j0.f13394g) {
                    j0.l(obj, j9, b9);
                } else {
                    j0.k(obj, j9, b9);
                }
                break;
            default:
                if (!j0.f13394g) {
                    j0.l(obj, j9, b9);
                } else {
                    j0.k(obj, j9, b9);
                }
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i0
    public final void l(Object obj, long j9, double d2) {
        switch (this.f13373b) {
            case 0:
                o(obj, j9, Double.doubleToLongBits(d2));
                break;
            default:
                o(obj, j9, Double.doubleToLongBits(d2));
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i0
    public final void m(Object obj, long j9, float f4) {
        switch (this.f13373b) {
            case 0:
                n(j9, obj, Float.floatToIntBits(f4));
                break;
            default:
                n(j9, obj, Float.floatToIntBits(f4));
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i0
    public final boolean r() {
        switch (this.f13373b) {
        }
        return false;
    }
}
