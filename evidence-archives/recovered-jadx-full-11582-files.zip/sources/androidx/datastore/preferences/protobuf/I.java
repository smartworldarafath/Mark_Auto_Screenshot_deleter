package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class I {
    public static H a(Object obj, Object obj2) {
        H hB = (H) obj;
        H h9 = (H) obj2;
        if (!h9.isEmpty()) {
            if (!hB.f13304t) {
                hB = hB.b();
            }
            hB.a();
            if (!h9.isEmpty()) {
                hB.putAll(h9);
            }
        }
        return hB;
    }
}
