package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.util.Locale;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1374j extends IOException {
    public /* synthetic */ C1374j(IndexOutOfBoundsException indexOutOfBoundsException) {
        super("CodedOutputStream was writing to a flat byte array and ran out of space.", indexOutOfBoundsException);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1374j(long j9, long j10, int i, IndexOutOfBoundsException indexOutOfBoundsException, int i4) {
        super("CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat("Pos: " + j9 + ", limit: " + j10 + ", len: " + i), indexOutOfBoundsException);
        switch (i4) {
            case 4:
                Locale locale = Locale.US;
                super("CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat("Pos: " + j9 + ", limit: " + j10 + ", len: " + i), indexOutOfBoundsException);
                break;
            case 7:
                Locale locale2 = Locale.US;
                super("CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat("Pos: " + j9 + ", limit: " + j10 + ", len: " + i), indexOutOfBoundsException);
                break;
            default:
                Locale locale3 = Locale.US;
                break;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1374j(String str, IndexOutOfBoundsException indexOutOfBoundsException, int i) {
        super("CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat(str), indexOutOfBoundsException);
        switch (i) {
            case 6:
                super("CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat(str), indexOutOfBoundsException);
                break;
            default:
                break;
        }
    }
}
