package androidx.datastore.preferences.protobuf;

import T.C1127t;

/* JADX INFO: loaded from: classes.dex */
public interface W {
    void a(Object obj, Object obj2);

    void b(Object obj, E e4);

    void c(Object obj);

    void d(Object obj, C1127t c1127t, C1377m c1377m);

    boolean e(Object obj);

    int f(AbstractC1384u abstractC1384u);

    int g(AbstractC1384u abstractC1384u);

    boolean h(AbstractC1384u abstractC1384u, AbstractC1384u abstractC1384u2);

    AbstractC1384u i();
}
