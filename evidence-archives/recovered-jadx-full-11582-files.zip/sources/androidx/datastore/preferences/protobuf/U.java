package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.measurement.AbstractC5061q1;
import java.util.AbstractList;
import java.util.Arrays;
import java.util.RandomAccess;

/* JADX INFO: loaded from: classes.dex */
public final class U extends AbstractC1366b implements RandomAccess {

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final U f13330w = new U(new Object[0], 0, false);

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Object[] f13331u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f13332v;

    public U(Object[] objArr, int i, boolean z8) {
        this.f13352t = z8;
        this.f13331u = objArr;
        this.f13332v = i;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean add(Object obj) {
        b();
        int i = this.f13332v;
        Object[] objArr = this.f13331u;
        if (i == objArr.length) {
            this.f13331u = Arrays.copyOf(objArr, ((i * 3) / 2) + 1);
        }
        Object[] objArr2 = this.f13331u;
        int i4 = this.f13332v;
        this.f13332v = i4 + 1;
        objArr2[i4] = obj;
        ((AbstractList) this).modCount++;
        return true;
    }

    public final void c(int i) {
        if (i < 0 || i >= this.f13332v) {
            StringBuilder sbP = AbstractC5061q1.p("Index:", i, ", Size:");
            sbP.append(this.f13332v);
            throw new IndexOutOfBoundsException(sbP.toString());
        }
    }

    public final U e(int i) {
        if (i >= this.f13332v) {
            return new U(Arrays.copyOf(this.f13331u, i), this.f13332v, true);
        }
        throw new IllegalArgumentException();
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i) {
        c(i);
        return this.f13331u[i];
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC1366b, java.util.AbstractList, java.util.List
    public final Object remove(int i) {
        b();
        c(i);
        Object[] objArr = this.f13331u;
        Object obj = objArr[i];
        int i4 = this.f13332v;
        if (i < i4 - 1) {
            System.arraycopy(objArr, i + 1, objArr, i, (i4 - i) - 1);
        }
        this.f13332v--;
        ((AbstractList) this).modCount++;
        return obj;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i, Object obj) {
        b();
        c(i);
        Object[] objArr = this.f13331u;
        Object obj2 = objArr[i];
        objArr[i] = obj;
        ((AbstractList) this).modCount++;
        return obj2;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f13332v;
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i, Object obj) {
        int i4;
        b();
        if (i >= 0 && i <= (i4 = this.f13332v)) {
            Object[] objArr = this.f13331u;
            if (i4 < objArr.length) {
                System.arraycopy(objArr, i, objArr, i + 1, i4 - i);
            } else {
                Object[] objArr2 = new Object[X3.b.f(i4, 3, 2, 1)];
                System.arraycopy(objArr, 0, objArr2, 0, i);
                System.arraycopy(this.f13331u, i, objArr2, i + 1, this.f13332v - i);
                this.f13331u = objArr2;
            }
            this.f13331u[i] = obj;
            this.f13332v++;
            ((AbstractList) this).modCount++;
            return;
        }
        StringBuilder sbP = AbstractC5061q1.p("Index:", i, ", Size:");
        sbP.append(this.f13332v);
        throw new IndexOutOfBoundsException(sbP.toString());
    }
}
