package androidx.datastore.preferences.protobuf;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'EF0' uses external variables
	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:485)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByRegister(EnumVisitor.java:422)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:351)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:284)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:153)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:102)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC1381q {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final EnumC1381q f13412u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final EnumC1381q f13413v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final EnumC1381q[] f13414w;
    public static final /* synthetic */ EnumC1381q[] x;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f13415t;

    /* JADX INFO: Fake field, exist only in values array */
    EnumC1381q EF0;

    static {
        EnumC1389z enumC1389z = EnumC1389z.DOUBLE;
        EnumC1381q enumC1381q = new EnumC1381q("DOUBLE", 0, 0, 1, enumC1389z);
        EnumC1389z enumC1389z2 = EnumC1389z.FLOAT;
        EnumC1381q enumC1381q2 = new EnumC1381q("FLOAT", 1, 1, 1, enumC1389z2);
        EnumC1389z enumC1389z3 = EnumC1389z.LONG;
        EnumC1381q enumC1381q3 = new EnumC1381q("INT64", 2, 2, 1, enumC1389z3);
        EnumC1381q enumC1381q4 = new EnumC1381q("UINT64", 3, 3, 1, enumC1389z3);
        EnumC1389z enumC1389z4 = EnumC1389z.INT;
        EnumC1381q enumC1381q5 = new EnumC1381q("INT32", 4, 4, 1, enumC1389z4);
        EnumC1381q enumC1381q6 = new EnumC1381q("FIXED64", 5, 5, 1, enumC1389z3);
        EnumC1381q enumC1381q7 = new EnumC1381q("FIXED32", 6, 6, 1, enumC1389z4);
        EnumC1389z enumC1389z5 = EnumC1389z.BOOLEAN;
        EnumC1381q enumC1381q8 = new EnumC1381q("BOOL", 7, 7, 1, enumC1389z5);
        EnumC1389z enumC1389z6 = EnumC1389z.STRING;
        EnumC1381q enumC1381q9 = new EnumC1381q("STRING", 8, 8, 1, enumC1389z6);
        EnumC1389z enumC1389z7 = EnumC1389z.MESSAGE;
        EnumC1381q enumC1381q10 = new EnumC1381q("MESSAGE", 9, 9, 1, enumC1389z7);
        EnumC1389z enumC1389z8 = EnumC1389z.BYTE_STRING;
        EnumC1381q enumC1381q11 = new EnumC1381q("BYTES", 10, 10, 1, enumC1389z8);
        EnumC1381q enumC1381q12 = new EnumC1381q("UINT32", 11, 11, 1, enumC1389z4);
        EnumC1389z enumC1389z9 = EnumC1389z.ENUM;
        EnumC1381q enumC1381q13 = new EnumC1381q("ENUM", 12, 12, 1, enumC1389z9);
        EnumC1381q enumC1381q14 = new EnumC1381q("SFIXED32", 13, 13, 1, enumC1389z4);
        EnumC1381q enumC1381q15 = new EnumC1381q("SFIXED64", 14, 14, 1, enumC1389z3);
        EnumC1381q enumC1381q16 = new EnumC1381q("SINT32", 15, 15, 1, enumC1389z4);
        EnumC1381q enumC1381q17 = new EnumC1381q("SINT64", 16, 16, 1, enumC1389z3);
        EnumC1381q enumC1381q18 = new EnumC1381q("GROUP", 17, 17, 1, enumC1389z7);
        EnumC1381q enumC1381q19 = new EnumC1381q("DOUBLE_LIST", 18, 18, 2, enumC1389z);
        EnumC1381q enumC1381q20 = new EnumC1381q("FLOAT_LIST", 19, 19, 2, enumC1389z2);
        EnumC1381q enumC1381q21 = new EnumC1381q("INT64_LIST", 20, 20, 2, enumC1389z3);
        EnumC1381q enumC1381q22 = new EnumC1381q("UINT64_LIST", 21, 21, 2, enumC1389z3);
        EnumC1381q enumC1381q23 = new EnumC1381q("INT32_LIST", 22, 22, 2, enumC1389z4);
        EnumC1381q enumC1381q24 = new EnumC1381q("FIXED64_LIST", 23, 23, 2, enumC1389z3);
        EnumC1381q enumC1381q25 = new EnumC1381q("FIXED32_LIST", 24, 24, 2, enumC1389z4);
        EnumC1381q enumC1381q26 = new EnumC1381q("BOOL_LIST", 25, 25, 2, enumC1389z5);
        EnumC1381q enumC1381q27 = new EnumC1381q("STRING_LIST", 26, 26, 2, enumC1389z6);
        EnumC1381q enumC1381q28 = new EnumC1381q("MESSAGE_LIST", 27, 27, 2, enumC1389z7);
        EnumC1381q enumC1381q29 = new EnumC1381q("BYTES_LIST", 28, 28, 2, enumC1389z8);
        EnumC1381q enumC1381q30 = new EnumC1381q("UINT32_LIST", 29, 29, 2, enumC1389z4);
        EnumC1381q enumC1381q31 = new EnumC1381q("ENUM_LIST", 30, 30, 2, enumC1389z9);
        EnumC1381q enumC1381q32 = new EnumC1381q("SFIXED32_LIST", 31, 31, 2, enumC1389z4);
        EnumC1381q enumC1381q33 = new EnumC1381q("SFIXED64_LIST", 32, 32, 2, enumC1389z3);
        EnumC1381q enumC1381q34 = new EnumC1381q("SINT32_LIST", 33, 33, 2, enumC1389z4);
        EnumC1381q enumC1381q35 = new EnumC1381q("SINT64_LIST", 34, 34, 2, enumC1389z3);
        EnumC1381q enumC1381q36 = new EnumC1381q("DOUBLE_LIST_PACKED", 35, 35, 3, enumC1389z);
        f13412u = enumC1381q36;
        EnumC1381q enumC1381q37 = new EnumC1381q("FLOAT_LIST_PACKED", 36, 36, 3, enumC1389z2);
        EnumC1381q enumC1381q38 = new EnumC1381q("INT64_LIST_PACKED", 37, 37, 3, enumC1389z3);
        EnumC1381q enumC1381q39 = new EnumC1381q("UINT64_LIST_PACKED", 38, 38, 3, enumC1389z3);
        EnumC1381q enumC1381q40 = new EnumC1381q("INT32_LIST_PACKED", 39, 39, 3, enumC1389z4);
        EnumC1381q enumC1381q41 = new EnumC1381q("FIXED64_LIST_PACKED", 40, 40, 3, enumC1389z3);
        EnumC1381q enumC1381q42 = new EnumC1381q("FIXED32_LIST_PACKED", 41, 41, 3, enumC1389z4);
        EnumC1381q enumC1381q43 = new EnumC1381q("BOOL_LIST_PACKED", 42, 42, 3, enumC1389z5);
        EnumC1381q enumC1381q44 = new EnumC1381q("UINT32_LIST_PACKED", 43, 43, 3, enumC1389z4);
        EnumC1381q enumC1381q45 = new EnumC1381q("ENUM_LIST_PACKED", 44, 44, 3, enumC1389z9);
        EnumC1381q enumC1381q46 = new EnumC1381q("SFIXED32_LIST_PACKED", 45, 45, 3, enumC1389z4);
        EnumC1381q enumC1381q47 = new EnumC1381q("SFIXED64_LIST_PACKED", 46, 46, 3, enumC1389z3);
        EnumC1381q enumC1381q48 = new EnumC1381q("SINT32_LIST_PACKED", 47, 47, 3, enumC1389z4);
        EnumC1381q enumC1381q49 = new EnumC1381q("SINT64_LIST_PACKED", 48, 48, 3, enumC1389z3);
        f13413v = enumC1381q49;
        x = new EnumC1381q[]{enumC1381q, enumC1381q2, enumC1381q3, enumC1381q4, enumC1381q5, enumC1381q6, enumC1381q7, enumC1381q8, enumC1381q9, enumC1381q10, enumC1381q11, enumC1381q12, enumC1381q13, enumC1381q14, enumC1381q15, enumC1381q16, enumC1381q17, enumC1381q18, enumC1381q19, enumC1381q20, enumC1381q21, enumC1381q22, enumC1381q23, enumC1381q24, enumC1381q25, enumC1381q26, enumC1381q27, enumC1381q28, enumC1381q29, enumC1381q30, enumC1381q31, enumC1381q32, enumC1381q33, enumC1381q34, enumC1381q35, enumC1381q36, enumC1381q37, enumC1381q38, enumC1381q39, enumC1381q40, enumC1381q41, enumC1381q42, enumC1381q43, enumC1381q44, enumC1381q45, enumC1381q46, enumC1381q47, enumC1381q48, enumC1381q49, new EnumC1381q("GROUP_LIST", 49, 49, 2, enumC1389z7), new EnumC1381q("MAP", 50, 50, 4, EnumC1389z.VOID)};
        EnumC1381q[] enumC1381qArrValues = values();
        f13414w = new EnumC1381q[enumC1381qArrValues.length];
        for (EnumC1381q enumC1381q50 : enumC1381qArrValues) {
            f13414w[enumC1381q50.f13415t] = enumC1381q50;
        }
    }

    public EnumC1381q(String str, int i, int i4, int i9, EnumC1389z enumC1389z) {
        super(str, i);
        this.f13415t = i4;
        int iB = Z.c.b(i9);
        if (iB == 1 || iB == 3) {
            enumC1389z.getClass();
        }
        if (i9 == 1) {
            enumC1389z.ordinal();
        }
    }

    public static EnumC1381q valueOf(String str) {
        return (EnumC1381q) Enum.valueOf(EnumC1381q.class, str);
    }

    public static EnumC1381q[] values() {
        return (EnumC1381q[]) x.clone();
    }
}
