package androidx.datastore.preferences.protobuf;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1367c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Class f13355a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final boolean f13356b;

    static {
        Class<?> cls;
        Class<?> cls2 = null;
        try {
            cls = Class.forName("libcore.io.Memory");
        } catch (Throwable unused) {
            cls = null;
        }
        f13355a = cls;
        try {
            cls2 = Class.forName("org.robolectric.Robolectric");
        } catch (Throwable unused2) {
        }
        f13356b = cls2 != null;
    }

    public static boolean a() {
        return (f13355a == null || f13356b) ? false : true;
    }
}
