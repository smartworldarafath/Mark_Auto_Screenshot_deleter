package androidx.datastore.preferences.protobuf;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1382s implements Cloneable {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final AbstractC1384u f13423t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public AbstractC1384u f13424u;

    public AbstractC1382s(AbstractC1384u abstractC1384u) {
        this.f13423t = abstractC1384u;
        if (abstractC1384u.g()) {
            throw new IllegalArgumentException("Default instance must be immutable.");
        }
        this.f13424u = abstractC1384u.i();
    }

    public final AbstractC1384u a() {
        AbstractC1384u abstractC1384uB = b();
        abstractC1384uB.getClass();
        if (AbstractC1384u.f(abstractC1384uB, true)) {
            return abstractC1384uB;
        }
        throw new c0();
    }

    public final AbstractC1384u b() {
        if (!this.f13424u.g()) {
            return this.f13424u;
        }
        AbstractC1384u abstractC1384u = this.f13424u;
        abstractC1384u.getClass();
        T t8 = T.f13327c;
        t8.getClass();
        t8.a(abstractC1384u.getClass()).c(abstractC1384u);
        abstractC1384u.h();
        return this.f13424u;
    }

    public final void c() {
        if (this.f13424u.g()) {
            return;
        }
        AbstractC1384u abstractC1384uI = this.f13423t.i();
        AbstractC1384u abstractC1384u = this.f13424u;
        T t8 = T.f13327c;
        t8.getClass();
        t8.a(abstractC1384uI.getClass()).a(abstractC1384uI, abstractC1384u);
        this.f13424u = abstractC1384uI;
    }

    public final Object clone() {
        AbstractC1382s abstractC1382s = (AbstractC1382s) this.f13423t.c(5);
        abstractC1382s.f13424u = b();
        return abstractC1382s;
    }
}
