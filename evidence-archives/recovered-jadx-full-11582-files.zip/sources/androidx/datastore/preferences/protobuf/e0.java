package androidx.datastore.preferences.protobuf;

import T.C1127t;

/* JADX INFO: loaded from: classes.dex */
public final class e0 {
    public static d0 a(Object obj) {
        AbstractC1384u abstractC1384u = (AbstractC1384u) obj;
        d0 d0Var = abstractC1384u.unknownFields;
        if (d0Var != d0.f13361f) {
            return d0Var;
        }
        d0 d0Var2 = new d0(0, new int[8], new Object[8], true);
        abstractC1384u.unknownFields = d0Var2;
        return d0Var2;
    }

    public static boolean b(int i, C1127t c1127t, Object obj) throws C1388y {
        int i4 = c1127t.f9424b;
        A1.M m8 = (A1.M) c1127t.f9427e;
        int i9 = i4 >>> 3;
        int i10 = i4 & 7;
        if (i10 == 0) {
            c1127t.C(0);
            ((d0) obj).c(i9 << 3, Long.valueOf(m8.s()));
            return true;
        }
        if (i10 == 1) {
            c1127t.C(1);
            ((d0) obj).c((i9 << 3) | 1, Long.valueOf(m8.p()));
            return true;
        }
        if (i10 == 2) {
            ((d0) obj).c((i9 << 3) | 2, c1127t.k());
            return true;
        }
        if (i10 != 3) {
            if (i10 == 4) {
                return false;
            }
            if (i10 != 5) {
                throw C1388y.b();
            }
            c1127t.C(5);
            ((d0) obj).c(5 | (i9 << 3), Integer.valueOf(m8.o()));
            return true;
        }
        d0 d0Var = new d0(0, new int[8], new Object[8], true);
        int i11 = i9 << 3;
        int i12 = i11 | 4;
        int i13 = i + 1;
        if (i13 >= 100) {
            throw new C1388y("Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit.");
        }
        while (c1127t.e() != Integer.MAX_VALUE && b(i13, c1127t, d0Var)) {
        }
        if (i12 != c1127t.f9424b) {
            throw new C1388y("Protocol message end-group tag did not match expected tag.");
        }
        if (d0Var.f13366e) {
            d0Var.f13366e = false;
        }
        ((d0) obj).c(i11 | 3, d0Var);
        return true;
    }
}
