package androidx.datastore.preferences.protobuf;

import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class Z implements Map.Entry, Comparable {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final Comparable f13345t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Object f13346u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ Y f13347v;

    public Z(Y y8, Comparable comparable, Object obj) {
        this.f13347v = y8;
        this.f13345t = comparable;
        this.f13346u = obj;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return this.f13345t.compareTo(((Z) obj).f13345t);
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        boolean zEquals;
        boolean zEquals2;
        if (obj != this) {
            if (obj instanceof Map.Entry) {
                Map.Entry entry = (Map.Entry) obj;
                Object key = entry.getKey();
                Comparable comparable = this.f13345t;
                if (comparable == null) {
                    zEquals = key == null;
                } else {
                    zEquals = comparable.equals(key);
                }
                if (zEquals) {
                    Object obj2 = this.f13346u;
                    Object value = entry.getValue();
                    if (obj2 == null) {
                        zEquals2 = value == null;
                    } else {
                        zEquals2 = obj2.equals(value);
                    }
                    if (zEquals2) {
                    }
                }
            }
            return false;
        }
        return true;
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        return this.f13345t;
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        return this.f13346u;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        Comparable comparable = this.f13345t;
        int iHashCode = comparable == null ? 0 : comparable.hashCode();
        Object obj = this.f13346u;
        return (obj != null ? obj.hashCode() : 0) ^ iHashCode;
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        this.f13347v.b();
        Object obj2 = this.f13346u;
        this.f13346u = obj;
        return obj2;
    }

    public final String toString() {
        return this.f13345t + "=" + this.f13346u;
    }
}
