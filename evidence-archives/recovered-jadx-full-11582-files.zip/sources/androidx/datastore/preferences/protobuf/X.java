package androidx.datastore.preferences.protobuf;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

/* JADX INFO: loaded from: classes.dex */
public abstract class X {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Class f13337a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final e0 f13338b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final e0 f13339c;

    static {
        Class<?> cls;
        Class<?> cls2;
        T t8 = T.f13327c;
        e0 e0Var = null;
        try {
            cls = Class.forName("androidx.datastore.preferences.protobuf.GeneratedMessage");
        } catch (Throwable unused) {
            cls = null;
        }
        f13337a = cls;
        try {
            T t9 = T.f13327c;
            try {
                cls2 = Class.forName("androidx.datastore.preferences.protobuf.UnknownFieldSetSchema");
            } catch (Throwable unused2) {
                cls2 = null;
            }
            if (cls2 != null) {
                e0Var = (e0) cls2.getConstructor(null).newInstance(null);
            }
        } catch (Throwable unused3) {
        }
        f13338b = e0Var;
        f13339c = new e0();
    }

    public static int a(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iK = 0;
        for (int i = 0; i < size; i++) {
            iK += C1375k.k(((Integer) list.get(i)).intValue());
        }
        return iK;
    }

    public static int b(int i, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C1375k.i(i) + 4) * size;
    }

    public static int c(int i, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C1375k.i(i) + 8) * size;
    }

    public static int d(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iK = 0;
        for (int i = 0; i < size; i++) {
            iK += C1375k.k(((Integer) list.get(i)).intValue());
        }
        return iK;
    }

    public static int e(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iK = 0;
        for (int i = 0; i < size; i++) {
            iK += C1375k.k(((Long) list.get(i)).longValue());
        }
        return iK;
    }

    public static int f(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iJ = 0;
        for (int i = 0; i < size; i++) {
            int iIntValue = ((Integer) list.get(i)).intValue();
            iJ += C1375k.j((iIntValue >> 31) ^ (iIntValue << 1));
        }
        return iJ;
    }

    public static int g(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iK = 0;
        for (int i = 0; i < size; i++) {
            long jLongValue = ((Long) list.get(i)).longValue();
            iK += C1375k.k((jLongValue >> 63) ^ (jLongValue << 1));
        }
        return iK;
    }

    public static int h(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iJ = 0;
        for (int i = 0; i < size; i++) {
            iJ += C1375k.j(((Integer) list.get(i)).intValue());
        }
        return iJ;
    }

    public static int i(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iK = 0;
        for (int i = 0; i < size; i++) {
            iK += C1375k.k(((Long) list.get(i)).longValue());
        }
        return iK;
    }

    public static Object j(Object obj, int i, InterfaceC1385v interfaceC1385v, Object obj2, e0 e0Var) {
        return obj2;
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public static void k(e0 e0Var, Object obj, Object obj2) {
        e0Var.getClass();
        AbstractC1384u abstractC1384u = (AbstractC1384u) obj;
        d0 d0Var = abstractC1384u.unknownFields;
        d0 d0Var2 = ((AbstractC1384u) obj2).unknownFields;
        d0 d0Var3 = d0.f13361f;
        if (!d0Var3.equals(d0Var2)) {
            if (d0Var3.equals(d0Var)) {
                int i = d0Var.f13362a + d0Var2.f13362a;
                int[] iArrCopyOf = Arrays.copyOf(d0Var.f13363b, i);
                System.arraycopy(d0Var2.f13363b, 0, iArrCopyOf, d0Var.f13362a, d0Var2.f13362a);
                Object[] objArrCopyOf = Arrays.copyOf(d0Var.f13364c, i);
                System.arraycopy(d0Var2.f13364c, 0, objArrCopyOf, d0Var.f13362a, d0Var2.f13362a);
                d0Var = new d0(i, iArrCopyOf, objArrCopyOf, true);
            } else {
                d0Var.getClass();
                if (!d0Var2.equals(d0Var3)) {
                    if (!d0Var.f13366e) {
                        throw new UnsupportedOperationException();
                    }
                    int i4 = d0Var.f13362a + d0Var2.f13362a;
                    d0Var.a(i4);
                    System.arraycopy(d0Var2.f13363b, 0, d0Var.f13363b, d0Var.f13362a, d0Var2.f13362a);
                    System.arraycopy(d0Var2.f13364c, 0, d0Var.f13364c, d0Var.f13362a, d0Var2.f13362a);
                    d0Var.f13362a = i4;
                }
            }
        }
        abstractC1384u.unknownFields = d0Var;
    }

    public static boolean l(Object obj, Object obj2) {
        if (obj != obj2) {
            return obj != null && obj.equals(obj2);
        }
        return true;
    }

    public static void m(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                c1375k.p(i, ((Boolean) list.get(i4)).booleanValue());
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int i9 = 0;
        for (int i10 = 0; i10 < list.size(); i10++) {
            ((Boolean) list.get(i10)).getClass();
            Logger logger = C1375k.f13395f;
            i9++;
        }
        c1375k.D(i9);
        while (i4 < list.size()) {
            c1375k.n(((Boolean) list.get(i4)).booleanValue() ? (byte) 1 : (byte) 0);
            i4++;
        }
    }

    public static void n(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                double dDoubleValue = ((Double) list.get(i4)).doubleValue();
                c1375k.getClass();
                c1375k.u(i, Double.doubleToRawLongBits(dDoubleValue));
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int i9 = 0;
        for (int i10 = 0; i10 < list.size(); i10++) {
            ((Double) list.get(i10)).getClass();
            Logger logger = C1375k.f13395f;
            i9 += 8;
        }
        c1375k.D(i9);
        while (i4 < list.size()) {
            c1375k.v(Double.doubleToRawLongBits(((Double) list.get(i4)).doubleValue()));
            i4++;
        }
    }

    public static void o(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                c1375k.w(i, ((Integer) list.get(i4)).intValue());
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int iK = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            iK += C1375k.k(((Integer) list.get(i9)).intValue());
        }
        c1375k.D(iK);
        while (i4 < list.size()) {
            c1375k.x(((Integer) list.get(i4)).intValue());
            i4++;
        }
    }

    public static void p(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                c1375k.s(i, ((Integer) list.get(i4)).intValue());
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int i9 = 0;
        for (int i10 = 0; i10 < list.size(); i10++) {
            ((Integer) list.get(i10)).getClass();
            Logger logger = C1375k.f13395f;
            i9 += 4;
        }
        c1375k.D(i9);
        while (i4 < list.size()) {
            c1375k.t(((Integer) list.get(i4)).intValue());
            i4++;
        }
    }

    public static void q(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                c1375k.u(i, ((Long) list.get(i4)).longValue());
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int i9 = 0;
        for (int i10 = 0; i10 < list.size(); i10++) {
            ((Long) list.get(i10)).getClass();
            Logger logger = C1375k.f13395f;
            i9 += 8;
        }
        c1375k.D(i9);
        while (i4 < list.size()) {
            c1375k.v(((Long) list.get(i4)).longValue());
            i4++;
        }
    }

    public static void r(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                float fFloatValue = ((Float) list.get(i4)).floatValue();
                c1375k.getClass();
                c1375k.s(i, Float.floatToRawIntBits(fFloatValue));
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int i9 = 0;
        for (int i10 = 0; i10 < list.size(); i10++) {
            ((Float) list.get(i10)).getClass();
            Logger logger = C1375k.f13395f;
            i9 += 4;
        }
        c1375k.D(i9);
        while (i4 < list.size()) {
            c1375k.t(Float.floatToRawIntBits(((Float) list.get(i4)).floatValue()));
            i4++;
        }
    }

    public static void s(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                c1375k.w(i, ((Integer) list.get(i4)).intValue());
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int iK = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            iK += C1375k.k(((Integer) list.get(i9)).intValue());
        }
        c1375k.D(iK);
        while (i4 < list.size()) {
            c1375k.x(((Integer) list.get(i4)).intValue());
            i4++;
        }
    }

    public static void t(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                c1375k.E(i, ((Long) list.get(i4)).longValue());
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int iK = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            iK += C1375k.k(((Long) list.get(i9)).longValue());
        }
        c1375k.D(iK);
        while (i4 < list.size()) {
            c1375k.F(((Long) list.get(i4)).longValue());
            i4++;
        }
    }

    public static void u(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                c1375k.s(i, ((Integer) list.get(i4)).intValue());
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int i9 = 0;
        for (int i10 = 0; i10 < list.size(); i10++) {
            ((Integer) list.get(i10)).getClass();
            Logger logger = C1375k.f13395f;
            i9 += 4;
        }
        c1375k.D(i9);
        while (i4 < list.size()) {
            c1375k.t(((Integer) list.get(i4)).intValue());
            i4++;
        }
    }

    public static void v(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                c1375k.u(i, ((Long) list.get(i4)).longValue());
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int i9 = 0;
        for (int i10 = 0; i10 < list.size(); i10++) {
            ((Long) list.get(i10)).getClass();
            Logger logger = C1375k.f13395f;
            i9 += 8;
        }
        c1375k.D(i9);
        while (i4 < list.size()) {
            c1375k.v(((Long) list.get(i4)).longValue());
            i4++;
        }
    }

    public static void w(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                int iIntValue = ((Integer) list.get(i4)).intValue();
                c1375k.C(i, (iIntValue >> 31) ^ (iIntValue << 1));
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int iJ = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            int iIntValue2 = ((Integer) list.get(i9)).intValue();
            iJ += C1375k.j((iIntValue2 >> 31) ^ (iIntValue2 << 1));
        }
        c1375k.D(iJ);
        while (i4 < list.size()) {
            int iIntValue3 = ((Integer) list.get(i4)).intValue();
            c1375k.D((iIntValue3 >> 31) ^ (iIntValue3 << 1));
            i4++;
        }
    }

    public static void x(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                long jLongValue = ((Long) list.get(i4)).longValue();
                c1375k.E(i, (jLongValue >> 63) ^ (jLongValue << 1));
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int iK = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            long jLongValue2 = ((Long) list.get(i9)).longValue();
            iK += C1375k.k((jLongValue2 >> 63) ^ (jLongValue2 << 1));
        }
        c1375k.D(iK);
        while (i4 < list.size()) {
            long jLongValue3 = ((Long) list.get(i4)).longValue();
            c1375k.F((jLongValue3 >> 63) ^ (jLongValue3 << 1));
            i4++;
        }
    }

    public static void y(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                c1375k.C(i, ((Integer) list.get(i4)).intValue());
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int iJ = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            iJ += C1375k.j(((Integer) list.get(i9)).intValue());
        }
        c1375k.D(iJ);
        while (i4 < list.size()) {
            c1375k.D(((Integer) list.get(i4)).intValue());
            i4++;
        }
    }

    public static void z(int i, List list, E e4, boolean z8) {
        if (list == null || list.isEmpty()) {
            return;
        }
        C1375k c1375k = (C1375k) e4.f13297a;
        int i4 = 0;
        if (!z8) {
            while (i4 < list.size()) {
                c1375k.E(i, ((Long) list.get(i4)).longValue());
                i4++;
            }
            return;
        }
        c1375k.B(i, 2);
        int iK = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            iK += C1375k.k(((Long) list.get(i9)).longValue());
        }
        c1375k.D(iK);
        while (i4 < list.size()) {
            c1375k.F(((Long) list.get(i4)).longValue());
            i4++;
        }
    }
}
