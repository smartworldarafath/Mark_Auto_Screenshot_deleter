package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public abstract class C {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final B f13293a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final B f13294b;

    static {
        T t8 = T.f13327c;
        B b9 = null;
        try {
            b9 = (B) Class.forName("androidx.datastore.preferences.protobuf.ListFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f13293a = b9;
        f13294b = new B();
    }
}
