package androidx.datastore.preferences.protobuf;

import java.io.IOException;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C1388y extends IOException {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f13437t;

    public static C1388y a() {
        return new C1388y("Protocol message had invalid UTF-8.");
    }

    public static C1387x b() {
        return new C1387x("Protocol message tag had invalid wire type.");
    }

    public static C1388y c() {
        return new C1388y("CodedInputStream encountered a malformed varint.");
    }

    public static C1388y d() {
        return new C1388y("CodedInputStream encountered an embedded string or message which claimed to have negative size.");
    }

    public static C1388y e() {
        return new C1388y("While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length.");
    }
}
