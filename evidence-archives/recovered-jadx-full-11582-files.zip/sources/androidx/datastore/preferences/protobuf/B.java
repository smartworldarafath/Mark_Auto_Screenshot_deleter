package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class B {
    public static InterfaceC1385v a(long j9, Object obj) {
        InterfaceC1385v interfaceC1385v = (InterfaceC1385v) j0.f13390c.h(j9, obj);
        if (((AbstractC1366b) interfaceC1385v).f13352t) {
            return interfaceC1385v;
        }
        U u8 = (U) interfaceC1385v;
        int i = u8.f13332v;
        U uE = u8.e(i == 0 ? 10 : i * 2);
        j0.o(j9, obj, uE);
        return uE;
    }
}
