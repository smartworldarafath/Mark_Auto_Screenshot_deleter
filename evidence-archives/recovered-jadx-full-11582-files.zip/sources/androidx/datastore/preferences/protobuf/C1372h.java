package androidx.datastore.preferences.protobuf;

import java.util.Arrays;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1372h extends A1.M {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f13374A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f13375B = Integer.MAX_VALUE;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final byte[] f13376v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f13377w;
    public int x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f13378y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final int f13379z;

    public C1372h(byte[] bArr, int i, int i4, boolean z8) {
        this.f13376v = bArr;
        this.f13377w = i4 + i;
        this.f13378y = i;
        this.f13379z = i;
    }

    @Override // A1.M
    public final int A() {
        return J();
    }

    @Override // A1.M
    public final long B() {
        return K();
    }

    @Override // A1.M
    public final boolean C(int i) throws C1388y {
        int i4 = i & 7;
        int i9 = 0;
        if (i4 != 0) {
            if (i4 == 1) {
                N(8);
                return true;
            }
            if (i4 == 2) {
                N(J());
                return true;
            }
            if (i4 == 3) {
                D();
                b(((i >>> 3) << 3) | 4);
                return true;
            }
            if (i4 == 4) {
                return false;
            }
            if (i4 != 5) {
                throw C1388y.b();
            }
            N(4);
            return true;
        }
        int i10 = this.f13377w - this.f13378y;
        byte[] bArr = this.f13376v;
        if (i10 >= 10) {
            while (i9 < 10) {
                int i11 = this.f13378y;
                this.f13378y = i11 + 1;
                if (bArr[i11] < 0) {
                    i9++;
                }
            }
            throw C1388y.c();
        }
        while (i9 < 10) {
            int i12 = this.f13378y;
            if (i12 == this.f13377w) {
                throw C1388y.e();
            }
            this.f13378y = i12 + 1;
            if (bArr[i12] < 0) {
                i9++;
            }
        }
        throw C1388y.c();
        return true;
    }

    public final int H() throws C1388y {
        int i = this.f13378y;
        if (this.f13377w - i < 4) {
            throw C1388y.e();
        }
        this.f13378y = i + 4;
        byte[] bArr = this.f13376v;
        return ((bArr[i + 3] & 255) << 24) | (bArr[i] & 255) | ((bArr[i + 1] & 255) << 8) | ((bArr[i + 2] & 255) << 16);
    }

    public final long I() throws C1388y {
        int i = this.f13378y;
        if (this.f13377w - i < 8) {
            throw C1388y.e();
        }
        this.f13378y = i + 8;
        byte[] bArr = this.f13376v;
        return ((((long) bArr[i + 7]) & 255) << 56) | (((long) bArr[i]) & 255) | ((((long) bArr[i + 1]) & 255) << 8) | ((((long) bArr[i + 2]) & 255) << 16) | ((((long) bArr[i + 3]) & 255) << 24) | ((((long) bArr[i + 4]) & 255) << 32) | ((((long) bArr[i + 5]) & 255) << 40) | ((((long) bArr[i + 6]) & 255) << 48);
    }

    public final int J() {
        int i;
        int i4 = this.f13378y;
        int i9 = this.f13377w;
        if (i9 != i4) {
            int i10 = i4 + 1;
            byte[] bArr = this.f13376v;
            byte b9 = bArr[i4];
            if (b9 >= 0) {
                this.f13378y = i10;
                return b9;
            }
            if (i9 - i10 >= 9) {
                int i11 = i4 + 2;
                int i12 = (bArr[i10] << 7) ^ b9;
                if (i12 < 0) {
                    i = i12 ^ (-128);
                } else {
                    int i13 = i4 + 3;
                    int i14 = (bArr[i11] << 14) ^ i12;
                    if (i14 >= 0) {
                        i = i14 ^ 16256;
                    } else {
                        int i15 = i4 + 4;
                        int i16 = i14 ^ (bArr[i13] << 21);
                        if (i16 < 0) {
                            i = (-2080896) ^ i16;
                        } else {
                            i13 = i4 + 5;
                            byte b10 = bArr[i15];
                            int i17 = (i16 ^ (b10 << 28)) ^ 266354560;
                            if (b10 < 0) {
                                i15 = i4 + 6;
                                if (bArr[i13] < 0) {
                                    i13 = i4 + 7;
                                    if (bArr[i15] < 0) {
                                        i15 = i4 + 8;
                                        if (bArr[i13] < 0) {
                                            i13 = i4 + 9;
                                            if (bArr[i15] < 0) {
                                                int i18 = i4 + 10;
                                                if (bArr[i13] >= 0) {
                                                    i11 = i18;
                                                    i = i17;
                                                }
                                            }
                                        }
                                    }
                                }
                                i = i17;
                            }
                            i = i17;
                        }
                        i11 = i15;
                    }
                    i11 = i13;
                }
                this.f13378y = i11;
                return i;
            }
        }
        return (int) L();
    }

    public final long K() {
        long j9;
        long j10;
        long j11;
        long j12;
        int i = this.f13378y;
        int i4 = this.f13377w;
        if (i4 != i) {
            int i9 = i + 1;
            byte[] bArr = this.f13376v;
            byte b9 = bArr[i];
            if (b9 >= 0) {
                this.f13378y = i9;
                return b9;
            }
            if (i4 - i9 >= 9) {
                int i10 = i + 2;
                int i11 = (bArr[i9] << 7) ^ b9;
                if (i11 < 0) {
                    j9 = i11 ^ (-128);
                } else {
                    int i12 = i + 3;
                    int i13 = (bArr[i10] << 14) ^ i11;
                    if (i13 >= 0) {
                        j9 = i13 ^ 16256;
                        i10 = i12;
                    } else {
                        int i14 = i + 4;
                        int i15 = i13 ^ (bArr[i12] << 21);
                        if (i15 < 0) {
                            j12 = (-2080896) ^ i15;
                        } else {
                            long j13 = i15;
                            i10 = i + 5;
                            long j14 = j13 ^ (((long) bArr[i14]) << 28);
                            if (j14 >= 0) {
                                j11 = 266354560;
                            } else {
                                i14 = i + 6;
                                long j15 = j14 ^ (((long) bArr[i10]) << 35);
                                if (j15 < 0) {
                                    j10 = -34093383808L;
                                } else {
                                    i10 = i + 7;
                                    j14 = j15 ^ (((long) bArr[i14]) << 42);
                                    if (j14 >= 0) {
                                        j11 = 4363953127296L;
                                    } else {
                                        i14 = i + 8;
                                        j15 = j14 ^ (((long) bArr[i10]) << 49);
                                        if (j15 < 0) {
                                            j10 = -558586000294016L;
                                        } else {
                                            i10 = i + 9;
                                            long j16 = (j15 ^ (((long) bArr[i14]) << 56)) ^ 71499008037633920L;
                                            if (j16 < 0) {
                                                int i16 = i + 10;
                                                if (bArr[i10] >= 0) {
                                                    i10 = i16;
                                                }
                                            }
                                            j9 = j16;
                                        }
                                    }
                                }
                                j12 = j10 ^ j15;
                            }
                            j9 = j11 ^ j14;
                        }
                        i10 = i14;
                        j9 = j12;
                    }
                }
                this.f13378y = i10;
                return j9;
            }
        }
        return L();
    }

    public final long L() throws C1388y {
        long j9 = 0;
        for (int i = 0; i < 64; i += 7) {
            int i4 = this.f13378y;
            if (i4 == this.f13377w) {
                throw C1388y.e();
            }
            this.f13378y = i4 + 1;
            byte b9 = this.f13376v[i4];
            j9 |= ((long) (b9 & 127)) << i;
            if ((b9 & 128) == 0) {
                return j9;
            }
        }
        throw C1388y.c();
    }

    public final void M() {
        int i = this.f13377w + this.x;
        this.f13377w = i;
        int i4 = i - this.f13379z;
        int i9 = this.f13375B;
        if (i4 <= i9) {
            this.x = 0;
            return;
        }
        int i10 = i4 - i9;
        this.x = i10;
        this.f13377w = i - i10;
    }

    public final void N(int i) throws C1388y {
        if (i >= 0) {
            int i4 = this.f13377w;
            int i9 = this.f13378y;
            if (i <= i4 - i9) {
                this.f13378y = i9 + i;
                return;
            }
        }
        if (i >= 0) {
            throw C1388y.e();
        }
        throw C1388y.d();
    }

    @Override // A1.M
    public final void b(int i) throws C1388y {
        if (this.f13374A != i) {
            throw new C1388y("Protocol message end-group tag did not match expected tag.");
        }
    }

    @Override // A1.M
    public final int c() {
        return this.f13378y - this.f13379z;
    }

    @Override // A1.M
    public final boolean d() {
        return this.f13378y == this.f13377w;
    }

    @Override // A1.M
    public final void i(int i) {
        this.f13375B = i;
        M();
    }

    @Override // A1.M
    public final int j(int i) throws C1388y {
        if (i < 0) {
            throw C1388y.d();
        }
        int iC = c() + i;
        if (iC < 0) {
            throw new C1388y("Failed to parse the message.");
        }
        int i4 = this.f13375B;
        if (iC > i4) {
            throw C1388y.e();
        }
        this.f13375B = iC;
        M();
        return i4;
    }

    @Override // A1.M
    public final boolean k() {
        return K() != 0;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x002f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:16:0x0031 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:17:0x0033  */
    /* JADX WARN: Code duplicated, block: B:20:0x003d  */
    /* JADX WARN: Code duplicated, block: B:22:0x0042  */
    @Override // A1.M
    public final C1371g l() throws C1388y {
        byte[] bArrCopyOfRange;
        int iJ = J();
        byte[] bArr = this.f13376v;
        if (iJ > 0) {
            int i = this.f13377w;
            int i4 = this.f13378y;
            if (iJ <= i - i4) {
                C1371g c1371gE = C1371g.e(bArr, i4, iJ);
                this.f13378y += iJ;
                return c1371gE;
            }
        }
        if (iJ == 0) {
            return C1371g.f13369v;
        }
        if (iJ > 0) {
            int i9 = this.f13377w;
            int i10 = this.f13378y;
            if (iJ <= i9 - i10) {
                int i11 = iJ + i10;
                this.f13378y = i11;
                bArrCopyOfRange = Arrays.copyOfRange(bArr, i10, i11);
            } else {
                if (iJ <= 0) {
                    throw C1388y.e();
                }
                if (iJ == 0) {
                    throw C1388y.d();
                }
                bArrCopyOfRange = AbstractC1386w.f13436b;
            }
        } else {
            if (iJ <= 0) {
                throw C1388y.e();
            }
            if (iJ == 0) {
                throw C1388y.d();
            }
            bArrCopyOfRange = AbstractC1386w.f13436b;
        }
        C1371g c1371g = C1371g.f13369v;
        return new C1371g(bArrCopyOfRange);
    }

    @Override // A1.M
    public final double m() {
        return Double.longBitsToDouble(I());
    }

    @Override // A1.M
    public final int n() {
        return J();
    }

    @Override // A1.M
    public final int o() {
        return H();
    }

    @Override // A1.M
    public final long p() {
        return I();
    }

    @Override // A1.M
    public final float q() {
        return Float.intBitsToFloat(H());
    }

    @Override // A1.M
    public final int r() {
        return J();
    }

    @Override // A1.M
    public final long s() {
        return K();
    }

    @Override // A1.M
    public final int t() {
        return H();
    }

    @Override // A1.M
    public final long u() {
        return I();
    }

    @Override // A1.M
    public final int v() {
        int iJ = J();
        return (-(iJ & 1)) ^ (iJ >>> 1);
    }

    @Override // A1.M
    public final long w() {
        long jK = K();
        return (-(jK & 1)) ^ (jK >>> 1);
    }

    @Override // A1.M
    public final String x() throws C1388y {
        int iJ = J();
        if (iJ > 0) {
            int i = this.f13377w;
            int i4 = this.f13378y;
            if (iJ <= i - i4) {
                String str = new String(this.f13376v, i4, iJ, AbstractC1386w.f13435a);
                this.f13378y += iJ;
                return str;
            }
        }
        if (iJ == 0) {
            return "";
        }
        if (iJ < 0) {
            throw C1388y.d();
        }
        throw C1388y.e();
    }

    @Override // A1.M
    public final String y() throws C1388y {
        int iJ = J();
        if (iJ > 0) {
            int i = this.f13377w;
            int i4 = this.f13378y;
            if (iJ <= i - i4) {
                String strA = m0.f13406a.a(this.f13376v, i4, iJ);
                this.f13378y += iJ;
                return strA;
            }
        }
        if (iJ == 0) {
            return "";
        }
        if (iJ <= 0) {
            throw C1388y.d();
        }
        throw C1388y.e();
    }

    @Override // A1.M
    public final int z() throws C1388y {
        if (d()) {
            this.f13374A = 0;
            return 0;
        }
        int iJ = J();
        this.f13374A = iJ;
        if ((iJ >>> 3) != 0) {
            return iJ;
        }
        throw new C1388y("Protocol message contained an invalid tag (zero).");
    }
}
