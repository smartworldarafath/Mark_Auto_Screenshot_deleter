package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.measurement.AbstractC5061q1;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1384u extends AbstractC1365a {
    private static final int MEMOIZED_SERIALIZED_SIZE_MASK = Integer.MAX_VALUE;
    private static final int MUTABLE_FLAG_MASK = Integer.MIN_VALUE;
    static final int UNINITIALIZED_HASH_CODE = 0;
    static final int UNINITIALIZED_SERIALIZED_SIZE = Integer.MAX_VALUE;
    private static Map<Object, AbstractC1384u> defaultInstanceMap = new ConcurrentHashMap();
    private int memoizedSerializedSize;
    protected d0 unknownFields;

    public AbstractC1384u() {
        this.memoizedHashCode = 0;
        this.memoizedSerializedSize = -1;
        this.unknownFields = d0.f13361f;
    }

    public static AbstractC1384u d(Class cls) {
        AbstractC1384u abstractC1384u = defaultInstanceMap.get(cls);
        if (abstractC1384u == null) {
            try {
                Class.forName(cls.getName(), true, cls.getClassLoader());
                abstractC1384u = defaultInstanceMap.get(cls);
            } catch (ClassNotFoundException e4) {
                throw new IllegalStateException("Class initialization cannot fail.", e4);
            }
        }
        if (abstractC1384u != null) {
            return abstractC1384u;
        }
        AbstractC1384u abstractC1384u2 = (AbstractC1384u) ((AbstractC1384u) j0.d(cls)).c(6);
        if (abstractC1384u2 == null) {
            throw new IllegalStateException();
        }
        defaultInstanceMap.put(cls, abstractC1384u2);
        return abstractC1384u2;
    }

    public static Object e(Method method, AbstractC1384u abstractC1384u, Object... objArr) {
        try {
            return method.invoke(abstractC1384u, objArr);
        } catch (IllegalAccessException e4) {
            throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", e4);
        } catch (InvocationTargetException e9) {
            Throwable cause = e9.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            if (cause instanceof Error) {
                throw ((Error) cause);
            }
            throw new RuntimeException("Unexpected exception thrown by generated accessor method.", cause);
        }
    }

    public static final boolean f(AbstractC1384u abstractC1384u, boolean z8) {
        byte bByteValue = ((Byte) abstractC1384u.c(1)).byteValue();
        if (bByteValue == 1) {
            return true;
        }
        if (bByteValue == 0) {
            return false;
        }
        T t8 = T.f13327c;
        t8.getClass();
        boolean zE = t8.a(abstractC1384u.getClass()).e(abstractC1384u);
        if (z8) {
            abstractC1384u.c(2);
        }
        return zE;
    }

    public static void j(Class cls, AbstractC1384u abstractC1384u) {
        abstractC1384u.h();
        defaultInstanceMap.put(cls, abstractC1384u);
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC1365a
    public final int a(W w6) {
        int iF;
        int iF2;
        if (g()) {
            if (w6 == null) {
                T t8 = T.f13327c;
                t8.getClass();
                iF2 = t8.a(getClass()).f(this);
            } else {
                iF2 = w6.f(this);
            }
            if (iF2 >= 0) {
                return iF2;
            }
            throw new IllegalStateException(AbstractC5061q1.j(iF2, "serialized size must be non-negative, was "));
        }
        int i = this.memoizedSerializedSize;
        if ((i & Integer.MAX_VALUE) != Integer.MAX_VALUE) {
            return i & Integer.MAX_VALUE;
        }
        if (w6 == null) {
            T t9 = T.f13327c;
            t9.getClass();
            iF = t9.a(getClass()).f(this);
        } else {
            iF = w6.f(this);
        }
        k(iF);
        return iF;
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC1365a
    public final void b(C1375k c1375k) {
        T t8 = T.f13327c;
        t8.getClass();
        W wA = t8.a(getClass());
        E e4 = c1375k.f13397a;
        if (e4 == null) {
            e4 = new E(c1375k);
        }
        wA.b(this, e4);
    }

    public abstract Object c(int i);

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        T t8 = T.f13327c;
        t8.getClass();
        return t8.a(getClass()).h(this, (AbstractC1384u) obj);
    }

    public final boolean g() {
        return (this.memoizedSerializedSize & MUTABLE_FLAG_MASK) != 0;
    }

    public final void h() {
        this.memoizedSerializedSize &= Integer.MAX_VALUE;
    }

    public final int hashCode() {
        if (g()) {
            T t8 = T.f13327c;
            t8.getClass();
            return t8.a(getClass()).g(this);
        }
        if (this.memoizedHashCode == 0) {
            T t9 = T.f13327c;
            t9.getClass();
            this.memoizedHashCode = t9.a(getClass()).g(this);
        }
        return this.memoizedHashCode;
    }

    public final AbstractC1384u i() {
        return (AbstractC1384u) c(4);
    }

    public final void k(int i) {
        if (i < 0) {
            throw new IllegalStateException(AbstractC5061q1.j(i, "serialized size must be non-negative, was "));
        }
        this.memoizedSerializedSize = (i & Integer.MAX_VALUE) | (this.memoizedSerializedSize & MUTABLE_FLAG_MASK);
    }

    public final String toString() {
        String string = super.toString();
        char[] cArr = L.f13307a;
        StringBuilder sb = new StringBuilder();
        sb.append("# ");
        sb.append(string);
        L.c(this, sb, 0);
        return sb.toString();
    }
}
