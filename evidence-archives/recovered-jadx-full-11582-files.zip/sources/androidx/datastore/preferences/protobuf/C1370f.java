package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.measurement.AbstractC5061q1;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1370f extends C1371g {
    public final int x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f13368y;

    public C1370f(byte[] bArr, int i, int i4) {
        super(bArr);
        C1371g.c(i, i + i4, bArr.length);
        this.x = i;
        this.f13368y = i4;
    }

    @Override // androidx.datastore.preferences.protobuf.C1371g
    public final byte b(int i) {
        int i4 = this.f13368y;
        if (((i4 - (i + 1)) | i) >= 0) {
            return this.f13372u[this.x + i];
        }
        if (i < 0) {
            throw new ArrayIndexOutOfBoundsException(AbstractC5061q1.j(i, "Index < 0: "));
        }
        throw new ArrayIndexOutOfBoundsException(AbstractC5061q1.i(i, i4, "Index > length: ", ", "));
    }

    @Override // androidx.datastore.preferences.protobuf.C1371g
    public final void f(int i, byte[] bArr) {
        System.arraycopy(this.f13372u, this.x, bArr, 0, i);
    }

    @Override // androidx.datastore.preferences.protobuf.C1371g
    public final int g() {
        return this.x;
    }

    @Override // androidx.datastore.preferences.protobuf.C1371g
    public final byte h(int i) {
        return this.f13372u[this.x + i];
    }

    @Override // androidx.datastore.preferences.protobuf.C1371g
    public final int size() {
        return this.f13368y;
    }
}
