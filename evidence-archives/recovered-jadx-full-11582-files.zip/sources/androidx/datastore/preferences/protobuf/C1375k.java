package androidx.datastore.preferences.protobuf;

import F4.AbstractC0438r5;
import I1.w0;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1375k extends AbstractC0438r5 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final Logger f13395f = Logger.getLogger(C1375k.class.getName());

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final boolean f13396g = j0.f13392e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public E f13397a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final byte[] f13398b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f13399c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f13400d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final w0 f13401e;

    public C1375k(w0 w0Var, int i) {
        if (i < 0) {
            throw new IllegalArgumentException("bufferSize must be >= 0");
        }
        int iMax = Math.max(i, 20);
        this.f13398b = new byte[iMax];
        this.f13399c = iMax;
        this.f13401e = w0Var;
    }

    public static int g(int i, C1371g c1371g) {
        int i4 = i(i);
        int size = c1371g.size();
        return j(size) + size + i4;
    }

    public static int h(String str) {
        int length;
        try {
            length = m0.a(str);
        } catch (l0 unused) {
            length = str.getBytes(AbstractC1386w.f13435a).length;
        }
        return j(length) + length;
    }

    public static int i(int i) {
        return j(i << 3);
    }

    public static int j(int i) {
        return (352 - (Integer.numberOfLeadingZeros(i) * 9)) >>> 6;
    }

    public static int k(long j9) {
        return (640 - (Long.numberOfLeadingZeros(j9) * 9)) >>> 6;
    }

    public final void A(String str) throws IOException {
        try {
            int length = str.length() * 3;
            int iJ = j(length);
            int i = iJ + length;
            int i4 = this.f13399c;
            if (i > i4) {
                byte[] bArr = new byte[length];
                int iB = m0.f13406a.b(str, bArr, 0, length);
                D(iB);
                o(bArr, 0, iB);
                return;
            }
            if (i > i4 - this.f13400d) {
                l();
            }
            int iJ2 = j(str.length());
            int i9 = this.f13400d;
            byte[] bArr2 = this.f13398b;
            try {
                try {
                    if (iJ2 == iJ) {
                        int i10 = i9 + iJ2;
                        this.f13400d = i10;
                        int iB2 = m0.f13406a.b(str, bArr2, i10, i4 - i10);
                        this.f13400d = i9;
                        e((iB2 - i9) - iJ2);
                        this.f13400d = iB2;
                    } else {
                        int iA = m0.a(str);
                        e(iA);
                        this.f13400d = m0.f13406a.b(str, bArr2, this.f13400d, iA);
                    }
                } catch (ArrayIndexOutOfBoundsException e4) {
                    throw new C1374j(e4);
                }
            } catch (l0 e9) {
                this.f13400d = i9;
                throw e9;
            }
        } catch (l0 e10) {
            f13395f.log(Level.WARNING, "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable) e10);
            byte[] bytes = str.getBytes(AbstractC1386w.f13435a);
            try {
                D(bytes.length);
                a(bytes, 0, bytes.length);
            } catch (IndexOutOfBoundsException e11) {
                throw new C1374j(e11);
            }
        }
    }

    public final void B(int i, int i4) {
        D((i << 3) | i4);
    }

    public final void C(int i, int i4) throws IOException {
        m(20);
        d(i, 0);
        e(i4);
    }

    public final void D(int i) throws IOException {
        m(5);
        e(i);
    }

    public final void E(int i, long j9) {
        m(20);
        d(i, 0);
        f(j9);
    }

    public final void F(long j9) throws IOException {
        m(10);
        f(j9);
    }

    @Override // F4.AbstractC0438r5
    public final void a(byte[] bArr, int i, int i4) throws IOException {
        o(bArr, i, i4);
    }

    public final void b(int i) {
        int i4 = this.f13400d;
        int i9 = i4 + 1;
        this.f13400d = i9;
        byte[] bArr = this.f13398b;
        bArr[i4] = (byte) (i & 255);
        int i10 = i4 + 2;
        this.f13400d = i10;
        bArr[i9] = (byte) ((i >> 8) & 255);
        int i11 = i4 + 3;
        this.f13400d = i11;
        bArr[i10] = (byte) ((i >> 16) & 255);
        this.f13400d = i4 + 4;
        bArr[i11] = (byte) ((i >> 24) & 255);
    }

    public final void c(long j9) {
        int i = this.f13400d;
        int i4 = i + 1;
        this.f13400d = i4;
        byte[] bArr = this.f13398b;
        bArr[i] = (byte) (j9 & 255);
        int i9 = i + 2;
        this.f13400d = i9;
        bArr[i4] = (byte) ((j9 >> 8) & 255);
        int i10 = i + 3;
        this.f13400d = i10;
        bArr[i9] = (byte) ((j9 >> 16) & 255);
        int i11 = i + 4;
        this.f13400d = i11;
        bArr[i10] = (byte) (255 & (j9 >> 24));
        int i12 = i + 5;
        this.f13400d = i12;
        bArr[i11] = (byte) (((int) (j9 >> 32)) & 255);
        int i13 = i + 6;
        this.f13400d = i13;
        bArr[i12] = (byte) (((int) (j9 >> 40)) & 255);
        int i14 = i + 7;
        this.f13400d = i14;
        bArr[i13] = (byte) (((int) (j9 >> 48)) & 255);
        this.f13400d = i + 8;
        bArr[i14] = (byte) (((int) (j9 >> 56)) & 255);
    }

    public final void d(int i, int i4) {
        e((i << 3) | i4);
    }

    public final void e(int i) {
        boolean z8 = f13396g;
        byte[] bArr = this.f13398b;
        if (z8) {
            while ((i & (-128)) != 0) {
                int i4 = this.f13400d;
                this.f13400d = i4 + 1;
                j0.j(bArr, i4, (byte) ((i | 128) & 255));
                i >>>= 7;
            }
            int i9 = this.f13400d;
            this.f13400d = i9 + 1;
            j0.j(bArr, i9, (byte) i);
            return;
        }
        while ((i & (-128)) != 0) {
            int i10 = this.f13400d;
            this.f13400d = i10 + 1;
            bArr[i10] = (byte) ((i | 128) & 255);
            i >>>= 7;
        }
        int i11 = this.f13400d;
        this.f13400d = i11 + 1;
        bArr[i11] = (byte) i;
    }

    public final void f(long j9) {
        boolean z8 = f13396g;
        byte[] bArr = this.f13398b;
        if (z8) {
            while ((j9 & (-128)) != 0) {
                int i = this.f13400d;
                this.f13400d = i + 1;
                j0.j(bArr, i, (byte) ((((int) j9) | 128) & 255));
                j9 >>>= 7;
            }
            int i4 = this.f13400d;
            this.f13400d = i4 + 1;
            j0.j(bArr, i4, (byte) j9);
            return;
        }
        while ((j9 & (-128)) != 0) {
            int i9 = this.f13400d;
            this.f13400d = i9 + 1;
            bArr[i9] = (byte) ((((int) j9) | 128) & 255);
            j9 >>>= 7;
        }
        int i10 = this.f13400d;
        this.f13400d = i10 + 1;
        bArr[i10] = (byte) j9;
    }

    public final void l() throws IOException {
        this.f13401e.write(this.f13398b, 0, this.f13400d);
        this.f13400d = 0;
    }

    public final void m(int i) throws IOException {
        if (this.f13399c - this.f13400d < i) {
            l();
        }
    }

    public final void n(byte b9) throws IOException {
        if (this.f13400d == this.f13399c) {
            l();
        }
        int i = this.f13400d;
        this.f13400d = i + 1;
        this.f13398b[i] = b9;
    }

    public final void o(byte[] bArr, int i, int i4) throws IOException {
        int i9 = this.f13400d;
        int i10 = this.f13399c;
        int i11 = i10 - i9;
        byte[] bArr2 = this.f13398b;
        if (i11 >= i4) {
            System.arraycopy(bArr, i, bArr2, i9, i4);
            this.f13400d += i4;
            return;
        }
        System.arraycopy(bArr, i, bArr2, i9, i11);
        int i12 = i + i11;
        int i13 = i4 - i11;
        this.f13400d = i10;
        l();
        if (i13 > i10) {
            this.f13401e.write(bArr, i12, i13);
        } else {
            System.arraycopy(bArr, i12, bArr2, 0, i13);
            this.f13400d = i13;
        }
    }

    public final void p(int i, boolean z8) throws IOException {
        m(11);
        d(i, 0);
        byte b9 = z8 ? (byte) 1 : (byte) 0;
        int i4 = this.f13400d;
        this.f13400d = i4 + 1;
        this.f13398b[i4] = b9;
    }

    public final void q(int i, C1371g c1371g) {
        B(i, 2);
        r(c1371g);
    }

    public final void r(C1371g c1371g) throws IOException {
        D(c1371g.size());
        a(c1371g.f13372u, c1371g.g(), c1371g.size());
    }

    public final void s(int i, int i4) {
        m(14);
        d(i, 5);
        b(i4);
    }

    public final void t(int i) throws IOException {
        m(4);
        b(i);
    }

    public final void u(int i, long j9) {
        m(18);
        d(i, 1);
        c(j9);
    }

    public final void v(long j9) throws IOException {
        m(8);
        c(j9);
    }

    public final void w(int i, int i4) throws IOException {
        m(20);
        d(i, 0);
        if (i4 >= 0) {
            e(i4);
        } else {
            f(i4);
        }
    }

    public final void x(int i) throws IOException {
        if (i >= 0) {
            D(i);
        } else {
            F(i);
        }
    }

    public final void y(int i, AbstractC1365a abstractC1365a, W w6) throws IOException {
        B(i, 2);
        D(abstractC1365a.a(w6));
        w6.b(abstractC1365a, this.f13397a);
    }

    public final void z(int i, String str) throws IOException {
        B(i, 2);
        A(str);
    }
}
