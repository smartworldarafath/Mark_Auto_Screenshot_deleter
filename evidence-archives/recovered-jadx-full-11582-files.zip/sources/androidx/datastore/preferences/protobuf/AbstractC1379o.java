package androidx.datastore.preferences.protobuf;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1379o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C1378n f13407a = new C1378n();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C1378n f13408b;

    static {
        T t8 = T.f13327c;
        C1378n c1378n = null;
        try {
            c1378n = (C1378n) Class.forName("androidx.datastore.preferences.protobuf.ExtensionSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f13408b = c1378n;
    }
}
