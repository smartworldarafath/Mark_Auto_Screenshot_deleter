package androidx.datastore.preferences.protobuf;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1373i extends A1.M {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f13380A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f13381B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public int f13382C = Integer.MAX_VALUE;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final FileInputStream f13383v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final byte[] f13384w;
    public int x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f13385y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f13386z;

    public C1373i(FileInputStream fileInputStream) {
        Charset charset = AbstractC1386w.f13435a;
        this.f13383v = fileInputStream;
        this.f13384w = new byte[4096];
        this.x = 0;
        this.f13386z = 0;
        this.f13381B = 0;
    }

    @Override // A1.M
    public final int A() {
        return M();
    }

    @Override // A1.M
    public final long B() {
        return N();
    }

    @Override // A1.M
    public final boolean C(int i) throws C1388y {
        int i4 = i & 7;
        int i9 = 0;
        if (i4 != 0) {
            if (i4 == 1) {
                R(8);
                return true;
            }
            if (i4 == 2) {
                R(M());
                return true;
            }
            if (i4 == 3) {
                D();
                b(((i >>> 3) << 3) | 4);
                return true;
            }
            if (i4 == 4) {
                return false;
            }
            if (i4 != 5) {
                throw C1388y.b();
            }
            R(4);
            return true;
        }
        int i10 = this.x - this.f13386z;
        byte[] bArr = this.f13384w;
        if (i10 >= 10) {
            while (i9 < 10) {
                int i11 = this.f13386z;
                this.f13386z = i11 + 1;
                if (bArr[i11] < 0) {
                    i9++;
                }
            }
            throw C1388y.c();
        }
        while (i9 < 10) {
            if (this.f13386z == this.x) {
                Q(1);
            }
            int i12 = this.f13386z;
            this.f13386z = i12 + 1;
            if (bArr[i12] < 0) {
                i9++;
            }
        }
        throw C1388y.c();
        return true;
    }

    public final byte[] H(int i) throws IOException {
        byte[] bArrI = I(i);
        if (bArrI != null) {
            return bArrI;
        }
        int i4 = this.f13386z;
        int i9 = this.x;
        int length = i9 - i4;
        this.f13381B += i9;
        this.f13386z = 0;
        this.x = 0;
        ArrayList arrayListJ = J(i - length);
        byte[] bArr = new byte[i];
        System.arraycopy(this.f13384w, i4, bArr, 0, length);
        int size = arrayListJ.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayListJ.get(i10);
            i10++;
            byte[] bArr2 = (byte[]) obj;
            System.arraycopy(bArr2, 0, bArr, length, bArr2.length);
            length += bArr2.length;
        }
        return bArr;
    }

    public final byte[] I(int i) throws IOException {
        if (i == 0) {
            return AbstractC1386w.f13436b;
        }
        if (i < 0) {
            throw C1388y.d();
        }
        int i4 = this.f13381B;
        int i9 = this.f13386z;
        int i10 = i4 + i9 + i;
        if (i10 - Integer.MAX_VALUE > 0) {
            throw new C1388y("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.");
        }
        int i11 = this.f13382C;
        if (i10 > i11) {
            R((i11 - i4) - i9);
            throw C1388y.e();
        }
        int i12 = this.x - i9;
        int i13 = i - i12;
        FileInputStream fileInputStream = this.f13383v;
        if (i13 >= 4096) {
            try {
                if (i13 > fileInputStream.available()) {
                    return null;
                }
            } catch (C1388y e4) {
                e4.f13437t = true;
                throw e4;
            }
        }
        byte[] bArr = new byte[i];
        System.arraycopy(this.f13384w, this.f13386z, bArr, 0, i12);
        this.f13381B += this.x;
        this.f13386z = 0;
        this.x = 0;
        while (i12 < i) {
            try {
                int i14 = fileInputStream.read(bArr, i12, i - i12);
                if (i14 == -1) {
                    throw C1388y.e();
                }
                this.f13381B += i14;
                i12 += i14;
            } catch (C1388y e9) {
                e9.f13437t = true;
                throw e9;
            }
        }
        return bArr;
    }

    public final ArrayList J(int i) throws IOException {
        ArrayList arrayList = new ArrayList();
        while (i > 0) {
            int iMin = Math.min(i, 4096);
            byte[] bArr = new byte[iMin];
            int i4 = 0;
            while (i4 < iMin) {
                int i9 = this.f13383v.read(bArr, i4, iMin - i4);
                if (i9 == -1) {
                    throw C1388y.e();
                }
                this.f13381B += i9;
                i4 += i9;
            }
            i -= iMin;
            arrayList.add(bArr);
        }
        return arrayList;
    }

    public final int K() throws C1388y {
        int i = this.f13386z;
        if (this.x - i < 4) {
            Q(4);
            i = this.f13386z;
        }
        this.f13386z = i + 4;
        byte[] bArr = this.f13384w;
        return ((bArr[i + 3] & 255) << 24) | (bArr[i] & 255) | ((bArr[i + 1] & 255) << 8) | ((bArr[i + 2] & 255) << 16);
    }

    public final long L() throws C1388y {
        int i = this.f13386z;
        if (this.x - i < 8) {
            Q(8);
            i = this.f13386z;
        }
        this.f13386z = i + 8;
        byte[] bArr = this.f13384w;
        return ((((long) bArr[i + 7]) & 255) << 56) | (((long) bArr[i]) & 255) | ((((long) bArr[i + 1]) & 255) << 8) | ((((long) bArr[i + 2]) & 255) << 16) | ((((long) bArr[i + 3]) & 255) << 24) | ((((long) bArr[i + 4]) & 255) << 32) | ((((long) bArr[i + 5]) & 255) << 40) | ((((long) bArr[i + 6]) & 255) << 48);
    }

    public final int M() {
        int i;
        int i4 = this.f13386z;
        int i9 = this.x;
        if (i9 != i4) {
            int i10 = i4 + 1;
            byte[] bArr = this.f13384w;
            byte b9 = bArr[i4];
            if (b9 >= 0) {
                this.f13386z = i10;
                return b9;
            }
            if (i9 - i10 >= 9) {
                int i11 = i4 + 2;
                int i12 = (bArr[i10] << 7) ^ b9;
                if (i12 < 0) {
                    i = i12 ^ (-128);
                } else {
                    int i13 = i4 + 3;
                    int i14 = (bArr[i11] << 14) ^ i12;
                    if (i14 >= 0) {
                        i = i14 ^ 16256;
                    } else {
                        int i15 = i4 + 4;
                        int i16 = i14 ^ (bArr[i13] << 21);
                        if (i16 < 0) {
                            i = (-2080896) ^ i16;
                        } else {
                            i13 = i4 + 5;
                            byte b10 = bArr[i15];
                            int i17 = (i16 ^ (b10 << 28)) ^ 266354560;
                            if (b10 < 0) {
                                i15 = i4 + 6;
                                if (bArr[i13] < 0) {
                                    i13 = i4 + 7;
                                    if (bArr[i15] < 0) {
                                        i15 = i4 + 8;
                                        if (bArr[i13] < 0) {
                                            i13 = i4 + 9;
                                            if (bArr[i15] < 0) {
                                                int i18 = i4 + 10;
                                                if (bArr[i13] >= 0) {
                                                    i11 = i18;
                                                    i = i17;
                                                }
                                            }
                                        }
                                    }
                                }
                                i = i17;
                            }
                            i = i17;
                        }
                        i11 = i15;
                    }
                    i11 = i13;
                }
                this.f13386z = i11;
                return i;
            }
        }
        return (int) O();
    }

    public final long N() {
        long j9;
        long j10;
        long j11;
        long j12;
        int i = this.f13386z;
        int i4 = this.x;
        if (i4 != i) {
            int i9 = i + 1;
            byte[] bArr = this.f13384w;
            byte b9 = bArr[i];
            if (b9 >= 0) {
                this.f13386z = i9;
                return b9;
            }
            if (i4 - i9 >= 9) {
                int i10 = i + 2;
                int i11 = (bArr[i9] << 7) ^ b9;
                if (i11 < 0) {
                    j9 = i11 ^ (-128);
                } else {
                    int i12 = i + 3;
                    int i13 = (bArr[i10] << 14) ^ i11;
                    if (i13 >= 0) {
                        j9 = i13 ^ 16256;
                        i10 = i12;
                    } else {
                        int i14 = i + 4;
                        int i15 = i13 ^ (bArr[i12] << 21);
                        if (i15 < 0) {
                            j12 = (-2080896) ^ i15;
                        } else {
                            long j13 = i15;
                            i10 = i + 5;
                            long j14 = j13 ^ (((long) bArr[i14]) << 28);
                            if (j14 >= 0) {
                                j11 = 266354560;
                            } else {
                                i14 = i + 6;
                                long j15 = j14 ^ (((long) bArr[i10]) << 35);
                                if (j15 < 0) {
                                    j10 = -34093383808L;
                                } else {
                                    i10 = i + 7;
                                    j14 = j15 ^ (((long) bArr[i14]) << 42);
                                    if (j14 >= 0) {
                                        j11 = 4363953127296L;
                                    } else {
                                        i14 = i + 8;
                                        j15 = j14 ^ (((long) bArr[i10]) << 49);
                                        if (j15 < 0) {
                                            j10 = -558586000294016L;
                                        } else {
                                            i10 = i + 9;
                                            long j16 = (j15 ^ (((long) bArr[i14]) << 56)) ^ 71499008037633920L;
                                            if (j16 < 0) {
                                                int i16 = i + 10;
                                                if (bArr[i10] >= 0) {
                                                    i10 = i16;
                                                }
                                            }
                                            j9 = j16;
                                        }
                                    }
                                }
                                j12 = j10 ^ j15;
                            }
                            j9 = j11 ^ j14;
                        }
                        i10 = i14;
                        j9 = j12;
                    }
                }
                this.f13386z = i10;
                return j9;
            }
        }
        return O();
    }

    public final long O() throws C1388y {
        long j9 = 0;
        for (int i = 0; i < 64; i += 7) {
            if (this.f13386z == this.x) {
                Q(1);
            }
            int i4 = this.f13386z;
            this.f13386z = i4 + 1;
            byte b9 = this.f13384w[i4];
            j9 |= ((long) (b9 & 127)) << i;
            if ((b9 & 128) == 0) {
                return j9;
            }
        }
        throw C1388y.c();
    }

    public final void P() {
        int i = this.x + this.f13385y;
        this.x = i;
        int i4 = this.f13381B + i;
        int i9 = this.f13382C;
        if (i4 <= i9) {
            this.f13385y = 0;
            return;
        }
        int i10 = i4 - i9;
        this.f13385y = i10;
        this.x = i - i10;
    }

    public final void Q(int i) throws C1388y {
        if (S(i)) {
            return;
        }
        if (i <= (Integer.MAX_VALUE - this.f13381B) - this.f13386z) {
            throw C1388y.e();
        }
        throw new C1388y("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.");
    }

    public final void R(int i) throws C1388y {
        int i4 = this.x;
        int i9 = this.f13386z;
        int i10 = i4 - i9;
        if (i <= i10 && i >= 0) {
            this.f13386z = i9 + i;
            return;
        }
        FileInputStream fileInputStream = this.f13383v;
        if (i < 0) {
            throw C1388y.d();
        }
        int i11 = this.f13381B;
        int i12 = i11 + i9;
        int i13 = i12 + i;
        int i14 = this.f13382C;
        if (i13 > i14) {
            R((i14 - i11) - i9);
            throw C1388y.e();
        }
        this.f13381B = i12;
        this.x = 0;
        this.f13386z = 0;
        while (i10 < i) {
            long j9 = i - i10;
            try {
                try {
                    long jSkip = fileInputStream.skip(j9);
                    if (jSkip < 0 || jSkip > j9) {
                        throw new IllegalStateException(fileInputStream.getClass() + "#skip returned invalid result: " + jSkip + "\nThe InputStream implementation is buggy.");
                    }
                    if (jSkip == 0) {
                        break;
                    } else {
                        i10 += (int) jSkip;
                    }
                } catch (C1388y e4) {
                    e4.f13437t = true;
                    throw e4;
                }
            } catch (Throwable th) {
                this.f13381B += i10;
                P();
                throw th;
            }
        }
        this.f13381B += i10;
        P();
        if (i10 >= i) {
            return;
        }
        int i15 = this.x;
        int i16 = i15 - this.f13386z;
        this.f13386z = i15;
        Q(1);
        while (true) {
            int i17 = i - i16;
            int i18 = this.x;
            if (i17 <= i18) {
                this.f13386z = i17;
                return;
            } else {
                i16 += i18;
                this.f13386z = i18;
                Q(1);
            }
        }
    }

    public final boolean S(int i) throws IOException {
        FileInputStream fileInputStream = this.f13383v;
        int i4 = this.f13386z;
        int i9 = i4 + i;
        int i10 = this.x;
        if (i9 <= i10) {
            throw new IllegalStateException(X3.b.j("refillBuffer() called when ", i, " bytes were already available in buffer"));
        }
        int i11 = this.f13381B;
        if (i <= (Integer.MAX_VALUE - i11) - i4 && i11 + i4 + i <= this.f13382C) {
            byte[] bArr = this.f13384w;
            if (i4 > 0) {
                if (i10 > i4) {
                    System.arraycopy(bArr, i4, bArr, 0, i10 - i4);
                }
                this.f13381B += i4;
                this.x -= i4;
                this.f13386z = 0;
            }
            int i12 = this.x;
            try {
                int i13 = fileInputStream.read(bArr, i12, Math.min(bArr.length - i12, (Integer.MAX_VALUE - this.f13381B) - i12));
                if (i13 == 0 || i13 < -1 || i13 > bArr.length) {
                    throw new IllegalStateException(fileInputStream.getClass() + "#read(byte[]) returned invalid result: " + i13 + "\nThe InputStream implementation is buggy.");
                }
                if (i13 > 0) {
                    this.x += i13;
                    P();
                    if (this.x >= i) {
                        return true;
                    }
                    return S(i);
                }
            } catch (C1388y e4) {
                e4.f13437t = true;
                throw e4;
            }
        }
        return false;
    }

    @Override // A1.M
    public final void b(int i) throws C1388y {
        if (this.f13380A != i) {
            throw new C1388y("Protocol message end-group tag did not match expected tag.");
        }
    }

    @Override // A1.M
    public final int c() {
        return this.f13381B + this.f13386z;
    }

    @Override // A1.M
    public final boolean d() {
        return this.f13386z == this.x && !S(1);
    }

    @Override // A1.M
    public final void i(int i) {
        this.f13382C = i;
        P();
    }

    @Override // A1.M
    public final int j(int i) throws C1388y {
        if (i < 0) {
            throw C1388y.d();
        }
        int i4 = this.f13381B + this.f13386z + i;
        if (i4 < 0) {
            throw new C1388y("Failed to parse the message.");
        }
        int i9 = this.f13382C;
        if (i4 > i9) {
            throw C1388y.e();
        }
        this.f13382C = i4;
        P();
        return i9;
    }

    @Override // A1.M
    public final boolean k() {
        return N() != 0;
    }

    @Override // A1.M
    public final C1371g l() throws IOException {
        int iM = M();
        int i = this.x;
        int i4 = this.f13386z;
        int i9 = i - i4;
        byte[] bArr = this.f13384w;
        if (iM <= i9 && iM > 0) {
            C1371g c1371gE = C1371g.e(bArr, i4, iM);
            this.f13386z += iM;
            return c1371gE;
        }
        if (iM == 0) {
            return C1371g.f13369v;
        }
        if (iM < 0) {
            throw C1388y.d();
        }
        byte[] bArrI = I(iM);
        if (bArrI != null) {
            return C1371g.e(bArrI, 0, bArrI.length);
        }
        int i10 = this.f13386z;
        int i11 = this.x;
        int length = i11 - i10;
        this.f13381B += i11;
        this.f13386z = 0;
        this.x = 0;
        ArrayList arrayListJ = J(iM - length);
        byte[] bArr2 = new byte[iM];
        System.arraycopy(bArr, i10, bArr2, 0, length);
        int size = arrayListJ.size();
        int i12 = 0;
        while (i12 < size) {
            Object obj = arrayListJ.get(i12);
            i12++;
            byte[] bArr3 = (byte[]) obj;
            System.arraycopy(bArr3, 0, bArr2, length, bArr3.length);
            length += bArr3.length;
        }
        C1371g c1371g = C1371g.f13369v;
        return new C1371g(bArr2);
    }

    @Override // A1.M
    public final double m() {
        return Double.longBitsToDouble(L());
    }

    @Override // A1.M
    public final int n() {
        return M();
    }

    @Override // A1.M
    public final int o() {
        return K();
    }

    @Override // A1.M
    public final long p() {
        return L();
    }

    @Override // A1.M
    public final float q() {
        return Float.intBitsToFloat(K());
    }

    @Override // A1.M
    public final int r() {
        return M();
    }

    @Override // A1.M
    public final long s() {
        return N();
    }

    @Override // A1.M
    public final int t() {
        return K();
    }

    @Override // A1.M
    public final long u() {
        return L();
    }

    @Override // A1.M
    public final int v() {
        int iM = M();
        return (-(iM & 1)) ^ (iM >>> 1);
    }

    @Override // A1.M
    public final long w() {
        long jN = N();
        return (-(jN & 1)) ^ (jN >>> 1);
    }

    @Override // A1.M
    public final String x() throws C1388y {
        int iM = M();
        byte[] bArr = this.f13384w;
        if (iM > 0) {
            int i = this.x;
            int i4 = this.f13386z;
            if (iM <= i - i4) {
                String str = new String(bArr, i4, iM, AbstractC1386w.f13435a);
                this.f13386z += iM;
                return str;
            }
        }
        if (iM == 0) {
            return "";
        }
        if (iM < 0) {
            throw C1388y.d();
        }
        if (iM > this.x) {
            return new String(H(iM), AbstractC1386w.f13435a);
        }
        Q(iM);
        String str2 = new String(bArr, this.f13386z, iM, AbstractC1386w.f13435a);
        this.f13386z += iM;
        return str2;
    }

    @Override // A1.M
    public final String y() throws IOException {
        int iM = M();
        int i = this.f13386z;
        int i4 = this.x;
        int i9 = i4 - i;
        byte[] bArrH = this.f13384w;
        if (iM <= i9 && iM > 0) {
            this.f13386z = i + iM;
        } else {
            if (iM == 0) {
                return "";
            }
            if (iM < 0) {
                throw C1388y.d();
            }
            i = 0;
            if (iM <= i4) {
                Q(iM);
                this.f13386z = iM;
            } else {
                bArrH = H(iM);
            }
        }
        return m0.f13406a.a(bArrH, i, iM);
    }

    @Override // A1.M
    public final int z() throws C1388y {
        if (d()) {
            this.f13380A = 0;
            return 0;
        }
        int iM = M();
        this.f13380A = iM;
        if ((iM >>> 3) != 0) {
            return iM;
        }
        throw new C1388y("Protocol message contained an invalid tag (zero).");
    }
}
