package androidx.datastore.preferences.protobuf;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class d0 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final d0 f13361f = new d0(0, new int[0], new Object[0], false);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f13362a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int[] f13363b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object[] f13364c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f13365d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f13366e;

    public d0(int i, int[] iArr, Object[] objArr, boolean z8) {
        this.f13362a = i;
        this.f13363b = iArr;
        this.f13364c = objArr;
        this.f13366e = z8;
    }

    public final void a(int i) {
        int[] iArr = this.f13363b;
        if (i > iArr.length) {
            int i4 = this.f13362a;
            int i9 = (i4 / 2) + i4;
            if (i9 >= i) {
                i = i9;
            }
            if (i < 8) {
                i = 8;
            }
            this.f13363b = Arrays.copyOf(iArr, i);
            this.f13364c = Arrays.copyOf(this.f13364c, i);
        }
    }

    public final int b() {
        int i;
        int iK;
        int i4;
        int i9 = this.f13365d;
        if (i9 != -1) {
            return i9;
        }
        int i10 = 0;
        for (int i11 = 0; i11 < this.f13362a; i11++) {
            int i12 = this.f13363b[i11];
            int i13 = i12 >>> 3;
            int i14 = i12 & 7;
            if (i14 != 0) {
                if (i14 == 1) {
                    ((Long) this.f13364c[i11]).getClass();
                    i4 = C1375k.i(i13) + 8;
                } else if (i14 == 2) {
                    i4 = C1375k.g(i13, (C1371g) this.f13364c[i11]);
                } else if (i14 == 3) {
                    i = C1375k.i(i13) * 2;
                    iK = ((d0) this.f13364c[i11]).b();
                } else {
                    if (i14 != 5) {
                        throw new IllegalStateException(C1388y.b());
                    }
                    ((Integer) this.f13364c[i11]).getClass();
                    i4 = C1375k.i(i13) + 4;
                }
                i10 = i4 + i10;
            } else {
                long jLongValue = ((Long) this.f13364c[i11]).longValue();
                i = C1375k.i(i13);
                iK = C1375k.k(jLongValue);
            }
            i10 = iK + i + i10;
        }
        this.f13365d = i10;
        return i10;
    }

    public final void c(int i, Object obj) {
        if (!this.f13366e) {
            throw new UnsupportedOperationException();
        }
        a(this.f13362a + 1);
        int[] iArr = this.f13363b;
        int i4 = this.f13362a;
        iArr[i4] = i;
        this.f13364c[i4] = obj;
        this.f13362a = i4 + 1;
    }

    public final void d(E e4) {
        if (this.f13362a == 0) {
            return;
        }
        e4.getClass();
        C1375k c1375k = (C1375k) e4.f13297a;
        for (int i = 0; i < this.f13362a; i++) {
            int i4 = this.f13363b[i];
            Object obj = this.f13364c[i];
            int i9 = i4 >>> 3;
            int i10 = i4 & 7;
            if (i10 == 0) {
                c1375k.E(i9, ((Long) obj).longValue());
            } else if (i10 == 1) {
                c1375k.u(i9, ((Long) obj).longValue());
            } else if (i10 == 2) {
                c1375k.q(i9, (C1371g) obj);
            } else if (i10 == 3) {
                c1375k.B(i9, 3);
                ((d0) obj).d(e4);
                c1375k.B(i9, 4);
            } else {
                if (i10 != 5) {
                    throw new RuntimeException(C1388y.b());
                }
                c1375k.s(i9, ((Integer) obj).intValue());
            }
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof d0)) {
            return false;
        }
        d0 d0Var = (d0) obj;
        int i = this.f13362a;
        if (i == d0Var.f13362a) {
            int[] iArr = this.f13363b;
            int[] iArr2 = d0Var.f13363b;
            for (int i4 = 0; i4 < i; i4++) {
                if (iArr[i4] == iArr2[i4]) {
                }
            }
            Object[] objArr = this.f13364c;
            Object[] objArr2 = d0Var.f13364c;
            int i9 = this.f13362a;
            for (int i10 = 0; i10 < i9; i10++) {
                if (objArr[i10].equals(objArr2[i10])) {
                }
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = this.f13362a;
        int i4 = (527 + i) * 31;
        int[] iArr = this.f13363b;
        int iHashCode = 17;
        int i9 = 17;
        for (int i10 = 0; i10 < i; i10++) {
            i9 = (i9 * 31) + iArr[i10];
        }
        int i11 = (i4 + i9) * 31;
        Object[] objArr = this.f13364c;
        int i12 = this.f13362a;
        for (int i13 = 0; i13 < i12; i13++) {
            iHashCode = (iHashCode * 31) + objArr[i13].hashCode();
        }
        return i11 + iHashCode;
    }
}
