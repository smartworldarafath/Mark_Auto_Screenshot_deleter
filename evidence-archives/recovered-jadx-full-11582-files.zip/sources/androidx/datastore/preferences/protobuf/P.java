package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public abstract class P {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final O f13325a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final O f13326b;

    static {
        T t8 = T.f13327c;
        O o5 = null;
        try {
            o5 = (O) Class.forName("androidx.datastore.preferences.protobuf.NewInstanceSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f13325a = o5;
        f13326b = new O();
    }
}
