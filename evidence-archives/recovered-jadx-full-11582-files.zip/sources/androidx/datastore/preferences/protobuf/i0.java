package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Field;
import sun.misc.Unsafe;

/* JADX INFO: loaded from: classes.dex */
public abstract class i0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Unsafe f13387a;

    public i0(Unsafe unsafe) {
        this.f13387a = unsafe;
    }

    public final int a(Class cls) {
        return this.f13387a.arrayBaseOffset(cls);
    }

    public final int b(Class cls) {
        return this.f13387a.arrayIndexScale(cls);
    }

    public abstract boolean c(long j9, Object obj);

    public abstract double d(long j9, Object obj);

    public abstract float e(long j9, Object obj);

    public final int f(long j9, Object obj) {
        return this.f13387a.getInt(obj, j9);
    }

    public final long g(long j9, Object obj) {
        return this.f13387a.getLong(obj, j9);
    }

    public final Object h(long j9, Object obj) {
        return this.f13387a.getObject(obj, j9);
    }

    public final long i(Field field) {
        return this.f13387a.objectFieldOffset(field);
    }

    public abstract void j(Object obj, long j9, boolean z8);

    public abstract void k(Object obj, long j9, byte b9);

    public abstract void l(Object obj, long j9, double d2);

    public abstract void m(Object obj, long j9, float f4);

    public final void n(long j9, Object obj, int i) {
        this.f13387a.putInt(obj, j9, i);
    }

    public final void o(Object obj, long j9, long j10) {
        this.f13387a.putLong(obj, j9, j10);
    }

    public final void p(long j9, Object obj, Object obj2) {
        this.f13387a.putObject(obj, j9, obj2);
    }

    public boolean q() {
        Unsafe unsafe = this.f13387a;
        if (unsafe == null) {
            return false;
        }
        try {
            Class<?> cls = unsafe.getClass();
            cls.getMethod("objectFieldOffset", Field.class);
            cls.getMethod("arrayBaseOffset", Class.class);
            cls.getMethod("arrayIndexScale", Class.class);
            Class cls2 = Long.TYPE;
            cls.getMethod("getInt", Object.class, cls2);
            cls.getMethod("putInt", Object.class, cls2, Integer.TYPE);
            cls.getMethod("getLong", Object.class, cls2);
            cls.getMethod("putLong", Object.class, cls2, cls2);
            cls.getMethod("getObject", Object.class, cls2);
            cls.getMethod("putObject", Object.class, cls2, Object.class);
            return true;
        } catch (Throwable th) {
            j0.a(th);
            return false;
        }
    }

    public abstract boolean r();
}
