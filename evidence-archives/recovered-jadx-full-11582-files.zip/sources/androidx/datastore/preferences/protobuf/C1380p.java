package androidx.datastore.preferences.protobuf;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1380p {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f13409c = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Y f13410a = Y.f();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f13411b;

    static {
        new C1380p(0);
    }

    public C1380p() {
    }

    public static void b(C1375k c1375k, r0 r0Var, int i, Object obj) {
        if (r0Var == r0.f13419w) {
            c1375k.B(i, 3);
            ((AbstractC1365a) obj).b(c1375k);
            c1375k.B(i, 4);
        }
        c1375k.B(i, r0Var.f13422u);
        switch (r0Var.ordinal()) {
            case 0:
                c1375k.v(Double.doubleToRawLongBits(((Double) obj).doubleValue()));
                break;
            case 1:
                c1375k.t(Float.floatToRawIntBits(((Float) obj).floatValue()));
                break;
            case 2:
                c1375k.F(((Long) obj).longValue());
                break;
            case 3:
                c1375k.F(((Long) obj).longValue());
                break;
            case 4:
                c1375k.x(((Integer) obj).intValue());
                break;
            case 5:
                c1375k.v(((Long) obj).longValue());
                break;
            case 6:
                c1375k.t(((Integer) obj).intValue());
                break;
            case 7:
                c1375k.n(((Boolean) obj).booleanValue() ? (byte) 1 : (byte) 0);
                break;
            case 8:
                if (!(obj instanceof C1371g)) {
                    c1375k.A((String) obj);
                } else {
                    c1375k.r((C1371g) obj);
                }
                break;
            case 9:
                ((AbstractC1365a) obj).b(c1375k);
                break;
            case 10:
                AbstractC1365a abstractC1365a = (AbstractC1365a) obj;
                c1375k.getClass();
                c1375k.D(((AbstractC1384u) abstractC1365a).a(null));
                abstractC1365a.b(c1375k);
                break;
            case 11:
                if (!(obj instanceof C1371g)) {
                    byte[] bArr = (byte[]) obj;
                    int length = bArr.length;
                    c1375k.D(length);
                    c1375k.o(bArr, 0, length);
                } else {
                    c1375k.r((C1371g) obj);
                }
                break;
            case 12:
                c1375k.D(((Integer) obj).intValue());
                break;
            case 13:
                c1375k.x(((Integer) obj).intValue());
                break;
            case 14:
                c1375k.t(((Integer) obj).intValue());
                break;
            case 15:
                c1375k.v(((Long) obj).longValue());
                break;
            case 16:
                int iIntValue = ((Integer) obj).intValue();
                c1375k.D((iIntValue >> 31) ^ (iIntValue << 1));
                break;
            case 17:
                long jLongValue = ((Long) obj).longValue();
                c1375k.F((jLongValue >> 63) ^ (jLongValue << 1));
                break;
        }
    }

    public final void a() {
        if (this.f13411b) {
            return;
        }
        Y y8 = this.f13410a;
        int size = y8.f13341t.size();
        for (int i = 0; i < size; i++) {
            Map.Entry entryC = y8.c(i);
            if (entryC.getValue() instanceof AbstractC1384u) {
                AbstractC1384u abstractC1384u = (AbstractC1384u) entryC.getValue();
                abstractC1384u.getClass();
                T t8 = T.f13327c;
                t8.getClass();
                t8.a(abstractC1384u.getClass()).c(abstractC1384u);
                abstractC1384u.h();
            }
        }
        if (!y8.f13343v) {
            if (y8.f13341t.size() > 0) {
                y8.c(0).getKey().getClass();
                throw new ClassCastException();
            }
            Iterator it = y8.d().iterator();
            if (it.hasNext()) {
                ((Map.Entry) it.next()).getKey().getClass();
                throw new ClassCastException();
            }
        }
        if (!y8.f13343v) {
            y8.f13342u = y8.f13342u.isEmpty() ? Collections.EMPTY_MAP : Collections.unmodifiableMap(y8.f13342u);
            y8.x = y8.x.isEmpty() ? Collections.EMPTY_MAP : Collections.unmodifiableMap(y8.x);
            y8.f13343v = true;
        }
        this.f13411b = true;
    }

    public final Object clone() {
        C1380p c1380p = new C1380p();
        Y y8 = this.f13410a;
        if (y8.f13341t.size() > 0) {
            Map.Entry entryC = y8.c(0);
            if (entryC.getKey() != null) {
                throw new ClassCastException();
            }
            entryC.getValue();
            throw null;
        }
        Iterator it = y8.d().iterator();
        if (!it.hasNext()) {
            return c1380p;
        }
        Map.Entry entry = (Map.Entry) it.next();
        if (entry.getKey() != null) {
            throw new ClassCastException();
        }
        entry.getValue();
        throw null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C1380p) {
            return this.f13410a.equals(((C1380p) obj).f13410a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f13410a.hashCode();
    }

    public C1380p(int i) {
        a();
        a();
    }
}
