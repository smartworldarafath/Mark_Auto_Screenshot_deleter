package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class F {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final r0 f13298a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final r0 f13299b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f13300c;

    public F(r0 r0Var, r0 r0Var2, Object obj) {
        this.f13298a = r0Var;
        this.f13299b = r0Var2;
        this.f13300c = obj;
    }
}
