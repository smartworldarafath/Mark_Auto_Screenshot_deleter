package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.consent_sdk.C4907h2;
import com.google.android.gms.internal.measurement.X1;
import com.google.android.gms.internal.mlkit_vision_text_bundled_common.AbstractC5481h5;
import com.google.android.gms.internal.play_billing.C5634h0;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1368d implements Iterator {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f13357t = 0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f13358u = 0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int f13359v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ Object f13360w;

    public C1368d(C4907h2 c4907h2) {
        this.f13360w = c4907h2;
        this.f13359v = c4907h2.e();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        switch (this.f13357t) {
            case 0:
                return this.f13358u < this.f13359v;
            case 1:
                return this.f13358u < this.f13359v;
            case 2:
                return this.f13358u < this.f13359v;
            case 3:
                return this.f13358u < this.f13359v;
            default:
                return this.f13358u < this.f13359v;
        }
    }

    @Override // java.util.Iterator
    public final Object next() {
        switch (this.f13357t) {
            case 0:
                int i = this.f13358u;
                if (i >= this.f13359v) {
                    throw new NoSuchElementException();
                }
                this.f13358u = i + 1;
                return Byte.valueOf(((C1371g) this.f13360w).h(i));
            case 1:
                int i4 = this.f13358u;
                if (i4 >= this.f13359v) {
                    throw new NoSuchElementException();
                }
                this.f13358u = i4 + 1;
                return Byte.valueOf(((C4907h2) this.f13360w).c(i4));
            case 2:
                int i9 = this.f13358u;
                if (i9 >= this.f13359v) {
                    throw new NoSuchElementException();
                }
                this.f13358u = i9 + 1;
                return Byte.valueOf(((X1) this.f13360w).c(i9));
            case 3:
                int i10 = this.f13358u;
                if (i10 >= this.f13359v) {
                    throw new NoSuchElementException();
                }
                this.f13358u = i10 + 1;
                return Byte.valueOf(((AbstractC5481h5) this.f13360w).c(i10));
            default:
                int i11 = this.f13358u;
                if (i11 >= this.f13359v) {
                    throw new NoSuchElementException();
                }
                this.f13358u = i11 + 1;
                return Byte.valueOf(((C5634h0) this.f13360w).c(i11));
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        switch (this.f13357t) {
            case 0:
                throw new UnsupportedOperationException();
            case 1:
                throw new UnsupportedOperationException();
            case 2:
                throw new UnsupportedOperationException();
            case 3:
                throw new UnsupportedOperationException();
            default:
                throw new UnsupportedOperationException();
        }
    }

    public C1368d(X1 x8) {
        this.f13360w = x8;
        this.f13359v = x8.e();
    }

    public C1368d(AbstractC5481h5 abstractC5481h5) {
        this.f13360w = abstractC5481h5;
        this.f13359v = abstractC5481h5.e();
    }

    public C1368d(C5634h0 c5634h0) {
        this.f13360w = c5634h0;
        this.f13359v = c5634h0.e();
    }

    public C1368d(C1371g c1371g) {
        this.f13360w = c1371g;
        this.f13359v = c1371g.size();
    }
}
