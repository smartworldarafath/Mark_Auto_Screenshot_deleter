package androidx.datastore.preferences.protobuf;

import F4.AbstractC0446s5;
import com.google.android.gms.internal.measurement.AbstractC5061q1;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Locale;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C1371g implements Iterable, Serializable {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final C1371g f13369v = new C1371g(AbstractC1386w.f13436b);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final C1369e f13370w;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f13371t = 0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final byte[] f13372u;

    static {
        f13370w = AbstractC1367c.a() ? new C1369e(1) : new C1369e(0);
    }

    public C1371g(byte[] bArr) {
        bArr.getClass();
        this.f13372u = bArr;
    }

    public static int c(int i, int i4, int i9) {
        int i10 = i4 - i;
        if ((i | i4 | i10 | (i9 - i4)) >= 0) {
            return i10;
        }
        if (i < 0) {
            throw new IndexOutOfBoundsException(X3.b.j("Beginning index: ", i, " < 0"));
        }
        if (i4 < i) {
            throw new IndexOutOfBoundsException(AbstractC5061q1.i(i, i4, "Beginning index larger than ending index: ", ", "));
        }
        throw new IndexOutOfBoundsException(AbstractC5061q1.i(i4, i9, "End index: ", " >= "));
    }

    public static C1371g e(byte[] bArr, int i, int i4) {
        byte[] bArrCopyOfRange;
        c(i, i + i4, bArr.length);
        switch (f13370w.f13367a) {
            case 0:
                bArrCopyOfRange = Arrays.copyOfRange(bArr, i, i4 + i);
                break;
            default:
                bArrCopyOfRange = new byte[i4];
                System.arraycopy(bArr, i, bArrCopyOfRange, 0, i4);
                break;
        }
        return new C1371g(bArrCopyOfRange);
    }

    public byte b(int i) {
        return this.f13372u[i];
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C1371g) || size() != ((C1371g) obj).size()) {
            return false;
        }
        if (size() == 0) {
            return true;
        }
        if (!(obj instanceof C1371g)) {
            return obj.equals(this);
        }
        C1371g c1371g = (C1371g) obj;
        int i = this.f13371t;
        int i4 = c1371g.f13371t;
        if (i != 0 && i4 != 0 && i != i4) {
            return false;
        }
        int size = size();
        if (size > c1371g.size()) {
            throw new IllegalArgumentException("Length too large: " + size + size());
        }
        if (size > c1371g.size()) {
            StringBuilder sbP = AbstractC5061q1.p("Ran off end of other: 0, ", size, ", ");
            sbP.append(c1371g.size());
            throw new IllegalArgumentException(sbP.toString());
        }
        byte[] bArr = c1371g.f13372u;
        int iG = g() + size;
        int iG2 = g();
        int iG3 = c1371g.g();
        while (iG2 < iG) {
            if (this.f13372u[iG2] != bArr[iG3]) {
                return false;
            }
            iG2++;
            iG3++;
        }
        return true;
    }

    public void f(int i, byte[] bArr) {
        System.arraycopy(this.f13372u, 0, bArr, 0, i);
    }

    public int g() {
        return 0;
    }

    public byte h(int i) {
        return this.f13372u[i];
    }

    public final int hashCode() {
        int i = this.f13371t;
        if (i != 0) {
            return i;
        }
        int size = size();
        int iG = g();
        int i4 = size;
        for (int i9 = iG; i9 < iG + size; i9++) {
            i4 = (i4 * 31) + this.f13372u[i9];
        }
        if (i4 == 0) {
            i4 = 1;
        }
        this.f13371t = i4;
        return i4;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        return new C1368d(this);
    }

    public int size() {
        return this.f13372u.length;
    }

    public final String toString() {
        String string;
        Locale locale = Locale.ROOT;
        String hexString = Integer.toHexString(System.identityHashCode(this));
        int size = size();
        if (size() <= 50) {
            string = AbstractC0446s5.a(this);
        } else {
            StringBuilder sb = new StringBuilder();
            int iC = c(0, 47, size());
            sb.append(AbstractC0446s5.a(iC == 0 ? f13369v : new C1370f(this.f13372u, g(), iC)));
            sb.append("...");
            string = sb.toString();
        }
        StringBuilder sb2 = new StringBuilder("<ByteString@");
        sb2.append(hexString);
        sb2.append(" size=");
        sb2.append(size);
        sb2.append(" contents=\"");
        return X3.b.m(sb2, string, "\">");
    }
}
