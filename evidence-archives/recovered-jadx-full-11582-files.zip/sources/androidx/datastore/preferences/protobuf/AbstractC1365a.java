package androidx.datastore.preferences.protobuf;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1365a {
    protected int memoizedHashCode;

    public abstract int a(W w6);

    public abstract void b(C1375k c1375k);
}
