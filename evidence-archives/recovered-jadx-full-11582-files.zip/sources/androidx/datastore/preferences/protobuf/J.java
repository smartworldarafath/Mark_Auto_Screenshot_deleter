package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public abstract class J {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final I f13305a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final I f13306b;

    static {
        T t8 = T.f13327c;
        I i = null;
        try {
            i = (I) Class.forName("androidx.datastore.preferences.protobuf.MapFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f13305a = i;
        f13306b = new I();
    }
}
