package androidx.datastore.preferences.protobuf;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
public final class Y extends AbstractMap {

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final /* synthetic */ int f13340y = 0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public List f13341t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Map f13342u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f13343v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public volatile b0 f13344w;
    public Map x;

    public static Y f() {
        Y y8 = new Y();
        y8.f13341t = Collections.EMPTY_LIST;
        Map map = Collections.EMPTY_MAP;
        y8.f13342u = map;
        y8.x = map;
        return y8;
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0024  */
    /* JADX WARN: Code duplicated, block: B:17:0x003e  */
    /* JADX WARN: Code duplicated, block: B:21:0x003c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:22:0x0042 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:23:0x0038 A[SYNTHETIC] */
    public final int a(Comparable comparable) {
        int i;
        int i4;
        int i9;
        int iCompareTo;
        int size = this.f13341t.size();
        int i10 = size - 1;
        if (i10 < 0) {
            i = 0;
            while (i <= i10) {
                i9 = (i + i10) / 2;
                iCompareTo = comparable.compareTo(((Z) this.f13341t.get(i9)).f13345t);
                if (iCompareTo < 0) {
                    i10 = i9 - 1;
                } else {
                    if (iCompareTo > 0) {
                        return i9;
                    }
                    i = i9 + 1;
                }
            }
            i4 = i + 1;
        } else {
            int iCompareTo2 = comparable.compareTo(((Z) this.f13341t.get(i10)).f13345t);
            if (iCompareTo2 > 0) {
                i4 = size + 1;
            } else {
                if (iCompareTo2 == 0) {
                    return i10;
                }
                i = 0;
                while (i <= i10) {
                    i9 = (i + i10) / 2;
                    iCompareTo = comparable.compareTo(((Z) this.f13341t.get(i9)).f13345t);
                    if (iCompareTo < 0) {
                        i10 = i9 - 1;
                    } else {
                        if (iCompareTo > 0) {
                            return i9;
                        }
                        i = i9 + 1;
                    }
                }
                i4 = i + 1;
            }
        }
        return -i4;
    }

    public final void b() {
        if (this.f13343v) {
            throw new UnsupportedOperationException();
        }
    }

    public final Map.Entry c(int i) {
        return (Map.Entry) this.f13341t.get(i);
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final void clear() {
        b();
        if (!this.f13341t.isEmpty()) {
            this.f13341t.clear();
        }
        if (this.f13342u.isEmpty()) {
            return;
        }
        this.f13342u.clear();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean containsKey(Object obj) {
        Comparable comparable = (Comparable) obj;
        return a(comparable) >= 0 || this.f13342u.containsKey(comparable);
    }

    public final Set d() {
        return this.f13342u.isEmpty() ? Collections.EMPTY_SET : this.f13342u.entrySet();
    }

    public final SortedMap e() {
        b();
        if (this.f13342u.isEmpty() && !(this.f13342u instanceof TreeMap)) {
            TreeMap treeMap = new TreeMap();
            this.f13342u = treeMap;
            this.x = treeMap.descendingMap();
        }
        return (SortedMap) this.f13342u;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set entrySet() {
        if (this.f13344w == null) {
            this.f13344w = new b0(0, this);
        }
        return this.f13344w;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Y)) {
            return super.equals(obj);
        }
        Y y8 = (Y) obj;
        int size = size();
        if (size == y8.size()) {
            int size2 = this.f13341t.size();
            if (size2 != y8.f13341t.size()) {
                return ((AbstractSet) entrySet()).equals(y8.entrySet());
            }
            for (int i = 0; i < size2; i++) {
                if (c(i).equals(y8.c(i))) {
                }
            }
            if (size2 != size) {
                return this.f13342u.equals(y8.f13342u);
            }
            return true;
        }
        return false;
    }

    @Override // java.util.AbstractMap, java.util.Map
    /* JADX INFO: renamed from: g, reason: merged with bridge method [inline-methods] */
    public final Object put(Comparable comparable, Object obj) {
        b();
        int iA = a(comparable);
        if (iA >= 0) {
            return ((Z) this.f13341t.get(iA)).setValue(obj);
        }
        b();
        if (this.f13341t.isEmpty() && !(this.f13341t instanceof ArrayList)) {
            this.f13341t = new ArrayList(16);
        }
        int i = -(iA + 1);
        if (i >= 16) {
            return e().put(comparable, obj);
        }
        if (this.f13341t.size() == 16) {
            Z z8 = (Z) this.f13341t.remove(15);
            e().put(z8.f13345t, z8.f13346u);
        }
        this.f13341t.add(i, new Z(this, comparable, obj));
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object get(Object obj) {
        Comparable comparable = (Comparable) obj;
        int iA = a(comparable);
        return iA >= 0 ? ((Z) this.f13341t.get(iA)).f13346u : this.f13342u.get(comparable);
    }

    public final Object h(int i) {
        b();
        Object obj = ((Z) this.f13341t.remove(i)).f13346u;
        if (!this.f13342u.isEmpty()) {
            Iterator it = e().entrySet().iterator();
            List list = this.f13341t;
            Map.Entry entry = (Map.Entry) it.next();
            list.add(new Z(this, (Comparable) entry.getKey(), entry.getValue()));
            it.remove();
        }
        return obj;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int hashCode() {
        int size = this.f13341t.size();
        int iHashCode = 0;
        for (int i = 0; i < size; i++) {
            iHashCode += ((Z) this.f13341t.get(i)).hashCode();
        }
        return this.f13342u.size() > 0 ? this.f13342u.hashCode() + iHashCode : iHashCode;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object remove(Object obj) {
        b();
        Comparable comparable = (Comparable) obj;
        int iA = a(comparable);
        if (iA >= 0) {
            return h(iA);
        }
        if (this.f13342u.isEmpty()) {
            return null;
        }
        return this.f13342u.remove(comparable);
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int size() {
        return this.f13342u.size() + this.f13341t.size();
    }
}
