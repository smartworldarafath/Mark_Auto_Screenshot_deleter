package androidx.datastore.preferences.protobuf;

import java.nio.charset.Charset;

/* JADX INFO: loaded from: classes.dex */
public final class E {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final r f13296b = new r(1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f13297a;

    public E(C1375k c1375k) {
        AbstractC1386w.a(c1375k, "output");
        this.f13297a = c1375k;
        c1375k.f13397a = this;
    }

    public void a(int i, Object obj, W w6) {
        C1375k c1375k = (C1375k) this.f13297a;
        c1375k.B(i, 3);
        w6.b((AbstractC1365a) obj, c1375k.f13397a);
        c1375k.B(i, 4);
    }

    public E() {
        K k4;
        T t8 = T.f13327c;
        try {
            k4 = (K) Class.forName("androidx.datastore.preferences.protobuf.DescriptorMessageInfoFactory").getDeclaredMethod("getInstance", null).invoke(null, null);
        } catch (Exception unused) {
            k4 = f13296b;
        }
        K[] kArr = {r.f13416b, k4};
        D d2 = new D();
        d2.f13295a = kArr;
        Charset charset = AbstractC1386w.f13435a;
        this.f13297a = d2;
    }
}
