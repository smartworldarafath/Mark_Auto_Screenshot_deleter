package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class V {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final AbstractC1365a f13333a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f13334b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object[] f13335c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f13336d;

    public V(AbstractC1384u abstractC1384u, String str, Object[] objArr) {
        this.f13333a = abstractC1384u;
        this.f13334b = str;
        this.f13335c = objArr;
        char cCharAt = str.charAt(0);
        if (cCharAt < 55296) {
            this.f13336d = cCharAt;
            return;
        }
        int i = cCharAt & 8191;
        int i4 = 13;
        int i9 = 1;
        while (true) {
            int i10 = i9 + 1;
            char cCharAt2 = str.charAt(i9);
            if (cCharAt2 < 55296) {
                this.f13336d = i | (cCharAt2 << i4);
                return;
            } else {
                i |= (cCharAt2 & 8191) << i4;
                i4 += 13;
                i9 = i10;
            }
        }
    }

    public final int a() {
        int i = this.f13336d;
        if ((i & 1) != 0) {
            return 1;
        }
        return (i & 4) == 4 ? 3 : 2;
    }
}
