package androidx.datastore.preferences.protobuf;

import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class T {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final T f13327c = new T();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ConcurrentHashMap f13329b = new ConcurrentHashMap();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final E f13328a = new E();

    public final W a(Class cls) {
        W w6;
        Class cls2;
        AbstractC1386w.a(cls, "messageType");
        ConcurrentHashMap concurrentHashMap = this.f13329b;
        W w8 = (W) concurrentHashMap.get(cls);
        if (w8 != null) {
            return w8;
        }
        E e4 = this.f13328a;
        e4.getClass();
        Class cls3 = X.f13337a;
        if (!AbstractC1384u.class.isAssignableFrom(cls) && (cls2 = X.f13337a) != null && !cls2.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("Message classes must extend GeneratedMessage or GeneratedMessageLite");
        }
        V vA = ((D) e4.f13297a).a(cls);
        int i = vA.f13336d;
        AbstractC1365a abstractC1365a = vA.f13333a;
        if ((i & 2) == 2) {
            if (AbstractC1384u.class.isAssignableFrom(cls)) {
                w6 = new N(X.f13339c, AbstractC1379o.f13407a, abstractC1365a);
            } else {
                e0 e0Var = X.f13338b;
                C1378n c1378n = AbstractC1379o.f13408b;
                if (c1378n == null) {
                    throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
                }
                w6 = new N(e0Var, c1378n, abstractC1365a);
            }
        } else if (AbstractC1384u.class.isAssignableFrom(cls)) {
            C1378n c1378n2 = null;
            O o5 = P.f13326b;
            B b9 = C.f13294b;
            e0 e0Var2 = X.f13339c;
            if (Z.c.b(vA.a()) != 1) {
                c1378n2 = AbstractC1379o.f13407a;
            }
            C1378n c1378n3 = c1378n2;
            I i4 = J.f13306b;
            int[] iArr = M.f13308n;
            if (!(vA instanceof V)) {
                vA.getClass();
                throw new ClassCastException();
            }
            w6 = M.w(vA, o5, b9, e0Var2, c1378n3, i4);
        } else {
            C1378n c1378n4 = null;
            O o8 = P.f13325a;
            B b10 = C.f13293a;
            e0 e0Var3 = X.f13338b;
            if (Z.c.b(vA.a()) != 1 && (c1378n4 = AbstractC1379o.f13408b) == null) {
                throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
            }
            C1378n c1378n5 = c1378n4;
            I i9 = J.f13305a;
            int[] iArr2 = M.f13308n;
            if (!(vA instanceof V)) {
                vA.getClass();
                throw new ClassCastException();
            }
            w6 = M.w(vA, o8, b10, e0Var3, c1378n5, i9);
        }
        W w9 = (W) concurrentHashMap.putIfAbsent(cls, w6);
        return w9 != null ? w9 : w6;
    }
}
