package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.ads.MG;
import com.google.android.gms.internal.ads.NG;
import com.google.android.gms.internal.consent_sdk.K2;
import com.google.android.gms.internal.consent_sdk.L2;
import com.google.android.gms.internal.mlkit_vision_internal_vkp.F2;
import com.google.android.gms.internal.mlkit_vision_internal_vkp.G2;
import com.google.android.gms.internal.mlkit_vision_text_bundled_common.Y5;
import com.google.android.gms.internal.mlkit_vision_text_bundled_common.Z5;
import java.util.AbstractMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class a0 implements Iterator {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f13348t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f13349u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f13350v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Iterator f13351w;
    public final /* synthetic */ AbstractMap x;

    public /* synthetic */ a0(AbstractMap abstractMap, int i) {
        this.f13348t = i;
        this.x = abstractMap;
        this.f13349u = -1;
    }

    public Iterator a() {
        if (this.f13351w == null) {
            this.f13351w = ((Y) this.x).f13342u.entrySet().iterator();
        }
        return this.f13351w;
    }

    public Iterator b() {
        if (this.f13351w == null) {
            this.f13351w = ((Y5) this.x).f26001v.entrySet().iterator();
        }
        return this.f13351w;
    }

    public Iterator c() {
        switch (this.f13348t) {
            case 1:
                if (this.f13351w == null) {
                    this.f13351w = ((MG) this.x).f16582v.entrySet().iterator();
                }
                break;
            case 2:
                if (this.f13351w == null) {
                    this.f13351w = ((K2) this.x).f24559v.entrySet().iterator();
                }
                break;
            case 3:
                if (this.f13351w == null) {
                    this.f13351w = ((com.google.android.gms.internal.measurement.K2) this.x).f24867v.entrySet().iterator();
                }
                break;
            default:
                if (this.f13351w == null) {
                    this.f13351w = ((F2) this.x).f25337v.entrySet().iterator();
                }
                break;
        }
        return this.f13351w;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        switch (this.f13348t) {
            case 0:
                int i = this.f13349u + 1;
                Y y8 = (Y) this.x;
                if (i >= y8.f13341t.size()) {
                    return !y8.f13342u.isEmpty() && a().hasNext();
                }
                return true;
            case 1:
                int i4 = this.f13349u + 1;
                MG mg = (MG) this.x;
                if (i4 >= mg.f16581u) {
                    return !mg.f16582v.isEmpty() && c().hasNext();
                }
                return true;
            case 2:
                int i9 = this.f13349u + 1;
                K2 k4 = (K2) this.x;
                if (i9 >= k4.f24558u) {
                    return !k4.f24559v.isEmpty() && c().hasNext();
                }
                return true;
            case 3:
                int i10 = this.f13349u + 1;
                com.google.android.gms.internal.measurement.K2 k9 = (com.google.android.gms.internal.measurement.K2) this.x;
                if (i10 >= k9.f24866u) {
                    return !k9.f24867v.isEmpty() && c().hasNext();
                }
                return true;
            case 4:
                int i11 = this.f13349u + 1;
                F2 f4 = (F2) this.x;
                if (i11 >= f4.f25336u) {
                    return !f4.f25337v.isEmpty() && c().hasNext();
                }
                return true;
            default:
                int i12 = this.f13349u + 1;
                Y5 y9 = (Y5) this.x;
                if (i12 >= y9.f26000u) {
                    return !y9.f26001v.isEmpty() && b().hasNext();
                }
                return true;
        }
    }

    @Override // java.util.Iterator
    public final Object next() {
        switch (this.f13348t) {
            case 0:
                this.f13350v = true;
                int i = this.f13349u + 1;
                this.f13349u = i;
                Y y8 = (Y) this.x;
                return i < y8.f13341t.size() ? (Map.Entry) y8.f13341t.get(this.f13349u) : (Map.Entry) a().next();
            case 1:
                this.f13350v = true;
                int i4 = this.f13349u + 1;
                this.f13349u = i4;
                MG mg = (MG) this.x;
                return i4 < mg.f16581u ? (NG) mg.f16580t[i4] : (Map.Entry) c().next();
            case 2:
                this.f13350v = true;
                int i9 = this.f13349u + 1;
                this.f13349u = i9;
                K2 k4 = (K2) this.x;
                return i9 < k4.f24558u ? (L2) k4.f24557t[i9] : (Map.Entry) c().next();
            case 3:
                this.f13350v = true;
                int i10 = this.f13349u + 1;
                this.f13349u = i10;
                com.google.android.gms.internal.measurement.K2 k9 = (com.google.android.gms.internal.measurement.K2) this.x;
                return i10 < k9.f24866u ? (com.google.android.gms.internal.measurement.L2) k9.f24865t[i10] : (Map.Entry) c().next();
            case 4:
                this.f13350v = true;
                int i11 = this.f13349u + 1;
                this.f13349u = i11;
                F2 f4 = (F2) this.x;
                return i11 < f4.f25336u ? (G2) f4.f25335t[i11] : (Map.Entry) c().next();
            default:
                this.f13350v = true;
                int i12 = this.f13349u + 1;
                this.f13349u = i12;
                Y5 y9 = (Y5) this.x;
                return i12 < y9.f26000u ? (Z5) y9.f25999t[i12] : (Map.Entry) b().next();
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        int i = this.f13348t;
        AbstractMap abstractMap = this.x;
        switch (i) {
            case 0:
                Y y8 = (Y) abstractMap;
                if (!this.f13350v) {
                    throw new IllegalStateException("remove() was called before next()");
                }
                this.f13350v = false;
                int i4 = Y.f13340y;
                y8.b();
                if (this.f13349u >= y8.f13341t.size()) {
                    a().remove();
                    return;
                }
                int i9 = this.f13349u;
                this.f13349u = i9 - 1;
                y8.h(i9);
                return;
            case 1:
                if (!this.f13350v) {
                    throw new IllegalStateException("remove() was called before next()");
                }
                this.f13350v = false;
                MG mg = (MG) abstractMap;
                mg.f();
                int i10 = this.f13349u;
                if (i10 >= mg.f16581u) {
                    c().remove();
                    return;
                } else {
                    this.f13349u = i10 - 1;
                    mg.d(i10);
                    return;
                }
            case 2:
                if (!this.f13350v) {
                    throw new IllegalStateException("remove() was called before next()");
                }
                this.f13350v = false;
                K2 k4 = (K2) abstractMap;
                int i11 = K2.f24556z;
                k4.g();
                int i12 = this.f13349u;
                if (i12 >= k4.f24558u) {
                    c().remove();
                    return;
                } else {
                    this.f13349u = i12 - 1;
                    k4.e(i12);
                    return;
                }
            case 3:
                if (!this.f13350v) {
                    throw new IllegalStateException("remove() was called before next()");
                }
                this.f13350v = false;
                com.google.android.gms.internal.measurement.K2 k9 = (com.google.android.gms.internal.measurement.K2) abstractMap;
                k9.f();
                int i13 = this.f13349u;
                if (i13 >= k9.f24866u) {
                    c().remove();
                    return;
                } else {
                    this.f13349u = i13 - 1;
                    k9.d(i13);
                    return;
                }
            case 4:
                F2 f4 = (F2) abstractMap;
                if (!this.f13350v) {
                    throw new IllegalStateException("remove() was called before next()");
                }
                this.f13350v = false;
                int i14 = F2.f25334z;
                f4.g();
                int i15 = this.f13349u;
                if (i15 >= f4.f25336u) {
                    c().remove();
                    return;
                } else {
                    this.f13349u = i15 - 1;
                    f4.e(i15);
                    return;
                }
            default:
                Y5 y9 = (Y5) abstractMap;
                if (!this.f13350v) {
                    throw new IllegalStateException("remove() was called before next()");
                }
                this.f13350v = false;
                int i16 = Y5.f25998z;
                y9.g();
                int i17 = this.f13349u;
                if (i17 >= y9.f26000u) {
                    b().remove();
                    return;
                } else {
                    this.f13349u = i17 - 1;
                    y9.e(i17);
                    return;
                }
        }
    }

    public /* synthetic */ a0(MG mg) {
        this.f13348t = 1;
        Objects.requireNonNull(mg);
        this.x = mg;
        this.f13349u = -1;
    }

    public /* synthetic */ a0(K2 k4) {
        this.f13348t = 2;
        Objects.requireNonNull(k4);
        this.x = k4;
        this.f13349u = -1;
    }

    public /* synthetic */ a0(com.google.android.gms.internal.measurement.K2 k4) {
        this.f13348t = 3;
        Objects.requireNonNull(k4);
        this.x = k4;
        this.f13349u = -1;
    }
}
