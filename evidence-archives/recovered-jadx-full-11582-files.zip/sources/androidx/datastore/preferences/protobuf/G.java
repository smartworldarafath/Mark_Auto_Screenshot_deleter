package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class G {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final F f13301a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f13302b;

    public G(r0 r0Var, r0 r0Var2, L1.h hVar) {
        this.f13301a = new F(r0Var, r0Var2, hVar);
        this.f13302b = hVar;
    }
}
