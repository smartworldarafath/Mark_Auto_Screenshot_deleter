package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class r implements K {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final r f13416b = new r(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f13417a;

    public /* synthetic */ r(int i) {
        this.f13417a = i;
    }

    @Override // androidx.datastore.preferences.protobuf.K
    public final V a(Class cls) {
        switch (this.f13417a) {
            case 0:
                if (!AbstractC1384u.class.isAssignableFrom(cls)) {
                    throw new IllegalArgumentException("Unsupported message type: ".concat(cls.getName()));
                }
                try {
                    return (V) AbstractC1384u.d(cls.asSubclass(AbstractC1384u.class)).c(3);
                } catch (Exception e4) {
                    throw new RuntimeException("Unable to get message info for ".concat(cls.getName()), e4);
                }
            default:
                throw new IllegalStateException("This should never be called.");
        }
    }

    @Override // androidx.datastore.preferences.protobuf.K
    public final boolean b(Class cls) {
        switch (this.f13417a) {
            case 0:
                return AbstractC1384u.class.isAssignableFrom(cls);
            default:
                return false;
        }
    }
}
