package androidx.datastore.preferences.protobuf;

import F4.AbstractC0454t5;
import java.nio.charset.Charset;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class k0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f13402a;

    /* JADX WARN: Code duplicated, block: B:107:0x0064 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:20:0x004a  */
    /* JADX WARN: Code duplicated, block: B:24:0x0057  */
    /* JADX WARN: Code duplicated, block: B:26:0x005b A[LOOP:2: B:23:0x0055->B:26:0x005b, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:31:0x006d  */
    /* JADX WARN: Code duplicated, block: B:44:0x009b  */
    /* JADX WARN: Code duplicated, block: B:61:0x00dd  */
    /* JADX WARN: Code duplicated, block: B:63:0x00f1  */
    /* JADX WARN: Code duplicated, block: B:81:0x0067 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:84:0x0050 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:85:0x0093 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:86:0x008e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:87:0x00d9 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:88:0x00d4 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:93:0x006b A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:97:0x0097 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:98:0x0132 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:99:0x012d A[SYNTHETIC] */
    public final String a(byte[] bArr, int i, int i4) {
        int i9;
        byte b9;
        int i10;
        byte b10;
        byte b11;
        byte b12;
        switch (this.f13402a) {
            case 0:
                if ((i | i4 | ((bArr.length - i) - i4)) < 0) {
                    throw new ArrayIndexOutOfBoundsException(String.format("buffer length=%d, index=%d, size=%d", Integer.valueOf(bArr.length), Integer.valueOf(i), Integer.valueOf(i4)));
                }
                int i11 = i + i4;
                char[] cArr = new char[i4];
                int i12 = 0;
                while (i < i11) {
                    byte b13 = bArr[i];
                    if (b13 < 0) {
                        while (i < i11) {
                            i9 = i + 1;
                            b9 = bArr[i];
                            if (b9 < 0) {
                                i10 = i12 + 1;
                                cArr[i12] = (char) b9;
                                while (i9 < i11) {
                                    b10 = bArr[i9];
                                    if (b10 >= 0) {
                                        i9++;
                                        cArr[i10] = (char) b10;
                                        i10++;
                                    } else {
                                        i12 = i10;
                                        i = i9;
                                    }
                                }
                                i12 = i10;
                                i = i9;
                            } else if (b9 < -32) {
                                if (i9 < i11) {
                                    throw C1388y.a();
                                }
                                i += 2;
                                byte b14 = bArr[i9];
                                int i13 = i12 + 1;
                                if (b9 >= -62 || AbstractC0454t5.a(b14)) {
                                    throw C1388y.a();
                                }
                                cArr[i12] = (char) ((b14 & 63) | ((b9 & 31) << 6));
                                i12 = i13;
                            } else {
                                if (b9 >= -16) {
                                    if (i9 < i11 - 2) {
                                        throw C1388y.a();
                                    }
                                    b12 = bArr[i9];
                                    int i14 = i + 3;
                                    byte b15 = bArr[i + 2];
                                    i += 4;
                                    byte b16 = bArr[i14];
                                    int i15 = i12 + 1;
                                    if (!AbstractC0454t5.a(b12)) {
                                        if ((((b12 + 112) + (b9 << 28)) >> 30) != 0 && !AbstractC0454t5.a(b15) && !AbstractC0454t5.a(b16)) {
                                            int i16 = ((b12 & 63) << 12) | ((b9 & 7) << 18) | ((b15 & 63) << 6) | (b16 & 63);
                                            cArr[i12] = (char) ((i16 >>> 10) + 55232);
                                            cArr[i15] = (char) ((i16 & 1023) + 56320);
                                            i12 += 2;
                                        }
                                    }
                                    throw C1388y.a();
                                }
                                if (i9 < i11 - 1) {
                                    throw C1388y.a();
                                }
                                int i17 = i + 2;
                                b11 = bArr[i9];
                                i += 3;
                                byte b17 = bArr[i17];
                                int i18 = i12 + 1;
                                if (!AbstractC0454t5.a(b11) || ((b9 == -32 && b11 < -96) || ((b9 == -19 && b11 >= -96) || AbstractC0454t5.a(b17)))) {
                                    throw C1388y.a();
                                }
                                cArr[i12] = (char) (((b11 & 63) << 6) | ((b9 & 15) << 12) | (b17 & 63));
                                i12 = i18;
                            }
                        }
                        return new String(cArr, 0, i12);
                    }
                    i++;
                    cArr[i12] = (char) b13;
                    i12++;
                }
                while (i < i11) {
                    i9 = i + 1;
                    b9 = bArr[i];
                    if (b9 < 0) {
                        if (b9 < -32) {
                            if (i9 < i11) {
                                throw C1388y.a();
                            }
                            i += 2;
                            byte b18 = bArr[i9];
                            int i19 = i12 + 1;
                            if (b9 >= -62) {
                            }
                            throw C1388y.a();
                        }
                        if (b9 >= -16) {
                            if (i9 < i11 - 1) {
                                throw C1388y.a();
                            }
                            int i110 = i + 2;
                            b11 = bArr[i9];
                            i += 3;
                            byte b19 = bArr[i110];
                            int i111 = i12 + 1;
                            if (AbstractC0454t5.a(b11)) {
                            }
                            throw C1388y.a();
                        }
                        if (i9 < i11 - 2) {
                            throw C1388y.a();
                        }
                        b12 = bArr[i9];
                        int i112 = i + 3;
                        byte b110 = bArr[i + 2];
                        i += 4;
                        byte b111 = bArr[i112];
                        int i113 = i12 + 1;
                        if (!AbstractC0454t5.a(b12)) {
                            if ((((b12 + 112) + (b9 << 28)) >> 30) != 0) {
                            }
                        }
                        throw C1388y.a();
                    }
                    i10 = i12 + 1;
                    cArr[i12] = (char) b9;
                    while (i9 < i11) {
                        b10 = bArr[i9];
                        if (b10 >= 0) {
                            i9++;
                            cArr[i10] = (char) b10;
                            i10++;
                        } else {
                            i12 = i10;
                            i = i9;
                        }
                    }
                    i12 = i10;
                    i = i9;
                }
                return new String(cArr, 0, i12);
            default:
                Charset charset = AbstractC1386w.f13435a;
                String str = new String(bArr, i, i4, charset);
                if (str.indexOf(65533) >= 0 && !Arrays.equals(str.getBytes(charset), Arrays.copyOfRange(bArr, i, i4 + i))) {
                    throw C1388y.a();
                }
                return str;
        }
    }

    public final int b(String str, byte[] bArr, int i, int i4) {
        int i9;
        int i10;
        char cCharAt;
        long j9;
        char c9;
        long j10;
        long j11;
        char c10;
        int i11;
        char cCharAt2;
        switch (this.f13402a) {
            case 0:
                int length = str.length();
                int i12 = i4 + i;
                int i13 = 0;
                while (i13 < length && (i10 = i13 + i) < i12 && (cCharAt = str.charAt(i13)) < 128) {
                    bArr[i10] = (byte) cCharAt;
                    i13++;
                }
                if (i13 == length) {
                    return i + length;
                }
                int i14 = i + i13;
                while (i13 < length) {
                    char cCharAt3 = str.charAt(i13);
                    if (cCharAt3 < 128 && i14 < i12) {
                        bArr[i14] = (byte) cCharAt3;
                        i14++;
                    } else if (cCharAt3 < 2048 && i14 <= i12 - 2) {
                        int i15 = i14 + 1;
                        bArr[i14] = (byte) ((cCharAt3 >>> 6) | 960);
                        i14 += 2;
                        bArr[i15] = (byte) ((cCharAt3 & '?') | 128);
                    } else {
                        if ((cCharAt3 >= 55296 && 57343 >= cCharAt3) || i14 > i12 - 3) {
                            if (i14 > i12 - 4) {
                                if (55296 <= cCharAt3 && cCharAt3 <= 57343 && ((i9 = i13 + 1) == str.length() || !Character.isSurrogatePair(cCharAt3, str.charAt(i9)))) {
                                    throw new l0(i13, length);
                                }
                                throw new ArrayIndexOutOfBoundsException("Failed writing " + cCharAt3 + " at index " + i14);
                            }
                            int i16 = i13 + 1;
                            if (i16 != str.length()) {
                                char cCharAt4 = str.charAt(i16);
                                if (Character.isSurrogatePair(cCharAt3, cCharAt4)) {
                                    int codePoint = Character.toCodePoint(cCharAt3, cCharAt4);
                                    bArr[i14] = (byte) ((codePoint >>> 18) | 240);
                                    bArr[i14 + 1] = (byte) (((codePoint >>> 12) & 63) | 128);
                                    int i17 = i14 + 3;
                                    bArr[i14 + 2] = (byte) (((codePoint >>> 6) & 63) | 128);
                                    i14 += 4;
                                    bArr[i17] = (byte) ((codePoint & 63) | 128);
                                    i13 = i16;
                                } else {
                                    i13 = i16;
                                }
                            }
                            throw new l0(i13 - 1, length);
                        }
                        bArr[i14] = (byte) ((cCharAt3 >>> '\f') | 480);
                        int i18 = i14 + 2;
                        bArr[i14 + 1] = (byte) (((cCharAt3 >>> 6) & 63) | 128);
                        i14 += 3;
                        bArr[i18] = (byte) ((cCharAt3 & '?') | 128);
                    }
                    i13++;
                }
                return i14;
            default:
                long j12 = i;
                long j13 = ((long) i4) + j12;
                int length2 = str.length();
                if (length2 > i4 || bArr.length - i4 < i) {
                    throw new ArrayIndexOutOfBoundsException("Failed writing " + str.charAt(length2 - 1) + " at index " + (i + i4));
                }
                int i19 = 0;
                while (true) {
                    j9 = 1;
                    c9 = 128;
                    if (i19 < length2 && (cCharAt2 = str.charAt(i19)) < 128) {
                        j0.j(bArr, j12, (byte) cCharAt2);
                        i19++;
                        j12 = 1 + j12;
                    }
                }
                if (i19 == length2) {
                    return (int) j12;
                }
                while (i19 < length2) {
                    char cCharAt5 = str.charAt(i19);
                    if (cCharAt5 < c9 && j12 < j13) {
                        j0.j(bArr, j12, (byte) cCharAt5);
                        c10 = c9;
                        j10 = j9;
                        j11 = j12 + j9;
                    } else if (cCharAt5 >= 2048 || j12 > j13 - 2) {
                        j10 = j9;
                        if ((cCharAt5 >= 55296 && 57343 >= cCharAt5) || j12 > j13 - 3) {
                            long j14 = j12;
                            if (j14 > j13 - 4) {
                                if (55296 <= cCharAt5 && cCharAt5 <= 57343 && ((i11 = i19 + 1) == length2 || !Character.isSurrogatePair(cCharAt5, str.charAt(i11)))) {
                                    throw new l0(i19, length2);
                                }
                                throw new ArrayIndexOutOfBoundsException("Failed writing " + cCharAt5 + " at index " + j14);
                            }
                            int i20 = i19 + 1;
                            if (i20 != length2) {
                                char cCharAt6 = str.charAt(i20);
                                if (Character.isSurrogatePair(cCharAt5, cCharAt6)) {
                                    int codePoint2 = Character.toCodePoint(cCharAt5, cCharAt6);
                                    j0.j(bArr, j14, (byte) ((codePoint2 >>> 18) | 240));
                                    c10 = 128;
                                    j0.j(bArr, j14 + j10, (byte) (((codePoint2 >>> 12) & 63) | 128));
                                    j0.j(bArr, j14 + 2, (byte) (((codePoint2 >>> 6) & 63) | 128));
                                    j0.j(bArr, j14 + 3, (byte) ((codePoint2 & 63) | 128));
                                    j11 = j14 + 4;
                                    i19 = i20;
                                } else {
                                    i19 = i20;
                                }
                            }
                            throw new l0(i19 - 1, length2);
                        }
                        j0.j(bArr, j12, (byte) ((cCharAt5 >>> '\f') | 480));
                        long j15 = j12;
                        j0.j(bArr, j12 + j10, (byte) (((cCharAt5 >>> 6) & 63) | 128));
                        j11 = j15 + 3;
                        j0.j(bArr, j15 + 2, (byte) ((cCharAt5 & '?') | 128));
                        c10 = 128;
                    } else {
                        j10 = j9;
                        j0.j(bArr, j12, (byte) ((cCharAt5 >>> 6) | 960));
                        j0.j(bArr, j12 + j10, (byte) ((cCharAt5 & '?') | c9));
                        j11 = j12 + 2;
                        c10 = c9;
                    }
                    i19++;
                    c9 = c10;
                    j12 = j11;
                    j9 = j10;
                }
                return (int) j12;
        }
    }
}
