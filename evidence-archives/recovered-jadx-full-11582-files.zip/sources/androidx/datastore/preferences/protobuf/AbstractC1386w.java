package androidx.datastore.preferences.protobuf;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1386w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Charset f13435a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final byte[] f13436b;

    static {
        Charset.forName("US-ASCII");
        f13435a = Charset.forName("UTF-8");
        Charset.forName("ISO-8859-1");
        byte[] bArr = new byte[0];
        f13436b = bArr;
        ByteBuffer.wrap(bArr);
        try {
            new C1372h(bArr, 0, 0, false).j(0);
        } catch (C1388y e4) {
            throw new IllegalArgumentException(e4);
        }
    }

    public static void a(Object obj, String str) {
        if (obj == null) {
            throw new NullPointerException(str);
        }
    }

    public static int b(long j9) {
        return (int) (j9 ^ (j9 >>> 32));
    }
}
