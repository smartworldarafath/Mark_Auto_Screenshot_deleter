package androidx.datastore.preferences.protobuf;

import java.util.Collections;
import java.util.Map;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1377m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static volatile C1377m f13404a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C1377m f13405b;

    static {
        C1377m c1377m = new C1377m();
        Map map = Collections.EMPTY_MAP;
        f13405b = c1377m;
    }

    public static C1377m a() {
        C1377m c1377m;
        T t8 = T.f13327c;
        C1377m c1377m2 = f13404a;
        if (c1377m2 != null) {
            return c1377m2;
        }
        synchronized (C1377m.class) {
            try {
                c1377m = f13404a;
                if (c1377m == null) {
                    Class cls = AbstractC1376l.f13403a;
                    C1377m c1377m3 = null;
                    if (cls != null) {
                        try {
                            c1377m3 = (C1377m) cls.getDeclaredMethod("getEmptyRegistry", null).invoke(null, null);
                        } catch (Exception unused) {
                        }
                    }
                    c1377m = c1377m3 != null ? c1377m3 : f13405b;
                    f13404a = c1377m;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return c1377m;
    }
}
