package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.measurement.AbstractC5061q1;

/* JADX INFO: loaded from: classes.dex */
public final class l0 extends IllegalArgumentException {
    public l0(int i, int i4) {
        super(AbstractC5061q1.i(i, i4, "Unpaired surrogate at index ", " of "));
    }
}
