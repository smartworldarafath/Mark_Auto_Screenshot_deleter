package androidx.datastore.preferences.protobuf;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public enum s0 {
    INT(0),
    LONG(0L),
    FLOAT(Float.valueOf(0.0f)),
    DOUBLE(Double.valueOf(0.0d)),
    BOOLEAN(Boolean.FALSE),
    STRING(""),
    BYTE_STRING(C1371g.f13369v),
    ENUM(null),
    MESSAGE(null);


    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final Object f13434t;

    s0(Serializable serializable) {
        this.f13434t = serializable;
    }
}
