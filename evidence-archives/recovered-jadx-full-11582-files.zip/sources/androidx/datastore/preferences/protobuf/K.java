package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public interface K {
    V a(Class cls);

    boolean b(Class cls);
}
