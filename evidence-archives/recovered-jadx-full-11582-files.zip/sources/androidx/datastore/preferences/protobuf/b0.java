package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.ads.MG;
import com.google.android.gms.internal.consent_sdk.K2;
import com.google.android.gms.internal.mlkit_vision_internal_vkp.F2;
import com.google.android.gms.internal.mlkit_vision_text_bundled_common.Y5;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;
import p116p.C5838c;
import p116p.C5840e;

/* JADX INFO: loaded from: classes.dex */
public class b0 extends AbstractSet {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f13353t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Map f13354u;

    public /* synthetic */ b0(int i, Map map) {
        this.f13353t = i;
        this.f13354u = map;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean add(Object obj) {
        switch (this.f13353t) {
            case 0:
                Map.Entry entry = (Map.Entry) obj;
                if (contains(entry)) {
                    return false;
                }
                ((Y) this.f13354u).put((Comparable) entry.getKey(), entry.getValue());
                return true;
            case 1:
                Map.Entry entry2 = (Map.Entry) obj;
                if (contains(entry2)) {
                    return false;
                }
                ((MG) this.f13354u).put((Comparable) entry2.getKey(), entry2.getValue());
                return true;
            case 2:
                Map.Entry entry3 = (Map.Entry) obj;
                if (contains(entry3)) {
                    return false;
                }
                ((K2) this.f13354u).b((Comparable) entry3.getKey(), entry3.getValue());
                return true;
            case 3:
                Map.Entry entry4 = (Map.Entry) obj;
                if (contains(entry4)) {
                    return false;
                }
                ((com.google.android.gms.internal.measurement.K2) this.f13354u).c((Comparable) entry4.getKey(), entry4.getValue());
                return true;
            case 4:
                Map.Entry entry5 = (Map.Entry) obj;
                if (contains(entry5)) {
                    return false;
                }
                ((F2) this.f13354u).b((Comparable) entry5.getKey(), entry5.getValue());
                return true;
            case 5:
                Map.Entry entry6 = (Map.Entry) obj;
                if (contains(entry6)) {
                    return false;
                }
                ((Y5) this.f13354u).b((Comparable) entry6.getKey(), entry6.getValue());
                return true;
            default:
                return super.add(obj);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public void clear() {
        switch (this.f13353t) {
            case 0:
                ((Y) this.f13354u).clear();
                break;
            case 1:
                ((MG) this.f13354u).clear();
                break;
            case 2:
                ((K2) this.f13354u).clear();
                break;
            case 3:
                ((com.google.android.gms.internal.measurement.K2) this.f13354u).clear();
                break;
            case 4:
                ((F2) this.f13354u).clear();
                break;
            case 5:
                ((Y5) this.f13354u).clear();
                break;
            default:
                super.clear();
                break;
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean contains(Object obj) {
        switch (this.f13353t) {
            case 0:
                Map.Entry entry = (Map.Entry) obj;
                Object obj2 = ((Y) this.f13354u).get(entry.getKey());
                Object value = entry.getValue();
                return obj2 == value || (obj2 != null && obj2.equals(value));
            case 1:
                Map.Entry entry2 = (Map.Entry) obj;
                Object obj3 = ((MG) this.f13354u).get(entry2.getKey());
                Object value2 = entry2.getValue();
                if (obj3 != value2) {
                    return obj3 != null && obj3.equals(value2);
                }
                return true;
            case 2:
                Map.Entry entry3 = (Map.Entry) obj;
                Object obj4 = ((K2) this.f13354u).get(entry3.getKey());
                Object value3 = entry3.getValue();
                if (obj4 != value3) {
                    return obj4 != null && obj4.equals(value3);
                }
                return true;
            case 3:
                Map.Entry entry4 = (Map.Entry) obj;
                Object obj5 = ((com.google.android.gms.internal.measurement.K2) this.f13354u).get(entry4.getKey());
                Object value4 = entry4.getValue();
                if (obj5 != value4) {
                    return obj5 != null && obj5.equals(value4);
                }
                return true;
            case 4:
                Map.Entry entry5 = (Map.Entry) obj;
                Object obj6 = ((F2) this.f13354u).get(entry5.getKey());
                Object value5 = entry5.getValue();
                if (obj6 != value5) {
                    return obj6 != null && obj6.equals(value5);
                }
                return true;
            case 5:
                Map.Entry entry6 = (Map.Entry) obj;
                Object obj7 = ((Y5) this.f13354u).get(entry6.getKey());
                Object value6 = entry6.getValue();
                if (obj7 != value6) {
                    return obj7 != null && obj7.equals(value6);
                }
                return true;
            default:
                return super.contains(obj);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
    public Iterator iterator() {
        switch (this.f13353t) {
            case 0:
                return new a0((Y) this.f13354u, 0);
            case 1:
                return new a0((MG) this.f13354u);
            case 2:
                return new a0((K2) this.f13354u);
            case 3:
                return new a0((com.google.android.gms.internal.measurement.K2) this.f13354u);
            case 4:
                return new a0((F2) this.f13354u, 4);
            case 5:
                return new a0((Y5) this.f13354u, 5);
            default:
                return new C5838c((C5840e) this.f13354u);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean remove(Object obj) {
        switch (this.f13353t) {
            case 0:
                Map.Entry entry = (Map.Entry) obj;
                if (!contains(entry)) {
                    return false;
                }
                ((Y) this.f13354u).remove(entry.getKey());
                return true;
            case 1:
                Map.Entry entry2 = (Map.Entry) obj;
                if (!contains(entry2)) {
                    return false;
                }
                ((MG) this.f13354u).remove(entry2.getKey());
                return true;
            case 2:
                Map.Entry entry3 = (Map.Entry) obj;
                if (!contains(entry3)) {
                    return false;
                }
                ((K2) this.f13354u).remove(entry3.getKey());
                return true;
            case 3:
                Map.Entry entry4 = (Map.Entry) obj;
                if (!contains(entry4)) {
                    return false;
                }
                ((com.google.android.gms.internal.measurement.K2) this.f13354u).remove(entry4.getKey());
                return true;
            case 4:
                Map.Entry entry5 = (Map.Entry) obj;
                if (!contains(entry5)) {
                    return false;
                }
                ((F2) this.f13354u).remove(entry5.getKey());
                return true;
            case 5:
                Map.Entry entry6 = (Map.Entry) obj;
                if (!contains(entry6)) {
                    return false;
                }
                ((Y5) this.f13354u).remove(entry6.getKey());
                return true;
            default:
                return super.remove(obj);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final int size() {
        switch (this.f13353t) {
            case 0:
                return ((Y) this.f13354u).size();
            case 1:
                return ((MG) this.f13354u).size();
            case 2:
                return ((K2) this.f13354u).size();
            case 3:
                return ((com.google.android.gms.internal.measurement.K2) this.f13354u).size();
            case 4:
                return ((F2) this.f13354u).size();
            case 5:
                return ((Y5) this.f13354u).size();
            default:
                return ((C5840e) this.f13354u).f29969v;
        }
    }
}
