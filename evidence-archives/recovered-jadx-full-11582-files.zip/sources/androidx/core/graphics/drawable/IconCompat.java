package androidx.core.graphics.drawable;

import A1.AbstractC0030f;
import A1.AbstractC0031g;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: classes.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final PorterDuff.Mode f13255k = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f13256a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f13257b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public byte[] f13258c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Parcelable f13259d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f13260e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f13261f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f13262g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f13263h;
    public String i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f13264j;

    public IconCompat() {
        this.f13256a = -1;
        this.f13258c = null;
        this.f13259d = null;
        this.f13260e = 0;
        this.f13261f = 0;
        this.f13262g = null;
        this.f13263h = f13255k;
        this.i = null;
    }

    public static IconCompat a(int i) {
        if (i == 0) {
            throw new IllegalArgumentException("Drawable resource ID must not be 0");
        }
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.f13260e = i;
        iconCompat.f13257b = "";
        iconCompat.f13264j = "";
        return iconCompat;
    }

    public final int b() {
        int i = this.f13256a;
        if (i != -1) {
            if (i == 2) {
                return this.f13260e;
            }
            throw new IllegalStateException("called getResId() on " + this);
        }
        int i4 = Build.VERSION.SDK_INT;
        Object obj = this.f13257b;
        if (i4 >= 28) {
            return AbstractC0030f.f(obj);
        }
        try {
            return ((Integer) obj.getClass().getMethod("getResId", null).invoke(obj, null)).intValue();
        } catch (IllegalAccessException e4) {
            Log.e("IconCompat", "Unable to get icon resource", e4);
            return 0;
        } catch (NoSuchMethodException e9) {
            Log.e("IconCompat", "Unable to get icon resource", e9);
            return 0;
        } catch (InvocationTargetException e10) {
            Log.e("IconCompat", "Unable to get icon resource", e10);
            return 0;
        }
    }

    public final int c() {
        int i = this.f13256a;
        if (i != -1) {
            return i;
        }
        int i4 = Build.VERSION.SDK_INT;
        Object obj = this.f13257b;
        if (i4 >= 28) {
            return AbstractC0030f.m(obj);
        }
        try {
            return ((Integer) obj.getClass().getMethod("getType", null).invoke(obj, null)).intValue();
        } catch (IllegalAccessException e4) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e4);
            return -1;
        } catch (NoSuchMethodException e9) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e9);
            return -1;
        } catch (InvocationTargetException e10) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e10);
            return -1;
        }
    }

    public final Uri d() {
        int i = this.f13256a;
        if (i != -1) {
            if (i == 4 || i == 6) {
                return Uri.parse((String) this.f13257b);
            }
            throw new IllegalStateException("called getUri() on " + this);
        }
        int i4 = Build.VERSION.SDK_INT;
        Object obj = this.f13257b;
        if (i4 >= 28) {
            return AbstractC0030f.n(obj);
        }
        try {
            return (Uri) obj.getClass().getMethod("getUri", null).invoke(obj, null);
        } catch (IllegalAccessException e4) {
            Log.e("IconCompat", "Unable to get icon uri", e4);
            return null;
        } catch (NoSuchMethodException e9) {
            Log.e("IconCompat", "Unable to get icon uri", e9);
            return null;
        } catch (InvocationTargetException e10) {
            Log.e("IconCompat", "Unable to get icon uri", e10);
            return null;
        }
    }

    public final Icon e(Context context) {
        Icon iconCreateWithBitmap;
        int i = Build.VERSION.SDK_INT;
        int i4 = this.f13256a;
        String strG = null;
        inputStreamOpenInputStream = null;
        InputStream inputStreamOpenInputStream = null;
        strG = null;
        strG = null;
        switch (i4) {
            case -1:
                return (Icon) this.f13257b;
            case 0:
            default:
                throw new IllegalArgumentException("Unknown type");
            case 1:
                iconCreateWithBitmap = Icon.createWithBitmap((Bitmap) this.f13257b);
                break;
            case 2:
                if (i4 == -1) {
                    Object obj = this.f13257b;
                    if (i >= 28) {
                        strG = AbstractC0030f.g(obj);
                    } else {
                        try {
                            strG = (String) obj.getClass().getMethod("getResPackage", null).invoke(obj, null);
                        } catch (IllegalAccessException e4) {
                            Log.e("IconCompat", "Unable to get icon package", e4);
                        } catch (NoSuchMethodException e9) {
                            Log.e("IconCompat", "Unable to get icon package", e9);
                        } catch (InvocationTargetException e10) {
                            Log.e("IconCompat", "Unable to get icon package", e10);
                        }
                    }
                } else {
                    if (i4 != 2) {
                        throw new IllegalStateException("called getResPackage() on " + this);
                    }
                    String str = this.f13264j;
                    strG = (str == null || TextUtils.isEmpty(str)) ? ((String) this.f13257b).split(":", -1)[0] : this.f13264j;
                }
                iconCreateWithBitmap = Icon.createWithResource(strG, this.f13260e);
                break;
            case 3:
                iconCreateWithBitmap = Icon.createWithData((byte[]) this.f13257b, this.f13260e, this.f13261f);
                break;
            case 4:
                iconCreateWithBitmap = Icon.createWithContentUri((String) this.f13257b);
                break;
            case 5:
                iconCreateWithBitmap = Icon.createWithAdaptiveBitmap((Bitmap) this.f13257b);
                break;
            case 6:
                if (i >= 30) {
                    iconCreateWithBitmap = AbstractC0031g.a(d());
                } else {
                    if (context == null) {
                        throw new IllegalArgumentException("Context is required to resolve the file uri of the icon: " + d());
                    }
                    Uri uriD = d();
                    String scheme = uriD.getScheme();
                    if ("content".equals(scheme) || "file".equals(scheme)) {
                        try {
                            inputStreamOpenInputStream = context.getContentResolver().openInputStream(uriD);
                        } catch (Exception e11) {
                            Log.w("IconCompat", "Unable to load image from URI: " + uriD, e11);
                        }
                        break;
                    } else {
                        try {
                            inputStreamOpenInputStream = new FileInputStream(new File((String) this.f13257b));
                        } catch (FileNotFoundException e12) {
                            Log.w("IconCompat", "Unable to load image from path: " + uriD, e12);
                        }
                    }
                    if (inputStreamOpenInputStream == null) {
                        throw new IllegalStateException("Cannot load adaptive icon from uri: " + d());
                    }
                    iconCreateWithBitmap = Icon.createWithAdaptiveBitmap(BitmapFactory.decodeStream(inputStreamOpenInputStream));
                }
                break;
        }
        ColorStateList colorStateList = this.f13262g;
        if (colorStateList != null) {
            iconCreateWithBitmap.setTintList(colorStateList);
        }
        PorterDuff.Mode mode = this.f13263h;
        if (mode != f13255k) {
            iconCreateWithBitmap.setTintMode(mode);
        }
        return iconCreateWithBitmap;
    }

    public final String toString() {
        String str;
        if (this.f13256a == -1) {
            return String.valueOf(this.f13257b);
        }
        StringBuilder sb = new StringBuilder("Icon(typ=");
        switch (this.f13256a) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case 3:
                str = "DATA";
                break;
            case 4:
                str = "URI";
                break;
            case 5:
                str = "BITMAP_MASKABLE";
                break;
            case 6:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        sb.append(str);
        switch (this.f13256a) {
            case 1:
            case 5:
                sb.append(" size=");
                sb.append(((Bitmap) this.f13257b).getWidth());
                sb.append("x");
                sb.append(((Bitmap) this.f13257b).getHeight());
                break;
            case 2:
                sb.append(" pkg=");
                sb.append(this.f13264j);
                sb.append(" id=");
                sb.append(String.format("0x%08x", Integer.valueOf(b())));
                break;
            case 3:
                sb.append(" len=");
                sb.append(this.f13260e);
                if (this.f13261f != 0) {
                    sb.append(" off=");
                    sb.append(this.f13261f);
                }
                break;
            case 4:
            case 6:
                sb.append(" uri=");
                sb.append(this.f13257b);
                break;
        }
        if (this.f13262g != null) {
            sb.append(" tint=");
            sb.append(this.f13262g);
        }
        if (this.f13263h != f13255k) {
            sb.append(" mode=");
            sb.append(this.f13263h);
        }
        sb.append(")");
        return sb.toString();
    }

    public IconCompat(int i) {
        this.f13258c = null;
        this.f13259d = null;
        this.f13260e = 0;
        this.f13261f = 0;
        this.f13262g = null;
        this.f13263h = f13255k;
        this.i = null;
        this.f13256a = i;
    }
}
