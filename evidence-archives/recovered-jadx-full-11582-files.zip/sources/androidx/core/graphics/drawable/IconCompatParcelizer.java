package androidx.core.graphics.drawable;

import D2.b;
import D2.c;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;

/* JADX INFO: loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(b bVar) {
        IconCompat iconCompat = new IconCompat();
        int i = iconCompat.f13256a;
        if (bVar.e(1)) {
            i = ((c) bVar).f990e.readInt();
        }
        iconCompat.f13256a = i;
        byte[] bArr = iconCompat.f13258c;
        if (bVar.e(2)) {
            Parcel parcel = ((c) bVar).f990e;
            int i4 = parcel.readInt();
            if (i4 < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[i4];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f13258c = bArr;
        iconCompat.f13259d = bVar.f(iconCompat.f13259d, 3);
        int i9 = iconCompat.f13260e;
        if (bVar.e(4)) {
            i9 = ((c) bVar).f990e.readInt();
        }
        iconCompat.f13260e = i9;
        int i10 = iconCompat.f13261f;
        if (bVar.e(5)) {
            i10 = ((c) bVar).f990e.readInt();
        }
        iconCompat.f13261f = i10;
        iconCompat.f13262g = (ColorStateList) bVar.f(iconCompat.f13262g, 6);
        String string = iconCompat.i;
        if (bVar.e(7)) {
            string = ((c) bVar).f990e.readString();
        }
        iconCompat.i = string;
        String string2 = iconCompat.f13264j;
        if (bVar.e(8)) {
            string2 = ((c) bVar).f990e.readString();
        }
        iconCompat.f13264j = string2;
        iconCompat.f13263h = PorterDuff.Mode.valueOf(iconCompat.i);
        switch (iconCompat.f13256a) {
            case -1:
                Parcelable parcelable = iconCompat.f13259d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.f13257b = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f13259d;
                if (parcelable2 != null) {
                    iconCompat.f13257b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.f13258c;
                iconCompat.f13257b = bArr3;
                iconCompat.f13256a = 3;
                iconCompat.f13260e = 0;
                iconCompat.f13261f = bArr3.length;
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str = new String(iconCompat.f13258c, Charset.forName("UTF-16"));
                iconCompat.f13257b = str;
                if (iconCompat.f13256a == 2 && iconCompat.f13264j == null) {
                    iconCompat.f13264j = str.split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.f13257b = iconCompat.f13258c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, b bVar) {
        bVar.getClass();
        iconCompat.i = iconCompat.f13263h.name();
        switch (iconCompat.f13256a) {
            case -1:
                iconCompat.f13259d = (Parcelable) iconCompat.f13257b;
                break;
            case 1:
            case 5:
                iconCompat.f13259d = (Parcelable) iconCompat.f13257b;
                break;
            case 2:
                iconCompat.f13258c = ((String) iconCompat.f13257b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f13258c = (byte[]) iconCompat.f13257b;
                break;
            case 4:
            case 6:
                iconCompat.f13258c = iconCompat.f13257b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i = iconCompat.f13256a;
        if (-1 != i) {
            bVar.h(1);
            ((c) bVar).f990e.writeInt(i);
        }
        byte[] bArr = iconCompat.f13258c;
        if (bArr != null) {
            bVar.h(2);
            Parcel parcel = ((c) bVar).f990e;
            parcel.writeInt(bArr.length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f13259d;
        if (parcelable != null) {
            bVar.h(3);
            ((c) bVar).f990e.writeParcelable(parcelable, 0);
        }
        int i4 = iconCompat.f13260e;
        if (i4 != 0) {
            bVar.h(4);
            ((c) bVar).f990e.writeInt(i4);
        }
        int i9 = iconCompat.f13261f;
        if (i9 != 0) {
            bVar.h(5);
            ((c) bVar).f990e.writeInt(i9);
        }
        ColorStateList colorStateList = iconCompat.f13262g;
        if (colorStateList != null) {
            bVar.h(6);
            ((c) bVar).f990e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.i;
        if (str != null) {
            bVar.h(7);
            ((c) bVar).f990e.writeString(str);
        }
        String str2 = iconCompat.f13264j;
        if (str2 != null) {
            bVar.h(8);
            ((c) bVar).f990e.writeString(str2);
        }
    }
}
