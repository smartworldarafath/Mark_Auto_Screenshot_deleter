package androidx.core.app;

import D2.b;
import D2.c;
import D2.d;
import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;

/* JADX INFO: loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(b bVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        d dVarG = remoteActionCompat.f13244a;
        boolean z8 = true;
        if (bVar.e(1)) {
            dVarG = bVar.g();
        }
        remoteActionCompat.f13244a = (IconCompat) dVarG;
        CharSequence charSequence = remoteActionCompat.f13245b;
        if (bVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((c) bVar).f990e);
        }
        remoteActionCompat.f13245b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f13246c;
        if (bVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((c) bVar).f990e);
        }
        remoteActionCompat.f13246c = charSequence2;
        remoteActionCompat.f13247d = (PendingIntent) bVar.f(remoteActionCompat.f13247d, 4);
        boolean z9 = remoteActionCompat.f13248e;
        if (bVar.e(5)) {
            z9 = ((c) bVar).f990e.readInt() != 0;
        }
        remoteActionCompat.f13248e = z9;
        boolean z10 = remoteActionCompat.f13249f;
        if (!bVar.e(6)) {
            z8 = z10;
        } else if (((c) bVar).f990e.readInt() == 0) {
            z8 = false;
        }
        remoteActionCompat.f13249f = z8;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, b bVar) {
        bVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f13244a;
        bVar.h(1);
        bVar.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.f13245b;
        bVar.h(2);
        Parcel parcel = ((c) bVar).f990e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f13246c;
        bVar.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f13247d;
        bVar.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z8 = remoteActionCompat.f13248e;
        bVar.h(5);
        parcel.writeInt(z8 ? 1 : 0);
        boolean z9 = remoteActionCompat.f13249f;
        bVar.h(6);
        parcel.writeInt(z9 ? 1 : 0);
    }
}
