package androidx.core.app;

import D2.d;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* JADX INFO: loaded from: classes.dex */
public final class RemoteActionCompat implements d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IconCompat f13244a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public CharSequence f13245b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f13246c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public PendingIntent f13247d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f13248e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f13249f;
}
