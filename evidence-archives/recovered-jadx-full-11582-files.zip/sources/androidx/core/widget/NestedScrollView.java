package androidx.core.widget;

import A1.AbstractC0047x;
import A1.AbstractC0048y;
import A1.C0028d;
import A1.C0033i;
import A1.C0034j;
import A1.C0037m;
import A1.C0049z;
import A1.D;
import A1.InterfaceC0035k;
import A1.InterfaceC0036l;
import A1.J;
import A1.r;
import C1.a;
import E1.c;
import E1.e;
import E1.f;
import E1.g;
import E4.B2;
import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import com.facebook.ads.AdError;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public class NestedScrollView extends FrameLayout implements InterfaceC0036l {
    public static final float V = (float) (Math.log(0.78d) / Math.log(0.9d));

    /* JADX INFO: renamed from: W, reason: collision with root package name */
    public static final e f13265W = new e();

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public static final int[] f13266a0 = {R.attr.fillViewport};

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f13267A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public boolean f13268B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public boolean f13269C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public View f13270D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public boolean f13271E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public VelocityTracker f13272F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public boolean f13273G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public boolean f13274H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final int f13275I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final int f13276J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final int f13277K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public int f13278L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public final int[] f13279M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public final int[] f13280N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public int f13281O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public int f13282P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public g f13283Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public final C0037m f13284R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public final C0034j f13285S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public float f13286T;
    public final C0028d U;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final float f13287t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public long f13288u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Rect f13289v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final OverScroller f13290w;
    public final EdgeEffect x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final EdgeEffect f13291y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public r f13292z;

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, com.markOne.ss_app.R.attr.nestedScrollViewStyle);
        this.f13289v = new Rect();
        this.f13268B = true;
        this.f13269C = false;
        this.f13270D = null;
        this.f13271E = false;
        this.f13274H = true;
        this.f13278L = -1;
        this.f13279M = new int[2];
        this.f13280N = new int[2];
        this.U = new C0028d(getContext(), new C0033i(5, this));
        int i = Build.VERSION.SDK_INT;
        this.x = i >= 31 ? c.a(context, attributeSet) : new EdgeEffect(context);
        this.f13291y = i >= 31 ? c.a(context, attributeSet) : new EdgeEffect(context);
        this.f13287t = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.f13290w = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f13275I = viewConfiguration.getScaledTouchSlop();
        this.f13276J = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f13277K = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f13266a0, com.markOne.ss_app.R.attr.nestedScrollViewStyle, 0);
        setFillViewport(typedArrayObtainStyledAttributes.getBoolean(0, false));
        typedArrayObtainStyledAttributes.recycle();
        this.f13284R = new C0037m();
        C0034j c0034j = new C0034j();
        c0034j.f264d = this;
        this.f13285S = c0034j;
        setNestedScrollingEnabled(true);
        J.d(this, f13265W);
    }

    private r getScrollFeedbackProvider() {
        if (this.f13292z == null) {
            this.f13292z = new r(this);
        }
        return this.f13292z;
    }

    public static boolean k(View view, NestedScrollView nestedScrollView) {
        if (view == nestedScrollView) {
            return true;
        }
        Object parent = view.getParent();
        return (parent instanceof ViewGroup) && k((View) parent, nestedScrollView);
    }

    public final boolean a(int i) {
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
        }
        View view = viewFindFocus;
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, view, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (viewFindNextFocus == null || !l(viewFindNextFocus, maxScrollAmount, getHeight())) {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            r(maxScrollAmount, -1, null, 0, 1, true);
        } else {
            Rect rect = this.f13289v;
            viewFindNextFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(viewFindNextFocus, rect);
            r(c(rect), -1, null, 0, 1, true);
            viewFindNextFocus.requestFocus(i);
        }
        if (view != null && view.isFocused() && !l(view, 0, getHeight())) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view);
    }

    @Override // A1.InterfaceC0035k
    public final void b(NestedScrollView nestedScrollView, int i, int i4, int i9, int i10, int i11) {
        m(i10, i11, null);
    }

    public final int c(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i4 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i - verticalFadingEdgeLength : i;
        int i9 = rect.bottom;
        if (i9 > i4 && rect.top > scrollY) {
            return Math.min(rect.height() > height ? rect.top - scrollY : rect.bottom - i4, (childAt.getBottom() + layoutParams.bottomMargin) - i);
        }
        if (rect.top >= scrollY || i9 >= i4) {
            return 0;
        }
        return Math.max(rect.height() > height ? 0 - (i4 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0087  */
    /* JADX WARN: Code duplicated, block: B:24:0x0096  */
    /* JADX WARN: Code duplicated, block: B:26:0x00bb  */
    /* JADX WARN: Code duplicated, block: B:30:0x00c5 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:31:0x00c7  */
    /* JADX WARN: Code duplicated, block: B:33:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:34:0x00d8  */
    /* JADX WARN: Code duplicated, block: B:36:0x00de  */
    /* JADX WARN: Code duplicated, block: B:40:0x00f8  */
    /* JADX WARN: Code duplicated, block: B:42:0x00fc  */
    @Override // android.view.View
    public final void computeScroll() {
        int iRound;
        int[] iArr;
        int i;
        int scrollRange;
        int overScrollMode;
        if (this.f13290w.isFinished()) {
            return;
        }
        this.f13290w.computeScrollOffset();
        int currY = this.f13290w.getCurrY();
        int i4 = currY - this.f13282P;
        int height = getHeight();
        EdgeEffect edgeEffect = this.x;
        EdgeEffect edgeEffect2 = this.f13291y;
        if (i4 <= 0 || B2.a(edgeEffect) == 0.0f) {
            if (i4 < 0 && B2.a(edgeEffect2) != 0.0f) {
                float f4 = height;
                iRound = Math.round(B2.b(edgeEffect2, (i4 * 4.0f) / f4, 0.5f) * (f4 / 4.0f));
                if (iRound != i4) {
                    edgeEffect2.finish();
                }
            }
            int i9 = i4;
            this.f13282P = currY;
            iArr = this.f13280N;
            iArr[1] = 0;
            this.f13285S.c(0, i9, 1, iArr, null);
            i = i9 - iArr[1];
            scrollRange = getScrollRange();
            if (Build.VERSION.SDK_INT >= 35) {
                a.a(this, Math.abs(this.f13290w.getCurrVelocity()));
            }
            if (i != 0) {
                int scrollY = getScrollY();
                o(i, getScrollX(), scrollY, scrollRange);
                int scrollY2 = getScrollY() - scrollY;
                int i10 = i - scrollY2;
                iArr[1] = 0;
                this.f13285S.d(0, scrollY2, 0, i10, this.f13279M, 1, iArr);
                i = i10 - iArr[1];
            }
            if (i != 0) {
                overScrollMode = getOverScrollMode();
                if (overScrollMode != 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    if (i < 0) {
                        if (edgeEffect.isFinished()) {
                            edgeEffect.onAbsorb((int) this.f13290w.getCurrVelocity());
                        }
                    } else if (edgeEffect2.isFinished()) {
                        edgeEffect2.onAbsorb((int) this.f13290w.getCurrVelocity());
                    }
                }
                this.f13290w.abortAnimation();
                w(1);
            }
            if (this.f13290w.isFinished()) {
                w(1);
            } else {
                postInvalidateOnAnimation();
            }
        }
        iRound = Math.round(B2.b(edgeEffect, ((-i4) * 4.0f) / height, 0.5f) * ((-height) / 4.0f));
        if (iRound != i4) {
            edgeEffect.finish();
        }
        i4 -= iRound;
        int i11 = i4;
        this.f13282P = currY;
        iArr = this.f13280N;
        iArr[1] = 0;
        this.f13285S.c(0, i11, 1, iArr, null);
        i = i11 - iArr[1];
        scrollRange = getScrollRange();
        if (Build.VERSION.SDK_INT >= 35) {
            a.a(this, Math.abs(this.f13290w.getCurrVelocity()));
        }
        if (i != 0) {
            int scrollY3 = getScrollY();
            o(i, getScrollX(), scrollY3, scrollRange);
            int scrollY4 = getScrollY() - scrollY3;
            int i12 = i - scrollY4;
            iArr[1] = 0;
            this.f13285S.d(0, scrollY4, 0, i12, this.f13279M, 1, iArr);
            i = i12 - iArr[1];
        }
        if (i != 0) {
            overScrollMode = getOverScrollMode();
            if (overScrollMode != 0) {
                if (i < 0) {
                    if (edgeEffect.isFinished()) {
                        edgeEffect.onAbsorb((int) this.f13290w.getCurrVelocity());
                    }
                } else if (edgeEffect2.isFinished()) {
                    edgeEffect2.onAbsorb((int) this.f13290w.getCurrVelocity());
                }
            } else if (i < 0) {
                if (edgeEffect.isFinished()) {
                    edgeEffect.onAbsorb((int) this.f13290w.getCurrVelocity());
                }
            } else if (edgeEffect2.isFinished()) {
                edgeEffect2.onAbsorb((int) this.f13290w.getCurrVelocity());
            }
            this.f13290w.abortAnimation();
            w(1);
        }
        if (this.f13290w.isFinished()) {
            postInvalidateOnAnimation();
        } else {
            w(1);
        }
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int iMax = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        return scrollY > iMax ? (scrollY - iMax) + bottom : bottom;
    }

    public final void d(int i) {
        if (getChildCount() > 0) {
            this.f13290w.fling(getScrollX(), getScrollY(), 0, i, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            u(2, 1);
            this.f13282P = getScrollY();
            postInvalidateOnAnimation();
            if (Build.VERSION.SDK_INT >= 35) {
                a.a(this, Math.abs(this.f13290w.getCurrVelocity()));
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:26:0x0065  */
    /* JADX WARN: Code duplicated, block: B:42:0x00a1  */
    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        boolean zJ;
        if (!super.dispatchKeyEvent(keyEvent)) {
            this.f13289v.setEmpty();
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                    if (keyEvent.getAction() != 0) {
                        zJ = false;
                    } else {
                        int keyCode = keyEvent.getKeyCode();
                        if (keyCode == 19) {
                            zJ = keyEvent.isAltPressed() ? j(33) : a(33);
                        } else if (keyCode != 20) {
                            if (keyCode == 62) {
                                p(keyEvent.isShiftPressed() ? 33 : 130);
                            } else if (keyCode == 92) {
                                zJ = j(33);
                            } else if (keyCode == 93) {
                                zJ = j(130);
                            } else if (keyCode == 122) {
                                p(33);
                            } else if (keyCode == 123) {
                                p(130);
                            }
                            zJ = false;
                        } else {
                            zJ = keyEvent.isAltPressed() ? j(130) : a(130);
                        }
                    }
                } else if (isFocused() || keyEvent.getKeyCode() == 4) {
                    zJ = false;
                } else {
                    View viewFindFocus = findFocus();
                    if (viewFindFocus == this) {
                        viewFindFocus = null;
                    }
                    View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
                    if (viewFindNextFocus == null || viewFindNextFocus == this || !viewFindNextFocus.requestFocus(130)) {
                        zJ = false;
                    } else {
                        zJ = true;
                    }
                }
            } else if (isFocused()) {
                zJ = false;
            } else {
                zJ = false;
            }
            if (!zJ) {
                return false;
            }
        }
        return true;
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f4, float f9, boolean z8) {
        ViewParent viewParentF;
        C0034j c0034j = this.f13285S;
        if (c0034j.f261a && (viewParentF = c0034j.f(0)) != null) {
            try {
                return viewParentF.onNestedFling((NestedScrollView) c0034j.f264d, f4, f9, z8);
            } catch (AbstractMethodError e4) {
                Log.e("ViewParentCompat", "ViewParent " + viewParentF + " does not implement interface method onNestedFling", e4);
            }
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f4, float f9) {
        return this.f13285S.b(f4, f9);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i4, int[] iArr, int[] iArr2) {
        return this.f13285S.c(i, i4, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i4, int i9, int i10, int[] iArr) {
        return this.f13285S.d(i, i4, i9, i10, iArr, 0, null);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int paddingLeft;
        super.draw(canvas);
        int scrollY = getScrollY();
        EdgeEffect edgeEffect = this.x;
        int paddingLeft2 = 0;
        if (!edgeEffect.isFinished()) {
            int iSave = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int iMin = Math.min(0, scrollY);
            if (getClipToPadding()) {
                width -= getPaddingRight() + getPaddingLeft();
                paddingLeft = getPaddingLeft();
            } else {
                paddingLeft = 0;
            }
            if (getClipToPadding()) {
                height -= getPaddingBottom() + getPaddingTop();
                iMin += getPaddingTop();
            }
            canvas.translate(paddingLeft, iMin);
            edgeEffect.setSize(width, height);
            if (edgeEffect.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect2 = this.f13291y;
        if (edgeEffect2.isFinished()) {
            return;
        }
        int iSave2 = canvas.save();
        int width2 = getWidth();
        int height2 = getHeight();
        int iMax = Math.max(getScrollRange(), scrollY) + height2;
        if (getClipToPadding()) {
            width2 -= getPaddingRight() + getPaddingLeft();
            paddingLeft2 = getPaddingLeft();
        }
        if (getClipToPadding()) {
            height2 -= getPaddingBottom() + getPaddingTop();
            iMax -= getPaddingBottom();
        }
        canvas.translate(paddingLeft2 - width2, iMax);
        canvas.rotate(180.0f, width2, 0.0f);
        edgeEffect2.setSize(width2, height2);
        if (edgeEffect2.draw(canvas)) {
            postInvalidateOnAnimation();
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // A1.InterfaceC0035k
    public final boolean e(View view, View view2, int i, int i4) {
        return (i & 2) != 0;
    }

    @Override // A1.InterfaceC0035k
    public final void f(View view, View view2, int i, int i4) {
        C0037m c0037m = this.f13284R;
        if (i4 == 1) {
            c0037m.f270b = i;
        } else {
            c0037m.f269a = i;
        }
        u(2, i4);
    }

    @Override // A1.InterfaceC0035k
    public final void g(View view, int i) {
        C0037m c0037m = this.f13284R;
        if (i == 1) {
            c0037m.f270b = 0;
        } else {
            c0037m.f269a = 0;
        }
        w(i);
    }

    @Override // android.view.View
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (getHeight() * 0.5f);
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0037m c0037m = this.f13284R;
        return c0037m.f270b | c0037m.f269a;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    @Override // android.view.View
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public float getVerticalScrollFactorCompat() {
        if (this.f13286T == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
            this.f13286T = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.f13286T;
    }

    @Override // A1.InterfaceC0036l
    public final void h(NestedScrollView nestedScrollView, int i, int i4, int i9, int i10, int i11, int[] iArr) {
        m(i10, i11, iArr);
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.f13285S.f(0) != null;
    }

    @Override // A1.InterfaceC0035k
    public final void i(int i, int i4, int[] iArr, int i9) {
        this.f13285S.c(i, i4, i9, iArr, null);
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.f13285S.f261a;
    }

    public final boolean j(int i) {
        int childCount;
        boolean z8 = i == 130;
        int height = getHeight();
        Rect rect = this.f13289v;
        rect.top = 0;
        rect.bottom = height;
        if (z8 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            rect.bottom = paddingBottom;
            rect.top = paddingBottom - height;
        }
        return q(i, rect.top, rect.bottom);
    }

    public final boolean l(View view, int i, int i4) {
        Rect rect = this.f13289v;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        return rect.bottom + i >= getScrollY() && rect.top - i <= getScrollY() + i4;
    }

    public final void m(int i, int i4, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f13285S.d(0, scrollY2, 0, i - scrollY2, null, i4, iArr);
    }

    @Override // android.view.ViewGroup
    public final void measureChild(View view, int i, int i4) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    @Override // android.view.ViewGroup
    public final void measureChildWithMargins(View view, int i, int i4, int i9, int i10) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i4, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void n(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f13278L) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f13267A = (int) motionEvent.getY(i);
            this.f13278L = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.f13272F;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    public final boolean o(int i, int i4, int i9, int i10) {
        int i11;
        boolean z8;
        int i12;
        boolean z9;
        getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        int i13 = i9 + i;
        if (i4 <= 0 && i4 >= 0) {
            i11 = i4;
            z8 = false;
        } else {
            i11 = 0;
            z8 = true;
        }
        if (i13 <= i10) {
            if (i13 < 0) {
                i12 = 0;
            } else {
                i12 = i13;
                z9 = false;
            }
            if (z9 && this.f13285S.f(1) == null) {
                this.f13290w.springBack(i11, i12, 0, 0, 0, getScrollRange());
            }
            super.scrollTo(i11, i12);
            return !z8 || z9;
        }
        i12 = i10;
        z9 = true;
        if (z9) {
            this.f13290w.springBack(i11, i12, 0, 0, 0, getScrollRange());
        }
        super.scrollTo(i11, i12);
        if (z8) {
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f13269C = false;
    }

    /* JADX WARN: Code duplicated, block: B:102:0x01d0  */
    /* JADX WARN: Code duplicated, block: B:49:0x00db  */
    /* JADX WARN: Code duplicated, block: B:70:0x0126  */
    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f4;
        int i;
        int width;
        int i4;
        int scaledMinimumFlingVelocity;
        int scaledMaximumFlingVelocity;
        boolean z8;
        NestedScrollView nestedScrollView;
        float yVelocity;
        NestedScrollView nestedScrollView2;
        float f9;
        long j9;
        float fSqrt;
        int i9;
        if (motionEvent.getAction() != 8 || this.f13271E) {
            return false;
        }
        if ((motionEvent.getSource() & 2) == 2) {
            float axisValue = motionEvent.getAxisValue(9);
            width = (int) motionEvent.getX();
            i = 9;
            f4 = axisValue;
        } else if ((motionEvent.getSource() & 4194304) == 4194304) {
            float axisValue2 = motionEvent.getAxisValue(26);
            width = getWidth() / 2;
            f4 = axisValue2;
            i = 26;
        } else {
            f4 = 0.0f;
            i = 0;
            width = 0;
        }
        if (f4 == 0.0f) {
            return false;
        }
        r(-((int) (getVerticalScrollFactorCompat() * f4)), i, motionEvent, width, 1, (motionEvent.getSource() & 8194) == 8194);
        if (i != 0) {
            C0028d c0028d = this.U;
            NestedScrollView nestedScrollView3 = (NestedScrollView) c0028d.f234b.f259u;
            int[] iArr = c0028d.f240h;
            int source = motionEvent.getSource();
            int deviceId = motionEvent.getDeviceId();
            int i10 = 1;
            if (c0028d.f238f == source && c0028d.f239g == deviceId && c0028d.f237e == i) {
                z8 = false;
                i4 = 0;
            } else {
                Context context = c0028d.f233a;
                ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
                int deviceId2 = motionEvent.getDeviceId();
                i4 = 0;
                int source2 = motionEvent.getSource();
                int i11 = Build.VERSION.SDK_INT;
                if (i11 >= 34) {
                    scaledMinimumFlingVelocity = AbstractC0047x.f(viewConfiguration, deviceId2, i, source2);
                } else {
                    InputDevice device = InputDevice.getDevice(deviceId2);
                    if (device == null || device.getMotionRange(i, source2) == null) {
                        scaledMinimumFlingVelocity = Integer.MAX_VALUE;
                    } else {
                        Resources resources = context.getResources();
                        int identifier = (source2 == 4194304 && i == 26) ? resources.getIdentifier("config_viewMinRotaryEncoderFlingVelocity", "dimen", "android") : -1;
                        Objects.requireNonNull(viewConfiguration);
                        if (identifier == -1) {
                            scaledMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
                        } else if (identifier == 0 || (scaledMinimumFlingVelocity = resources.getDimensionPixelSize(identifier)) < 0) {
                            scaledMinimumFlingVelocity = Integer.MAX_VALUE;
                        }
                    }
                }
                iArr[0] = scaledMinimumFlingVelocity;
                int deviceId3 = motionEvent.getDeviceId();
                int source3 = motionEvent.getSource();
                if (i11 >= 34) {
                    scaledMaximumFlingVelocity = AbstractC0047x.e(viewConfiguration, deviceId3, i, source3);
                } else {
                    InputDevice device2 = InputDevice.getDevice(deviceId3);
                    if (device2 == null || device2.getMotionRange(i, source3) == null) {
                        scaledMaximumFlingVelocity = Integer.MIN_VALUE;
                    } else {
                        Resources resources2 = context.getResources();
                        int identifier2 = (source3 == 4194304 && i == 26) ? resources2.getIdentifier("config_viewMaxRotaryEncoderFlingVelocity", "dimen", "android") : -1;
                        Objects.requireNonNull(viewConfiguration);
                        if (identifier2 == -1) {
                            scaledMaximumFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
                        } else if (identifier2 == 0 || (scaledMaximumFlingVelocity = resources2.getDimensionPixelSize(identifier2)) < 0) {
                            scaledMaximumFlingVelocity = Integer.MIN_VALUE;
                        }
                    }
                }
                iArr[1] = scaledMaximumFlingVelocity;
                c0028d.f238f = source;
                c0028d.f239g = deviceId;
                c0028d.f237e = i;
                z8 = true;
            }
            if (iArr[i4] == Integer.MAX_VALUE) {
                VelocityTracker velocityTracker = c0028d.f235c;
                if (velocityTracker == null) {
                    return true;
                }
                velocityTracker.recycle();
                c0028d.f235c = null;
                return true;
            }
            if (c0028d.f235c == null) {
                c0028d.f235c = VelocityTracker.obtain();
            }
            VelocityTracker velocityTracker2 = c0028d.f235c;
            Map map = AbstractC0048y.f286a;
            velocityTracker2.addMovement(motionEvent);
            int i12 = 20;
            if (Build.VERSION.SDK_INT < 34 && motionEvent.getSource() == 4194304) {
                Map map2 = AbstractC0048y.f286a;
                if (!map2.containsKey(velocityTracker2)) {
                    map2.put(velocityTracker2, new C0049z());
                }
                C0049z c0049z = (C0049z) map2.get(velocityTracker2);
                long[] jArr = c0049z.f288b;
                long eventTime = motionEvent.getEventTime();
                if (c0049z.f290d != 0 && eventTime - jArr[c0049z.f291e] > 40) {
                    c0049z.f290d = i4;
                    c0049z.f289c = 0.0f;
                }
                int i13 = (c0049z.f291e + 1) % 20;
                c0049z.f291e = i13;
                int i14 = c0049z.f290d;
                if (i14 != 20) {
                    c0049z.f290d = i14 + 1;
                }
                c0049z.f287a[i13] = motionEvent.getAxisValue(26);
                jArr[c0049z.f291e] = eventTime;
            }
            velocityTracker2.computeCurrentVelocity(AdError.NETWORK_ERROR_CODE, Float.MAX_VALUE);
            C0049z c0049z2 = (C0049z) AbstractC0048y.f286a.get(velocityTracker2);
            if (c0049z2 != null) {
                float[] fArr = c0049z2.f287a;
                long[] jArr2 = c0049z2.f288b;
                int i15 = c0049z2.f290d;
                if (i15 < 2) {
                    nestedScrollView = nestedScrollView3;
                    i9 = 1000;
                    fSqrt = 0.0f;
                } else {
                    int i16 = c0049z2.f291e;
                    int i17 = ((i16 + 20) - (i15 - 1)) % 20;
                    long j10 = jArr2[i16];
                    while (true) {
                        j9 = jArr2[i17];
                        if (j10 - j9 <= 100) {
                            break;
                        }
                        c0049z2.f290d--;
                        i17 = (i17 + 1) % 20;
                    }
                    int i18 = c0049z2.f290d;
                    if (i18 < 2) {
                        nestedScrollView = nestedScrollView3;
                        i9 = 1000;
                        fSqrt = 0.0f;
                    } else if (i18 == 2) {
                        int i19 = (i17 + 1) % 20;
                        long j11 = jArr2[i19];
                        if (j9 == j11) {
                            nestedScrollView = nestedScrollView3;
                            i9 = 1000;
                            fSqrt = 0.0f;
                        } else {
                            nestedScrollView = nestedScrollView3;
                            i9 = 1000;
                            fSqrt = fArr[i19] / (j11 - j9);
                        }
                    } else {
                        float f10 = 0.0f;
                        int i20 = 0;
                        int i21 = 0;
                        while (true) {
                            if (i20 >= c0049z2.f290d - 1) {
                                break;
                            }
                            int i22 = i20 + i17;
                            long j12 = jArr2[i22 % 20];
                            int i23 = (i22 + 1) % i12;
                            if (jArr2[i23] != j12) {
                                i21++;
                                float fSqrt2 = (f10 < 0.0f ? -1.0f : 1.0f) * ((float) Math.sqrt(Math.abs(f10) * 2.0f));
                                float f11 = fArr[i23] / (jArr2[i23] - j12);
                                float fAbs = (Math.abs(f11) * (f11 - fSqrt2)) + f10;
                                if (i21 == i10) {
                                    fAbs *= 0.5f;
                                }
                                f10 = fAbs;
                            }
                            i20++;
                            nestedScrollView3 = nestedScrollView3;
                            i12 = 20;
                            i10 = 1;
                        }
                        nestedScrollView = nestedScrollView3;
                        fSqrt = ((float) Math.sqrt(Math.abs(f10) * 2.0f)) * (f10 < 0.0f ? -1.0f : 1.0f);
                        i9 = AdError.NETWORK_ERROR_CODE;
                    }
                }
                float f12 = fSqrt * i9;
                c0049z2.f289c = f12;
                if (f12 < (-Math.abs((float) r6))) {
                    c0049z2.f289c = -Math.abs(Float.MAX_VALUE);
                } else if (c0049z2.f289c > Math.abs((float) r6)) {
                    c0049z2.f289c = Math.abs((float) r6);
                }
            } else {
                nestedScrollView = nestedScrollView3;
            }
            if (Build.VERSION.SDK_INT >= 34) {
                yVelocity = AbstractC0047x.b(velocityTracker2, i);
            } else if (i == 0) {
                yVelocity = velocityTracker2.getXVelocity();
            } else if (i == 1) {
                yVelocity = velocityTracker2.getYVelocity();
            } else {
                C0049z c0049z3 = (C0049z) AbstractC0048y.f286a.get(velocityTracker2);
                yVelocity = (c0049z3 == null || i != 26) ? 0.0f : c0049z3.f289c;
            }
            float f13 = yVelocity * (-nestedScrollView.getVerticalScrollFactorCompat());
            float fSignum = Math.signum(f13);
            if (z8 || !(fSignum == Math.signum(c0028d.f236d) || fSignum == 0.0f)) {
                nestedScrollView2 = nestedScrollView;
                nestedScrollView2.f13290w.abortAnimation();
            } else {
                nestedScrollView2 = nestedScrollView;
            }
            if (Math.abs(f13) >= iArr[0]) {
                int i24 = iArr[1];
                float fMax = Math.max(-i24, Math.min(f13, i24));
                if (fMax == 0.0f) {
                    f9 = 0.0f;
                } else {
                    nestedScrollView2.f13290w.abortAnimation();
                    nestedScrollView2.d((int) fMax);
                    f9 = fMax;
                }
                c0028d.f236d = f9;
                return true;
            }
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0083  */
    /* JADX WARN: Code duplicated, block: B:36:0x008b  */
    /* JADX WARN: Code duplicated, block: B:39:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:62:0x0117  */
    /* JADX WARN: Code duplicated, block: B:70:0x012d  */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        VelocityTracker velocityTracker;
        VelocityTracker velocityTracker2;
        int action = motionEvent.getAction();
        boolean z8 = true;
        if (action == 2 && this.f13271E) {
            return true;
        }
        int i = action & 255;
        if (i == 0) {
            int y8 = (int) motionEvent.getY();
            int x = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y8 < childAt.getTop() - scrollY || y8 >= childAt.getBottom() - scrollY || x < childAt.getLeft() || x >= childAt.getRight()) {
                    if (!v(motionEvent) && this.f13290w.isFinished()) {
                        z8 = false;
                    }
                    this.f13271E = z8;
                    velocityTracker = this.f13272F;
                    if (velocityTracker != null) {
                        velocityTracker.recycle();
                        this.f13272F = null;
                    }
                } else {
                    this.f13267A = y8;
                    this.f13278L = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker3 = this.f13272F;
                    if (velocityTracker3 == null) {
                        this.f13272F = VelocityTracker.obtain();
                    } else {
                        velocityTracker3.clear();
                    }
                    this.f13272F.addMovement(motionEvent);
                    this.f13290w.computeScrollOffset();
                    if (!v(motionEvent) && this.f13290w.isFinished()) {
                        z8 = false;
                    }
                    this.f13271E = z8;
                    u(2, 0);
                }
            } else {
                if (!v(motionEvent)) {
                    z8 = false;
                }
                this.f13271E = z8;
                velocityTracker = this.f13272F;
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    this.f13272F = null;
                }
            }
        } else if (i == 1) {
            this.f13271E = false;
            this.f13278L = -1;
            velocityTracker2 = this.f13272F;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f13272F = null;
            }
            if (this.f13290w.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i == 2) {
            int i4 = this.f13278L;
            if (i4 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i4);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + i4 + " in onInterceptTouchEvent");
                } else {
                    int y9 = (int) motionEvent.getY(iFindPointerIndex);
                    if (Math.abs(y9 - this.f13267A) > this.f13275I && (2 & getNestedScrollAxes()) == 0) {
                        this.f13271E = true;
                        this.f13267A = y9;
                        if (this.f13272F == null) {
                            this.f13272F = VelocityTracker.obtain();
                        }
                        this.f13272F.addMovement(motionEvent);
                        this.f13281O = 0;
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
            }
        } else if (i == 3) {
            this.f13271E = false;
            this.f13278L = -1;
            velocityTracker2 = this.f13272F;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f13272F = null;
            }
            if (this.f13290w.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i == 6) {
            n(motionEvent);
        }
        return this.f13271E;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z8, int i, int i4, int i9, int i10) {
        int measuredHeight;
        super.onLayout(z8, i, i4, i9, i10);
        int i11 = 0;
        this.f13268B = false;
        View view = this.f13270D;
        if (view != null && k(view, this)) {
            View view2 = this.f13270D;
            Rect rect = this.f13289v;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iC = c(rect);
            if (iC != 0) {
                scrollBy(0, iC);
            }
        }
        this.f13270D = null;
        if (!this.f13269C) {
            if (this.f13283Q != null) {
                scrollTo(getScrollX(), this.f13283Q.f1491t);
                this.f13283Q = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                measuredHeight = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                measuredHeight = 0;
            }
            int paddingTop = ((i10 - i4) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < measuredHeight && scrollY >= 0) {
                i11 = paddingTop + scrollY > measuredHeight ? measuredHeight - paddingTop : scrollY;
            }
            if (i11 != scrollY) {
                scrollTo(getScrollX(), i11);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f13269C = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i4) {
        super.onMeasure(i, i4);
        if (this.f13273G && View.MeasureSpec.getMode(i4) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f4, float f9, boolean z8) {
        if (z8) {
            return false;
        }
        dispatchNestedFling(0.0f, f9, true);
        d((int) f9);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f4, float f9) {
        return this.f13285S.b(f4, f9);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i4, int[] iArr) {
        this.f13285S.c(i, i4, 0, iArr, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i4, int i9, int i10) {
        m(i10, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        f(view, view2, i, 0);
    }

    @Override // android.view.View
    public final void onOverScrolled(int i, int i4, boolean z8, boolean z9) {
        super.scrollTo(i, i4);
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        View viewFindNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i);
        if (viewFindNextFocus != null && l(viewFindNextFocus, 0, getHeight())) {
            return viewFindNextFocus.requestFocus(i, rect);
        }
        return false;
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.getSuperState());
        this.f13283Q = gVar;
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        g gVar = new g(super.onSaveInstanceState());
        gVar.f1491t = getScrollY();
        return gVar;
    }

    @Override // android.view.View
    public final void onScrollChanged(int i, int i4, int i9, int i10) {
        super.onScrollChanged(i, i4, i9, i10);
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i4, int i9, int i10) {
        super.onSizeChanged(i, i4, i9, i10);
        View viewFindFocus = findFocus();
        if (viewFindFocus == null || this == viewFindFocus || !l(viewFindFocus, 0, i10)) {
            return;
        }
        Rect rect = this.f13289v;
        viewFindFocus.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(viewFindFocus, rect);
        int iC = c(rect);
        if (iC != 0) {
            if (this.f13274H) {
                t(0, iC, false);
            } else {
                scrollBy(0, iC);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        return e(view, view2, i, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        g(view, 0);
    }

    /* JADX WARN: Code duplicated, block: B:49:0x011f  */
    /* JADX WARN: Code duplicated, block: B:56:0x0135  */
    /* JADX WARN: Code duplicated, block: B:59:0x013c  */
    /* JADX WARN: Code duplicated, block: B:60:0x0140  */
    /* JADX WARN: Code duplicated, block: B:63:0x0147  */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        float fB;
        int iRound;
        int i;
        ViewParent parent2;
        if (this.f13272F == null) {
            this.f13272F = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f13281O = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        float f4 = 0.0f;
        motionEventObtain.offsetLocation(0.0f, this.f13281O);
        if (actionMasked != 0) {
            EdgeEffect edgeEffect = this.x;
            EdgeEffect edgeEffect2 = this.f13291y;
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.f13272F;
                velocityTracker.computeCurrentVelocity(AdError.NETWORK_ERROR_CODE, this.f13277K);
                int yVelocity = (int) velocityTracker.getYVelocity(this.f13278L);
                if (Math.abs(yVelocity) >= this.f13276J) {
                    if (B2.a(edgeEffect) != 0.0f) {
                        if (s(edgeEffect, yVelocity)) {
                            edgeEffect.onAbsorb(yVelocity);
                        } else {
                            d(-yVelocity);
                        }
                    } else if (B2.a(edgeEffect2) != 0.0f) {
                        int i4 = -yVelocity;
                        if (s(edgeEffect2, i4)) {
                            edgeEffect2.onAbsorb(i4);
                        } else {
                            d(i4);
                        }
                    } else {
                        int i9 = -yVelocity;
                        float f9 = i9;
                        if (!this.f13285S.b(0.0f, f9)) {
                            dispatchNestedFling(0.0f, f9, true);
                            d(i9);
                        }
                    }
                } else if (this.f13290w.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.f13278L = -1;
                this.f13271E = false;
                VelocityTracker velocityTracker2 = this.f13272F;
                if (velocityTracker2 != null) {
                    velocityTracker2.recycle();
                    this.f13272F = null;
                }
                w(0);
                this.x.onRelease();
                this.f13291y.onRelease();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f13278L);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.f13278L + " in onTouchEvent");
                } else {
                    int y8 = (int) motionEvent.getY(iFindPointerIndex);
                    int i10 = this.f13267A - y8;
                    float x = motionEvent.getX(iFindPointerIndex) / getWidth();
                    float height = i10 / getHeight();
                    if (B2.a(edgeEffect) != 0.0f) {
                        fB = -B2.b(edgeEffect, -height, x);
                        if (B2.a(edgeEffect) == 0.0f) {
                            edgeEffect.onRelease();
                        }
                    } else if (B2.a(edgeEffect2) != 0.0f) {
                        fB = B2.b(edgeEffect2, height, 1.0f - x);
                        if (B2.a(edgeEffect2) == 0.0f) {
                            edgeEffect2.onRelease();
                        }
                    } else {
                        iRound = Math.round(f4 * getHeight());
                        if (iRound != 0) {
                            invalidate();
                        }
                        i = i10 - iRound;
                        if (!this.f13271E && Math.abs(i) > this.f13275I) {
                            parent2 = getParent();
                            if (parent2 != null) {
                                parent2.requestDisallowInterceptTouchEvent(true);
                            }
                            this.f13271E = true;
                            if (i > 0) {
                                i -= this.f13275I;
                            } else {
                                i += this.f13275I;
                            }
                        }
                        if (this.f13271E) {
                            int iR = r(i, 1, motionEvent, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                            this.f13267A = y8 - iR;
                            this.f13281O += iR;
                        }
                    }
                    f4 = fB;
                    iRound = Math.round(f4 * getHeight());
                    if (iRound != 0) {
                        invalidate();
                    }
                    i = i10 - iRound;
                    if (!this.f13271E) {
                        parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.f13271E = true;
                        if (i > 0) {
                            i -= this.f13275I;
                        } else {
                            i += this.f13275I;
                        }
                    }
                    if (this.f13271E) {
                        int iR2 = r(i, 1, motionEvent, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                        this.f13267A = y8 - iR2;
                        this.f13281O += iR2;
                    }
                }
            } else if (actionMasked == 3) {
                if (this.f13271E && getChildCount() > 0) {
                    if (this.f13290w.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                        postInvalidateOnAnimation();
                    }
                }
                this.f13278L = -1;
                this.f13271E = false;
                VelocityTracker velocityTracker3 = this.f13272F;
                if (velocityTracker3 != null) {
                    velocityTracker3.recycle();
                    this.f13272F = null;
                }
                w(0);
                this.x.onRelease();
                this.f13291y.onRelease();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                this.f13267A = (int) motionEvent.getY(actionIndex);
                this.f13278L = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                n(motionEvent);
                this.f13267A = (int) motionEvent.getY(motionEvent.findPointerIndex(this.f13278L));
            }
        } else {
            if (getChildCount() == 0) {
                return false;
            }
            if (this.f13271E && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.f13290w.isFinished()) {
                this.f13290w.abortAnimation();
                w(1);
            }
            int y9 = (int) motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            this.f13267A = y9;
            this.f13278L = pointerId;
            u(2, 0);
        }
        VelocityTracker velocityTracker4 = this.f13272F;
        if (velocityTracker4 != null) {
            velocityTracker4.addMovement(motionEventObtain);
        }
        motionEventObtain.recycle();
        return true;
    }

    public final void p(int i) {
        boolean z8 = i == 130;
        int height = getHeight();
        Rect rect = this.f13289v;
        if (z8) {
            rect.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
                if (rect.top + height > paddingBottom) {
                    rect.top = paddingBottom - height;
                }
            }
        } else {
            int scrollY = getScrollY() - height;
            rect.top = scrollY;
            if (scrollY < 0) {
                rect.top = 0;
            }
        }
        int i4 = rect.top;
        int i9 = height + i4;
        rect.bottom = i9;
        q(i, i4, i9);
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0068  */
    public final boolean q(int i, int i4, int i9) {
        boolean z8;
        int height = getHeight();
        int scrollY = getScrollY();
        int i10 = height + scrollY;
        boolean z9 = i == 33;
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z10 = false;
        for (int i11 = 0; i11 < size; i11++) {
            View view2 = focusables.get(i11);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i4 < bottom && top < i9) {
                boolean z11 = i4 < top && bottom < i9;
                if (view == null) {
                    view = view2;
                    z10 = z11;
                } else {
                    boolean z12 = (z9 && top < view.getTop()) || (!z9 && bottom > view.getBottom());
                    if (z10) {
                        if (z11 && z12) {
                            view = view2;
                        }
                    } else if (z11) {
                        view = view2;
                        z10 = true;
                    } else if (z12) {
                        view = view2;
                    }
                }
            }
        }
        View view3 = view == null ? this : view;
        if (i4 < scrollY || i9 > i10) {
            r(z9 ? i4 - scrollY : i9 - i10, -1, null, 0, 1, true);
            z8 = true;
        } else {
            z8 = false;
        }
        if (view3 != findFocus()) {
            view3.requestFocus(i);
        }
        return z8;
    }

    /* JADX WARN: Code duplicated, block: B:53:0x0116  */
    /* JADX WARN: Code duplicated, block: B:60:0x0127  */
    public final int r(int i, int i4, MotionEvent motionEvent, int i9, int i10, boolean z8) {
        int i11;
        int i12;
        boolean z9;
        boolean z10;
        VelocityTracker velocityTracker;
        if (i10 == 1) {
            u(2, i10);
        }
        boolean zC = this.f13285S.c(0, i, i10, this.f13280N, this.f13279M);
        int[] iArr = this.f13279M;
        int[] iArr2 = this.f13280N;
        if (zC) {
            i11 = i - iArr2[1];
            i12 = iArr[1];
        } else {
            i11 = i;
            i12 = 0;
        }
        int scrollY = getScrollY();
        int scrollRange = getScrollRange();
        int overScrollMode = getOverScrollMode();
        boolean z11 = (overScrollMode == 0 || (overScrollMode == 1 && getScrollRange() > 0)) && !z8;
        boolean z12 = o(i11, 0, scrollY, scrollRange) && this.f13285S.f(i10) == null;
        int scrollY2 = getScrollY() - scrollY;
        if (motionEvent != null && scrollY2 != 0) {
            getScrollFeedbackProvider().f277a.onScrollProgress(motionEvent.getDeviceId(), motionEvent.getSource(), i4, scrollY2);
        }
        iArr2[1] = 0;
        this.f13285S.d(0, scrollY2, 0, i11 - scrollY2, this.f13279M, i10, iArr2);
        int i13 = i12 + iArr[1];
        int i14 = i11 - iArr2[1];
        int i15 = scrollY + i14;
        EdgeEffect edgeEffect = this.f13291y;
        EdgeEffect edgeEffect2 = this.x;
        if (i15 >= 0) {
            if (i15 > scrollRange && z11) {
                B2.b(edgeEffect, i14 / getHeight(), 1.0f - (i9 / getWidth()));
                if (motionEvent != null) {
                    z9 = false;
                    getScrollFeedbackProvider().f277a.onScrollLimit(motionEvent.getDeviceId(), motionEvent.getSource(), i4, false);
                } else {
                    z9 = false;
                }
                if (!edgeEffect2.isFinished()) {
                    edgeEffect2.onRelease();
                }
            }
            if (edgeEffect2.isFinished() || !edgeEffect.isFinished()) {
                postInvalidateOnAnimation();
                z10 = z9;
            } else {
                z10 = z12;
            }
            if (z10 && i10 == 0 && (velocityTracker = this.f13272F) != null) {
                velocityTracker.clear();
            }
            if (i10 == 1) {
                w(i10);
                edgeEffect2.onRelease();
                edgeEffect.onRelease();
            }
            return i13;
        }
        if (z11) {
            B2.b(edgeEffect2, (-i14) / getHeight(), i9 / getWidth());
            if (motionEvent != null) {
                getScrollFeedbackProvider().f277a.onScrollLimit(motionEvent.getDeviceId(), motionEvent.getSource(), i4, true);
            }
            if (!edgeEffect.isFinished()) {
                edgeEffect.onRelease();
            }
        }
        z9 = false;
        if (edgeEffect2.isFinished()) {
            postInvalidateOnAnimation();
            z10 = z9;
        } else {
            postInvalidateOnAnimation();
            z10 = z9;
        }
        if (z10) {
            velocityTracker.clear();
        }
        if (i10 == 1) {
            w(i10);
            edgeEffect2.onRelease();
            edgeEffect.onRelease();
        }
        return i13;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        if (this.f13268B) {
            this.f13270D = view2;
        } else {
            Rect rect = this.f13289v;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iC = c(rect);
            if (iC != 0) {
                scrollBy(0, iC);
            }
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z8) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int iC = c(rect);
        boolean z9 = iC != 0;
        if (z9) {
            if (z8) {
                scrollBy(0, iC);
                return z9;
            }
            t(0, iC, false);
        }
        return z9;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z8) {
        VelocityTracker velocityTracker;
        if (z8 && (velocityTracker = this.f13272F) != null) {
            velocityTracker.recycle();
            this.f13272F = null;
        }
        super.requestDisallowInterceptTouchEvent(z8);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.f13268B = true;
        super.requestLayout();
    }

    public final boolean s(EdgeEffect edgeEffect, int i) {
        if (i > 0) {
            return true;
        }
        float fA = B2.a(edgeEffect) * getHeight();
        float fAbs = Math.abs(-i) * 0.35f;
        float f4 = this.f13287t * 0.015f;
        double dLog = Math.log(fAbs / f4);
        double d2 = V;
        return ((float) (Math.exp((d2 / (d2 - 1.0d)) * dLog) * ((double) f4))) < fA;
    }

    @Override // android.view.View
    public final void scrollTo(int i, int i4) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width >= width2 || i < 0) {
                i = 0;
            } else if (width + i > width2) {
                i = width2 - width;
            }
            if (height >= height2 || i4 < 0) {
                i4 = 0;
            } else if (height + i4 > height2) {
                i4 = height2 - height;
            }
            if (i == getScrollX() && i4 == getScrollY()) {
                return;
            }
            super.scrollTo(i, i4);
        }
    }

    public void setFillViewport(boolean z8) {
        if (z8 != this.f13273G) {
            this.f13273G = z8;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z8) {
        C0034j c0034j = this.f13285S;
        if (c0034j.f261a) {
            NestedScrollView nestedScrollView = (NestedScrollView) c0034j.f264d;
            Field field = J.f187a;
            D.h(nestedScrollView);
        }
        c0034j.f261a = z8;
    }

    public void setOnScrollChangeListener(f fVar) {
    }

    public void setSmoothScrollingEnabled(boolean z8) {
        this.f13274H = z8;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        return u(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        w(0);
    }

    public final void t(int i, int i4, boolean z8) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.f13288u > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int iMax = Math.max(0, Math.min(i4 + scrollY, Math.max(0, height - height2))) - scrollY;
            this.f13290w.startScroll(getScrollX(), scrollY, 0, iMax, 250);
            if (z8) {
                u(2, 1);
            } else {
                w(1);
            }
            this.f13282P = getScrollY();
            postInvalidateOnAnimation();
        } else {
            if (!this.f13290w.isFinished()) {
                this.f13290w.abortAnimation();
                w(1);
            }
            scrollBy(i, i4);
        }
        this.f13288u = AnimationUtils.currentAnimationTimeMillis();
    }

    public final boolean u(int i, int i4) {
        boolean zOnStartNestedScroll;
        C0034j c0034j = this.f13285S;
        View view = (NestedScrollView) c0034j.f264d;
        if (c0034j.f(i4) != null) {
            return true;
        }
        if (c0034j.f261a) {
            View view2 = view;
            for (ViewParent parent = view.getParent(); parent != null; parent = parent.getParent()) {
                boolean z8 = parent instanceof InterfaceC0035k;
                if (z8) {
                    zOnStartNestedScroll = ((InterfaceC0035k) parent).e(view2, view, i, i4);
                } else if (i4 == 0) {
                    try {
                        zOnStartNestedScroll = parent.onStartNestedScroll(view2, view, i);
                    } catch (AbstractMethodError e4) {
                        Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface method onStartNestedScroll", e4);
                        zOnStartNestedScroll = false;
                    }
                } else {
                    zOnStartNestedScroll = false;
                }
                if (zOnStartNestedScroll) {
                    if (i4 == 0) {
                        c0034j.f262b = parent;
                    } else if (i4 == 1) {
                        c0034j.f263c = parent;
                    }
                    if (z8) {
                        ((InterfaceC0035k) parent).f(view2, view, i, i4);
                        return true;
                    }
                    if (i4 != 0) {
                        return true;
                    }
                    try {
                        parent.onNestedScrollAccepted(view2, view, i);
                        return true;
                    } catch (AbstractMethodError e9) {
                        Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface method onNestedScrollAccepted", e9);
                        return true;
                    }
                }
                if (parent instanceof View) {
                    view2 = (View) parent;
                }
            }
        }
        return false;
    }

    public final boolean v(MotionEvent motionEvent) {
        boolean z8;
        EdgeEffect edgeEffect = this.x;
        if (B2.a(edgeEffect) != 0.0f) {
            B2.b(edgeEffect, 0.0f, motionEvent.getX() / getWidth());
            z8 = true;
        } else {
            z8 = false;
        }
        EdgeEffect edgeEffect2 = this.f13291y;
        if (B2.a(edgeEffect2) == 0.0f) {
            return z8;
        }
        B2.b(edgeEffect2, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
        return true;
    }

    public final void w(int i) {
        C0034j c0034j = this.f13285S;
        ViewParent viewParentF = c0034j.f(i);
        if (viewParentF != null) {
            NestedScrollView nestedScrollView = (NestedScrollView) c0034j.f264d;
            if (viewParentF instanceof InterfaceC0035k) {
                ((InterfaceC0035k) viewParentF).g(nestedScrollView, i);
            } else if (i == 0) {
                try {
                    viewParentF.onStopNestedScroll(nestedScrollView);
                } catch (AbstractMethodError e4) {
                    Log.e("ViewParentCompat", "ViewParent " + viewParentF + " does not implement interface method onStopNestedScroll", e4);
                }
            }
            if (i == 0) {
                c0034j.f262b = null;
            } else {
                if (i != 1) {
                    return;
                }
                c0034j.f263c = null;
            }
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i) {
        if (getChildCount() <= 0) {
            super.addView(view, i);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }
}
