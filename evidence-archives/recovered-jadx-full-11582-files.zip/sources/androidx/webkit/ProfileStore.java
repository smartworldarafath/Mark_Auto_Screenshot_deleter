package androidx.webkit;

import E2.a;
import F2.h;
import F2.l;
import F2.m;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public interface ProfileStore {
    static ProfileStore getInstance() {
        if (!l.f2089f.b()) {
            throw l.a();
        }
        if (h.f2079b == null) {
            h.f2079b = new h(m.f2092a.getProfileStore());
        }
        return h.f2079b;
    }

    boolean deleteProfile(String str);

    List<String> getAllProfileNames();

    a getOrCreateProfile(String str);

    a getProfile(String str);
}
