package androidx.work.impl.background.systemalarm;

import J2.c;

/* JADX INFO: loaded from: classes.dex */
public class ConstraintProxy$BatteryChargingProxy extends c {
}
