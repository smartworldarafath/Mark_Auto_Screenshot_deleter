package androidx.work.impl.background.systemalarm;

import G2.x;
import H2.s;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* JADX INFO: loaded from: classes.dex */
public class RescheduleReceiver extends BroadcastReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String f13585a = x.g("RescheduleReceiver");

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        x.e().a(f13585a, "Received intent " + intent);
        try {
            s sVarF = s.f(context);
            BroadcastReceiver.PendingResult pendingResultGoAsync = goAsync();
            synchronized (s.f3427m) {
                try {
                    BroadcastReceiver.PendingResult pendingResult = sVarF.i;
                    if (pendingResult != null) {
                        pendingResult.finish();
                    }
                    sVarF.i = pendingResultGoAsync;
                    if (sVarF.f3435h) {
                        pendingResultGoAsync.finish();
                        sVarF.i = null;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        } catch (IllegalStateException e4) {
            x.e().d(f13585a, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", e4);
        }
    }
}
