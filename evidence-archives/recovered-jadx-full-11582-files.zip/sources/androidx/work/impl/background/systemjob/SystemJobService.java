package androidx.work.impl.background.systemjob;

import A1.AbstractC0030f;
import A4.f;
import G2.C0511h;
import G2.x;
import H2.C0549e;
import H2.InterfaceC0546b;
import H2.k;
import H2.s;
import P2.c;
import P2.j;
import R2.a;
import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build;
import android.os.Looper;
import android.os.PersistableBundle;
import java.util.Arrays;
import java.util.HashMap;
import p127q3.h;

/* JADX INFO: loaded from: classes.dex */
public class SystemJobService extends JobService implements InterfaceC0546b {
    public static final String x = x.g("SystemJobService");

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public s f13589t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final HashMap f13590u = new HashMap();

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final C0511h f13591v = new C0511h(1);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public c f13592w;

    public static void a(String str) {
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException(h.i("Cannot invoke ", str, " on a background thread"));
        }
    }

    public static j b(JobParameters jobParameters) {
        try {
            PersistableBundle extras = jobParameters.getExtras();
            if (extras == null || !extras.containsKey("EXTRA_WORK_SPEC_ID")) {
                return null;
            }
            return new j(extras.getString("EXTRA_WORK_SPEC_ID"), extras.getInt("EXTRA_WORK_SPEC_GENERATION"));
        } catch (NullPointerException unused) {
            return null;
        }
    }

    @Override // H2.InterfaceC0546b
    public final void e(j jVar, boolean z8) {
        a("onExecuted");
        x.e().a(x, jVar.f8231a + " executed on JobScheduler");
        JobParameters jobParameters = (JobParameters) this.f13590u.remove(jVar);
        this.f13591v.d(jVar);
        if (jobParameters != null) {
            jobFinished(jobParameters, z8);
        }
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        try {
            s sVarF = s.f(getApplicationContext());
            this.f13589t = sVarF;
            C0549e c0549e = sVarF.f3433f;
            this.f13592w = new c(c0549e, sVarF.f3431d);
            c0549e.a(this);
        } catch (IllegalStateException e4) {
            if (!Application.class.equals(getApplication().getClass())) {
                throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", e4);
            }
            x.e().h(x, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.");
        }
    }

    @Override // android.app.Service
    public final void onDestroy() {
        super.onDestroy();
        s sVar = this.f13589t;
        if (sVar != null) {
            sVar.f3433f.f(this);
        }
    }

    @Override // android.app.job.JobService
    public final boolean onStartJob(JobParameters jobParameters) {
        a("onStartJob");
        s sVar = this.f13589t;
        String str = x;
        if (sVar == null) {
            x.e().a(str, "WorkManager is not initialized; requesting retry.");
            jobFinished(jobParameters, true);
            return false;
        }
        j jVarB = b(jobParameters);
        if (jVarB == null) {
            x.e().c(str, "WorkSpec id not found!");
            return false;
        }
        HashMap map = this.f13590u;
        if (map.containsKey(jVarB)) {
            x.e().a(str, "Job is already being executed by SystemJobService: " + jVarB);
            return false;
        }
        x.e().a(str, "onStartJob for " + jVarB);
        map.put(jVarB, jobParameters);
        int i = Build.VERSION.SDK_INT;
        f fVar = new f(7);
        if (jobParameters.getTriggeredContentUris() != null) {
            fVar.f323v = Arrays.asList(jobParameters.getTriggeredContentUris());
        }
        if (jobParameters.getTriggeredContentAuthorities() != null) {
            fVar.f322u = Arrays.asList(jobParameters.getTriggeredContentAuthorities());
        }
        if (i >= 28) {
            fVar.f324w = AbstractC0030f.e(jobParameters);
        }
        c cVar = this.f13592w;
        k kVarF = this.f13591v.f(jVarB);
        cVar.getClass();
        ((a) cVar.f8218v).c(new E2.c(cVar, kVarF, fVar, 4));
        return true;
    }

    @Override // android.app.job.JobService
    public final boolean onStopJob(JobParameters jobParameters) {
        boolean zContains;
        a("onStopJob");
        if (this.f13589t == null) {
            x.e().a(x, "WorkManager is not initialized; requesting retry.");
            return true;
        }
        j jVarB = b(jobParameters);
        if (jVarB == null) {
            x.e().c(x, "WorkSpec id not found!");
            return false;
        }
        x.e().a(x, "onStopJob for " + jVarB);
        this.f13590u.remove(jVarB);
        k kVarD = this.f13591v.d(jVarB);
        if (kVarD != null) {
            int iC = Build.VERSION.SDK_INT >= 31 ? K2.f.c(jobParameters) : -512;
            c cVar = this.f13592w;
            cVar.getClass();
            cVar.n(kVarD, iC);
        }
        C0549e c0549e = this.f13589t.f3433f;
        String str = jVarB.f8231a;
        synchronized (c0549e.f3393k) {
            zContains = c0549e.i.contains(str);
        }
        return !zContains;
    }
}
