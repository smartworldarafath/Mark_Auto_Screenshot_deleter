package androidx.work;

import D7.AbstractC0094y;
import D7.e0;
import E4.W2;
import F4.r7;
import G2.C0508e;
import G2.C0509f;
import G2.C0510g;
import G2.w;
import X4.b;
import android.content.Context;
import p062h7.c;
import p062h7.h;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
public abstract class CoroutineWorker extends w {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final WorkerParameters f13564e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final C0508e f13565f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public CoroutineWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        j.e(context, "appContext");
        j.e(workerParameters, "params");
        this.f13564e = workerParameters;
        this.f13565f = C0508e.f3139v;
    }

    public abstract Object a(c cVar);

    @Override // G2.w
    public final b getForegroundInfoAsync() {
        e0 e0VarC = AbstractC0094y.c();
        C0508e c0508e = this.f13565f;
        c0508e.getClass();
        return W2.a(r7.c(c0508e, e0VarC), new C0509f(this, null));
    }

    @Override // G2.w
    public final b startWork() {
        C0508e c0508e = C0508e.f3139v;
        h hVar = this.f13565f;
        if (j.a(hVar, c0508e)) {
            hVar = this.f13564e.f13573g;
        }
        j.d(hVar, "if (coroutineContext != …rkerContext\n            }");
        return W2.a(hVar.S(AbstractC0094y.c()), new C0510g(this, null));
    }
}
