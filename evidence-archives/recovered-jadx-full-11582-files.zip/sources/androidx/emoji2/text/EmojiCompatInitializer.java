package androidx.emoji2.text;

import A2.a;
import A2.b;
import C3.l;
import E.V;
import O1.m;
import O1.u;
import android.content.Context;
import androidx.lifecycle.InterfaceC1411w;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class EmojiCompatInitializer implements b {
    @Override // A2.b
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // A2.b
    public final Object create(Context context) {
        Object objB;
        u uVar = new u(new l(context, 1));
        uVar.f8093a = 1;
        if (O1.l.f8100k == null) {
            synchronized (O1.l.f8099j) {
                try {
                    if (O1.l.f8100k == null) {
                        O1.l.f8100k = new O1.l(uVar);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        a aVarC = a.c(context);
        aVarC.getClass();
        synchronized (a.f293e) {
            try {
                objB = aVarC.f294a.get(ProcessLifecycleInitializer.class);
                if (objB == null) {
                    objB = aVarC.b(ProcessLifecycleInitializer.class, new HashSet());
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        V vG = ((InterfaceC1411w) objB).g();
        vG.l(new m(this, vG));
        return Boolean.TRUE;
    }
}
