package androidx.profileinstaller;

import A2.b;
import S1.e;
import android.content.Context;
import android.view.Choreographer;
import java.util.Collections;
import java.util.List;
import p019c1.A;

/* JADX INFO: loaded from: classes.dex */
public class ProfileInstallerInitializer implements b {
    @Override // A2.b
    public final List a() {
        return Collections.EMPTY_LIST;
    }

    @Override // A2.b
    public final Object create(Context context) {
        Choreographer.getInstance().postFrameCallback(new A(this, context.getApplicationContext()));
        return new e(14);
    }
}
