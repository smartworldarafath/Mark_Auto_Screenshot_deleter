package A0;

import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import org.xmlpull.v1.XmlPullParser;
import p146s7.j;
import p166w.C5976a;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final XmlPullParser f172a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f173b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C5976a f174c;

    public a(XmlResourceParser xmlResourceParser) {
        this.f172a = xmlResourceParser;
        C5976a c5976a = new C5976a();
        c5976a.f32094t = new float[64];
        this.f174c = c5976a;
    }

    public final float a(TypedArray typedArray, String str, int i, float f4) {
        if (p140s1.b.b(this.f172a, str)) {
            f4 = typedArray.getFloat(i, f4);
        }
        b(typedArray.getChangingConfigurations());
        return f4;
    }

    public final void b(int i) {
        this.f173b = i | this.f173b;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return j.a(this.f172a, aVar.f172a) && this.f173b == aVar.f173b;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f173b) + (this.f172a.hashCode() * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("AndroidVectorParser(xmlParser=");
        sb.append(this.f172a);
        sb.append(", config=");
        return X3.b.k(sb, this.f173b, ')');
    }
}
