package C0;

/* JADX INFO: loaded from: classes.dex */
public interface b {
}
