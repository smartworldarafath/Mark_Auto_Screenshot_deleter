package C0;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f703a;

    public final boolean equals(Object obj) {
        if (obj instanceof a) {
            return this.f703a == ((a) obj).f703a;
        }
        return false;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f703a);
    }

    public final String toString() {
        int i = this.f703a;
        if (i == 1) {
            return "Touch";
        }
        return i == 2 ? "Keyboard" : "Error";
    }
}
