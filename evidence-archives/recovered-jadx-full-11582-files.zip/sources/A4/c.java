package A4;

import android.os.IBinder;
import android.os.IInterface;

/* JADX INFO: loaded from: classes.dex */
public final class c implements IInterface {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final IBinder f317t;

    public c(IBinder iBinder) {
        this.f317t = iBinder;
    }

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f317t;
    }
}
