package A4;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Status;

/* JADX INFO: loaded from: classes.dex */
public final class h extends Binder implements IInterface {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ O4.h f326t;

    public h(O4.h hVar) {
        this.f326t = hVar;
        attachInterface(this, "com.google.android.gms.appset.internal.IAppSetIdCallback");
    }

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this;
    }

    @Override // android.os.Binder
    public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i4) {
        if (i <= 16777215) {
            parcel.enforceInterface(getInterfaceDescriptor());
        } else if (super.onTransact(i, parcel, parcel2, i4)) {
            return true;
        }
        if (i != 1) {
            return false;
        }
        Parcelable.Creator<Status> creator = Status.CREATOR;
        int i9 = a.f316a;
        Status statusCreateFromParcel = parcel.readInt() == 0 ? null : creator.createFromParcel(parcel);
        p074j4.c cVarCreateFromParcel = parcel.readInt() == 0 ? null : p074j4.c.CREATOR.createFromParcel(parcel);
        p074j4.b bVar = cVarCreateFromParcel != null ? new p074j4.b(cVarCreateFromParcel.f27669t, cVarCreateFromParcel.f27670u) : null;
        int i10 = statusCreateFromParcel.f14282t;
        O4.h hVar = this.f326t;
        if (i10 <= 0) {
            hVar.b(bVar);
            return true;
        }
        hVar.a(statusCreateFromParcel.f14284v != null ? new R4.a(statusCreateFromParcel) : new p106n4.d(statusCreateFromParcel));
        return true;
    }
}
