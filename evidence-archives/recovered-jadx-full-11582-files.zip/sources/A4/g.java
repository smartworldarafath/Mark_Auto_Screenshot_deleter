package A4;

import T3.C1162o;
import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import p114o4.k;
import p120p4.o;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f325a;

    public p106n4.c a(Context context, Looper looper, C1162o c1162o, Object obj, p106n4.g gVar, p106n4.h hVar) {
        switch (this.f325a) {
            case 1:
                c1162o.getClass();
                Integer num = (Integer) c1162o.f9795y;
                Bundle bundle = new Bundle();
                bundle.putParcelable("com.google.android.gms.signin.internal.clientRequestedAccount", null);
                if (num != null) {
                    bundle.putInt("com.google.android.gms.common.internal.ClientSettings.sessionId", num.intValue());
                }
                bundle.putBoolean("com.google.android.gms.signin.internal.offlineAccessRequested", false);
                bundle.putBoolean("com.google.android.gms.signin.internal.idTokenRequested", false);
                bundle.putString("com.google.android.gms.signin.internal.serverClientId", null);
                bundle.putBoolean("com.google.android.gms.signin.internal.usePromptModeForAuthCode", true);
                bundle.putBoolean("com.google.android.gms.signin.internal.forceCodeForRefreshToken", false);
                bundle.putString("com.google.android.gms.signin.internal.hostedDomain", null);
                bundle.putString("com.google.android.gms.signin.internal.logSessionId", null);
                bundle.putBoolean("com.google.android.gms.signin.internal.waitForAccessTokenRefresh", false);
                return new N4.a(context, looper, c1162o, bundle, gVar, hVar);
            case 2:
                throw p127q3.h.f(obj);
            default:
                k kVar = (k) gVar;
                k kVar2 = (k) hVar;
                switch (this.f325a) {
                    case 0:
                        return new b(context, looper, 300, c1162o, kVar, kVar2);
                    case 1:
                    case 2:
                    default:
                        throw new UnsupportedOperationException("buildClient must be implemented");
                    case 3:
                        return new p134r4.c(context, looper, c1162o, (o) obj, kVar, kVar2);
                    case 4:
                        return new p151t4.h(context, looper, 308, c1162o, kVar, kVar2);
                }
        }
    }
}
