package A4;

import android.os.IBinder;
import android.os.IInterface;
import p120p4.AbstractC5864h;

/* JADX INFO: loaded from: classes.dex */
public final class b extends AbstractC5864h {
    @Override // p120p4.AbstractC5861e, p106n4.c
    public final int j() {
        return 212800000;
    }

    @Override // p120p4.AbstractC5861e
    public final /* synthetic */ IInterface o(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.appset.internal.IAppSetService");
        return iInterfaceQueryLocalInterface instanceof c ? (c) iInterfaceQueryLocalInterface : new c(iBinder);
    }

    @Override // p120p4.AbstractC5861e
    public final p099m4.d[] q() {
        return p074j4.d.f27672b;
    }

    @Override // p120p4.AbstractC5861e
    public final String u() {
        return "com.google.android.gms.appset.internal.IAppSetService";
    }

    @Override // p120p4.AbstractC5861e
    public final String v() {
        return "com.google.android.gms.appset.service.START";
    }

    @Override // p120p4.AbstractC5861e
    public final boolean w() {
        return true;
    }

    @Override // p120p4.AbstractC5861e
    public final boolean x() {
        return true;
    }
}
