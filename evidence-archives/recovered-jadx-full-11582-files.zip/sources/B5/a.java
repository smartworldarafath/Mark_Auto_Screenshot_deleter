package B5;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f494a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f495b;

    public a(String str, ArrayList arrayList) {
        if (str == null) {
            throw new NullPointerException("Null userAgent");
        }
        this.f494a = str;
        this.f495b = arrayList;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return this.f494a.equals(aVar.f494a) && this.f495b.equals(aVar.f495b);
    }

    public final int hashCode() {
        return ((this.f494a.hashCode() ^ 1000003) * 1000003) ^ this.f495b.hashCode();
    }

    public final String toString() {
        return "HeartBeatResult{userAgent=" + this.f494a + ", usedDates=" + this.f495b + "}";
    }
}
