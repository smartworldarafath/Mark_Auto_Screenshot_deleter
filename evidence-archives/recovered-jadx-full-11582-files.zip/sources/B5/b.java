package B5;

import T3.C1162o;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import p030d5.q;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements C5.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f496a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f497b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f498c;

    public /* synthetic */ b(int i, Object obj, Object obj2) {
        this.f496a = i;
        this.f497b = obj;
        this.f498c = obj2;
    }

    @Override // C5.b
    public final Object get() {
        ApplicationInfo applicationInfo;
        Bundle bundle;
        switch (this.f496a) {
            case 0:
                return new j((Context) this.f497b, (String) this.f498c);
            case 1:
                Y4.f fVar = (Y4.f) this.f498c;
                Context context = (Context) this.f497b;
                String strC = fVar.c();
                H5.a aVar = new H5.a();
                Context contextCreateDeviceProtectedStorageContext = context.createDeviceProtectedStorageContext();
                SharedPreferences sharedPreferences = contextCreateDeviceProtectedStorageContext.getSharedPreferences("com.google.firebase.common.prefs:" + strC, 0);
                boolean z8 = true;
                if (sharedPreferences.contains("firebase_data_collection_default_enabled")) {
                    z8 = sharedPreferences.getBoolean("firebase_data_collection_default_enabled", true);
                } else {
                    try {
                        PackageManager packageManager = contextCreateDeviceProtectedStorageContext.getPackageManager();
                        if (packageManager != null && (applicationInfo = packageManager.getApplicationInfo(contextCreateDeviceProtectedStorageContext.getPackageName(), 128)) != null && (bundle = applicationInfo.metaData) != null && bundle.containsKey("firebase_data_collection_default_enabled")) {
                            z8 = applicationInfo.metaData.getBoolean("firebase_data_collection_default_enabled");
                        }
                        break;
                    } catch (PackageManager.NameNotFoundException unused) {
                    }
                }
                aVar.f4307a = z8;
                return aVar;
            default:
                p030d5.f fVar2 = (p030d5.f) this.f497b;
                p030d5.a aVar2 = (p030d5.a) this.f498c;
                p030d5.c cVar = aVar2.f26756f;
                C1162o c1162o = new C1162o();
                HashSet hashSet = new HashSet();
                HashSet hashSet2 = new HashSet();
                HashSet hashSet3 = new HashSet();
                HashSet hashSet4 = new HashSet();
                HashSet hashSet5 = new HashSet();
                Set<p030d5.i> set = aVar2.f26753c;
                Set set2 = aVar2.f26757g;
                for (p030d5.i iVar : set) {
                    int i = iVar.f26774c;
                    int i4 = iVar.f26773b;
                    boolean z9 = i == 0;
                    q qVar = iVar.f26772a;
                    if (z9) {
                        if (i4 == 2) {
                            hashSet4.add(qVar);
                        } else {
                            hashSet.add(qVar);
                        }
                    } else if (i == 2) {
                        hashSet3.add(qVar);
                    } else if (i4 == 2) {
                        hashSet5.add(qVar);
                    } else {
                        hashSet2.add(qVar);
                    }
                }
                if (!set2.isEmpty()) {
                    hashSet.add(q.a(A5.a.class));
                }
                c1162o.f9791t = Collections.unmodifiableSet(hashSet);
                c1162o.f9792u = Collections.unmodifiableSet(hashSet2);
                c1162o.f9793v = Collections.unmodifiableSet(hashSet3);
                c1162o.f9794w = Collections.unmodifiableSet(hashSet4);
                c1162o.x = Collections.unmodifiableSet(hashSet5);
                c1162o.f9795y = fVar2;
                return cVar.f(c1162o);
        }
    }

    public /* synthetic */ b(Y4.f fVar, Context context) {
        this.f496a = 1;
        this.f498c = fVar;
        this.f497b = context;
    }
}
