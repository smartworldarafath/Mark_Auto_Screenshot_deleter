package B5;

import A1.InterfaceC0041q;
import L4.A;
import L4.InterfaceC1019u;
import O1.z;
import T3.C1162o;
import android.os.Looper;
import android.text.Editable;
import android.text.Selection;
import com.google.android.gms.internal.ads.V7;
import com.google.android.gms.internal.measurement.C4993c3;
import com.google.android.gms.internal.measurement.C5003e3;
import com.google.android.gms.internal.measurement.C5018h3;
import com.google.android.gms.internal.measurement.C5107z3;
import com.google.android.gms.internal.measurement.I3;
import com.google.android.gms.internal.measurement.M3;
import com.google.android.gms.internal.measurement.O3;
import com.google.android.gms.internal.measurement.P3;
import com.google.android.gms.internal.measurement.R3;
import com.google.android.gms.internal.measurement.a4;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class e implements InterfaceC0041q, InterfaceC1019u, p030d5.c {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f528t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final /* synthetic */ e f523u = new e(4);

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final /* synthetic */ e f524v = new e(5);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final /* synthetic */ e f525w = new e(6);
    public static final /* synthetic */ e x = new e(7);

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final /* synthetic */ e f526y = new e(8);

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final /* synthetic */ e f527z = new e(9);

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public static final /* synthetic */ e f506A = new e(10);

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public static final /* synthetic */ e f507B = new e(11);

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public static final /* synthetic */ e f508C = new e(12);

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public static final /* synthetic */ e f509D = new e(13);

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public static final /* synthetic */ e f510E = new e(14);

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public static final /* synthetic */ e f511F = new e(15);

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public static final /* synthetic */ e f512G = new e(16);

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public static final /* synthetic */ e f513H = new e(17);

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public static final /* synthetic */ e f514I = new e(18);

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public static final /* synthetic */ e f515J = new e(19);

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public static final /* synthetic */ e f516K = new e(20);

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public static final /* synthetic */ e f517L = new e(21);

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public static final /* synthetic */ e f518M = new e(22);

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public static final /* synthetic */ e f519N = new e(23);

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public static final /* synthetic */ e f520O = new e(24);

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public static final /* synthetic */ e f521P = new e(25);

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public static final /* synthetic */ e f522Q = new e(26);

    public /* synthetic */ e(int i) {
        this.f528t = i;
    }

    public static boolean b(Q1.b bVar, Editable editable, int i, int i4, boolean z8) {
        int iMin;
        if (editable != null && i >= 0 && i4 >= 0) {
            int selectionStart = Selection.getSelectionStart(editable);
            int selectionEnd = Selection.getSelectionEnd(editable);
            if (selectionStart != -1 && selectionEnd != -1 && selectionStart == selectionEnd) {
                if (z8) {
                    int iMax = Math.max(i, 0);
                    int length = editable.length();
                    if (selectionStart >= 0 && length >= selectionStart && iMax >= 0) {
                        loop0: while (true) {
                            boolean z9 = false;
                            while (true) {
                                if (iMax == 0) {
                                    break loop0;
                                }
                                selectionStart--;
                                if (selectionStart < 0) {
                                    if (!z9) {
                                        selectionStart = 0;
                                        break loop0;
                                    }
                                    break loop0;
                                }
                                char cCharAt = editable.charAt(selectionStart);
                                if (z9) {
                                    if (Character.isHighSurrogate(cCharAt)) {
                                        iMax--;
                                    }
                                } else if (!Character.isSurrogate(cCharAt)) {
                                    iMax--;
                                } else if (!Character.isHighSurrogate(cCharAt)) {
                                    z9 = true;
                                }
                                selectionStart = -1;
                                break loop0;
                            }
                        }
                    }
                    selectionStart = -1;
                    break loop0;
                    int iMax2 = Math.max(i4, 0);
                    iMin = editable.length();
                    if (selectionEnd >= 0 && iMin >= selectionEnd && iMax2 >= 0) {
                        loop2: while (true) {
                            boolean z10 = false;
                            while (true) {
                                if (iMax2 != 0) {
                                    if (selectionEnd >= iMin) {
                                        if (!z10) {
                                            break loop2;
                                        }
                                        break loop2;
                                    }
                                    char cCharAt2 = editable.charAt(selectionEnd);
                                    if (z10) {
                                        if (Character.isLowSurrogate(cCharAt2)) {
                                            iMax2--;
                                            selectionEnd++;
                                        }
                                    } else if (!Character.isSurrogate(cCharAt2)) {
                                        iMax2--;
                                        selectionEnd++;
                                    } else if (!Character.isLowSurrogate(cCharAt2)) {
                                        selectionEnd++;
                                        z10 = true;
                                    }
                                    iMin = -1;
                                    break loop2;
                                }
                                iMin = selectionEnd;
                                break loop2;
                            }
                        }
                    }
                    iMin = -1;
                    break loop2;
                    if (selectionStart != -1 && iMin != -1) {
                    }
                } else {
                    selectionStart = Math.max(selectionStart - i, 0);
                    iMin = Math.min(selectionEnd + i4, editable.length());
                }
                z[] zVarArr = (z[]) editable.getSpans(selectionStart, iMin, z.class);
                if (zVarArr != null && zVarArr.length > 0) {
                    for (z zVar : zVarArr) {
                        int spanStart = editable.getSpanStart(zVar);
                        int spanEnd = editable.getSpanEnd(zVar);
                        selectionStart = Math.min(spanStart, selectionStart);
                        iMin = Math.max(spanEnd, iMin);
                    }
                    int iMax3 = Math.max(selectionStart, 0);
                    int iMin2 = Math.min(iMin, editable.length());
                    bVar.beginBatchEdit();
                    editable.delete(iMax3, iMin2);
                    bVar.endBatchEdit();
                    return true;
                }
            }
        }
        return false;
    }

    public static final boolean c() {
        return Looper.myLooper() == Looper.getMainLooper();
    }

    @Override // L4.InterfaceC1019u
    public Object a() {
        switch (this.f528t) {
            case 4:
                return new Boolean(((Boolean) C5107z3.f25305a.b()).booleanValue());
            case 5:
                List list = A.f6576a;
                Boolean bool = (Boolean) a4.f25000a.b();
                bool.getClass();
                return bool;
            case 6:
                List list2 = A.f6576a;
                C4993c3.f25020u.get();
                return Integer.valueOf((int) ((Long) C5003e3.f25086o0.b()).longValue());
            case 7:
                List list3 = A.f6576a;
                C4993c3.f25020u.get();
                return (String) C5003e3.f25083n.b();
            case 8:
                List list4 = A.f6576a;
                C4993c3.f25020u.get();
                Long l8 = (Long) C5003e3.U.b();
                l8.getClass();
                return l8;
            case 9:
                List list5 = A.f6576a;
                C4993c3.f25020u.get();
                return Integer.valueOf((int) ((Long) C5003e3.f25048O.b()).longValue());
            case 10:
                List list6 = A.f6576a;
                C4993c3.f25020u.get();
                Long l9 = (Long) C5003e3.f25068f.b();
                l9.getClass();
                return l9;
            case 11:
                List list7 = A.f6576a;
                C4993c3.f25020u.get();
                Long l10 = (Long) C5003e3.i.b();
                l10.getClass();
                return l10;
            case 12:
                List list8 = A.f6576a;
                C4993c3.f25020u.get();
                Long l11 = (Long) C5003e3.f25071g0.b();
                l11.getClass();
                return l11;
            case 13:
                List list9 = A.f6576a;
                C4993c3.f25020u.get();
                Long l12 = (Long) C5003e3.f25081m.b();
                l12.getClass();
                return l12;
            case 14:
                List list10 = A.f6576a;
                M3.f24884u.get();
                Boolean bool2 = (Boolean) O3.f24896a.b();
                bool2.getClass();
                return bool2;
            case 15:
                List list11 = A.f6576a;
                M3.f24884u.get();
                return Integer.valueOf((int) ((Long) O3.f24899d.b()).longValue());
            case 16:
                List list12 = A.f6576a;
                C4993c3.f25020u.get();
                return Integer.valueOf((int) ((Long) C5003e3.f25064d.b()).longValue());
            case 17:
                List list13 = A.f6576a;
                C4993c3.f25020u.get();
                return Integer.valueOf((int) ((Long) C5003e3.f25087p.b()).longValue());
            case 18:
                List list14 = A.f6576a;
                C4993c3.f25020u.get();
                return (String) C5003e3.f25037D.b();
            case 19:
                List list15 = A.f6576a;
                C4993c3.f25020u.get();
                Long l13 = (Long) C5003e3.f25057Z.b();
                l13.getClass();
                return l13;
            case 20:
                List list16 = A.f6576a;
                C4993c3.f25020u.get();
                Boolean bool3 = (Boolean) C5003e3.f25062c.b();
                bool3.getClass();
                return bool3;
            case V7.zzm /* 21 */:
                List list17 = A.f6576a;
                C4993c3.f25020u.get();
                return Integer.valueOf((int) ((Long) C5003e3.f25074i0.b()).longValue());
            case 22:
                List list18 = A.f6576a;
                return Integer.valueOf((int) ((Long) C5018h3.f25126a.b()).longValue());
            case 23:
                List list19 = A.f6576a;
                P3.f24903u.get();
                Boolean bool4 = (Boolean) R3.f24933f.b();
                bool4.getClass();
                return bool4;
            case 24:
                List list20 = A.f6576a;
                P3.f24903u.get();
                Boolean bool5 = (Boolean) R3.f24929b.b();
                bool5.getClass();
                return bool5;
            case 25:
                List list21 = A.f6576a;
                P3.f24903u.get();
                Boolean bool6 = (Boolean) R3.f24931d.b();
                bool6.getClass();
                return bool6;
            default:
                return new Boolean(((Boolean) I3.f24858a.b()).booleanValue());
        }
    }

    @Override // p030d5.c
    public Object f(C1162o c1162o) {
        return new T5.d(c1162o.e(T5.h.class));
    }

    @Override // A1.InterfaceC0041q
    public void onScrollLimit(int i, int i4, int i9, boolean z8) {
    }

    @Override // A1.InterfaceC0041q
    public void onScrollProgress(int i, int i4, int i9, int i10) {
    }
}
