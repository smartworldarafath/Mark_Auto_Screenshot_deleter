package B5;

import E4.AbstractC0181j4;
import H4.R5;
import O4.o;
import android.content.Context;
import java.util.Set;
import java.util.concurrent.Executor;
import p030d5.m;

/* JADX INFO: loaded from: classes.dex */
public final class d implements f, g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m f501a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Context f502b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C5.b f503c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Set f504d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Executor f505e;

    public d(Context context, String str, Set set, C5.b bVar, Executor executor) {
        this.f501a = new m(new b(0, context, str));
        this.f504d = set;
        this.f505e = executor;
        this.f503c = bVar;
        this.f502b = context;
    }

    public final o a() {
        return !R5.a(this.f502b) ? AbstractC0181j4.e("") : AbstractC0181j4.c(new c(this, 0), this.f505e);
    }

    public final void b() {
        if (this.f504d.size() <= 0) {
            AbstractC0181j4.e(null);
        } else if (R5.a(this.f502b)) {
            AbstractC0181j4.c(new c(this, 1), this.f505e);
        } else {
            AbstractC0181j4.e(null);
        }
    }
}
