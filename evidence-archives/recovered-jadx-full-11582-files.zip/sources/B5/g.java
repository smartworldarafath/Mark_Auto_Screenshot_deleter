package B5;

/* JADX INFO: loaded from: classes.dex */
public interface g {
}
