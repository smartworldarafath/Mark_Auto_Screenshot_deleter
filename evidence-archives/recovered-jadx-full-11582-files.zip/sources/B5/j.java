package B5;

import D7.AbstractC0094y;
import E4.R3;
import H4.AbstractC0705q5;
import android.content.Context;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final M1.e f535b = new M1.e("fire-global");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final M1.e f536c = new M1.e("fire-count");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final M1.e f537d = new M1.e("last-used-date");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p152t5.d f538a;

    public j(Context context, String str) {
        this.f538a = new p152t5.d(context, p127q3.h.h("FirebaseHeartBeat", str));
    }

    public final synchronized ArrayList a() {
        try {
            ArrayList arrayList = new ArrayList();
            String strB = b(System.currentTimeMillis());
            p152t5.d dVar = this.f538a;
            dVar.getClass();
            for (Map.Entry entry : ((Map) AbstractC0094y.B(p062h7.i.f27295t, new p152t5.c(dVar, null))).entrySet()) {
                if (entry.getValue() instanceof Set) {
                    HashSet hashSet = new HashSet((Set) entry.getValue());
                    hashSet.remove(strB);
                    if (!hashSet.isEmpty()) {
                        arrayList.add(new a(((M1.e) entry.getKey()).f7830a, new ArrayList(hashSet)));
                    }
                }
            }
            long jCurrentTimeMillis = System.currentTimeMillis();
            synchronized (this) {
                this.f538a.a(new i(0, jCurrentTimeMillis));
            }
            return arrayList;
        } catch (Throwable th) {
            throw th;
        }
        return arrayList;
    }

    public final synchronized String b(long j9) {
        return new Date(j9).toInstant().atOffset(ZoneOffset.UTC).toLocalDateTime().format(DateTimeFormatter.ISO_LOCAL_DATE);
    }

    public final synchronized M1.e c(M1.b bVar, String str) {
        for (Map.Entry entry : bVar.a().entrySet()) {
            if (entry.getValue() instanceof Set) {
                Iterator it = ((Set) entry.getValue()).iterator();
                while (it.hasNext()) {
                    if (str.equals((String) it.next())) {
                        return R3.a(((M1.e) entry.getKey()).f7830a);
                    }
                }
            }
        }
        return null;
    }

    public final synchronized void d(M1.b bVar, String str) {
        try {
            M1.e eVarC = c(bVar, str);
            if (eVarC == null) {
                return;
            }
            HashSet hashSet = new HashSet((Collection) AbstractC0705q5.a(bVar, eVarC, new HashSet()));
            hashSet.remove(str);
            if (hashSet.isEmpty()) {
                bVar.c(eVarC);
            } else {
                bVar.e(eVarC, hashSet);
            }
        } catch (Throwable th) {
            throw th;
        }
    }
}
