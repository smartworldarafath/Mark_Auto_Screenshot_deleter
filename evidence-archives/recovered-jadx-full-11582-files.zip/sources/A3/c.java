package A3;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Spanned;
import com.google.android.gms.internal.ads.AbstractC3784dn;
import com.google.android.gms.internal.ads.AbstractC4074jh;
import com.google.android.gms.internal.ads.AbstractC4239mz;
import com.google.android.gms.internal.ads.Ao;
import com.google.android.gms.internal.ads.C3328Dg;
import com.google.android.gms.internal.ads.C3509Sh;
import com.google.android.gms.internal.ads.C3630ai;
import com.google.android.gms.internal.ads.C3651b2;
import com.google.android.gms.internal.ads.C3899g2;
import com.google.android.gms.internal.ads.C4141kz;
import com.google.android.gms.internal.ads.C4504sJ;
import com.google.android.gms.internal.ads.C4563th;
import com.google.android.gms.internal.ads.C4710wh;
import com.google.android.gms.internal.ads.InterfaceC3547Vj;
import com.google.android.gms.internal.ads.InterfaceC3931gl;
import com.google.android.gms.internal.ads.InterfaceC4290o0;
import com.google.android.gms.internal.ads.InterfaceC4553tJ;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class c implements InterfaceC3547Vj, InterfaceC3931gl {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f305t = 3;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public long f306u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f307v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Object f308w;

    public /* synthetic */ c() {
    }

    /* JADX WARN: Code duplicated, block: B:28:0x0141  */
    @Override // com.google.android.gms.internal.ads.InterfaceC3547Vj, com.google.android.gms.internal.ads.InterfaceC3931gl
    /* JADX INFO: renamed from: c */
    public void mo14c(Object obj) {
        long j9;
        long j10;
        int i;
        switch (this.f305t) {
            case 1:
                C3899g2 c3899g2 = (C3899g2) this.f308w;
                long j11 = this.f306u;
                int i4 = this.f307v;
                C3651b2 c3651b2 = (C3651b2) obj;
                c3899g2.f20119h.getClass();
                AbstractC4239mz abstractC4239mz = c3651b2.f19074a;
                long j12 = c3651b2.f19076c;
                ArrayList<? extends Parcelable> arrayList = new ArrayList<>(abstractC4239mz.size());
                int i9 = 0;
                C4141kz c4141kzListIterator = abstractC4239mz.listIterator(0);
                while (c4141kzListIterator.hasNext()) {
                    C3328Dg c3328Dg = (C3328Dg) c4141kzListIterator.next();
                    c3328Dg.getClass();
                    Bundle bundle = new Bundle();
                    CharSequence charSequence = c3328Dg.f14964a;
                    if (charSequence != null) {
                        bundle.putCharSequence(C3328Dg.f14955q, charSequence);
                        if (charSequence instanceof Spanned) {
                            Spanned spanned = (Spanned) charSequence;
                            String str = AbstractC4074jh.f21302a;
                            ArrayList<? extends Parcelable> arrayList2 = new ArrayList<>();
                            C4710wh[] c4710whArr = (C4710wh[]) spanned.getSpans(i9, spanned.length(), C4710wh.class);
                            int length = c4710whArr.length;
                            while (i9 < length) {
                                C4710wh[] c4710whArr2 = c4710whArr;
                                C4710wh c4710wh = c4710whArr2[i9];
                                c4710wh.getClass();
                                long j13 = j11;
                                Bundle bundle2 = new Bundle();
                                bundle2.putString(C4710wh.f23975c, c4710wh.f23977a);
                                bundle2.putInt(C4710wh.f23976d, c4710wh.f23978b);
                                arrayList2.add(AbstractC4074jh.a(spanned, c4710wh, 1, bundle2));
                                i9++;
                                c4710whArr = c4710whArr2;
                                j11 = j13;
                                i4 = i4;
                            }
                            j10 = j11;
                            i = i4;
                            C3509Sh[] c3509ShArr = (C3509Sh[]) spanned.getSpans(0, spanned.length(), C3509Sh.class);
                            int length2 = c3509ShArr.length;
                            int i10 = 0;
                            while (i10 < length2) {
                                C3509Sh c3509Sh = c3509ShArr[i10];
                                c3509Sh.getClass();
                                Bundle bundle3 = new Bundle();
                                bundle3.putInt(C3509Sh.f17615d, c3509Sh.f17618a);
                                bundle3.putInt(C3509Sh.f17616e, c3509Sh.f17619b);
                                bundle3.putInt(C3509Sh.f17617f, c3509Sh.f17620c);
                                arrayList2.add(AbstractC4074jh.a(spanned, c3509Sh, 2, bundle3));
                                i10++;
                                c3509ShArr = c3509ShArr;
                            }
                            for (C4563th c4563th : (C4563th[]) spanned.getSpans(0, spanned.length(), C4563th.class)) {
                                arrayList2.add(AbstractC4074jh.a(spanned, c4563th, 3, null));
                            }
                            C3630ai[] c3630aiArr = (C3630ai[]) spanned.getSpans(0, spanned.length(), C3630ai.class);
                            int length3 = c3630aiArr.length;
                            int i11 = 0;
                            while (i11 < length3) {
                                C3630ai c3630ai = c3630aiArr[i11];
                                c3630ai.getClass();
                                Bundle bundle4 = new Bundle();
                                bundle4.putString(C3630ai.f19029b, c3630ai.f19030a);
                                arrayList2.add(AbstractC4074jh.a(spanned, c3630ai, 4, bundle4));
                                i11++;
                                c3630aiArr = c3630aiArr;
                            }
                            if (!arrayList2.isEmpty()) {
                                bundle.putParcelableArrayList(C3328Dg.f14956r, arrayList2);
                            }
                        } else {
                            j10 = j11;
                            i = i4;
                        }
                    } else {
                        j10 = j11;
                        i = i4;
                    }
                    bundle.putSerializable(C3328Dg.f14957s, c3328Dg.f14965b);
                    bundle.putSerializable(C3328Dg.f14958t, c3328Dg.f14966c);
                    bundle.putFloat(C3328Dg.f14960v, c3328Dg.f14968e);
                    bundle.putInt(C3328Dg.f14961w, c3328Dg.f14969f);
                    bundle.putInt(C3328Dg.x, c3328Dg.f14970g);
                    bundle.putFloat(C3328Dg.f14962y, c3328Dg.f14971h);
                    bundle.putInt(C3328Dg.f14963z, c3328Dg.i);
                    bundle.putInt(C3328Dg.f14946A, c3328Dg.f14974l);
                    bundle.putFloat(C3328Dg.f14947B, c3328Dg.f14975m);
                    bundle.putFloat(C3328Dg.f14948C, c3328Dg.f14972j);
                    bundle.putFloat(C3328Dg.f14949D, c3328Dg.f14973k);
                    bundle.putBoolean(C3328Dg.f14951F, false);
                    bundle.putInt(C3328Dg.f14950E, -16777216);
                    bundle.putInt(C3328Dg.f14952G, c3328Dg.f14976n);
                    bundle.putFloat(C3328Dg.f14953H, c3328Dg.f14977o);
                    bundle.putInt(C3328Dg.f14954I, c3328Dg.f14978p);
                    Bitmap bitmap = c3328Dg.f14967d;
                    if (bitmap != null) {
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        AbstractC3784dn.S(bitmap.compress(Bitmap.CompressFormat.PNG, 0, byteArrayOutputStream));
                        bundle.putByteArray(C3328Dg.f14959u, byteArrayOutputStream.toByteArray());
                    }
                    arrayList.add(bundle);
                    j11 = j10;
                    i4 = i;
                    i9 = 0;
                }
                long j14 = j11;
                int i12 = i4;
                Bundle bundle5 = new Bundle();
                bundle5.putParcelableArrayList("c", arrayList);
                bundle5.putLong("d", j12);
                Parcel parcelObtain = Parcel.obtain();
                parcelObtain.writeBundle(bundle5);
                byte[] bArrMarshall = parcelObtain.marshall();
                parcelObtain.recycle();
                Ao ao = c3899g2.f20114c;
                int length4 = bArrMarshall.length;
                ao.y(length4, bArrMarshall);
                InterfaceC4290o0 interfaceC4290o0 = c3899g2.f20112a;
                interfaceC4290o0.b(ao, length4, 0);
                long j15 = c3651b2.f19075b;
                if (j15 == -9223372036854775807L) {
                    AbstractC3784dn.S(c3899g2.f20119h.f16303r == Long.MAX_VALUE);
                    j9 = j14;
                } else {
                    long j16 = c3899g2.f20119h.f16303r;
                    j9 = j16 == Long.MAX_VALUE ? j14 + j15 : j15 + j16;
                }
                interfaceC4290o0.c(j9, i12 | 1, length4, 0, null);
                break;
            default:
                ((InterfaceC4553tJ) obj).g((C4504sJ) this.f308w, this.f307v, this.f306u);
                break;
        }
    }

    public /* synthetic */ c(C3899g2 c3899g2, long j9, int i) {
        this.f308w = c3899g2;
        this.f306u = j9;
        this.f307v = i;
    }

    public /* synthetic */ c(C4504sJ c4504sJ, int i, long j9, long j10) {
        this.f308w = c4504sJ;
        this.f307v = i;
        this.f306u = j9;
    }

    public c(int i, URL url, long j9) {
        this.f307v = i;
        this.f308w = url;
        this.f306u = j9;
    }
}
