package B7;

import A7.n;
import E4.AbstractC0229s;
import E4.AbstractC0235t;
import H4.Z5;
import com.facebook.ads.AdError;
import p146s7.j;

/* JADX INFO: loaded from: classes.dex */
public final class a implements Comparable {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final long f539u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final long f540v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final /* synthetic */ int f541w = 0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final long f542t;

    static {
        int i = b.f543a;
        f539u = AbstractC0229s.b(4611686018427387903L);
        f540v = AbstractC0229s.b(-4611686018427387903L);
    }

    public static final long a(long j9, long j10) {
        long j11 = 1000000;
        long j12 = j10 / j11;
        long j13 = j9 + j12;
        if (-4611686018426L > j13 || j13 >= 4611686018427L) {
            return AbstractC0229s.b(Z5.d(j13, -4611686018427387903L, 4611686018427387903L));
        }
        return AbstractC0229s.d((j13 * j11) + (j10 - (j12 * j11)));
    }

    public static final void b(StringBuilder sb, int i, int i4, int i9, String str, boolean z8) {
        sb.append(i);
        if (i4 != 0) {
            sb.append('.');
            String strF = n.F(i9, String.valueOf(i4));
            int i10 = -1;
            int length = strF.length() - 1;
            if (length >= 0) {
                while (true) {
                    int i11 = length - 1;
                    if (strF.charAt(length) != '0') {
                        i10 = length;
                        break;
                    } else if (i11 < 0) {
                        break;
                    } else {
                        length = i11;
                    }
                }
            }
            int i12 = i10 + 1;
            if (z8 || i12 >= 3) {
                sb.append((CharSequence) strF, 0, ((i10 + 3) / 3) * 3);
            } else {
                sb.append((CharSequence) strF, 0, i12);
            }
        }
        sb.append(str);
    }

    public static int c(long j9, long j10) {
        long j11 = j9 ^ j10;
        if (j11 < 0 || (((int) j11) & 1) == 0) {
            return j.g(j9, j10);
        }
        int i = (((int) j9) & 1) - (((int) j10) & 1);
        return j9 < 0 ? -i : i;
    }

    public static final int d(long j9) {
        if (e(j9)) {
            return 0;
        }
        return (int) ((((int) j9) & 1) == 1 ? ((j9 >> 1) % ((long) AdError.NETWORK_ERROR_CODE)) * ((long) 1000000) : (j9 >> 1) % ((long) 1000000000));
    }

    public static final boolean e(long j9) {
        return j9 == f539u || j9 == f540v;
    }

    public static final long f(long j9, long j10) {
        if (e(j9)) {
            if (!e(j10) || (j10 ^ j9) >= 0) {
                return j9;
            }
            throw new IllegalArgumentException("Summing infinite durations of different signs yields an undefined result.");
        }
        if (e(j10)) {
            return j10;
        }
        int i = ((int) j9) & 1;
        if (i != (((int) j10) & 1)) {
            return i == 1 ? a(j9 >> 1, j10 >> 1) : a(j10 >> 1, j9 >> 1);
        }
        long j11 = (j9 >> 1) + (j10 >> 1);
        if (i == 0) {
            return (-4611686018426999999L > j11 || j11 >= 4611686018427000000L) ? AbstractC0229s.b(j11 / ((long) 1000000)) : AbstractC0229s.d(j11);
        }
        return AbstractC0229s.c(j11);
    }

    public static final long g(long j9, c cVar) {
        j.e(cVar, "unit");
        if (j9 == f539u) {
            return Long.MAX_VALUE;
        }
        if (j9 == f540v) {
            return Long.MIN_VALUE;
        }
        return AbstractC0235t.b(j9 >> 1, (((int) j9) & 1) == 0 ? c.NANOSECONDS : c.MILLISECONDS, cVar);
    }

    public static final long h(long j9) {
        long j10 = ((-(j9 >> 1)) << 1) + ((long) (((int) j9) & 1));
        int i = b.f543a;
        return j10;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return c(this.f542t, ((a) obj).f542t);
    }

    public final boolean equals(Object obj) {
        if (obj instanceof a) {
            return this.f542t == ((a) obj).f542t;
        }
        return false;
    }

    public final int hashCode() {
        return Long.hashCode(this.f542t);
    }

    public final String toString() {
        long jH = this.f542t;
        if (jH == 0) {
            return "0s";
        }
        if (jH == f539u) {
            return "Infinity";
        }
        if (jH == f540v) {
            return "-Infinity";
        }
        int i = 0;
        boolean z8 = jH < 0;
        StringBuilder sb = new StringBuilder();
        if (z8) {
            sb.append('-');
        }
        if (jH < 0) {
            jH = h(jH);
        }
        long jG = g(jH, c.DAYS);
        int iG = e(jH) ? 0 : (int) (g(jH, c.HOURS) % ((long) 24));
        int iG2 = e(jH) ? 0 : (int) (g(jH, c.MINUTES) % ((long) 60));
        int iG3 = e(jH) ? 0 : (int) (g(jH, c.SECONDS) % ((long) 60));
        int iD = d(jH);
        boolean z9 = jG != 0;
        boolean z10 = iG != 0;
        boolean z11 = iG2 != 0;
        boolean z12 = (iG3 == 0 && iD == 0) ? false : true;
        if (z9) {
            sb.append(jG);
            sb.append('d');
            i = 1;
        }
        if (z10 || (z9 && (z11 || z12))) {
            int i4 = i + 1;
            if (i > 0) {
                sb.append(' ');
            }
            sb.append(iG);
            sb.append('h');
            i = i4;
        }
        if (z11 || (z12 && (z10 || z9))) {
            int i9 = i + 1;
            if (i > 0) {
                sb.append(' ');
            }
            sb.append(iG2);
            sb.append('m');
            i = i9;
        }
        if (z12) {
            int i10 = i + 1;
            if (i > 0) {
                sb.append(' ');
            }
            if (iG3 != 0 || z9 || z10 || z11) {
                b(sb, iG3, iD, 9, "s", false);
            } else if (iD >= 1000000) {
                b(sb, iD / 1000000, iD % 1000000, 6, "ms", false);
            } else if (iD >= 1000) {
                b(sb, iD / AdError.NETWORK_ERROR_CODE, iD % AdError.NETWORK_ERROR_CODE, 3, "us", false);
            } else {
                sb.append(iD);
                sb.append("ns");
            }
            i = i10;
        }
        if (z8 && i > 1) {
            sb.insert(1, '(').append(')');
        }
        return sb.toString();
    }
}
