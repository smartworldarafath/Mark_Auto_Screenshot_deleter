package B7;

/* JADX INFO: loaded from: classes.dex */
public abstract class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final long f551a = System.nanoTime();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f552b = 0;
}
