package A7;

import H4.Z5;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes.dex */
public final class b implements Iterator, p154t7.a {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f341t = -1;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f342u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f343v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public p181x7.d f344w;
    public final /* synthetic */ c x;

    public b(c cVar) {
        this.x = cVar;
        int iC = Z5.c(0, 0, ((CharSequence) cVar.f346b).length());
        this.f342u = iC;
        this.f343v = iC;
    }

    public final void a() {
        p032d7.k kVar;
        c cVar = this.x;
        CharSequence charSequence = (CharSequence) cVar.f346b;
        int i = this.f343v;
        if (i < 0) {
            this.f341t = 0;
            this.f344w = null;
            return;
        }
        if (i <= charSequence.length() && (kVar = (p032d7.k) ((p137r7.e) cVar.f347c).j(charSequence, Integer.valueOf(this.f343v))) != null) {
            int iIntValue = ((Number) kVar.f26813t).intValue();
            int iIntValue2 = ((Number) kVar.f26814u).intValue();
            this.f344w = Z5.f(this.f342u, iIntValue);
            int i4 = iIntValue + iIntValue2;
            this.f342u = i4;
            this.f343v = i4 + (iIntValue2 == 0 ? 1 : 0);
        } else {
            this.f344w = new p181x7.d(this.f342u, n.v(charSequence), 1);
            this.f343v = -1;
        }
        this.f341t = 1;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.f341t == -1) {
            a();
        }
        return this.f341t == 1;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (this.f341t == -1) {
            a();
        }
        if (this.f341t == 0) {
            throw new NoSuchElementException();
        }
        p181x7.d dVar = this.f344w;
        p146s7.j.c(dVar, "null cannot be cast to non-null type kotlin.ranges.IntRange");
        this.f344w = null;
        this.f341t = -1;
        return dVar;
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
