package A7;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f361a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p181x7.d f362b;

    public i(String str, p181x7.d dVar) {
        this.f361a = str;
        this.f362b = dVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return p146s7.j.a(this.f361a, iVar.f361a) && p146s7.j.a(this.f362b, iVar.f362b);
    }

    public final int hashCode() {
        return this.f362b.hashCode() + (this.f361a.hashCode() * 31);
    }

    public final String toString() {
        return "MatchGroup(value=" + this.f361a + ", range=" + this.f362b + ')';
    }
}
