package A7;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final g f353d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f354a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final e f355b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final f f356c;

    static {
        e eVar = e.f350a;
        f fVar = f.f351b;
        f353d = new g(false, eVar, fVar);
        new g(true, eVar, fVar);
    }

    public g(boolean z8, e eVar, f fVar) {
        p146s7.j.e(eVar, "bytes");
        p146s7.j.e(fVar, "number");
        this.f354a = z8;
        this.f355b = eVar;
        this.f356c = fVar;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("HexFormat(\n    upperCase = ");
        sb.append(this.f354a);
        sb.append(",\n    bytes = BytesHexFormat(\n");
        this.f355b.a("        ", sb);
        sb.append('\n');
        sb.append("    ),");
        sb.append('\n');
        sb.append("    number = NumberHexFormat(");
        sb.append('\n');
        this.f356c.a("        ", sb);
        sb.append('\n');
        sb.append("    )");
        sb.append('\n');
        sb.append(")");
        return sb.toString();
    }
}
