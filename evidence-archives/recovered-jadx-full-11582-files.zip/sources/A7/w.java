package A7;

import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class w implements p198z7.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f371a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f372b;

    public /* synthetic */ w(int i, Object obj) {
        this.f371a = i;
        this.f372b = obj;
    }

    @Override // p198z7.f
    public final Iterator iterator() {
        switch (this.f371a) {
            case 0:
                return new h((CharSequence) this.f372b);
            case 1:
                return ((Iterable) this.f372b).iterator();
            default:
                return (Iterator) this.f372b;
        }
    }
}
