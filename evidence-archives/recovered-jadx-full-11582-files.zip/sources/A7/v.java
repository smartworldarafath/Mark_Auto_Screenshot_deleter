package A7;

import E4.AbstractC0194m;

/* JADX INFO: loaded from: classes.dex */
public abstract class v extends u {
    public static String f(byte[] bArr) {
        return new String(bArr, a.f340a);
    }

    public static boolean g(String str, String str2, boolean z8) {
        p146s7.j.e(str, "<this>");
        p146s7.j.e(str2, "suffix");
        return !z8 ? str.endsWith(str2) : j(str.length() - str2.length(), 0, str2.length(), str, str2, true);
    }

    public static boolean h(String str, String str2, boolean z8) {
        if (str == null) {
            return str2 == null;
        }
        return !z8 ? str.equals(str2) : str.equalsIgnoreCase(str2);
    }

    public static final void i(String str) {
        throw new NumberFormatException(C3.a.h('\'', "Invalid number format: '", str));
    }

    public static boolean j(int i, int i4, int i9, String str, String str2, boolean z8) {
        p146s7.j.e(str, "<this>");
        p146s7.j.e(str2, "other");
        return !z8 ? str.regionMatches(i, str2, i4, i9) : str.regionMatches(z8, i, str2, i4, i9);
    }

    public static String k(int i, String str) {
        if (i < 0) {
            throw new IllegalArgumentException(("Count 'n' must be non-negative, but was " + i + '.').toString());
        }
        if (i == 0) {
            return "";
        }
        int i4 = 1;
        if (i == 1) {
            return str.toString();
        }
        int length = str.length();
        if (length == 0) {
            return "";
        }
        if (length == 1) {
            char cCharAt = str.charAt(0);
            char[] cArr = new char[i];
            for (int i9 = 0; i9 < i; i9++) {
                cArr[i9] = cCharAt;
            }
            return new String(cArr);
        }
        StringBuilder sb = new StringBuilder(str.length() * i);
        if (1 <= i) {
            while (true) {
                sb.append((CharSequence) str);
                if (i4 == i) {
                    break;
                }
                i4++;
            }
        }
        String string = sb.toString();
        p146s7.j.b(string);
        return string;
    }

    public static String l(String str, String str2, String str3) {
        p146s7.j.e(str, "<this>");
        int iW = n.w(str, str2, 0, false);
        if (iW < 0) {
            return str;
        }
        int length = str2.length();
        int i = length >= 1 ? length : 1;
        int length2 = str3.length() + (str.length() - length);
        if (length2 < 0) {
            throw new OutOfMemoryError();
        }
        StringBuilder sb = new StringBuilder(length2);
        int i4 = 0;
        do {
            sb.append((CharSequence) str, i4, iW);
            sb.append(str3);
            i4 = iW + length;
            if (iW >= str.length()) {
                break;
            }
            iW = n.w(str, str2, iW + i, false);
        } while (iW > 0);
        sb.append((CharSequence) str, i4, str.length());
        String string = sb.toString();
        p146s7.j.d(string, "toString(...)");
        return string;
    }

    public static boolean m(String str, int i, String str2, boolean z8) {
        p146s7.j.e(str, "<this>");
        return !z8 ? str.startsWith(str2, i) : j(i, 0, str2.length(), str, str2, z8);
    }

    public static boolean n(String str, String str2, boolean z8) {
        p146s7.j.e(str, "<this>");
        p146s7.j.e(str2, "prefix");
        return !z8 ? str.startsWith(str2) : j(0, 0, str2.length(), str, str2, z8);
    }

    public static Integer o(String str) {
        boolean z8;
        int i;
        int i4;
        p146s7.j.e(str, "<this>");
        AbstractC0194m.a(10);
        int length = str.length();
        if (length == 0) {
            return null;
        }
        int i9 = 0;
        char cCharAt = str.charAt(0);
        int i10 = -2147483647;
        if (p146s7.j.f(cCharAt, 48) < 0) {
            i = 1;
            if (length == 1) {
                return null;
            }
            if (cCharAt == '+') {
                z8 = false;
            } else {
                if (cCharAt != '-') {
                    return null;
                }
                i10 = Integer.MIN_VALUE;
                z8 = true;
            }
        } else {
            z8 = false;
            i = 0;
        }
        int i11 = -59652323;
        while (i < length) {
            int iDigit = Character.digit((int) str.charAt(i), 10);
            if (iDigit < 0) {
                return null;
            }
            if ((i9 < i11 && (i11 != -59652323 || i9 < (i11 = i10 / 10))) || (i4 = i9 * 10) < i10 + iDigit) {
                return null;
            }
            i9 = i4 - iDigit;
            i++;
        }
        return z8 ? Integer.valueOf(i9) : Integer.valueOf(-i9);
    }

    public static Long p(String str) {
        boolean z8;
        p146s7.j.e(str, "<this>");
        AbstractC0194m.a(10);
        int length = str.length();
        if (length == 0) {
            return null;
        }
        int i = 0;
        char cCharAt = str.charAt(0);
        long j9 = -9223372036854775807L;
        if (p146s7.j.f(cCharAt, 48) < 0) {
            z8 = true;
            if (length == 1) {
                return null;
            }
            if (cCharAt == '+') {
                z8 = false;
                i = 1;
            } else {
                if (cCharAt != '-') {
                    return null;
                }
                j9 = Long.MIN_VALUE;
                i = 1;
            }
        } else {
            z8 = false;
        }
        long j10 = 0;
        long j11 = -256204778801521550L;
        while (i < length) {
            int iDigit = Character.digit((int) str.charAt(i), 10);
            if (iDigit < 0) {
                return null;
            }
            if (j10 < j11) {
                if (j11 != -256204778801521550L) {
                    return null;
                }
                j11 = j9 / ((long) 10);
                if (j10 < j11) {
                    return null;
                }
            }
            long j12 = j10 * ((long) 10);
            long j13 = iDigit;
            if (j12 < j9 + j13) {
                return null;
            }
            j10 = j12 - j13;
            i++;
        }
        return z8 ? Long.valueOf(j10) : Long.valueOf(-j10);
    }
}
