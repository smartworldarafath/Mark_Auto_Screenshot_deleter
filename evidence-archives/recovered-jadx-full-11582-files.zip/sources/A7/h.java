package A7;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes.dex */
public final class h implements Iterator, p154t7.a {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final CharSequence f357t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f358u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f359v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f360w;
    public int x;

    public h(CharSequence charSequence) {
        p146s7.j.e(charSequence, "string");
        this.f357t = charSequence;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        int i;
        int i4;
        int i9 = this.f358u;
        if (i9 != 0) {
            return i9 == 1;
        }
        if (this.x < 0) {
            this.f358u = 2;
            return false;
        }
        CharSequence charSequence = this.f357t;
        int length = charSequence.length();
        int length2 = charSequence.length();
        for (int i10 = this.f359v; i10 < length2; i10++) {
            char cCharAt = charSequence.charAt(i10);
            if (cCharAt == '\n' || cCharAt == '\r') {
                i = (cCharAt == '\r' && (i4 = i10 + 1) < charSequence.length() && charSequence.charAt(i4) == '\n') ? 2 : 1;
                length = i10;
                this.f358u = 1;
                this.x = i;
                this.f360w = length;
                return true;
            }
        }
        i = -1;
        this.f358u = 1;
        this.x = i;
        this.f360w = length;
        return true;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        this.f358u = 0;
        int i = this.f360w;
        int i4 = this.f359v;
        this.f359v = this.x + i;
        return this.f357t.subSequence(i4, i).toString();
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
