package A7;

import java.nio.charset.Charset;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Charset f340a;

    static {
        Charset charsetForName = Charset.forName("UTF-8");
        p146s7.j.d(charsetForName, "forName(...)");
        f340a = charsetForName;
        p146s7.j.d(Charset.forName("UTF-16"), "forName(...)");
        p146s7.j.d(Charset.forName("UTF-16BE"), "forName(...)");
        p146s7.j.d(Charset.forName("UTF-16LE"), "forName(...)");
        p146s7.j.d(Charset.forName("US-ASCII"), "forName(...)");
        p146s7.j.d(Charset.forName("ISO-8859-1"), "forName(...)");
    }
}
