package A7;

import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class c implements p198z7.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f345a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f346b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final p032d7.e f347c;

    public /* synthetic */ c(int i, Object obj, p137r7.c cVar) {
        this.f345a = i;
        this.f346b = obj;
        this.f347c = cVar;
    }

    @Override // p198z7.f
    public final Iterator iterator() {
        switch (this.f345a) {
            case 0:
                return new b(this);
            case 1:
                return new p198z7.e(this);
            default:
                return new p050g0.c(this);
        }
    }

    public c(CharSequence charSequence, p137r7.e eVar) {
        this.f345a = 0;
        p146s7.j.e(charSequence, "input");
        this.f346b = charSequence;
        this.f347c = eVar;
    }
}
