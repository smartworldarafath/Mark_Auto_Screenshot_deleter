package A7;

import com.google.ads.mediation.facebook.FacebookMediationAdapter;

/* JADX INFO: loaded from: classes.dex */
public abstract class u extends t {
    /* JADX WARN: Code duplicated, block: B:106:0x0121  */
    /* JADX WARN: Code duplicated, block: B:69:0x00c5  */
    public static final boolean e(String str) {
        char c9;
        boolean z8;
        boolean z9;
        int i;
        boolean z10;
        String str2;
        boolean z11;
        boolean z12 = true;
        int length = str.length() - 1;
        int i4 = 0;
        while (true) {
            c9 = ' ';
            if (i4 > length || str.charAt(i4) > ' ') {
                break;
            }
            i4++;
        }
        if (i4 > length) {
            return false;
        }
        while (length > i4 && str.charAt(length) <= ' ') {
            length--;
        }
        if (str.charAt(i4) == '+' || str.charAt(i4) == '-') {
            i4++;
        }
        if (i4 > length) {
            return false;
        }
        if (str.charAt(i4) != '0') {
            z8 = true;
            z9 = false;
        } else {
            int i9 = i4 + 1;
            if (i9 > length) {
                return true;
            }
            if ((str.charAt(i9) | ' ') == 120) {
                int i10 = i4 + 2;
                int i11 = i10;
                while (true) {
                    if (i11 > length) {
                        z8 = z12;
                        break;
                    }
                    char cCharAt = str.charAt(i11);
                    z8 = z12;
                    if (((cCharAt - '0') & 65535) >= 10 && (((cCharAt | ' ') - 97) & 65535) >= 6) {
                        break;
                    }
                    i11++;
                    z12 = z8;
                }
                boolean z13 = i10 != i11 ? z8 : false;
                if (i11 <= length) {
                    if (str.charAt(i11) == '.') {
                        int i12 = i11 + 1;
                        int i13 = i12;
                        while (i13 <= length) {
                            char cCharAt2 = str.charAt(i13);
                            char c10 = c9;
                            if (((cCharAt2 - '0') & 65535) >= 10 && (((cCharAt2 | ' ') - 97) & 65535) >= 6) {
                                break;
                            }
                            i13++;
                            c9 = c10;
                        }
                        z11 = i12 != i13 ? z8 : false;
                        i11 = i13;
                    } else {
                        z11 = false;
                    }
                    if (z13 || z11) {
                        i4 = i11;
                    }
                    if (i4 != -1 || i4 > length) {
                        return false;
                    }
                    z9 = z8;
                }
                i4 = -1;
                if (i4 != -1) {
                }
                return false;
            }
            z8 = true;
            z9 = false;
        }
        if (!z9) {
            int i14 = i4;
            while (i14 <= length && ((str.charAt(i14) - '0') & 65535) < 10) {
                i14++;
            }
            boolean z14 = i4 != i14 ? z8 : false;
            if (i14 > length) {
                i4 = i14;
            } else {
                if (str.charAt(i14) == '.') {
                    int i15 = i14 + 1;
                    i = i15;
                    while (i <= length && ((str.charAt(i) - '0') & 65535) < 10) {
                        i++;
                    }
                    if (i15 != i) {
                        z10 = z8;
                    }
                    if (!z14 || z10) {
                        i4 = i;
                    } else {
                        if (length == i + 2) {
                            str2 = "NaN";
                        } else {
                            str2 = length == i + 7 ? "Infinity" : null;
                        }
                        i4 = (str2 != null && n.w(str, str2, i, false) == i) ? length + 1 : -1;
                    }
                } else {
                    i = i14;
                }
                z10 = false;
                if (z14) {
                    i4 = i;
                } else {
                    i4 = i;
                }
            }
            if (i4 == -1) {
                return false;
            }
            if (i4 > length) {
                return z8;
            }
        }
        int i16 = i4 + 1;
        int iCharAt = str.charAt(i4) | ' ';
        if (iCharAt != (z9 ? 112 : FacebookMediationAdapter.ERROR_INVALID_SERVER_PARAMETERS)) {
            if (z9 || (!(iCharAt == 102 || iCharAt == 100) || i16 <= length)) {
                return false;
            }
            return z8;
        }
        if (i16 > length) {
            return false;
        }
        if ((str.charAt(i16) == '+' || str.charAt(i16) == '-') && (i16 = i4 + 2) > length) {
            return false;
        }
        while (i16 <= length && ((str.charAt(i16) - '0') & 65535) < 10) {
            i16++;
        }
        if (i16 > length) {
            return z8;
        }
        if (i16 != length) {
            return false;
        }
        int iCharAt2 = str.charAt(i16) | ' ';
        if (iCharAt2 == 102 || iCharAt2 == 100) {
            return z8;
        }
        return false;
    }
}
