package A7;

import com.google.android.gms.internal.measurement.AbstractC5061q1;
import java.util.ArrayList;
import p032d7.z;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class o implements p137r7.c {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f369t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ String f370u;

    public /* synthetic */ o(String str, int i) {
        this.f369t = i;
        this.f370u = str;
    }

    @Override // p137r7.c
    public final Object g(Object obj) throws Exception {
        switch (this.f369t) {
            case 0:
                String str = (String) obj;
                p146s7.j.e(str, "it");
                boolean zB = n.B(str);
                String str2 = this.f370u;
                if (zB) {
                    return str.length() < str2.length() ? str2 : str;
                }
                return AbstractC5061q1.l(str2, str);
            case 1:
                p162v2.c cVarD0 = ((p162v2.a) obj).d0("SELECT screenshotId FROM screenshot_index_entity WHERE extractedText LIKE '%' || ? || '%' OR labels LIKE '%' || ? || '%' ORDER BY indexedAtEpochMillis DESC");
                String str3 = this.f370u;
                try {
                    if (str3 == null) {
                        cVarD0.d(1);
                    } else {
                        cVarD0.r(1, str3);
                    }
                    if (str3 == null) {
                        cVarD0.d(2);
                    } else {
                        cVarD0.r(2, str3);
                    }
                    ArrayList arrayList = new ArrayList();
                    while (cVarD0.Y()) {
                        arrayList.add(cVarD0.isNull(0) ? null : Long.valueOf(cVarD0.getLong(0)));
                        break;
                    }
                    cVarD0.close();
                    return arrayList;
                } catch (Throwable th) {
                    cVarD0.close();
                    throw th;
                }
            default:
                T0.j jVar = (T0.j) obj;
                T0.u.b(jVar, this.f370u);
                T0.u.c(jVar, 5);
                return z.f26831a;
        }
    }
}
