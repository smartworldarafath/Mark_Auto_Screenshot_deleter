package A7;

/* JADX INFO: loaded from: classes.dex */
public abstract class q extends p {
}
