package A7;

import A.o0;
import E4.AbstractC0194m;
import F4.Z6;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import p040e7.x;

/* JADX INFO: loaded from: classes.dex */
public abstract class n extends v {
    public static final int A(CharSequence charSequence, char[] cArr, int i, boolean z8) {
        p146s7.j.e(charSequence, "<this>");
        if (!z8 && cArr.length == 1 && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(p040e7.k.w(cArr), i);
        }
        if (i < 0) {
            i = 0;
        }
        int iV = v(charSequence);
        if (i > iV) {
            return -1;
        }
        while (true) {
            char cCharAt = charSequence.charAt(i);
            for (char c9 : cArr) {
                if (AbstractC0194m.b(c9, cCharAt, z8)) {
                    return i;
                }
            }
            if (i == iV) {
                return -1;
            }
            i++;
        }
    }

    public static boolean B(CharSequence charSequence) {
        p146s7.j.e(charSequence, "<this>");
        for (int i = 0; i < charSequence.length(); i++) {
            if (!AbstractC0194m.c(charSequence.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static char C(CharSequence charSequence) {
        if (charSequence.length() != 0) {
            return charSequence.charAt(v(charSequence));
        }
        throw new NoSuchElementException("Char sequence is empty.");
    }

    public static int D(CharSequence charSequence, char c9, int i, int i4) {
        if ((i4 & 2) != 0) {
            i = v(charSequence);
        }
        p146s7.j.e(charSequence, "<this>");
        if (charSequence instanceof String) {
            return ((String) charSequence).lastIndexOf(c9, i);
        }
        char[] cArr = {c9};
        if (charSequence instanceof String) {
            return ((String) charSequence).lastIndexOf(p040e7.k.w(cArr), i);
        }
        int iV = v(charSequence);
        if (i > iV) {
            i = iV;
        }
        while (-1 < i) {
            if (AbstractC0194m.b(cArr[0], charSequence.charAt(i), false)) {
                return i;
            }
            i--;
        }
        return -1;
    }

    public static int E(String str, int i, String str2) {
        int iV = (i & 2) != 0 ? v(str) : 0;
        p146s7.j.e(str, "<this>");
        p146s7.j.e(str2, "string");
        return str.lastIndexOf(str2, iV);
    }

    public static String F(int i, String str) {
        CharSequence charSequenceSubSequence;
        p146s7.j.e(str, "<this>");
        if (i < 0) {
            throw new IllegalArgumentException(X3.b.j("Desired length ", i, " is less than zero."));
        }
        if (i <= str.length()) {
            charSequenceSubSequence = str.subSequence(0, str.length());
        } else {
            StringBuilder sb = new StringBuilder(i);
            int length = i - str.length();
            int i4 = 1;
            if (1 <= length) {
                while (true) {
                    sb.append('0');
                    if (i4 == length) {
                        break;
                    }
                    i4++;
                }
            }
            sb.append((CharSequence) str);
            charSequenceSubSequence = sb;
        }
        return charSequenceSubSequence.toString();
    }

    public static final boolean G(CharSequence charSequence, int i, CharSequence charSequence2, int i4, int i9, boolean z8) {
        p146s7.j.e(charSequence, "<this>");
        p146s7.j.e(charSequence2, "other");
        if (i4 < 0 || i < 0 || i > charSequence.length() - i9 || i4 > charSequence2.length() - i9) {
            return false;
        }
        for (int i10 = 0; i10 < i9; i10++) {
            if (!AbstractC0194m.b(charSequence.charAt(i + i10), charSequence2.charAt(i4 + i10), z8)) {
                return false;
            }
        }
        return true;
    }

    public static String H(String str, String str2) {
        if (!v.n(str, str2, false)) {
            return str;
        }
        String strSubstring = str.substring(str2.length());
        p146s7.j.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    public static String I(String str, String str2) {
        if (!u(str, str2)) {
            return str;
        }
        String strSubstring = str.substring(0, str.length() - str2.length());
        p146s7.j.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    public static final List J(CharSequence charSequence, String str) {
        int iW = w(charSequence, str, 0, false);
        if (iW == -1) {
            return Z6.c(charSequence.toString());
        }
        ArrayList arrayList = new ArrayList(10);
        int length = 0;
        do {
            arrayList.add(charSequence.subSequence(length, iW).toString());
            length = str.length() + iW;
            iW = w(charSequence, str, length, false);
        } while (iW != -1);
        arrayList.add(charSequence.subSequence(length, charSequence.length()).toString());
        return arrayList;
    }

    public static List K(String str, char[] cArr) {
        p146s7.j.e(str, "<this>");
        if (cArr.length == 1) {
            return J(str, String.valueOf(cArr[0]));
        }
        x xVar = new x(1, new c(str, new o0(4, cArr)));
        ArrayList arrayList = new ArrayList(p040e7.n.l(xVar, 10));
        Iterator it = xVar.iterator();
        while (true) {
            b bVar = (b) it;
            if (!bVar.hasNext()) {
                return arrayList;
            }
            p181x7.d dVar = (p181x7.d) bVar.next();
            p146s7.j.e(dVar, "range");
            arrayList.add(str.subSequence(dVar.f32547t, dVar.f32548u + 1).toString());
        }
    }

    public static boolean L(String str, char c9) {
        return str.length() > 0 && AbstractC0194m.b(str.charAt(0), c9, false);
    }

    public static String M(char c9, String str, String str2) {
        int iY = y(str, c9, 0, 6);
        if (iY == -1) {
            return str2;
        }
        String strSubstring = str.substring(iY + 1, str.length());
        p146s7.j.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    public static String N(String str, String str2, String str3) {
        p146s7.j.e(str2, "delimiter");
        int iZ = z(str, str2, 0, 6);
        if (iZ == -1) {
            return str3;
        }
        String strSubstring = str.substring(str2.length() + iZ, str.length());
        p146s7.j.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    public static String O(char c9, String str, String str2) {
        p146s7.j.e(str, "<this>");
        p146s7.j.e(str2, "missingDelimiterValue");
        int iD = D(str, c9, 0, 6);
        if (iD == -1) {
            return str2;
        }
        String strSubstring = str.substring(iD + 1, str.length());
        p146s7.j.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    public static String P(String str, char c9) {
        int iY = y(str, c9, 0, 6);
        if (iY == -1) {
            return str;
        }
        String strSubstring = str.substring(0, iY);
        p146s7.j.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    public static String Q(String str, char c9) {
        p146s7.j.e(str, "<this>");
        p146s7.j.e(str, "missingDelimiterValue");
        int iD = D(str, c9, 0, 6);
        if (iD == -1) {
            return str;
        }
        String strSubstring = str.substring(0, iD);
        p146s7.j.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    public static String R(int i, String str) {
        p146s7.j.e(str, "<this>");
        if (i < 0) {
            throw new IllegalArgumentException(X3.b.j("Requested character count ", i, " is less than zero.").toString());
        }
        int length = str.length();
        if (i > length) {
            i = length;
        }
        String strSubstring = str.substring(0, i);
        p146s7.j.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    public static CharSequence S(CharSequence charSequence) {
        p146s7.j.e(charSequence, "<this>");
        int length = charSequence.length() - 1;
        int i = 0;
        boolean z8 = false;
        while (i <= length) {
            boolean zC = AbstractC0194m.c(charSequence.charAt(!z8 ? i : length));
            if (z8) {
                if (!zC) {
                    break;
                }
                length--;
            } else if (zC) {
                i++;
            } else {
                z8 = true;
            }
        }
        return charSequence.subSequence(i, length + 1);
    }

    public static boolean q(CharSequence charSequence, char c9) {
        p146s7.j.e(charSequence, "<this>");
        return y(charSequence, c9, 0, 2) >= 0;
    }

    public static boolean r(CharSequence charSequence, CharSequence charSequence2) {
        p146s7.j.e(charSequence, "<this>");
        p146s7.j.e(charSequence2, "other");
        if (charSequence2 instanceof String) {
            if (z(charSequence, (String) charSequence2, 0, 2) >= 0) {
                return true;
            }
        } else if (x(charSequence, charSequence2, 0, charSequence.length(), false, false) >= 0) {
            return true;
        }
        return false;
    }

    public static String s(int i, String str) {
        p146s7.j.e(str, "<this>");
        if (i < 0) {
            throw new IllegalArgumentException(X3.b.j("Requested character count ", i, " is less than zero.").toString());
        }
        int length = str.length();
        if (i > length) {
            i = length;
        }
        String strSubstring = str.substring(i);
        p146s7.j.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    public static boolean t(CharSequence charSequence, char c9) {
        p146s7.j.e(charSequence, "<this>");
        return charSequence.length() > 0 && AbstractC0194m.b(charSequence.charAt(v(charSequence)), c9, false);
    }

    public static boolean u(CharSequence charSequence, String str) {
        return charSequence instanceof String ? v.g((String) charSequence, str, false) : G(charSequence, charSequence.length() - str.length(), str, 0, str.length(), false);
    }

    public static final int v(CharSequence charSequence) {
        p146s7.j.e(charSequence, "<this>");
        return charSequence.length() - 1;
    }

    public static final int w(CharSequence charSequence, String str, int i, boolean z8) {
        p146s7.j.e(charSequence, "<this>");
        p146s7.j.e(str, "string");
        return (z8 || !(charSequence instanceof String)) ? x(charSequence, str, i, charSequence.length(), z8, false) : ((String) charSequence).indexOf(str, i);
    }

    public static final int x(CharSequence charSequence, CharSequence charSequence2, int i, int i4, boolean z8, boolean z9) {
        p181x7.b bVar;
        if (z9) {
            int iV = v(charSequence);
            if (i > iV) {
                i = iV;
            }
            if (i4 < 0) {
                i4 = 0;
            }
            bVar = new p181x7.b(i, i4, -1);
        } else {
            if (i < 0) {
                i = 0;
            }
            int length = charSequence.length();
            if (i4 > length) {
                i4 = length;
            }
            bVar = new p181x7.d(i, i4, 1);
        }
        boolean z10 = charSequence instanceof String;
        int i9 = bVar.f32549v;
        int i10 = bVar.f32548u;
        int i11 = bVar.f32547t;
        if (!z10 || !(charSequence2 instanceof String)) {
            boolean z11 = z8;
            if ((i9 > 0 && i11 <= i10) || (i9 < 0 && i10 <= i11)) {
                while (true) {
                    CharSequence charSequence3 = charSequence;
                    CharSequence charSequence4 = charSequence2;
                    boolean z12 = z11;
                    z11 = z12;
                    if (G(charSequence4, 0, charSequence3, i11, charSequence2.length(), z12)) {
                        return i11;
                    }
                    if (i11 != i10) {
                        i11 += i9;
                        charSequence2 = charSequence4;
                        charSequence = charSequence3;
                    }
                }
            }
        } else if ((i9 > 0 && i11 <= i10) || (i9 < 0 && i10 <= i11)) {
            int i12 = i11;
            while (true) {
                String str = (String) charSequence2;
                boolean z13 = z8;
                if (v.j(0, i12, str.length(), str, (String) charSequence, z13)) {
                    return i12;
                }
                if (i12 != i10) {
                    i12 += i9;
                    z8 = z13;
                }
            }
        }
        return -1;
    }

    public static int y(CharSequence charSequence, char c9, int i, int i4) {
        if ((i4 & 2) != 0) {
            i = 0;
        }
        p146s7.j.e(charSequence, "<this>");
        return !(charSequence instanceof String) ? A(charSequence, new char[]{c9}, i, false) : ((String) charSequence).indexOf(c9, i);
    }

    public static /* synthetic */ int z(CharSequence charSequence, String str, int i, int i4) {
        if ((i4 & 2) != 0) {
            i = 0;
        }
        return w(charSequence, str, i, false);
    }
}
