package A7;

import E4.AbstractC0194m;
import F4.Z6;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class p {
    public static void a(StringBuilder sb, Object obj, p137r7.c cVar) {
        if (cVar != null) {
            sb.append((CharSequence) cVar.g(obj));
            return;
        }
        if (obj == null ? true : obj instanceof CharSequence) {
            sb.append((CharSequence) obj);
        } else if (obj instanceof Character) {
            sb.append(((Character) obj).charValue());
        } else {
            sb.append((CharSequence) obj.toString());
        }
    }

    public static String b(String str) {
        p146s7.j.e(str, "<this>");
        int i = 0;
        return p198z7.h.d(new p198z7.j(new w(i, str), new o("    ", i), 1), "\n");
    }

    public static String c(String str) {
        List listC;
        Comparable comparable;
        p146s7.j.e(str, "<this>");
        h hVar = new h(str);
        if (hVar.hasNext()) {
            Object next = hVar.next();
            if (hVar.hasNext()) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(next);
                while (hVar.hasNext()) {
                    arrayList.add(hVar.next());
                }
                listC = arrayList;
            } else {
                listC = Z6.c(next);
            }
        } else {
            listC = p040e7.t.f26995t;
        }
        ArrayList arrayList2 = new ArrayList();
        for (Object obj : listC) {
            if (!n.B((String) obj)) {
                arrayList2.add(obj);
            }
        }
        ArrayList arrayList3 = new ArrayList(p040e7.n.l(arrayList2, 10));
        int size = arrayList2.size();
        int i = 0;
        int i4 = 0;
        while (i4 < size) {
            Object obj2 = arrayList2.get(i4);
            i4++;
            String str2 = (String) obj2;
            int length = str2.length();
            int length2 = 0;
            while (true) {
                if (length2 >= length) {
                    length2 = -1;
                    break;
                }
                if (!AbstractC0194m.c(str2.charAt(length2))) {
                    break;
                }
                length2++;
            }
            if (length2 == -1) {
                length2 = str2.length();
            }
            arrayList3.add(Integer.valueOf(length2));
        }
        Iterator it = arrayList3.iterator();
        if (it.hasNext()) {
            comparable = (Comparable) it.next();
            while (it.hasNext()) {
                Comparable comparable2 = (Comparable) it.next();
                if (comparable.compareTo(comparable2) > 0) {
                    comparable = comparable2;
                }
            }
        } else {
            comparable = null;
        }
        Integer num = (Integer) comparable;
        int iIntValue = num != null ? num.intValue() : 0;
        int length3 = str.length();
        listC.size();
        int iF = p040e7.m.f(listC);
        ArrayList arrayList4 = new ArrayList();
        for (Object obj3 : listC) {
            int i9 = i + 1;
            if (i < 0) {
                p040e7.m.k();
                throw null;
            }
            String str3 = (String) obj3;
            String strS = ((i == 0 || i == iF) && n.B(str3)) ? null : n.s(iIntValue, str3);
            if (strS != null) {
                arrayList4.add(strS);
            }
            i = i9;
        }
        StringBuilder sb = new StringBuilder(length3);
        p040e7.l.z(arrayList4, sb, null, 124);
        return sb.toString();
    }

    public static String d(String str) {
        List listC;
        p146s7.j.e(str, "<this>");
        if (n.B("|")) {
            throw new IllegalArgumentException("marginPrefix must be non-blank string.");
        }
        h hVar = new h(str);
        if (hVar.hasNext()) {
            Object next = hVar.next();
            if (hVar.hasNext()) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(next);
                while (hVar.hasNext()) {
                    arrayList.add(hVar.next());
                }
                listC = arrayList;
            } else {
                listC = Z6.c(next);
            }
        } else {
            listC = p040e7.t.f26995t;
        }
        int length = str.length();
        listC.size();
        int iF = p040e7.m.f(listC);
        ArrayList arrayList2 = new ArrayList();
        Iterator it = listC.iterator();
        int i = 0;
        while (true) {
            String strSubstring = null;
            if (!it.hasNext()) {
                StringBuilder sb = new StringBuilder(length);
                p040e7.l.z(arrayList2, sb, null, 124);
                return sb.toString();
            }
            Object next2 = it.next();
            int i4 = i + 1;
            if (i < 0) {
                p040e7.m.k();
                throw null;
            }
            String str2 = (String) next2;
            if ((i != 0 && i != iF) || !n.B(str2)) {
                int length2 = str2.length();
                int i9 = 0;
                while (true) {
                    if (i9 >= length2) {
                        i9 = -1;
                        break;
                    }
                    if (!AbstractC0194m.c(str2.charAt(i9))) {
                        break;
                    }
                    i9++;
                }
                if (i9 != -1 && v.m(str2, i9, "|", false)) {
                    strSubstring = str2.substring("|".length() + i9);
                    p146s7.j.d(strSubstring, "substring(...)");
                }
                if (strSubstring == null) {
                    strSubstring = str2;
                }
            }
            if (strSubstring != null) {
                arrayList2.add(strSubstring);
            }
            i = i4;
        }
    }
}
