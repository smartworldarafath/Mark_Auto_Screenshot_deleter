package A7;

import F4.X6;
import com.google.android.gms.internal.measurement.AbstractC5061q1;

/* JADX INFO: loaded from: classes.dex */
public abstract class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f348a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final long[] f349b;

    static {
        int[] iArr = new int[256];
        int i = 0;
        for (int i4 = 0; i4 < 256; i4++) {
            iArr[i4] = "0123456789abcdef".charAt(i4 & 15) | ("0123456789abcdef".charAt(i4 >> 4) << '\b');
        }
        f348a = iArr;
        int[] iArr2 = new int[256];
        for (int i9 = 0; i9 < 256; i9++) {
            iArr2[i9] = "0123456789ABCDEF".charAt(i9 & 15) | ("0123456789ABCDEF".charAt(i9 >> 4) << '\b');
        }
        int[] iArr3 = new int[256];
        for (int i10 = 0; i10 < 256; i10++) {
            iArr3[i10] = -1;
        }
        int i11 = 0;
        int i12 = 0;
        while (i11 < "0123456789abcdef".length()) {
            iArr3["0123456789abcdef".charAt(i11)] = i12;
            i11++;
            i12++;
        }
        int i13 = 0;
        int i14 = 0;
        while (i13 < "0123456789ABCDEF".length()) {
            iArr3["0123456789ABCDEF".charAt(i13)] = i14;
            i13++;
            i14++;
        }
        long[] jArr = new long[256];
        for (int i15 = 0; i15 < 256; i15++) {
            jArr[i15] = -1;
        }
        int i16 = 0;
        int i17 = 0;
        while (i16 < "0123456789abcdef".length()) {
            jArr["0123456789abcdef".charAt(i16)] = i17;
            i16++;
            i17++;
        }
        int i18 = 0;
        while (i < "0123456789ABCDEF".length()) {
            jArr["0123456789ABCDEF".charAt(i)] = i18;
            i++;
            i18++;
        }
        f349b = jArr;
    }

    public static final void a(int i, String str, int i4) {
        int i9 = i4 - i;
        if (i9 < 1) {
            String strSubstring = str.substring(i, i4);
            p146s7.j.d(strSubstring, "substring(...)");
            throw new NumberFormatException("Expected at least 1 hexadecimal digits at index " + i + ", but was \"" + strSubstring + "\" of length " + i9);
        }
        if (i9 > 16) {
            int i10 = (i9 + i) - 16;
            while (i < i10) {
                if (str.charAt(i) != '0') {
                    StringBuilder sbP = AbstractC5061q1.p("Expected the hexadecimal digit '0' at index ", i, ", but was '");
                    sbP.append(str.charAt(i));
                    sbP.append("'.\nThe result won't fit the type being parsed.");
                    throw new NumberFormatException(sbP.toString());
                }
                i++;
            }
        }
    }

    public static long b(int i, String str, int i4) {
        g gVar = g.f353d;
        p146s7.j.e(gVar, "format");
        X6.a(i, i4, str.length());
        if (gVar.f356c.f352a) {
            a(i, str, i4);
            return c(i, str, i4);
        }
        if (i4 - i > 0) {
            a(i, str, i4);
            return c(i, str, i4);
        }
        String strSubstring = str.substring(i, i4);
        p146s7.j.d(strSubstring, "substring(...)");
        throw new NumberFormatException("Expected a hexadecimal number with prefix \"\" and suffix \"\", but was ".concat(strSubstring));
    }

    public static final long c(int i, String str, int i4) {
        long j9 = 0;
        while (i < i4) {
            long j10 = j9 << 4;
            char cCharAt = str.charAt(i);
            if ((cCharAt >>> '\b') == 0) {
                long j11 = f349b[cCharAt];
                if (j11 >= 0) {
                    j9 = j10 | j11;
                    i++;
                }
            }
            StringBuilder sbP = AbstractC5061q1.p("Expected a hexadecimal digit at index ", i, ", but was ");
            sbP.append(str.charAt(i));
            throw new NumberFormatException(sbP.toString());
        }
        return j9;
    }
}
