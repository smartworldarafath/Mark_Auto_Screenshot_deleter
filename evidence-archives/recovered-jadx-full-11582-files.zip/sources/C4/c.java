package C4;

import E4.AbstractC0271z;

/* JADX INFO: loaded from: classes.dex */
public final class c extends e {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final transient e f783v;

    public c(e eVar) {
        this.f783v = eVar;
    }

    @Override // C4.e, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(Object obj) {
        return this.f783v.contains(obj);
    }

    @Override // C4.e
    public final e g() {
        return this.f783v;
    }

    @Override // java.util.List
    public final Object get(int i) {
        e eVar = this.f783v;
        AbstractC0271z.a(i, eVar.size());
        return eVar.get((eVar.size() - 1) - i);
    }

    @Override // C4.e, java.util.List
    /* JADX INFO: renamed from: h */
    public final e subList(int i, int i4) {
        e eVar = this.f783v;
        AbstractC0271z.b(i, i4, eVar.size());
        return eVar.subList(eVar.size() - i4, eVar.size() - i).g();
    }

    @Override // C4.e, java.util.List
    public final int indexOf(Object obj) {
        e eVar = this.f783v;
        int iLastIndexOf = eVar.lastIndexOf(obj);
        if (iLastIndexOf >= 0) {
            return (eVar.size() - 1) - iLastIndexOf;
        }
        return -1;
    }

    @Override // C4.e, java.util.List
    public final int lastIndexOf(Object obj) {
        e eVar = this.f783v;
        int iIndexOf = eVar.indexOf(obj);
        if (iIndexOf >= 0) {
            return (eVar.size() - 1) - iIndexOf;
        }
        return -1;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f783v.size();
    }
}
