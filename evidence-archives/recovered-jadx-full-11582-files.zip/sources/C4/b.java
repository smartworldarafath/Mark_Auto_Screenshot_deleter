package C4;

import E4.AbstractC0271z;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes.dex */
public final class b extends g implements ListIterator {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final int f780u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f781v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final e f782w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(e eVar, int i) {
        super(0);
        int size = eVar.size();
        if (i < 0 || i > size) {
            throw new IndexOutOfBoundsException(AbstractC0271z.c(i, "index", size));
        }
        this.f780u = size;
        this.f781v = i;
        this.f782w = eVar;
    }

    @Override // java.util.ListIterator
    public final void add(Object obj) {
        throw new UnsupportedOperationException();
    }

    public final Object b(int i) {
        return this.f782w.get(i);
    }

    @Override // java.util.Iterator, java.util.ListIterator
    public final boolean hasNext() {
        return this.f781v < this.f780u;
    }

    @Override // java.util.ListIterator
    public final boolean hasPrevious() {
        return this.f781v > 0;
    }

    @Override // C4.g, java.util.Iterator, java.util.ListIterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        int i = this.f781v;
        this.f781v = i + 1;
        return b(i);
    }

    @Override // java.util.ListIterator
    public final int nextIndex() {
        return this.f781v;
    }

    @Override // java.util.ListIterator
    public final Object previous() {
        if (!hasPrevious()) {
            throw new NoSuchElementException();
        }
        int i = this.f781v - 1;
        this.f781v = i;
        return b(i);
    }

    @Override // java.util.ListIterator
    public final int previousIndex() {
        return this.f781v - 1;
    }

    @Override // java.util.ListIterator
    public final void set(Object obj) {
        throw new UnsupportedOperationException();
    }
}
