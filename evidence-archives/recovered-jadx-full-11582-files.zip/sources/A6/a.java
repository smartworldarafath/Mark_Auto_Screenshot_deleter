package A6;

import p098m3.h;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements p137r7.a {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f330t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ h f331u;

    public /* synthetic */ a(h hVar, int i) {
        this.f330t = i;
        this.f331u = hVar;
    }

    @Override // p137r7.a
    public final Object a() {
        float fFloatValue;
        switch (this.f330t) {
            case 0:
                fFloatValue = ((Number) this.f331u.getValue()).floatValue();
                break;
            default:
                fFloatValue = ((Number) this.f331u.getValue()).floatValue();
                break;
        }
        return Float.valueOf(fFloatValue);
    }
}
