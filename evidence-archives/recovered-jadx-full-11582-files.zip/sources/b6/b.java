package b6;

import M0.AbstractC1035c;

/* JADX INFO: loaded from: classes.dex */
public final class b extends AbstractC1035c {
}
