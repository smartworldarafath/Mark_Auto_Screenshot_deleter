package b6;

import E4.AbstractC0180j3;
import H4.C0761x;
import H4.Z7;
import T5.q;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f13768a;

    public d(Z7 z8) {
        ArrayList arrayList = new ArrayList();
        this.f13768a = z8.f3660t;
        arrayList.addAll(AbstractC0180j3.a(z8.f3661u, new q(6)));
    }

    public d(String str, C0761x c0761x) {
        new ArrayList().addAll(c0761x);
        this.f13768a = str;
    }
}
