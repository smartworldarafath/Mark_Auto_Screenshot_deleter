package b6;

import androidx.lifecycle.E;
import androidx.lifecycle.EnumC1404o;
import androidx.lifecycle.InterfaceC1410v;
import java.io.Closeable;
import p106n4.j;

/* JADX INFO: loaded from: classes.dex */
public interface e extends Closeable, InterfaceC1410v, j {
    @Override // java.io.Closeable, java.lang.AutoCloseable
    @E(EnumC1404o.ON_DESTROY)
    void close();
}
