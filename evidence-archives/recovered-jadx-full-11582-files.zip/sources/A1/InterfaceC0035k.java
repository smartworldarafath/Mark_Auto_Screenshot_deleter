package A1;

import android.view.View;
import androidx.core.widget.NestedScrollView;

/* JADX INFO: renamed from: A1.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0035k {
    void b(NestedScrollView nestedScrollView, int i, int i4, int i9, int i10, int i11);

    boolean e(View view, View view2, int i, int i4);

    void f(View view, View view2, int i, int i4);

    void g(View view, int i);

    void i(int i, int i4, int[] iArr, int i9);
}
