package A1;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class O extends AnimatorListenerAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ W f199a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f200b;

    public O(W w6, View view) {
        this.f199a = w6;
        this.f200b = view;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        W w6 = this.f199a;
        w6.f220a.e(1.0f);
        S.f(w6, this.f200b);
    }
}
