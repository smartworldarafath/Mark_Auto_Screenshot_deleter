package A1;

import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import android.view.animation.PathInterpolator;
import java.util.Collections;

/* JADX INFO: loaded from: classes.dex */
public final class N implements ValueAnimator.AnimatorUpdateListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ W f194a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ q0 f195b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ q0 f196c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f197d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ View f198e;

    public N(W w6, q0 q0Var, q0 q0Var2, int i, View view) {
        this.f194a = w6;
        this.f195b = q0Var;
        this.f196c = q0Var2;
        this.f197d = i;
        this.f198e = view;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        d0 z8;
        float animatedFraction = valueAnimator.getAnimatedFraction();
        W w6 = this.f194a;
        w6.f220a.e(animatedFraction);
        q0 q0Var = this.f195b;
        l0 l0Var = q0Var.f276a;
        float fC = w6.f220a.c();
        PathInterpolator pathInterpolator = S.f207e;
        int i = Build.VERSION.SDK_INT;
        if (i >= 34) {
            z8 = new c0(q0Var);
        } else if (i >= 31) {
            z8 = new b0(q0Var);
        } else if (i >= 30) {
            z8 = new a0(q0Var);
        } else {
            z8 = i >= 29 ? new Z(q0Var) : new X(q0Var);
        }
        for (int i4 = 1; i4 <= 512; i4 <<= 1) {
            if ((this.f197d & i4) == 0) {
                z8.c(i4, l0Var.g(i4));
            } else {
                t1.b bVarG = l0Var.g(i4);
                t1.b bVarG2 = this.f196c.f276a.g(i4);
                float f4 = 1.0f - fC;
                z8.c(i4, q0.a(bVarG, (int) (((double) ((bVarG.f31354a - bVarG2.f31354a) * f4)) + 0.5d), (int) (((double) ((bVarG.f31355b - bVarG2.f31355b) * f4)) + 0.5d), (int) (((double) ((bVarG.f31356c - bVarG2.f31356c) * f4)) + 0.5d), (int) (((double) ((bVarG.f31357d - bVarG2.f31357d) * f4)) + 0.5d)));
            }
        }
        S.h(this.f198e, z8.b(), Collections.singletonList(w6));
    }
}
