package A1;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;

/* JADX INFO: loaded from: classes.dex */
public final class C implements View.OnApplyWindowInsetsListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public q0 f180a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f181b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0038n f182c;

    public C(View view, InterfaceC0038n interfaceC0038n) {
        this.f181b = view;
        this.f182c = interfaceC0038n;
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        q0 q0VarC = q0.c(view, windowInsets);
        int i = Build.VERSION.SDK_INT;
        InterfaceC0038n interfaceC0038n = this.f182c;
        if (i < 30) {
            D.a(windowInsets, this.f181b);
            if (q0VarC.equals(this.f180a)) {
                return interfaceC0038n.a(view, q0VarC).b();
            }
        }
        this.f180a = q0VarC;
        q0 q0VarA = interfaceC0038n.a(view, q0VarC);
        if (i >= 30) {
            return q0VarA.b();
        }
        Field field = J.f187a;
        B.b(view);
        return q0VarA.b();
    }
}
