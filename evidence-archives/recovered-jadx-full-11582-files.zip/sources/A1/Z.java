package A1;

import android.view.WindowInsets;

/* JADX INFO: loaded from: classes.dex */
public class Z extends d0 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final WindowInsets.Builder f227c;

    public Z() {
        this.f227c = Y.e();
    }

    @Override // A1.d0
    public q0 b() {
        a();
        q0 q0VarC = q0.c(null, this.f227c.build());
        q0VarC.f276a.r(this.f242b);
        return q0VarC;
    }

    @Override // A1.d0
    public void d(t1.b bVar) {
        this.f227c.setMandatorySystemGestureInsets(bVar.d());
    }

    @Override // A1.d0
    public void e(t1.b bVar) {
        this.f227c.setStableInsets(bVar.d());
    }

    @Override // A1.d0
    public void f(t1.b bVar) {
        this.f227c.setSystemGestureInsets(bVar.d());
    }

    @Override // A1.d0
    public void g(t1.b bVar) {
        this.f227c.setSystemWindowInsets(bVar.d());
    }

    @Override // A1.d0
    public void h(t1.b bVar) {
        this.f227c.setTappableElementInsets(bVar.d());
    }

    public Z(q0 q0Var) {
        WindowInsets.Builder builderE;
        super(q0Var);
        WindowInsets windowInsetsB = q0Var.b();
        if (windowInsetsB != null) {
            builderE = Y.f(windowInsetsB);
        } else {
            builderE = Y.e();
        }
        this.f227c = builderE;
    }
}
