package A1;

import android.graphics.Rect;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import android.window.BackEvent;

/* JADX INFO: renamed from: A1.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0047x {
    public static AccessibilityNodeInfo.AccessibilityAction a() {
        return AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_IN_DIRECTION;
    }

    public static float b(VelocityTracker velocityTracker, int i) {
        return velocityTracker.getAxisVelocity(i);
    }

    public static void c(AccessibilityNodeInfo accessibilityNodeInfo, Rect rect) {
        accessibilityNodeInfo.getBoundsInWindow(rect);
    }

    public static CharSequence d(AccessibilityNodeInfo accessibilityNodeInfo) {
        return accessibilityNodeInfo.getContainerTitle();
    }

    public static int e(ViewConfiguration viewConfiguration, int i, int i4, int i9) {
        return viewConfiguration.getScaledMaximumFlingVelocity(i, i4, i9);
    }

    public static int f(ViewConfiguration viewConfiguration, int i, int i4, int i9) {
        return viewConfiguration.getScaledMinimumFlingVelocity(i, i4, i9);
    }

    public static boolean g(AccessibilityNodeInfo accessibilityNodeInfo) {
        return accessibilityNodeInfo.isAccessibilityDataSensitive();
    }

    public static boolean h(AccessibilityManager accessibilityManager) {
        return accessibilityManager.isRequestFromAccessibilityTool();
    }

    public static float i(BackEvent backEvent) {
        return backEvent.getProgress();
    }

    public static void j(AccessibilityEvent accessibilityEvent, boolean z8) {
        accessibilityEvent.setAccessibilityDataSensitive(z8);
    }

    public static void k(AccessibilityNodeInfo accessibilityNodeInfo, boolean z8) {
        accessibilityNodeInfo.setAccessibilityDataSensitive(z8);
    }

    public static void l(TextView textView, int i, float f4) {
        textView.setLineHeight(i, f4);
    }

    public static int m(BackEvent backEvent) {
        return backEvent.getSwipeEdge();
    }

    public static float n(BackEvent backEvent) {
        return backEvent.getTouchX();
    }

    public static float o(BackEvent backEvent) {
        return backEvent.getTouchY();
    }
}
