package A1;

import android.view.WindowInsets;

/* JADX INFO: loaded from: classes.dex */
public class f0 extends e0 {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public t1.b f253n;

    public f0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var, windowInsets);
        this.f253n = null;
    }

    @Override // A1.l0
    public q0 b() {
        return q0.c(null, this.f247c.consumeStableInsets());
    }

    @Override // A1.l0
    public q0 c() {
        return q0.c(null, this.f247c.consumeSystemWindowInsets());
    }

    @Override // A1.l0
    public final t1.b j() {
        if (this.f253n == null) {
            WindowInsets windowInsets = this.f247c;
            this.f253n = t1.b.b(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
        }
        return this.f253n;
    }

    @Override // A1.l0
    public boolean o() {
        return this.f247c.isConsumed();
    }

    @Override // A1.l0
    public void u(t1.b bVar) {
        this.f253n = bVar;
    }

    public f0(q0 q0Var, f0 f0Var) {
        super(q0Var, f0Var);
        this.f253n = null;
        this.f253n = f0Var.f253n;
    }
}
