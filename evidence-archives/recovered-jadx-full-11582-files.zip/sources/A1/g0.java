package A1;

import android.view.DisplayCutout;
import android.view.WindowInsets;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public class g0 extends f0 {
    public g0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var, windowInsets);
    }

    @Override // A1.l0
    public q0 a() {
        return q0.c(null, this.f247c.consumeDisplayCutout());
    }

    @Override // A1.e0, A1.l0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof g0)) {
            return false;
        }
        g0 g0Var = (g0) obj;
        return Objects.equals(this.f247c, g0Var.f247c) && Objects.equals(this.f251g, g0Var.f251g) && e0.C(this.f252h, g0Var.f252h);
    }

    @Override // A1.l0
    public C0032h f() {
        DisplayCutout displayCutout = this.f247c.getDisplayCutout();
        if (displayCutout == null) {
            return null;
        }
        return new C0032h(displayCutout);
    }

    @Override // A1.l0
    public int hashCode() {
        return this.f247c.hashCode();
    }

    public g0(q0 q0Var, g0 g0Var) {
        super(q0Var, g0Var);
    }
}
