package A1;

import android.view.animation.Interpolator;

/* JADX INFO: loaded from: classes.dex */
public abstract class V {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f216a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f217b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Interpolator f218c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f219d;

    public V(int i, Interpolator interpolator, long j9) {
        this.f216a = i;
        this.f218c = interpolator;
        this.f219d = j9;
    }

    public float a() {
        return 1.0f;
    }

    public long b() {
        return this.f219d;
    }

    public float c() {
        Interpolator interpolator = this.f218c;
        return interpolator != null ? interpolator.getInterpolation(this.f217b) : this.f217b;
    }

    public int d() {
        return this.f216a;
    }

    public void e(float f4) {
        this.f217b = f4;
    }
}
