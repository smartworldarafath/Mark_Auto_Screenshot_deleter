package A1;

import android.graphics.Rect;
import android.util.Log;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/* JADX INFO: loaded from: classes.dex */
public final class X extends d0 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Field f221e = null;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static boolean f222f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static Constructor f223g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static boolean f224h = false;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public WindowInsets f225c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public t1.b f226d;

    public X() {
        this.f225c = i();
    }

    private static WindowInsets i() {
        if (!f222f) {
            try {
                f221e = WindowInsets.class.getDeclaredField("CONSUMED");
            } catch (ReflectiveOperationException e4) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e4);
            }
            f222f = true;
        }
        Field field = f221e;
        if (field != null) {
            try {
                WindowInsets windowInsets = (WindowInsets) field.get(null);
                if (windowInsets != null) {
                    return new WindowInsets(windowInsets);
                }
            } catch (ReflectiveOperationException e9) {
                Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e9);
            }
        }
        if (!f224h) {
            try {
                f223g = WindowInsets.class.getConstructor(Rect.class);
            } catch (ReflectiveOperationException e10) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e10);
            }
            f224h = true;
        }
        Constructor constructor = f223g;
        if (constructor != null) {
            try {
                return (WindowInsets) constructor.newInstance(new Rect());
            } catch (ReflectiveOperationException e11) {
                Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e11);
            }
        }
        return null;
    }

    @Override // A1.d0
    public q0 b() {
        a();
        q0 q0VarC = q0.c(null, this.f225c);
        t1.b[] bVarArr = this.f242b;
        l0 l0Var = q0VarC.f276a;
        l0Var.r(bVarArr);
        l0Var.u(this.f226d);
        return q0VarC;
    }

    @Override // A1.d0
    public void e(t1.b bVar) {
        this.f226d = bVar;
    }

    @Override // A1.d0
    public void g(t1.b bVar) {
        WindowInsets windowInsets = this.f225c;
        if (windowInsets != null) {
            this.f225c = windowInsets.replaceSystemWindowInsets(bVar.f31354a, bVar.f31355b, bVar.f31356c, bVar.f31357d);
        }
    }

    public X(q0 q0Var) {
        super(q0Var);
        this.f225c = q0Var.b();
    }
}
