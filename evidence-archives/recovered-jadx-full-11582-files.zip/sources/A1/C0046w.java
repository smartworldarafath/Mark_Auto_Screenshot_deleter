package A1;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: renamed from: A1.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0046w extends C0043t {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public View f285u;

    /* JADX WARN: Type inference failed for: r4v0, types: [A1.v] */
    @Override // A1.C0043t
    public final void o() {
        View view = this.f285u;
        WindowInsetsController windowInsetsController = view != null ? view.getWindowInsetsController() : null;
        if (windowInsetsController == null) {
            super.o();
            return;
        }
        final AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        ?? r8 = new WindowInsetsController.OnControllableInsetsChangedListener() { // from class: A1.v
            @Override // android.view.WindowInsetsController.OnControllableInsetsChangedListener
            public final void onControllableInsetsChanged(WindowInsetsController windowInsetsController2, int i) {
                atomicBoolean.set((i & 8) != 0);
            }
        };
        windowInsetsController.addOnControllableInsetsChangedListener(r8);
        if (!atomicBoolean.get() && view != null) {
            ((InputMethodManager) view.getContext().getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        windowInsetsController.removeOnControllableInsetsChangedListener(r8);
        windowInsetsController.hide(WindowInsets.Type.ime());
    }

    @Override // A1.C0043t
    public final void u() {
        View view = this.f285u;
        if (view != null && Build.VERSION.SDK_INT < 33) {
            ((InputMethodManager) view.getContext().getSystemService("input_method")).isActive();
        }
        WindowInsetsController windowInsetsController = view != null ? view.getWindowInsetsController() : null;
        if (windowInsetsController != null) {
            windowInsetsController.show(WindowInsets.Type.ime());
        }
        super.u();
    }
}
