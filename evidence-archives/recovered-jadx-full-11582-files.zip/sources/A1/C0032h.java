package A1;

import android.os.Build;
import android.view.DisplayCutout;
import java.util.Objects;

/* JADX INFO: renamed from: A1.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0032h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final DisplayCutout f254a;

    public C0032h(DisplayCutout displayCutout) {
        this.f254a = displayCutout;
    }

    public final t1.b a() {
        return Build.VERSION.SDK_INT >= 30 ? t1.b.c(AbstractC0031g.c(this.f254a)) : t1.b.f31353e;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0032h.class != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.f254a, ((C0032h) obj).f254a);
    }

    public final int hashCode() {
        return this.f254a.hashCode();
    }

    public final String toString() {
        return "DisplayCutoutCompat{" + this.f254a + "}";
    }
}
