package A1;

import E4.AbstractC0176j;
import android.view.View;
import android.view.Window;

/* JADX INFO: loaded from: classes.dex */
public final class r0 extends AbstractC0176j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Window f278a;

    public r0(Window window) {
        this.f278a = window;
    }

    @Override // E4.AbstractC0176j
    public final void a(boolean z8) {
        Window window = this.f278a;
        if (!z8) {
            View decorView = window.getDecorView();
            decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() & (-17));
        } else {
            window.clearFlags(134217728);
            window.addFlags(Integer.MIN_VALUE);
            View decorView2 = window.getDecorView();
            decorView2.setSystemUiVisibility(decorView2.getSystemUiVisibility() | 16);
        }
    }

    @Override // E4.AbstractC0176j
    public final void b(boolean z8) {
        Window window = this.f278a;
        if (!z8) {
            View decorView = window.getDecorView();
            decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() & (-8193));
        } else {
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            View decorView2 = window.getDecorView();
            decorView2.setSystemUiVisibility(decorView2.getSystemUiVisibility() | 8192);
        }
    }
}
