package A1;

import androidx.core.widget.NestedScrollView;

/* JADX INFO: renamed from: A1.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0036l extends InterfaceC0035k {
    void h(NestedScrollView nestedScrollView, int i, int i4, int i9, int i10, int i11, int[] iArr);
}
