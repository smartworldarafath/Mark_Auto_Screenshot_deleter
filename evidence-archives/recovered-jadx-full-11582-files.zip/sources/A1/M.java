package A1;

import androidx.datastore.preferences.protobuf.C1371g;
import androidx.datastore.preferences.protobuf.C1388y;
import com.google.android.gms.internal.ads.AbstractC4791yC;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class M {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f192t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Object f193u;

    public M(int i) {
        this.f192t = i;
    }

    public abstract int A();

    public abstract long B();

    public abstract boolean C(int i);

    public void D() {
        boolean zC;
        do {
            int iZ = z();
            if (iZ == 0) {
                return;
            }
            int i = this.f192t;
            if (i >= 100) {
                throw new C1388y("Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit.");
            }
            this.f192t = i + 1;
            zC = C(iZ);
            this.f192t--;
        } while (zC);
    }

    public abstract int[] E(int[] iArr, int i);

    public abstract int F();

    public ByteBuffer G(int i, byte[] bArr) {
        int[] iArrE = E(AbstractC4791yC.c(bArr), i);
        int[] iArr = (int[]) iArrE.clone();
        AbstractC4791yC.a(iArr);
        for (int i4 = 0; i4 < 16; i4++) {
            iArrE[i4] = iArrE[i4] + iArr[i4];
        }
        ByteBuffer byteBufferOrder = ByteBuffer.allocate(64).order(ByteOrder.LITTLE_ENDIAN);
        byteBufferOrder.asIntBuffer().put(iArrE, 0, 16);
        return byteBufferOrder;
    }

    public abstract void b(int i);

    public abstract int c();

    public abstract boolean d();

    public void e(W w6) {
    }

    public void f() {
    }

    public abstract q0 g(q0 q0Var, List list);

    public abstract P2.c h(W w6, P2.c cVar);

    public abstract void i(int i);

    public abstract int j(int i);

    public abstract boolean k();

    public abstract C1371g l();

    public abstract double m();

    public abstract int n();

    public abstract int o();

    public abstract long p();

    public abstract float q();

    public abstract int r();

    public abstract long s();

    public abstract int t();

    public abstract long u();

    public abstract int v();

    public abstract long w();

    public abstract String x();

    public abstract String y();

    public abstract int z();
}
