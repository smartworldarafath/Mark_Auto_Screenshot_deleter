package A1;

import android.view.WindowInsets;

/* JADX INFO: loaded from: classes.dex */
public class h0 extends g0 {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public t1.b f255o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public t1.b f256p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public t1.b f257q;

    public h0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var, windowInsets);
        this.f255o = null;
        this.f256p = null;
        this.f257q = null;
    }

    @Override // A1.l0
    public t1.b i() {
        if (this.f256p == null) {
            this.f256p = t1.b.c(this.f247c.getMandatorySystemGestureInsets());
        }
        return this.f256p;
    }

    @Override // A1.l0
    public t1.b k() {
        if (this.f255o == null) {
            this.f255o = t1.b.c(this.f247c.getSystemGestureInsets());
        }
        return this.f255o;
    }

    @Override // A1.l0
    public t1.b m() {
        if (this.f257q == null) {
            this.f257q = t1.b.c(this.f247c.getTappableElementInsets());
        }
        return this.f257q;
    }

    @Override // A1.e0, A1.l0
    public q0 n(int i, int i4, int i9, int i10) {
        return q0.c(null, this.f247c.inset(i, i4, i9, i10));
    }

    @Override // A1.f0, A1.l0
    public void u(t1.b bVar) {
    }

    public h0(q0 q0Var, h0 h0Var) {
        super(q0Var, h0Var);
        this.f255o = null;
        this.f256p = null;
        this.f257q = null;
    }
}
