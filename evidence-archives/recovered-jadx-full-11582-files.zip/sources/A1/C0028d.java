package A1;

import android.content.Context;
import android.view.VelocityTracker;

/* JADX INFO: renamed from: A1.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0028d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f233a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0033i f234b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public VelocityTracker f235c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f236d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f237e = -1;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f238f = -1;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f239g = -1;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int[] f240h = {Integer.MAX_VALUE, 0};

    public C0028d(Context context, C0033i c0033i) {
        this.f233a = context;
        this.f234b = c0033i;
    }
}
