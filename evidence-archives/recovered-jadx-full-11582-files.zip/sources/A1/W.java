package A1;

import android.os.Build;
import android.view.animation.Interpolator;

/* JADX INFO: loaded from: classes.dex */
public final class W {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public V f220a;

    public W(int i, Interpolator interpolator, long j9) {
        if (Build.VERSION.SDK_INT >= 30) {
            this.f220a = new U(AbstractC0044u.i(i, interpolator, j9));
        } else {
            this.f220a = new S(i, interpolator, j9);
        }
    }
}
