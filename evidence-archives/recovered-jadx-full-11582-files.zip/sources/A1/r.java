package A1;

import android.os.Build;
import androidx.core.widget.NestedScrollView;

/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final InterfaceC0041q f277a;

    public r(NestedScrollView nestedScrollView) {
        if (Build.VERSION.SDK_INT >= 35) {
            this.f277a = new C0040p(nestedScrollView);
        } else {
            this.f277a = new B5.e(1);
        }
    }
}
