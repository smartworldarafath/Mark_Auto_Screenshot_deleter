package A1;

import android.text.PrecomputedText;
import android.view.textclassifier.TextClassification;
import android.view.textclassifier.TextClassificationContext;
import android.view.textclassifier.TextSelection;

/* JADX INFO: renamed from: A1.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0029e {
    public static /* synthetic */ void B() {
    }

    public static /* synthetic */ TextClassification.Request.Builder f(CharSequence charSequence, int i, int i4) {
        return new TextClassification.Request.Builder(charSequence, i, i4);
    }

    public static /* synthetic */ TextClassificationContext.Builder i(String str, String str2) {
        return new TextClassificationContext.Builder(str, str2);
    }

    public static /* synthetic */ TextSelection.Request.Builder k(CharSequence charSequence, int i, int i4) {
        return new TextSelection.Request.Builder(charSequence, i, i4);
    }

    public static /* synthetic */ void q() {
    }

    public static /* bridge */ /* synthetic */ boolean z(CharSequence charSequence) {
        return charSequence instanceof PrecomputedText;
    }
}
