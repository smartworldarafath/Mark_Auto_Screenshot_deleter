package A1;

/* JADX INFO: renamed from: A1.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0041q {
    void onScrollLimit(int i, int i4, int i9, boolean z8);

    void onScrollProgress(int i, int i4, int i9, int i10);
}
