package A1;

import android.view.WindowInsets;

/* JADX INFO: loaded from: classes.dex */
public final class k0 extends j0 {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final q0 f266s = q0.c(null, WindowInsets.CONSUMED);

    public k0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var, windowInsets);
    }

    @Override // A1.i0, A1.e0, A1.l0
    public t1.b g(int i) {
        return t1.b.c(this.f247c.getInsets(p0.a(i)));
    }

    @Override // A1.i0, A1.e0, A1.l0
    public t1.b h(int i) {
        return t1.b.c(this.f247c.getInsetsIgnoringVisibility(p0.a(i)));
    }

    @Override // A1.i0, A1.e0, A1.l0
    public boolean q(int i) {
        return this.f247c.isVisible(p0.a(i));
    }

    public k0(q0 q0Var, k0 k0Var) {
        super(q0Var, k0Var);
    }
}
