package A1;

/* JADX INFO: loaded from: classes.dex */
public class b0 extends a0 {
    public b0() {
    }

    public b0(q0 q0Var) {
        super(q0Var);
    }
}
