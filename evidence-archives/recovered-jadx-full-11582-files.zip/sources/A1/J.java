package A1;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.PathInterpolator;
import com.markOne.ss_app.R;
import java.lang.reflect.Field;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class J {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static Field f187a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static boolean f188b = false;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final A f189c = new A();

    public static View.AccessibilityDelegate a(View view) {
        if (Build.VERSION.SDK_INT >= 29) {
            return G.a(view);
        }
        if (f188b) {
            return null;
        }
        if (f187a == null) {
            try {
                Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                f187a = declaredField;
                declaredField.setAccessible(true);
            } catch (Throwable unused) {
                f188b = true;
                return null;
            }
        }
        try {
            Object obj = f187a.get(view);
            if (obj instanceof View.AccessibilityDelegate) {
                return (View.AccessibilityDelegate) obj;
            }
            return null;
        } catch (Throwable unused2) {
            f188b = true;
            return null;
        }
    }

    public static void b(View view, int i) {
        Object tag;
        AccessibilityManager accessibilityManager = (AccessibilityManager) view.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled()) {
            int i4 = Build.VERSION.SDK_INT;
            Object objA = null;
            if (i4 >= 28) {
                tag = F.a(view);
            } else {
                tag = view.getTag(R.id.tag_accessibility_pane_title);
                if (!CharSequence.class.isInstance(tag)) {
                    tag = null;
                }
            }
            boolean z8 = ((CharSequence) tag) != null && view.isShown() && view.getWindowVisibility() == 0;
            if (view.getAccessibilityLiveRegion() != 0 || z8) {
                AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain();
                accessibilityEventObtain.setEventType(z8 ? 32 : 2048);
                accessibilityEventObtain.setContentChangeTypes(i);
                if (z8) {
                    List<CharSequence> text = accessibilityEventObtain.getText();
                    if (i4 >= 28) {
                        objA = F.a(view);
                    } else {
                        Object tag2 = view.getTag(R.id.tag_accessibility_pane_title);
                        if (CharSequence.class.isInstance(tag2)) {
                            objA = tag2;
                        }
                    }
                    text.add((CharSequence) objA);
                    if (view.getImportantForAccessibility() == 0) {
                        view.setImportantForAccessibility(1);
                    }
                }
                view.sendAccessibilityEventUnchecked(accessibilityEventObtain);
                return;
            }
            if (i != 32) {
                if (view.getParent() != null) {
                    try {
                        view.getParent().notifySubtreeAccessibilityStateChanged(view, view, i);
                        return;
                    } catch (AbstractMethodError e4) {
                        Log.e("ViewCompat", view.getParent().getClass().getSimpleName().concat(" does not fully implement ViewParent"), e4);
                        return;
                    }
                }
                return;
            }
            AccessibilityEvent accessibilityEventObtain2 = AccessibilityEvent.obtain();
            view.onInitializeAccessibilityEvent(accessibilityEventObtain2);
            accessibilityEventObtain2.setEventType(32);
            accessibilityEventObtain2.setContentChangeTypes(i);
            accessibilityEventObtain2.setSource(view);
            view.onPopulateAccessibilityEvent(accessibilityEventObtain2);
            List<CharSequence> text2 = accessibilityEventObtain2.getText();
            if (i4 >= 28) {
                objA = F.a(view);
            } else {
                Object tag3 = view.getTag(R.id.tag_accessibility_pane_title);
                if (CharSequence.class.isInstance(tag3)) {
                    objA = tag3;
                }
            }
            text2.add((CharSequence) objA);
            accessibilityManager.sendAccessibilityEvent(accessibilityEventObtain2);
        }
    }

    public static void c(View view, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i) {
        if (Build.VERSION.SDK_INT >= 29) {
            G.b(view, context, iArr, attributeSet, typedArray, i, 0);
        }
    }

    public static void d(View view, C0026b c0026b) {
        if (c0026b == null && (a(view) instanceof C0025a)) {
            c0026b = new C0026b();
        }
        if (view.getImportantForAccessibility() == 0) {
            view.setImportantForAccessibility(1);
        }
        view.setAccessibilityDelegate(c0026b == null ? null : c0026b.f231b);
    }

    public static void e(View view, CharSequence charSequence) {
        Object tag;
        int i = Build.VERSION.SDK_INT;
        if (i >= 28) {
            F.d(view, charSequence);
        } else {
            C0026b c0026b = null;
            if (i >= 28) {
                tag = F.a(view);
            } else {
                tag = view.getTag(R.id.tag_accessibility_pane_title);
                if (!CharSequence.class.isInstance(tag)) {
                    tag = null;
                }
            }
            if (!TextUtils.equals((CharSequence) tag, charSequence)) {
                View.AccessibilityDelegate accessibilityDelegateA = a(view);
                if (accessibilityDelegateA != null) {
                    c0026b = accessibilityDelegateA instanceof C0025a ? ((C0025a) accessibilityDelegateA).f228a : new C0026b(accessibilityDelegateA);
                }
                if (c0026b == null) {
                    c0026b = new C0026b();
                }
                d(view, c0026b);
                view.setTag(R.id.tag_accessibility_pane_title, charSequence);
                b(view, 8);
            }
        }
        A a9 = f189c;
        if (charSequence == null) {
            a9.f179t.remove(view);
            view.removeOnAttachStateChangeListener(a9);
            view.getViewTreeObserver().removeOnGlobalLayoutListener(a9);
        } else {
            a9.f179t.put(view, Boolean.valueOf(view.isShown() && view.getWindowVisibility() == 0));
            view.addOnAttachStateChangeListener(a9);
            if (view.isAttachedToWindow()) {
                view.getViewTreeObserver().addOnGlobalLayoutListener(a9);
            }
        }
    }

    public static void f(View view, M m8) {
        if (Build.VERSION.SDK_INT >= 30) {
            view.setWindowInsetsAnimationCallback(m8 != null ? new T(m8) : null);
            return;
        }
        PathInterpolator pathInterpolator = S.f207e;
        View.OnApplyWindowInsetsListener q6 = m8 != null ? new Q(view, m8) : null;
        view.setTag(R.id.tag_window_insets_animation_callback, q6);
        if (view.getTag(R.id.tag_compat_insets_dispatch) == null && view.getTag(R.id.tag_on_apply_window_listener) == null) {
            view.setOnApplyWindowInsetsListener(q6);
        }
    }
}
