package A1;

import android.view.ViewParent;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class L extends p146s7.h implements p137r7.c {

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public static final L f191B = new L(1, ViewParent.class, "getParent", "getParent()Landroid/view/ViewParent;", 0);

    @Override // p137r7.c
    public final Object g(Object obj) {
        return ((ViewParent) obj).getParent();
    }
}
