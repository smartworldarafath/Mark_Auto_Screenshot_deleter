package A1;

import com.google.android.gms.internal.ads.C4638v6;

/* JADX INFO: renamed from: A1.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0037m implements p019c1.q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f269a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f270b;

    public /* synthetic */ C0037m(int i, int i4) {
        this.f269a = i;
        this.f270b = i4;
    }

    @Override // p019c1.q
    public int a(int i) {
        if (i >= 0 && i <= this.f270b) {
            I.W.B(i, this.f269a, i);
        }
        return i;
    }

    @Override // p019c1.q
    public int b(int i) {
        if (i >= 0 && i <= this.f269a) {
            I.W.A(i, this.f270b, i);
        }
        return i;
    }

    public int c() {
        int i = this.f270b;
        if (i == 2) {
            return 10;
        }
        if (i == 5) {
            return 11;
        }
        if (i == 29) {
            return 12;
        }
        if (i == 42) {
            return 16;
        }
        if (i != 22) {
            return i != 23 ? 0 : 15;
        }
        return 1073741824;
    }

    public C0037m(C4638v6 c4638v6, int i, int i4) {
        this.f269a = i;
        this.f270b = i4;
    }
}
