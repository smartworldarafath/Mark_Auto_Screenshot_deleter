package A1;

import android.os.Build;
import android.view.View;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public class l0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final q0 f267b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final q0 f268a;

    static {
        d0 z8;
        int i = Build.VERSION.SDK_INT;
        if (i >= 34) {
            z8 = new c0();
        } else if (i >= 31) {
            z8 = new b0();
        } else if (i >= 30) {
            z8 = new a0();
        } else {
            z8 = i >= 29 ? new Z() : new X();
        }
        f267b = z8.b().f276a.a().f276a.b().f276a.c();
    }

    public l0(q0 q0Var) {
        this.f268a = q0Var;
    }

    public q0 a() {
        return this.f268a;
    }

    public q0 b() {
        return this.f268a;
    }

    public q0 c() {
        return this.f268a;
    }

    public void d(View view) {
    }

    public void e(q0 q0Var) {
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof l0)) {
            return false;
        }
        l0 l0Var = (l0) obj;
        return p() == l0Var.p() && o() == l0Var.o() && Objects.equals(l(), l0Var.l()) && Objects.equals(j(), l0Var.j()) && Objects.equals(f(), l0Var.f());
    }

    public C0032h f() {
        return null;
    }

    public t1.b g(int i) {
        return t1.b.f31353e;
    }

    public t1.b h(int i) {
        if ((i & 8) == 0) {
            return t1.b.f31353e;
        }
        throw new IllegalArgumentException("Unable to query the maximum insets for IME");
    }

    public int hashCode() {
        return Objects.hash(Boolean.valueOf(p()), Boolean.valueOf(o()), l(), j(), f());
    }

    public t1.b i() {
        return l();
    }

    public t1.b j() {
        return t1.b.f31353e;
    }

    public t1.b k() {
        return l();
    }

    public t1.b l() {
        return t1.b.f31353e;
    }

    public t1.b m() {
        return l();
    }

    public q0 n(int i, int i4, int i9, int i10) {
        return f267b;
    }

    public boolean o() {
        return false;
    }

    public boolean p() {
        return false;
    }

    public boolean q(int i) {
        return true;
    }

    public void r(t1.b[] bVarArr) {
    }

    public void s(t1.b bVar) {
    }

    public void t(q0 q0Var) {
    }

    public void u(t1.b bVar) {
    }

    public void v(int i) {
    }
}
