package A1;

import T3.C1162o;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Base64;
import android.util.Log;
import com.google.firebase.components.ComponentRegistrar;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.installations.FirebaseInstallationsRegistrar;
import com.google.firebase.sessions.FirebaseSessionsRegistrar;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ScheduledExecutorService;

/* JADX INFO: renamed from: A1.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0027c implements p195z3.f, p030d5.c, J3.g, p195z3.d, p030d5.d, C5.a {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f232t;

    public /* synthetic */ C0027c(int i) {
        this.f232t = i;
    }

    @Override // p195z3.f
    public void a(Exception exc) {
    }

    @Override // J3.g, p195z3.d
    public Object apply(Object obj) {
        switch (this.f232t) {
            case 6:
                Cursor cursorRawQuery = ((SQLiteDatabase) obj).rawQuery("SELECT distinct t._id, t.backend_name, t.priority, t.extras FROM transport_contexts AS t, events AS e WHERE e.context_id = t._id", new String[0]);
                try {
                    ArrayList arrayList = new ArrayList();
                    while (cursorRawQuery.moveToNext()) {
                        A4.f fVarA = C3.k.a();
                        fVarA.u(cursorRawQuery.getString(1));
                        fVarA.f324w = M3.a.b(cursorRawQuery.getInt(2));
                        String string = cursorRawQuery.getString(3);
                        fVarA.f323v = string == null ? null : Base64.decode(string, 0);
                        arrayList.add(fVarA.h());
                        break;
                    }
                    return arrayList;
                } finally {
                    cursorRawQuery.close();
                }
            default:
                K5.P p7 = (K5.P) obj;
                String strE = K5.Q.f5829b.e(p7);
                p146s7.j.d(strE, "encode(...)");
                p7.getClass();
                Log.d("FirebaseSessions", "Session Event Type: SESSION_START");
                byte[] bytes = strE.getBytes(A7.a.f340a);
                p146s7.j.d(bytes, "getBytes(...)");
                return bytes;
        }
    }

    @Override // p030d5.d
    public List b(ComponentRegistrar componentRegistrar) {
        return componentRegistrar.getComponents();
    }

    @Override // C5.a
    public void c(C5.b bVar) {
    }

    @Override // p030d5.c
    public Object f(C1162o c1162o) {
        switch (this.f232t) {
            case 3:
                return FirebaseInstallationsRegistrar.lambda$getComponents$0(c1162o);
            case 4:
                Set setC = c1162o.c(p030d5.q.a(I5.a.class));
                I5.c cVar = I5.c.f5279b;
                if (cVar == null) {
                    synchronized (I5.c.class) {
                        try {
                            cVar = I5.c.f5279b;
                            if (cVar == null) {
                                cVar = new I5.c(0);
                                I5.c.f5279b = cVar;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                }
                return new I5.b(setC, cVar);
            case 9:
                return FirebaseSessionsRegistrar.getComponents$lambda$0(c1162o);
            case 10:
                return FirebaseSessionsRegistrar.getComponents$lambda$1(c1162o);
            case 27:
                return (ScheduledExecutorService) ExecutorsRegistrar.f26419a.get();
            case 28:
                return (ScheduledExecutorService) ExecutorsRegistrar.f26421c.get();
            default:
                return (ScheduledExecutorService) ExecutorsRegistrar.f26420b.get();
        }
    }
}
