package A1;

import E4.AbstractC0176j;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;

/* JADX INFO: loaded from: classes.dex */
public class s0 extends AbstractC0176j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final WindowInsetsController f281a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Window f282b;

    public s0(Window window) {
        this.f281a = window.getInsetsController();
        this.f282b = window;
    }

    @Override // E4.AbstractC0176j
    public final void a(boolean z8) {
        Window window = this.f282b;
        if (z8) {
            if (window != null) {
                View decorView = window.getDecorView();
                decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | 16);
            }
            this.f281a.setSystemBarsAppearance(16, 16);
            return;
        }
        if (window != null) {
            View decorView2 = window.getDecorView();
            decorView2.setSystemUiVisibility(decorView2.getSystemUiVisibility() & (-17));
        }
        this.f281a.setSystemBarsAppearance(0, 16);
    }

    @Override // E4.AbstractC0176j
    public final void b(boolean z8) {
        Window window = this.f282b;
        if (z8) {
            if (window != null) {
                View decorView = window.getDecorView();
                decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | 8192);
            }
            this.f281a.setSystemBarsAppearance(8, 8);
            return;
        }
        if (window != null) {
            View decorView2 = window.getDecorView();
            decorView2.setSystemUiVisibility(decorView2.getSystemUiVisibility() & (-8193));
        }
        this.f281a.setSystemBarsAppearance(0, 8);
    }
}
