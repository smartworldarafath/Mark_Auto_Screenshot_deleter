package A1;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class q0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final q0 f275b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final l0 f276a;

    static {
        int i = Build.VERSION.SDK_INT;
        if (i >= 34) {
            f275b = k0.f266s;
        } else if (i >= 30) {
            f275b = i0.f260r;
        } else {
            f275b = l0.f267b;
        }
    }

    public q0(WindowInsets windowInsets) {
        int i = Build.VERSION.SDK_INT;
        if (i >= 34) {
            this.f276a = new k0(this, windowInsets);
            return;
        }
        if (i >= 31) {
            this.f276a = new j0(this, windowInsets);
            return;
        }
        if (i >= 30) {
            this.f276a = new i0(this, windowInsets);
            return;
        }
        if (i >= 29) {
            this.f276a = new h0(this, windowInsets);
        } else if (i >= 28) {
            this.f276a = new g0(this, windowInsets);
        } else {
            this.f276a = new f0(this, windowInsets);
        }
    }

    public static t1.b a(t1.b bVar, int i, int i4, int i9, int i10) {
        int iMax = Math.max(0, bVar.f31354a - i);
        int iMax2 = Math.max(0, bVar.f31355b - i4);
        int iMax3 = Math.max(0, bVar.f31356c - i9);
        int iMax4 = Math.max(0, bVar.f31357d - i10);
        return (iMax == i && iMax2 == i4 && iMax3 == i9 && iMax4 == i10) ? bVar : t1.b.b(iMax, iMax2, iMax3, iMax4);
    }

    public static q0 c(View view, WindowInsets windowInsets) {
        windowInsets.getClass();
        q0 q0Var = new q0(windowInsets);
        if (view != null && view.isAttachedToWindow()) {
            Field field = J.f187a;
            q0 q0VarA = E.a(view);
            l0 l0Var = q0Var.f276a;
            l0Var.t(q0VarA);
            l0Var.d(view.getRootView());
            l0Var.v(view.getWindowSystemUiVisibility());
        }
        return q0Var;
    }

    public final WindowInsets b() {
        l0 l0Var = this.f276a;
        if (l0Var instanceof e0) {
            return ((e0) l0Var).f247c;
        }
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof q0) {
            return Objects.equals(this.f276a, ((q0) obj).f276a);
        }
        return false;
    }

    public final int hashCode() {
        l0 l0Var = this.f276a;
        if (l0Var == null) {
            return 0;
        }
        return l0Var.hashCode();
    }

    public q0(q0 q0Var) {
        if (q0Var != null) {
            l0 l0Var = q0Var.f276a;
            int i = Build.VERSION.SDK_INT;
            if (i >= 34 && (l0Var instanceof k0)) {
                this.f276a = new k0(this, (k0) l0Var);
            } else if (i >= 31 && (l0Var instanceof j0)) {
                this.f276a = new j0(this, (j0) l0Var);
            } else if (i >= 30 && (l0Var instanceof i0)) {
                this.f276a = new i0(this, (i0) l0Var);
            } else if (i >= 29 && (l0Var instanceof h0)) {
                this.f276a = new h0(this, (h0) l0Var);
            } else if (i >= 28 && (l0Var instanceof g0)) {
                this.f276a = new g0(this, (g0) l0Var);
            } else if (l0Var instanceof f0) {
                this.f276a = new f0(this, (f0) l0Var);
            } else if (l0Var instanceof e0) {
                this.f276a = new e0(this, (e0) l0Var);
            } else {
                this.f276a = new l0(this);
            }
            l0Var.e(this);
            return;
        }
        this.f276a = new l0(this);
    }
}
