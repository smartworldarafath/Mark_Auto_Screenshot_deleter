package A1;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: A1.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0048y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Map f286a = Collections.synchronizedMap(new WeakHashMap());
}
