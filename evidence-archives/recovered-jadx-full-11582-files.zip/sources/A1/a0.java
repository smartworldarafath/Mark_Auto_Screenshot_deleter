package A1;

/* JADX INFO: loaded from: classes.dex */
public class a0 extends Z {
    public a0() {
    }

    @Override // A1.d0
    public void c(int i, t1.b bVar) {
        this.f227c.setInsets(n0.a(i), bVar.d());
    }

    public a0(q0 q0Var) {
        super(q0Var);
    }
}
