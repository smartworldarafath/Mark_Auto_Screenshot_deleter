package A1;

/* JADX INFO: renamed from: A1.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0049z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float[] f287a = new float[20];

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long[] f288b = new long[20];

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f289c = 0.0f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f290d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f291e = 0;
}
