package A1;

import android.view.WindowInsets;

/* JADX INFO: loaded from: classes.dex */
public class j0 extends i0 {
    public j0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var, windowInsets);
    }

    public j0(q0 q0Var, j0 j0Var) {
        super(q0Var, j0Var);
    }
}
