package A1;

import E4.AbstractC0170i;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public class e0 extends l0 {
    public static boolean i = false;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static Method f243j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static Class f244k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static Field f245l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static Field f246m;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final WindowInsets f247c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public t1.b[] f248d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public t1.b f249e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public q0 f250f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public t1.b f251g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f252h;

    public e0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var);
        this.f249e = null;
        this.f247c = windowInsets;
    }

    private static void B() {
        try {
            f243j = View.class.getDeclaredMethod("getViewRootImpl", null);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            f244k = cls;
            f245l = cls.getDeclaredField("mVisibleInsets");
            f246m = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
            f245l.setAccessible(true);
            f246m.setAccessible(true);
        } catch (ReflectiveOperationException e4) {
            Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e4.getMessage(), e4);
        }
        i = true;
    }

    public static boolean C(int i4, int i9) {
        return (i4 & 6) == (i9 & 6);
    }

    private t1.b w(int i4, boolean z8) {
        t1.b bVarA = t1.b.f31353e;
        for (int i9 = 1; i9 <= 512; i9 <<= 1) {
            if ((i4 & i9) != 0) {
                bVarA = t1.b.a(bVarA, x(i9, z8));
            }
        }
        return bVarA;
    }

    private t1.b y() {
        q0 q0Var = this.f250f;
        return q0Var != null ? q0Var.f276a.j() : t1.b.f31353e;
    }

    private t1.b z(View view) {
        if (Build.VERSION.SDK_INT >= 30) {
            throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
        }
        if (!i) {
            B();
        }
        Method method = f243j;
        if (method != null && f244k != null && f245l != null) {
            try {
                Object objInvoke = method.invoke(view, null);
                if (objInvoke == null) {
                    Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                    return null;
                }
                Rect rect = (Rect) f245l.get(f246m.get(objInvoke));
                if (rect != null) {
                    return t1.b.b(rect.left, rect.top, rect.right, rect.bottom);
                }
            } catch (ReflectiveOperationException e4) {
                Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e4.getMessage(), e4);
            }
        }
        return null;
    }

    public boolean A(int i4) {
        if (i4 != 1 && i4 != 2) {
            if (i4 == 4) {
                return false;
            }
            if (i4 != 8 && i4 != 128) {
                return true;
            }
        }
        return !x(i4, false).equals(t1.b.f31353e);
    }

    @Override // A1.l0
    public void d(View view) {
        t1.b bVarZ = z(view);
        if (bVarZ == null) {
            bVarZ = t1.b.f31353e;
        }
        s(bVarZ);
    }

    @Override // A1.l0
    public void e(q0 q0Var) {
        q0Var.f276a.t(this.f250f);
        t1.b bVar = this.f251g;
        l0 l0Var = q0Var.f276a;
        l0Var.s(bVar);
        l0Var.v(this.f252h);
    }

    @Override // A1.l0
    public boolean equals(Object obj) {
        if (!super.equals(obj)) {
            return false;
        }
        e0 e0Var = (e0) obj;
        return Objects.equals(this.f251g, e0Var.f251g) && C(this.f252h, e0Var.f252h);
    }

    @Override // A1.l0
    public t1.b g(int i4) {
        return w(i4, false);
    }

    @Override // A1.l0
    public t1.b h(int i4) {
        return w(i4, true);
    }

    @Override // A1.l0
    public final t1.b l() {
        if (this.f249e == null) {
            WindowInsets windowInsets = this.f247c;
            this.f249e = t1.b.b(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        }
        return this.f249e;
    }

    @Override // A1.l0
    public q0 n(int i4, int i9, int i10, int i11) {
        d0 z8;
        q0 q0VarC = q0.c(null, this.f247c);
        int i12 = Build.VERSION.SDK_INT;
        if (i12 >= 34) {
            z8 = new c0(q0VarC);
        } else if (i12 >= 31) {
            z8 = new b0(q0VarC);
        } else if (i12 >= 30) {
            z8 = new a0(q0VarC);
        } else {
            z8 = i12 >= 29 ? new Z(q0VarC) : new X(q0VarC);
        }
        z8.g(q0.a(l(), i4, i9, i10, i11));
        z8.e(q0.a(j(), i4, i9, i10, i11));
        return z8.b();
    }

    @Override // A1.l0
    public boolean p() {
        return this.f247c.isRound();
    }

    @Override // A1.l0
    public boolean q(int i4) {
        for (int i9 = 1; i9 <= 512; i9 <<= 1) {
            if ((i4 & i9) != 0 && !A(i9)) {
                return false;
            }
        }
        return true;
    }

    @Override // A1.l0
    public void r(t1.b[] bVarArr) {
        this.f248d = bVarArr;
    }

    @Override // A1.l0
    public void s(t1.b bVar) {
        this.f251g = bVar;
    }

    @Override // A1.l0
    public void t(q0 q0Var) {
        this.f250f = q0Var;
    }

    @Override // A1.l0
    public void v(int i4) {
        this.f252h = i4;
    }

    public t1.b x(int i4, boolean z8) {
        t1.b bVarJ;
        int i9;
        t1.b bVar = t1.b.f31353e;
        if (i4 != 1) {
            if (i4 != 2) {
                if (i4 == 8) {
                    t1.b[] bVarArr = this.f248d;
                    bVarJ = bVarArr != null ? bVarArr[AbstractC0170i.a(8)] : null;
                    if (bVarJ != null) {
                        return bVarJ;
                    }
                    t1.b bVarL = l();
                    t1.b bVarY = y();
                    int i10 = bVarL.f31357d;
                    if (i10 > bVarY.f31357d) {
                        return t1.b.b(0, 0, 0, i10);
                    }
                    t1.b bVar2 = this.f251g;
                    if (bVar2 != null && !bVar2.equals(bVar) && (i9 = this.f251g.f31357d) > bVarY.f31357d) {
                        return t1.b.b(0, 0, 0, i9);
                    }
                } else {
                    if (i4 == 16) {
                        return k();
                    }
                    if (i4 == 32) {
                        return i();
                    }
                    if (i4 == 64) {
                        return m();
                    }
                    if (i4 == 128) {
                        q0 q0Var = this.f250f;
                        C0032h c0032hF = q0Var != null ? q0Var.f276a.f() : f();
                        if (c0032hF != null) {
                            int i11 = Build.VERSION.SDK_INT;
                            return t1.b.b(i11 >= 28 ? AbstractC0030f.i(c0032hF.f254a) : 0, i11 >= 28 ? AbstractC0030f.k(c0032hF.f254a) : 0, i11 >= 28 ? AbstractC0030f.j(c0032hF.f254a) : 0, i11 >= 28 ? AbstractC0030f.h(c0032hF.f254a) : 0);
                        }
                    }
                }
            } else {
                if (z8) {
                    t1.b bVarY2 = y();
                    t1.b bVarJ2 = j();
                    return t1.b.b(Math.max(bVarY2.f31354a, bVarJ2.f31354a), 0, Math.max(bVarY2.f31356c, bVarJ2.f31356c), Math.max(bVarY2.f31357d, bVarJ2.f31357d));
                }
                if ((this.f252h & 2) == 0) {
                    t1.b bVarL2 = l();
                    q0 q0Var2 = this.f250f;
                    bVarJ = q0Var2 != null ? q0Var2.f276a.j() : null;
                    int iMin = bVarL2.f31357d;
                    if (bVarJ != null) {
                        iMin = Math.min(iMin, bVarJ.f31357d);
                    }
                    return t1.b.b(bVarL2.f31354a, 0, bVarL2.f31356c, iMin);
                }
            }
        } else {
            if (z8) {
                return t1.b.b(0, Math.max(y().f31355b, l().f31355b), 0, 0);
            }
            if ((this.f252h & 4) == 0) {
                return t1.b.b(0, l().f31355b, 0, 0);
            }
        }
        return bVar;
    }

    public e0(q0 q0Var, e0 e0Var) {
        this(q0Var, new WindowInsets(e0Var.f247c));
    }
}
