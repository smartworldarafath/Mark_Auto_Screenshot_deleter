package A1;

import android.view.View;
import android.view.WindowInsets;

/* JADX INFO: loaded from: classes.dex */
public abstract class E {
    public static q0 a(View view) {
        WindowInsets rootWindowInsets = view.getRootWindowInsets();
        if (rootWindowInsets == null) {
            return null;
        }
        q0 q0VarC = q0.c(null, rootWindowInsets);
        l0 l0Var = q0VarC.f276a;
        l0Var.t(q0VarC);
        l0Var.d(view.getRootView());
        return q0VarC;
    }
}
