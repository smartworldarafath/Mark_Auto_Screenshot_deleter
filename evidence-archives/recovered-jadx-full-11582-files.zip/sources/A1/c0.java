package A1;

/* JADX INFO: loaded from: classes.dex */
public final class c0 extends b0 {
    public c0() {
    }

    @Override // A1.a0, A1.d0
    public void c(int i, t1.b bVar) {
        this.f227c.setInsets(p0.a(i), bVar.d());
    }

    public c0(q0 q0Var) {
        super(q0Var);
    }
}
