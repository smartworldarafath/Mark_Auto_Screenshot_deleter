package A1;

import android.view.View;

/* JADX INFO: renamed from: A1.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0038n {
    q0 a(View view, q0 q0Var);
}
