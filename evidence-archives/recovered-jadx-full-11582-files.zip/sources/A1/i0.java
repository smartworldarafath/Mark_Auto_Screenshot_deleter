package A1;

import android.view.View;
import android.view.WindowInsets;

/* JADX INFO: loaded from: classes.dex */
public class i0 extends h0 {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final q0 f260r = q0.c(null, WindowInsets.CONSUMED);

    public i0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var, windowInsets);
    }

    @Override // A1.e0, A1.l0
    public final void d(View view) {
    }

    @Override // A1.e0, A1.l0
    public t1.b g(int i) {
        return t1.b.c(this.f247c.getInsets(n0.a(i)));
    }

    @Override // A1.e0, A1.l0
    public t1.b h(int i) {
        return t1.b.c(this.f247c.getInsetsIgnoringVisibility(n0.a(i)));
    }

    @Override // A1.e0, A1.l0
    public boolean q(int i) {
        return this.f247c.isVisible(n0.a(i));
    }

    public i0(q0 q0Var, i0 i0Var) {
        super(q0Var, i0Var);
    }
}
