package A1;

import android.view.View;
import android.view.ViewTreeObserver;

/* JADX INFO: renamed from: A1.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ViewTreeObserverOnPreDrawListenerC0039o implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final View f271t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public ViewTreeObserver f272u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Runnable f273v;

    public ViewTreeObserverOnPreDrawListenerC0039o(View view, Runnable runnable) {
        this.f271t = view;
        this.f272u = view.getViewTreeObserver();
        this.f273v = runnable;
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public final boolean onPreDraw() {
        boolean zIsAlive = this.f272u.isAlive();
        View view = this.f271t;
        if (zIsAlive) {
            this.f272u.removeOnPreDrawListener(this);
        } else {
            view.getViewTreeObserver().removeOnPreDrawListener(this);
        }
        view.removeOnAttachStateChangeListener(this);
        this.f273v.run();
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        this.f272u = view.getViewTreeObserver();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        boolean zIsAlive = this.f272u.isAlive();
        View view2 = this.f271t;
        if (zIsAlive) {
            this.f272u.removeOnPreDrawListener(this);
        } else {
            view2.getViewTreeObserver().removeOnPreDrawListener(this);
        }
        view2.removeOnAttachStateChangeListener(this);
    }
}
