package A1;

import android.view.View;
import android.view.WindowInsets;

/* JADX INFO: loaded from: classes.dex */
public abstract class B {
    public static WindowInsets a(View view, WindowInsets windowInsets) {
        int i = K.f190a;
        return view.dispatchApplyWindowInsets(windowInsets);
    }

    public static void b(View view) {
        view.requestApplyInsets();
    }
}
