package A1;

import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.PathInterpolator;
import com.markOne.ss_app.R;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class S extends V {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final PathInterpolator f207e = new PathInterpolator(0.0f, 1.1f, 0.0f, 1.0f);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final U1.a f208f = new U1.a(U1.a.f9953c);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final DecelerateInterpolator f209g = new DecelerateInterpolator(1.5f);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final AccelerateInterpolator f210h = new AccelerateInterpolator(1.5f);

    public static void f(W w6, View view) {
        M mK = k(view);
        if (mK != null) {
            mK.e(w6);
            if (mK.f192t == 0) {
                return;
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                f(w6, viewGroup.getChildAt(i));
            }
        }
    }

    public static void g(View view, W w6, q0 q0Var, boolean z8) {
        M mK = k(view);
        if (mK != null) {
            mK.f193u = q0Var;
            if (!z8) {
                mK.f();
                z8 = mK.f192t == 0;
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                g(viewGroup.getChildAt(i), w6, q0Var, z8);
            }
        }
    }

    public static void h(View view, q0 q0Var, List list) {
        M mK = k(view);
        if (mK != null) {
            q0Var = mK.g(q0Var, list);
            if (mK.f192t == 0) {
                return;
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                h(viewGroup.getChildAt(i), q0Var, list);
            }
        }
    }

    public static void i(View view, W w6, P2.c cVar) {
        M mK = k(view);
        if (mK != null) {
            mK.h(w6, cVar);
            if (mK.f192t == 0) {
                return;
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                i(viewGroup.getChildAt(i), w6, cVar);
            }
        }
    }

    public static WindowInsets j(View view, WindowInsets windowInsets) {
        return view.getTag(R.id.tag_on_apply_window_listener) != null ? windowInsets : view.onApplyWindowInsets(windowInsets);
    }

    public static M k(View view) {
        Object tag = view.getTag(R.id.tag_window_insets_animation_callback);
        if (tag instanceof Q) {
            return ((Q) tag).f205a;
        }
        return null;
    }
}
