package A1;

import E4.AbstractC0170i;

/* JADX INFO: loaded from: classes.dex */
public abstract class d0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final q0 f241a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public t1.b[] f242b;

    public d0() {
        this(new q0((q0) null));
    }

    public final void a() {
        t1.b[] bVarArr = this.f242b;
        if (bVarArr != null) {
            t1.b bVarG = bVarArr[0];
            t1.b bVarG2 = bVarArr[1];
            q0 q0Var = this.f241a;
            if (bVarG2 == null) {
                bVarG2 = q0Var.f276a.g(2);
            }
            if (bVarG == null) {
                bVarG = q0Var.f276a.g(1);
            }
            g(t1.b.a(bVarG, bVarG2));
            t1.b bVar = this.f242b[AbstractC0170i.a(16)];
            if (bVar != null) {
                f(bVar);
            }
            t1.b bVar2 = this.f242b[AbstractC0170i.a(32)];
            if (bVar2 != null) {
                d(bVar2);
            }
            t1.b bVar3 = this.f242b[AbstractC0170i.a(64)];
            if (bVar3 != null) {
                h(bVar3);
            }
        }
    }

    public abstract q0 b();

    public void c(int i, t1.b bVar) {
        if (this.f242b == null) {
            this.f242b = new t1.b[10];
        }
        for (int i4 = 1; i4 <= 512; i4 <<= 1) {
            if ((i & i4) != 0) {
                this.f242b[AbstractC0170i.a(i4)] = bVar;
            }
        }
    }

    public void d(t1.b bVar) {
    }

    public abstract void e(t1.b bVar);

    public void f(t1.b bVar) {
    }

    public abstract void g(t1.b bVar);

    public void h(t1.b bVar) {
    }

    public d0(q0 q0Var) {
        this.f241a = q0Var;
    }
}
