package A1;

/* JADX INFO: loaded from: classes.dex */
public final class t0 extends s0 {
}
