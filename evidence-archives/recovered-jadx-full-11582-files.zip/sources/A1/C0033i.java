package A1;

import I1.C0844b;
import I1.InterfaceC0845c;
import L0.A0;
import L0.AbstractC0938f;
import L4.C0976f0;
import L4.C0997m0;
import L4.EnumC0981h;
import L4.EnumC1028y0;
import L4.J1;
import L4.O1;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import androidx.work.impl.WorkDatabase;
import com.google.android.gms.internal.ads.InterfaceC3411Kf;
import com.google.android.gms.internal.ads.InterfaceC4463rf;
import com.google.android.gms.internal.ads.V7;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.chromium.support_lib_boundary.WebViewStartUpConfigBoundaryInterface;
import org.chromium.support_lib_boundary.WebViewStartUpResultBoundaryInterface;
import p085l.AbstractC5755m;

/* JADX INFO: renamed from: A1.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0033i implements E2.a, E2.g, WebViewStartUpConfigBoundaryInterface, InterfaceC0845c, O1, O4.e, p037e3.g, InterfaceC3411Kf {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f258t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Object f259u;

    public /* synthetic */ C0033i(int i, Object obj) {
        this.f258t = i;
        this.f259u = obj;
    }

    public static E.c0 f(C0033i c0033i, int i) {
        C.B b9 = (C.B) c0033i.f259u;
        p078k0.f fVarN = T5.p.n();
        p137r7.c cVarE = fVarN != null ? fVarN.e() : null;
        p078k0.f fVarO = T5.p.o(fVarN);
        try {
            C.r rVar = (C.r) b9.f559f.getValue();
            return b9.f568p.a(i, rVar.f656j, b9.f557d, new C.v(i, rVar));
        } finally {
            T5.p.r(fVarN, fVarO, cVarE);
        }
    }

    @Override // com.google.android.gms.internal.ads.InterfaceC3411Kf
    public /* synthetic */ void H(String str, int i, String str2, boolean z8) {
        InterfaceC4463rf interfaceC4463rf = ((V3.c) this.f259u).f10090w;
        if (interfaceC4463rf != null) {
            interfaceC4463rf.D();
        }
    }

    @Override // p037e3.g
    public Object a(T2.f fVar) {
        return G7.W.i(new G7.Q(4, ((U2.j) this.f259u).f9980y), fVar);
    }

    @Override // I1.InterfaceC0845c
    public Object b(C0844b c0844b) {
        return ((p137r7.c) this.f259u).g(c0844b);
    }

    public void c(L0.J j9) {
        if (!j9.I()) {
            I0.a.b("DepthSortedSet.add called on an unattached node");
        }
        ((A0) this.f259u).add(j9);
    }

    public boolean d(L0.J j9) {
        if (!j9.I()) {
            I0.a.b("DepthSortedSet.remove called on an unattached node");
        }
        return ((A0) this.f259u).remove(j9);
    }

    public ArrayList e(int i) {
        ArrayList arrayList = new ArrayList();
        D.A a9 = (D.A) this.f259u;
        p078k0.f fVarN = T5.p.n();
        p137r7.c cVarE = fVarN != null ? fVarN.e() : null;
        p078k0.f fVarO = T5.p.o(fVarN);
        try {
            D.o oVar = a9.f813b ? a9.f814c : (D.o) a9.f816e.getValue();
            if (oVar != null) {
                p146s7.s sVar = new p146s7.s();
                sVar.f31259t = 1;
                List list = (List) oVar.f902k.g(Integer.valueOf(i));
                int size = list.size();
                for (int i4 = 0; i4 < size; i4++) {
                    p032d7.k kVar = (p032d7.k) list.get(i4);
                    E.d0 d0Var = a9.f825o;
                    int iIntValue = ((Number) kVar.f26813t).intValue();
                    long j9 = ((j1.a) kVar.f26814u).f27638a;
                    p076j6.b bVar = D.A.f811w;
                    sVar = sVar;
                    arrayList.add(d0Var.a(iIntValue, j9, false, new B5.h((ArrayList) null, sVar, list, i, oVar)));
                }
            }
            return arrayList;
        } finally {
            T5.p.r(fVarN, fVarO, cVarE);
        }
    }

    public void g(int i, String str, List list, boolean z8, boolean z9) {
        L4.O o5;
        C0976f0 c0976f0 = (C0976f0) this.f259u;
        int i4 = i - 1;
        if (i4 == 0) {
            L4.Q q6 = ((C0997m0) c0976f0.f1283u).f7169y;
            C0997m0.l(q6);
            o5 = q6.f6812G;
        } else if (i4 != 1) {
            if (i4 == 3) {
                L4.Q q7 = ((C0997m0) c0976f0.f1283u).f7169y;
                C0997m0.l(q7);
                o5 = q7.f6813H;
            } else if (i4 != 4) {
                L4.Q q8 = ((C0997m0) c0976f0.f1283u).f7169y;
                C0997m0.l(q8);
                o5 = q8.f6811F;
            } else if (z8) {
                L4.Q q9 = ((C0997m0) c0976f0.f1283u).f7169y;
                C0997m0.l(q9);
                o5 = q9.f6809D;
            } else if (z9) {
                L4.Q q10 = ((C0997m0) c0976f0.f1283u).f7169y;
                C0997m0.l(q10);
                o5 = q10.f6808C;
            } else {
                L4.Q q11 = ((C0997m0) c0976f0.f1283u).f7169y;
                C0997m0.l(q11);
                o5 = q11.f6810E;
            }
        } else if (z8) {
            L4.Q q12 = ((C0997m0) c0976f0.f1283u).f7169y;
            C0997m0.l(q12);
            o5 = q12.f6806A;
        } else if (z9) {
            L4.Q q13 = ((C0997m0) c0976f0.f1283u).f7169y;
            C0997m0.l(q13);
            o5 = q13.f6816z;
        } else {
            L4.Q q14 = ((C0997m0) c0976f0.f1283u).f7169y;
            C0997m0.l(q14);
            o5 = q14.f6807B;
        }
        int size = list.size();
        if (size == 1) {
            o5.g(list.get(0), str);
            return;
        }
        if (size == 2) {
            o5.h(str, list.get(0), list.get(1));
        } else if (size != 3) {
            o5.f(str);
        } else {
            o5.i(str, list.get(0), list.get(1), list.get(2));
        }
    }

    @Override // org.chromium.support_lib_boundary.WebViewStartUpConfigBoundaryInterface
    public Executor getBackgroundExecutor() {
        return (Executor) ((E2.f) this.f259u).f1510u;
    }

    @Override // E2.g
    public Long getTotalTimeInUiThreadMillis() {
        return ((WebViewStartUpResultBoundaryInterface) this.f259u).getTotalTimeInUiThreadMillis();
    }

    @Override // O4.e
    public void h(Object obj) {
        ((O4.h) ((C0043t) this.f259u).f283t).f8156a.n();
    }

    /* JADX WARN: Code duplicated, block: B:14:0x001b  */
    public void i(EnumC1028y0 enumC1028y0, int i) {
        EnumC0981h enumC0981h;
        if (i == -30) {
            enumC0981h = EnumC0981h.TCF;
        } else if (i == -20) {
            enumC0981h = EnumC0981h.API;
        } else if (i == -10) {
            enumC0981h = EnumC0981h.MANIFEST;
        } else if (i != 0) {
            enumC0981h = i != 30 ? EnumC0981h.UNSET : EnumC0981h.INITIALIZATION;
        } else {
            enumC0981h = EnumC0981h.API;
        }
        ((EnumMap) this.f259u).put(enumC1028y0, enumC0981h);
    }

    public void j(EnumC1028y0 enumC1028y0, EnumC0981h enumC0981h) {
        ((EnumMap) this.f259u).put(enumC1028y0, enumC0981h);
    }

    @Override // L4.O1
    public void k0(String str, Bundle bundle, String str2) {
        J1 j9 = (J1) this.f259u;
        if (!TextUtils.isEmpty(str)) {
            j9.b().R(new P(this, str, str2, bundle, 11, false));
            return;
        }
        C0997m0 c0997m0 = j9.f6721E;
        if (c0997m0 != null) {
            L4.Q q6 = c0997m0.f7169y;
            C0997m0.l(q6);
            q6.f6816z.g(str2, "AppId not known when logging event");
        }
    }

    @Override // org.chromium.support_lib_boundary.WebViewStartUpConfigBoundaryInterface
    public boolean shouldRunUiThreadStartUpTasks() {
        return ((E2.f) this.f259u).f1509t;
    }

    public String toString() {
        switch (this.f258t) {
            case 13:
                return ((A0) this.f259u).toString();
            case 14:
                StringBuilder sb = new StringBuilder("1");
                for (EnumC1028y0 enumC1028y0 : EnumC1028y0.values()) {
                    EnumC0981h enumC0981h = (EnumC0981h) ((EnumMap) this.f259u).get(enumC1028y0);
                    if (enumC0981h == null) {
                        enumC0981h = EnumC0981h.UNSET;
                    }
                    sb.append(enumC0981h.f7083t);
                }
                return sb.toString();
            default:
                return super.toString();
        }
    }

    public /* synthetic */ C0033i(int i, boolean z8) {
        this.f258t = i;
    }

    public C0033i(EnumMap enumMap) {
        this.f258t = 14;
        EnumMap enumMap2 = new EnumMap(EnumC1028y0.class);
        this.f259u = enumMap2;
        enumMap2.putAll(enumMap);
    }

    public C0033i(WorkDatabase workDatabase) {
        this.f258t = 24;
        p146s7.j.e(workDatabase, "workDatabase");
        this.f259u = workDatabase;
    }

    public C0033i(boolean z8) {
        this.f258t = 18;
        this.f259u = new AtomicBoolean(z8);
    }

    public C0033i(int i) {
        this.f258t = i;
        switch (i) {
            case 14:
                this.f259u = new EnumMap(EnumC1028y0.class);
                break;
            case V7.zzm /* 21 */:
                this.f259u = new O4.o();
                break;
            case 29:
                p146s7.j.e(TimeUnit.MINUTES, "timeUnit");
                this.f259u = new L4.S(Y7.d.i);
                break;
            default:
                this.f259u = new A0(AbstractC0938f.f6389b);
                break;
        }
    }

    public C0033i(View view) {
        this.f258t = 1;
        if (Build.VERSION.SDK_INT >= 30) {
            C0046w c0046w = new C0046w(view);
            c0046w.f285u = view;
            this.f259u = c0046w;
            return;
        }
        this.f259u = new C0043t(view);
    }

    public C0033i(Runnable runnable) {
        this.f258t = 0;
        this.f259u = new CopyOnWriteArrayList();
        new HashMap();
    }

    public C0033i(WebViewStartUpResultBoundaryInterface webViewStartUpResultBoundaryInterface) {
        this.f258t = 8;
        this.f259u = webViewStartUpResultBoundaryInterface;
        List<Throwable> blockingStartUpLocations = webViewStartUpResultBoundaryInterface.getBlockingStartUpLocations();
        ArrayList arrayList = new ArrayList();
        for (Throwable th : blockingStartUpLocations) {
            arrayList.add(new F2.e());
        }
    }

    public C0033i(AbstractC5755m abstractC5755m) {
        this.f258t = 23;
        P2.e eVar = new P2.e();
        eVar.f8221t = abstractC5755m;
        Q1.i iVar = new Q1.i(abstractC5755m);
        eVar.f8222u = iVar;
        abstractC5755m.addTextChangedListener(iVar);
        if (Q1.a.f8563b == null) {
            synchronized (Q1.a.f8562a) {
                try {
                    if (Q1.a.f8563b == null) {
                        Q1.a aVar = new Q1.a();
                        try {
                            Q1.a.f8564c = Class.forName("android.text.DynamicLayout$ChangeWatcher", false, Q1.a.class.getClassLoader());
                        } catch (Throwable unused) {
                        }
                        Q1.a.f8563b = aVar;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        abstractC5755m.setEditableFactory(Q1.a.f8563b);
        this.f259u = eVar;
    }
}
