package A1;

import android.view.ScrollFeedbackProvider;
import androidx.core.widget.NestedScrollView;

/* JADX INFO: renamed from: A1.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0040p implements InterfaceC0041q {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final ScrollFeedbackProvider f274t;

    public C0040p(NestedScrollView nestedScrollView) {
        this.f274t = ScrollFeedbackProvider.createProvider(nestedScrollView);
    }

    @Override // A1.InterfaceC0041q
    public final void onScrollLimit(int i, int i4, int i9, boolean z8) {
        this.f274t.onScrollLimit(i, i4, i9, z8);
    }

    @Override // A1.InterfaceC0041q
    public final void onScrollProgress(int i, int i4, int i9, int i10) {
        this.f274t.onScrollProgress(i, i4, i9, i10);
    }
}
