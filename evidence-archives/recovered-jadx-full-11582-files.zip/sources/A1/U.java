package A1;

import android.view.WindowInsetsAnimation;

/* JADX INFO: loaded from: classes.dex */
public final class U extends V {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final WindowInsetsAnimation f215e;

    public U(WindowInsetsAnimation windowInsetsAnimation) {
        super(0, null, 0L);
        this.f215e = windowInsetsAnimation;
    }

    @Override // A1.V
    public final float a() {
        return this.f215e.getAlpha();
    }

    @Override // A1.V
    public final long b() {
        return this.f215e.getDurationMillis();
    }

    @Override // A1.V
    public final float c() {
        return this.f215e.getInterpolatedFraction();
    }

    @Override // A1.V
    public final int d() {
        return this.f215e.getTypeMask();
    }

    @Override // A1.V
    public final void e(float f4) {
        this.f215e.setFraction(f4);
    }
}
