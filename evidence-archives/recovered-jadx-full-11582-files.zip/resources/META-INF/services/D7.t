E7.b
