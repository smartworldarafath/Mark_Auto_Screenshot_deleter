.class public abstract LA7/q;
.super LA7/p;
.source "SourceFile"
