.class public abstract LA7/s;
.super LA7/r;
.source "SourceFile"
