.class public abstract LA7/t;
.super LA7/s;
.source "SourceFile"
