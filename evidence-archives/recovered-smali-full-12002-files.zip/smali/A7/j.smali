.class public final synthetic LA7/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA7/j;->t:I

    iput-object p2, p0, LA7/j;->u:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 2
    iput p1, p0, LA7/j;->t:I

    iput-object p2, p0, LA7/j;->u:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    iget v0, p0, LA7/j;->t:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, Lb2/y;

    check-cast p1, Lb2/e;

    const-string v1, "backStackEntry"

    invoke-static {p1, v1}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p1, Lb2/e;->A:Le2/c;

    iget-object v2, p1, Lb2/e;->u:Lb2/p;

    const/4 v3, 0x0

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    move-object v2, v3

    :goto_0
    if-nez v2, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v1}, Le2/c;->a()Landroid/os/Bundle;

    invoke-virtual {v0, v2}, Lb2/y;->c(Lb2/p;)Lb2/p;

    move-result-object v4

    if-nez v4, :cond_2

    :goto_1
    move-object p1, v3

    goto :goto_2

    :cond_2
    invoke-virtual {v4, v2}, Lb2/p;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    goto :goto_2

    :cond_3
    invoke-virtual {v0}, Lb2/y;->b()Lb2/h;

    move-result-object p1

    invoke-virtual {v1}, Le2/c;->a()Landroid/os/Bundle;

    move-result-object v0

    invoke-virtual {v4, v0}, Lb2/p;->b(Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    invoke-virtual {p1, v4, v0}, Lb2/h;->b(Lb2/p;Landroid/os/Bundle;)Lb2/e;

    move-result-object p1

    :goto_2
    return-object p1

    :pswitch_0
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, La1/n;

    check-cast p1, La1/D;

    iget-object v3, p1, La1/D;->b:La1/w;

    iget v4, p1, La1/D;->c:I

    iget v5, p1, La1/D;->d:I

    iget-object v6, p1, La1/D;->e:Ljava/lang/Object;

    new-instance v1, La1/D;

    const/4 v2, 0x0

    invoke-direct/range {v1 .. v6}, La1/D;-><init>(La1/m;La1/w;IILjava/lang/Object;)V

    invoke-virtual {v0, v1}, La1/n;->a(La1/D;)La1/G;

    move-result-object p1

    invoke-interface {p1}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :pswitch_1
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, Lp/I;

    instance-of v1, p1, Lk0/u;

    if-eqz v1, :cond_4

    move-object v1, p1

    check-cast v1, Lk0/u;

    const/4 v2, 0x4

    invoke-virtual {v1, v2}, Lk0/u;->g(I)V

    :cond_4
    invoke-virtual {v0, p1}, Lp/I;->a(Ljava/lang/Object;)Z

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_2
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, La0/y0;

    check-cast p1, Ljava/lang/Throwable;

    const-string v1, "Recomposer effect job completed"

    new-instance v2, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    iget-object v1, v0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    iget-object v3, v0, La0/y0;->c:LD7/c0;

    const/4 v4, 0x0

    if-eqz v3, :cond_5

    iget-object v5, v0, La0/y0;->t:LG7/g0;

    sget-object v6, La0/s0;->u:La0/s0;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v5, v4, v6}, LG7/g0;->j(Ljava/lang/Object;Ljava/lang/Object;)Z

    invoke-interface {v3, v2}, LD7/c0;->f(Ljava/util/concurrent/CancellationException;)V

    iput-object v4, v0, La0/y0;->q:LD7/h;

    new-instance v2, LA/Q;

    const/16 v4, 0x16

    invoke-direct {v2, v4, v0, p1}, LA/Q;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v3, v2}, LD7/c0;->a0(Lr7/c;)LD7/K;

    goto :goto_3

    :catchall_0
    move-exception v0

    move-object p1, v0

    goto :goto_4

    :cond_5
    iput-object v2, v0, La0/y0;->d:Ljava/lang/Throwable;

    iget-object p1, v0, La0/y0;->t:LG7/g0;

    sget-object v0, La0/s0;->t:La0/s0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1, v4, v0}, LG7/g0;->j(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_3
    monitor-exit v1

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :goto_4
    monitor-exit v1

    throw p1

    :pswitch_3
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, La0/x;

    invoke-virtual {v0, p1}, La0/x;->z(Ljava/lang/Object;)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_4
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LW2/e;

    check-cast p1, Ljava/io/IOException;

    const/4 p1, 0x1

    iput-boolean p1, v0, LW2/e;->D:Z

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_5
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LR7/O;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, v0, LR7/O;->e:[Ljava/lang/String;

    aget-object v2, v2, p1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, LR7/O;->j(I)LP7/f;

    move-result-object p1

    invoke-interface {p1}, LP7/f;->a()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_6
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LR/w;

    check-cast p1, Lc1/g;

    invoke-virtual {v0, p1}, LR/w;->a(Lc1/g;)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_7
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LP7/g;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, v0, LP7/g;->e:[Ljava/lang/String;

    aget-object v2, v2, p1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v0, LP7/g;->f:[LP7/f;

    aget-object p1, v0, p1

    invoke-interface {p1}, LP7/f;->a()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_8
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LP/c;

    check-cast p1, La0/H;

    new-instance p1, LE/J;

    const/4 v1, 0x6

    invoke-direct {p1, v1, v0}, LE/J;-><init>(ILjava/lang/Object;)V

    return-object p1

    :pswitch_9
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LK/a;

    check-cast p1, Lr7/c;

    invoke-interface {p1, v0}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_a
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LA7/j;

    check-cast p1, LL0/E0;

    instance-of v1, p1, LO/a;

    if-eqz v1, :cond_6

    check-cast p1, LO/a;

    iget-object p1, p1, LO/a;->H:LA7/j;

    invoke-virtual {v0, p1}, LA7/j;->g(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object p1

    :cond_6
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "TextContextMenuDataNode.TraverseKey key must only be attached to instances of TextContextMenuDataNode."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :pswitch_b
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LO/b;

    check-cast p1, LK/a;

    iget-object v1, v0, LO/b;->J:LE/S;

    sget-object v2, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->b:La0/X0;

    invoke-static {v0, v2}, LL0/f;->i(LL0/k;La0/q0;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v1, p1, v0}, LE/S;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_c
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LO6/a;

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    invoke-virtual {v0, p1}, LO6/a;->k(Z)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_d
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, Landroid/graphics/drawable/Drawable;

    check-cast p1, Lv0/d;

    invoke-interface {p1}, Lv0/d;->c0()Lcom/google/android/gms/internal/play_billing/l;

    move-result-object v1

    invoke-virtual {v1}, Lcom/google/android/gms/internal/play_billing/l;->f()Lt0/n;

    move-result-object v1

    invoke-interface {p1}, Lv0/d;->d()J

    move-result-wide v2

    const/16 v4, 0x20

    shr-long/2addr v2, v4

    long-to-int v2, v2

    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v2

    float-to-int v2, v2

    invoke-interface {p1}, Lv0/d;->d()J

    move-result-wide v3

    const-wide v5, 0xffffffffL

    and-long/2addr v3, v5

    long-to-int p1, v3

    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    float-to-int p1, p1

    const/4 v3, 0x0

    invoke-virtual {v0, v3, v3, v2, p1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-static {v1}, Lt0/b;->a(Lt0/n;)Landroid/graphics/Canvas;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_e
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LL7/c;

    check-cast p1, Ljava/lang/Throwable;

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, LL7/c;->f(Ljava/lang/Object;)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_f
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LK6/o;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, LK6/o;->b(IZ)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_10
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LK5/K;

    check-cast p1, LI1/b;

    const-string v1, "ex"

    invoke-static {p1, v1}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "FirebaseSessions"

    const-string v2, "CorruptionException in session data DataStore"

    invoke-static {v1, v2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    new-instance p1, LK5/J;

    iget-object v0, v0, LK5/K;->a:LK5/X;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, LK5/X;->a(LK5/O;)LK5/O;

    move-result-object v0

    invoke-direct {p1, v0, v1, v1}, LK5/J;-><init>(LK5/O;LK5/m0;Ljava/util/Map;)V

    return-object p1

    :pswitch_11
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LI/D0;

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    iget-object v1, v0, LI/D0;->a:La0/d0;

    invoke-virtual {v1}, La0/d0;->h()F

    move-result v2

    add-float/2addr v2, p1

    iget-object v0, v0, LI/D0;->b:La0/d0;

    invoke-virtual {v0}, La0/d0;->h()F

    move-result v3

    cmpl-float v3, v2, v3

    if-lez v3, :cond_7

    invoke-virtual {v0}, La0/d0;->h()F

    move-result p1

    invoke-virtual {v1}, La0/d0;->h()F

    move-result v0

    sub-float/2addr p1, v0

    goto :goto_5

    :cond_7
    const/4 v0, 0x0

    cmpg-float v0, v2, v0

    if-gez v0, :cond_8

    invoke-virtual {v1}, La0/d0;->h()F

    move-result p1

    neg-float p1, p1

    :cond_8
    :goto_5
    invoke-virtual {v1}, La0/d0;->h()F

    move-result v0

    add-float/2addr v0, p1

    invoke-virtual {v1, v0}, La0/d0;->i(F)V

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    return-object p1

    :pswitch_12
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LT/j;

    check-cast p1, LT0/j;

    sget-object v1, LT/H;->c:LT0/v;

    new-instance v2, LT/G;

    sget-object v3, LI/N;->t:LI/N;

    invoke-interface {v0}, LT/j;->a()J

    move-result-wide v4

    sget-object v6, LT/F;->u:LT/F;

    const/4 v7, 0x1

    invoke-direct/range {v2 .. v7}, LT/G;-><init>(LI/N;JLT/F;Z)V

    invoke-virtual {p1, v1, v2}, LT0/j;->f(LT0/v;Ljava/lang/Object;)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_13
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, Lj0/g;

    if-eqz v0, :cond_9

    invoke-interface {v0, p1}, Lj0/g;->c(Ljava/lang/Object;)Z

    move-result p1

    goto :goto_6

    :cond_9
    const/4 p1, 0x1

    :goto_6
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1

    :pswitch_14
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LE/Y;

    check-cast p1, La0/H;

    new-instance p1, LE/J;

    const/4 v1, 0x2

    invoke-direct {p1, v1, v0}, LE/J;-><init>(ILjava/lang/Object;)V

    return-object p1

    :pswitch_15
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LE/L;

    check-cast p1, La0/H;

    new-instance p1, LE/J;

    const/4 v1, 0x0

    invoke-direct {p1, v1, v0}, LE/J;-><init>(ILjava/lang/Object;)V

    return-object p1

    :pswitch_16
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LD/A;

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    neg-float p1, p1

    const/4 v1, 0x0

    cmpg-float v2, p1, v1

    if-gez v2, :cond_a

    invoke-virtual {v0}, LD/A;->d()Z

    move-result v2

    if-eqz v2, :cond_b

    :cond_a
    cmpl-float v2, p1, v1

    if-lez v2, :cond_c

    invoke-virtual {v0}, LD/A;->b()Z

    move-result v2

    if-nez v2, :cond_c

    :cond_b
    move p1, v1

    goto/16 :goto_a

    :cond_c
    iget v2, v0, LD/A;->g:F

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    const/high16 v3, 0x3f000000    # 0.5f

    cmpg-float v2, v2, v3

    if-gtz v2, :cond_d

    goto :goto_7

    :cond_d
    const-string v2, "entered drag with non-zero pending scroll"

    invoke-static {v2}, Lz/a;->c(Ljava/lang/String;)V

    :goto_7
    iget v2, v0, LD/A;->g:F

    add-float/2addr v2, p1

    iput v2, v0, LD/A;->g:F

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    cmpl-float v2, v2, v3

    if-lez v2, :cond_12

    iget v2, v0, LD/A;->g:F

    invoke-static {v2}, Lu7/a;->b(F)I

    move-result v4

    iget-object v5, v0, LD/A;->e:La0/h0;

    invoke-virtual {v5}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LD/o;

    iget-boolean v6, v0, LD/A;->b:Z

    const/4 v7, 0x1

    xor-int/2addr v6, v7

    invoke-virtual {v5, v4, v6}, LD/o;->a(IZ)LD/o;

    move-result-object v5

    if-eqz v5, :cond_f

    iget-object v6, v0, LD/A;->c:LD/o;

    if-eqz v6, :cond_f

    invoke-virtual {v6, v4, v7}, LD/o;->a(IZ)LD/o;

    move-result-object v4

    if-eqz v4, :cond_e

    iput-object v4, v0, LD/A;->c:LD/o;

    goto :goto_8

    :cond_e
    const/4 v5, 0x0

    :cond_f
    :goto_8
    if-eqz v5, :cond_10

    iget-boolean v4, v0, LD/A;->b:Z

    invoke-virtual {v0, v5, v4, v7}, LD/A;->f(LD/o;ZZ)V

    iget-object v4, v0, LD/A;->r:La0/Z;

    sget-object v6, Ld7/z;->a:Ld7/z;

    invoke-interface {v4, v6}, La0/Z;->setValue(Ljava/lang/Object;)V

    iget v4, v0, LD/A;->g:F

    sub-float/2addr v2, v4

    invoke-virtual {v0, v2, v5}, LD/A;->h(FLD/o;)V

    goto :goto_9

    :cond_10
    iget-object v4, v0, LD/A;->j:LL0/J;

    if-eqz v4, :cond_11

    invoke-virtual {v4}, LL0/J;->k()V

    :cond_11
    iget v4, v0, LD/A;->g:F

    sub-float/2addr v2, v4

    invoke-virtual {v0}, LD/A;->g()LD/o;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, LD/A;->h(FLD/o;)V

    :cond_12
    :goto_9
    iget v2, v0, LD/A;->g:F

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    cmpg-float v2, v2, v3

    if-gtz v2, :cond_13

    goto :goto_a

    :cond_13
    iget v2, v0, LD/A;->g:F

    sub-float/2addr p1, v2

    iput v1, v0, LD/A;->g:F

    :goto_a
    neg-float p1, p1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    return-object p1

    :pswitch_17
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LD/w;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-virtual {v0, p1}, LD/w;->d(I)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    return-object p1

    :pswitch_18
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    return-object v0

    :pswitch_19
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LC/B;

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    neg-float p1, p1

    const/4 v1, 0x0

    cmpg-float v2, p1, v1

    if-gez v2, :cond_14

    invoke-virtual {v0}, LC/B;->d()Z

    move-result v2

    if-eqz v2, :cond_15

    :cond_14
    cmpl-float v2, p1, v1

    if-lez v2, :cond_16

    invoke-virtual {v0}, LC/B;->b()Z

    move-result v2

    if-nez v2, :cond_16

    :cond_15
    move p1, v1

    goto/16 :goto_e

    :cond_16
    iget v2, v0, LC/B;->h:F

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    const/high16 v3, 0x3f000000    # 0.5f

    cmpg-float v2, v2, v3

    if-gtz v2, :cond_17

    goto :goto_b

    :cond_17
    const-string v2, "entered drag with non-zero pending scroll"

    invoke-static {v2}, Lz/a;->c(Ljava/lang/String;)V

    :goto_b
    const/4 v2, 0x1

    iput-boolean v2, v0, LC/B;->d:Z

    iget v4, v0, LC/B;->h:F

    add-float/2addr v4, p1

    iput v4, v0, LC/B;->h:F

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4

    cmpl-float v4, v4, v3

    if-lez v4, :cond_1c

    iget v4, v0, LC/B;->h:F

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v5

    iget-object v6, v0, LC/B;->f:La0/h0;

    invoke-virtual {v6}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LC/r;

    iget-boolean v7, v0, LC/B;->b:Z

    xor-int/2addr v7, v2

    invoke-virtual {v6, v5, v7}, LC/r;->a(IZ)LC/r;

    move-result-object v6

    if-eqz v6, :cond_19

    iget-object v7, v0, LC/B;->c:LC/r;

    if-eqz v7, :cond_19

    invoke-virtual {v7, v5, v2}, LC/r;->a(IZ)LC/r;

    move-result-object v5

    if-eqz v5, :cond_18

    iput-object v5, v0, LC/B;->c:LC/r;

    goto :goto_c

    :cond_18
    const/4 v6, 0x0

    :cond_19
    :goto_c
    if-eqz v6, :cond_1a

    iget-boolean v5, v0, LC/B;->b:Z

    invoke-virtual {v0, v6, v5, v2}, LC/B;->f(LC/r;ZZ)V

    iget-object v2, v0, LC/B;->v:La0/Z;

    sget-object v5, Ld7/z;->a:Ld7/z;

    invoke-interface {v2, v5}, La0/Z;->setValue(Ljava/lang/Object;)V

    iget v2, v0, LC/B;->h:F

    sub-float/2addr v4, v2

    invoke-virtual {v0, v4, v6}, LC/B;->h(FLC/r;)V

    goto :goto_d

    :cond_1a
    iget-object v2, v0, LC/B;->k:LL0/J;

    if-eqz v2, :cond_1b

    invoke-virtual {v2}, LL0/J;->k()V

    :cond_1b
    iget v2, v0, LC/B;->h:F

    sub-float/2addr v4, v2

    invoke-virtual {v0}, LC/B;->g()LC/r;

    move-result-object v2

    invoke-virtual {v0, v4, v2}, LC/B;->h(FLC/r;)V

    :cond_1c
    :goto_d
    iget v2, v0, LC/B;->h:F

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    cmpg-float v2, v2, v3

    if-gtz v2, :cond_1d

    goto :goto_e

    :cond_1d
    iget v2, v0, LC/B;->h:F

    sub-float/2addr p1, v2

    iput v1, v0, LC/B;->h:F

    :goto_e
    neg-float p1, p1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    return-object p1

    :pswitch_1a
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LC/o;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    iget-wide v1, v0, LC/o;->x:J

    invoke-virtual {v0, p1, v1, v2}, LC/o;->J(IJ)LC/s;

    move-result-object p1

    return-object p1

    :pswitch_1b
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LB5/j;

    check-cast p1, LM1/b;

    sget-object v1, LB5/j;->c:LM1/e;

    invoke-virtual {p1}, LM1/b;->a()Ljava/util/Map;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const-wide/16 v3, 0x0

    move-wide v5, v3

    :cond_1e
    :goto_f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_21

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Map$Entry;

    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v8

    instance-of v8, v8, Ljava/util/Set;

    if-eqz v8, :cond_1e

    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, LM1/e;

    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Set;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v9

    invoke-virtual {v0, v9, v10}, LB5/j;->b(J)Ljava/lang/String;

    move-result-object v9

    invoke-interface {v7, v9}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_20

    filled-new-array {v9}, [Ljava/lang/Object;

    move-result-object v7

    new-instance v9, Ljava/util/HashSet;

    const/4 v10, 0x1

    invoke-direct {v9, v10}, Ljava/util/HashSet;-><init>(I)V

    const/4 v10, 0x0

    aget-object v7, v7, v10

    invoke-static {v7}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v9, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_1f

    invoke-static {v9}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object v7

    invoke-virtual {p1, v8, v7}, LM1/b;->d(LM1/e;Ljava/lang/Object;)V

    const-wide/16 v7, 0x1

    add-long/2addr v5, v7

    goto :goto_f

    :cond_1f
    new-instance p1, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "duplicate element: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_20
    invoke-virtual {p1, v8}, LM1/b;->c(LM1/e;)V

    goto :goto_f

    :cond_21
    cmp-long v0, v5, v3

    if-nez v0, :cond_22

    invoke-virtual {p1, v1}, LM1/b;->c(LM1/e;)V

    goto :goto_10

    :cond_22
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {p1, v1, v0}, LM1/b;->d(LM1/e;Ljava/lang/Object;)V

    :goto_10
    const/4 p1, 0x0

    return-object p1

    :pswitch_1c
    iget-object v0, p0, LA7/j;->u:Ljava/lang/Object;

    check-cast v0, LA7/k;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-virtual {v0, p1}, LA7/k;->c(I)LA7/i;

    move-result-object p1

    return-object p1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
