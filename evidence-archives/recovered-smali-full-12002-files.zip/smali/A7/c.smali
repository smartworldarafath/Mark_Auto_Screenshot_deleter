.class public final LA7/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lz7/f;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;

.field public final c:Ld7/e;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Lr7/c;)V
    .locals 0

    .line 1
    iput p1, p0, LA7/c;->a:I

    iput-object p2, p0, LA7/c;->b:Ljava/lang/Object;

    iput-object p3, p0, LA7/c;->c:Ld7/e;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/CharSequence;Lr7/e;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LA7/c;->a:I

    const-string v0, "input"

    invoke-static {p1, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, LA7/c;->b:Ljava/lang/Object;

    .line 4
    iput-object p2, p0, LA7/c;->c:Ld7/e;

    return-void
.end method


# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .locals 1

    iget v0, p0, LA7/c;->a:I

    packed-switch v0, :pswitch_data_0

    new-instance v0, Lg0/c;

    invoke-direct {v0, p0}, Lg0/c;-><init>(LA7/c;)V

    return-object v0

    :pswitch_0
    new-instance v0, Lz7/e;

    invoke-direct {v0, p0}, Lz7/e;-><init>(LA7/c;)V

    return-object v0

    :pswitch_1
    new-instance v0, LA7/b;

    invoke-direct {v0, p0}, LA7/b;-><init>(LA7/c;)V

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
