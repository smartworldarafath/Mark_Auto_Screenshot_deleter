.class public final LA7/k;
.super Le7/a;
.source "SourceFile"


# instance fields
.field public final synthetic t:I

.field public final u:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, LA7/k;->t:I

    iput-object p2, p0, LA7/k;->u:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final b()I
    .locals 1

    iget v0, p0, LA7/k;->t:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LA7/k;->u:Ljava/lang/Object;

    check-cast v0, Lf0/c;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v0, v0, Lf0/c;->u:I

    return v0

    :pswitch_0
    iget-object v0, p0, LA7/k;->u:Ljava/lang/Object;

    check-cast v0, LA4/f;

    iget-object v0, v0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, Ljava/util/regex/Matcher;

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->groupCount()I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    return v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public c(I)LA7/i;
    .locals 3

    iget-object v0, p0, LA7/k;->u:Ljava/lang/Object;

    check-cast v0, LA4/f;

    iget-object v0, v0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, Ljava/util/regex/Matcher;

    invoke-virtual {v0, p1}, Ljava/util/regex/Matcher;->start(I)I

    move-result v1

    invoke-virtual {v0, p1}, Ljava/util/regex/Matcher;->end(I)I

    move-result v2

    invoke-static {v1, v2}, LH4/Z5;->f(II)Lx7/d;

    move-result-object v1

    iget v2, v1, Lx7/b;->t:I

    if-ltz v2, :cond_0

    new-instance v2, LA7/i;

    invoke-virtual {v0, p1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object p1

    const-string v0, "group(...)"

    invoke-static {p1, v0}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v2, p1, v1}, LA7/i;-><init>(Ljava/lang/String;Lx7/d;)V

    return-object v2

    :cond_0
    const/4 p1, 0x0

    return-object p1
.end method

.method public final contains(Ljava/lang/Object;)Z
    .locals 1

    iget v0, p0, LA7/k;->t:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LA7/k;->u:Ljava/lang/Object;

    check-cast v0, Lf0/c;

    invoke-virtual {v0, p1}, Le7/e;->containsValue(Ljava/lang/Object;)Z

    move-result p1

    return p1

    :pswitch_0
    if-nez p1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    instance-of v0, p1, LA7/i;

    :goto_0
    if-nez v0, :cond_1

    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    check-cast p1, LA7/i;

    invoke-super {p0, p1}, Le7/a;->contains(Ljava/lang/Object;)Z

    move-result p1

    :goto_1
    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public isEmpty()Z
    .locals 1

    iget v0, p0, LA7/k;->t:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, Le7/a;->isEmpty()Z

    move-result v0

    return v0

    :pswitch_0
    const/4 v0, 0x0

    return v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final iterator()Ljava/util/Iterator;
    .locals 7

    iget v0, p0, LA7/k;->t:I

    packed-switch v0, :pswitch_data_0

    new-instance v0, Lf0/k;

    iget-object v1, p0, LA7/k;->u:Ljava/lang/Object;

    check-cast v1, Lf0/c;

    iget-object v1, v1, Lf0/c;->t:Lf0/l;

    const/16 v2, 0x8

    new-array v3, v2, [Lf0/m;

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v2, :cond_0

    new-instance v5, Lf0/n;

    const/4 v6, 0x2

    invoke-direct {v5, v6}, Lf0/n;-><init>(I)V

    aput-object v5, v3, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    invoke-direct {v0, v1, v3}, Lf0/d;-><init>(Lf0/l;[Lf0/m;)V

    return-object v0

    :pswitch_0
    new-instance v0, Lx7/d;

    invoke-virtual {p0}, Le7/a;->size()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    const/4 v3, 0x0

    invoke-direct {v0, v3, v1, v2}, Lx7/b;-><init>(III)V

    new-instance v1, LA7/w;

    invoke-direct {v1, v2, v0}, LA7/w;-><init>(ILjava/lang/Object;)V

    new-instance v0, LA7/j;

    const/4 v2, 0x0

    invoke-direct {v0, v2, p0}, LA7/j;-><init>(ILjava/lang/Object;)V

    new-instance v2, Lz7/j;

    const/4 v3, 0x1

    invoke-direct {v2, v1, v0, v3}, Lz7/j;-><init>(Lz7/f;Lr7/c;I)V

    new-instance v0, Lz7/k;

    invoke-direct {v0, v2}, Lz7/k;-><init>(Lz7/j;)V

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
