.class public final LA7/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Iterator;
.implements Lt7/a;


# instance fields
.field public t:I

.field public u:I

.field public v:I

.field public w:Lx7/d;

.field public final synthetic x:LA7/c;


# direct methods
.method public constructor <init>(LA7/c;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA7/b;->x:LA7/c;

    const/4 v0, -0x1

    iput v0, p0, LA7/b;->t:I

    iget-object p1, p1, LA7/c;->b:Ljava/lang/Object;

    check-cast p1, Ljava/lang/CharSequence;

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p1

    const/4 v0, 0x0

    invoke-static {v0, v0, p1}, LH4/Z5;->c(III)I

    move-result p1

    iput p1, p0, LA7/b;->u:I

    iput p1, p0, LA7/b;->v:I

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 7

    iget-object v0, p0, LA7/b;->x:LA7/c;

    iget-object v1, v0, LA7/c;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/CharSequence;

    iget v2, p0, LA7/b;->v:I

    const/4 v3, 0x0

    if-gez v2, :cond_0

    iput v3, p0, LA7/b;->t:I

    const/4 v0, 0x0

    iput-object v0, p0, LA7/b;->w:Lx7/d;

    return-void

    :cond_0
    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v4

    const/4 v5, -0x1

    const/4 v6, 0x1

    if-le v2, v4, :cond_1

    new-instance v0, Lx7/d;

    iget v2, p0, LA7/b;->u:I

    invoke-static {v1}, LA7/n;->v(Ljava/lang/CharSequence;)I

    move-result v1

    invoke-direct {v0, v2, v1, v6}, Lx7/b;-><init>(III)V

    iput-object v0, p0, LA7/b;->w:Lx7/d;

    iput v5, p0, LA7/b;->v:I

    goto :goto_0

    :cond_1
    iget-object v0, v0, LA7/c;->c:Ld7/e;

    check-cast v0, Lr7/e;

    iget v2, p0, LA7/b;->v:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld7/k;

    if-nez v0, :cond_2

    new-instance v0, Lx7/d;

    iget v2, p0, LA7/b;->u:I

    invoke-static {v1}, LA7/n;->v(Ljava/lang/CharSequence;)I

    move-result v1

    invoke-direct {v0, v2, v1, v6}, Lx7/b;-><init>(III)V

    iput-object v0, p0, LA7/b;->w:Lx7/d;

    iput v5, p0, LA7/b;->v:I

    goto :goto_0

    :cond_2
    iget-object v1, v0, Ld7/k;->t:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    iget-object v0, v0, Ld7/k;->u:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    iget v2, p0, LA7/b;->u:I

    invoke-static {v2, v1}, LH4/Z5;->f(II)Lx7/d;

    move-result-object v2

    iput-object v2, p0, LA7/b;->w:Lx7/d;

    add-int/2addr v1, v0

    iput v1, p0, LA7/b;->u:I

    if-nez v0, :cond_3

    move v3, v6

    :cond_3
    add-int/2addr v1, v3

    iput v1, p0, LA7/b;->v:I

    :goto_0
    iput v6, p0, LA7/b;->t:I

    return-void
.end method

.method public final hasNext()Z
    .locals 2

    iget v0, p0, LA7/b;->t:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, LA7/b;->a()V

    :cond_0
    iget v0, p0, LA7/b;->t:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    return v1

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final next()Ljava/lang/Object;
    .locals 3

    iget v0, p0, LA7/b;->t:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, LA7/b;->a()V

    :cond_0
    iget v0, p0, LA7/b;->t:I

    if-eqz v0, :cond_1

    iget-object v0, p0, LA7/b;->w:Lx7/d;

    const-string v2, "null cannot be cast to non-null type kotlin.ranges.IntRange"

    invoke-static {v0, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    iput-object v2, p0, LA7/b;->w:Lx7/d;

    iput v1, p0, LA7/b;->t:I

    return-object v0

    :cond_1
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method

.method public final remove()V
    .locals 2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "Operation is not supported for read-only collection"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
