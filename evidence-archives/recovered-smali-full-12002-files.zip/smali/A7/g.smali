.class public final LA7/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final d:LA7/g;


# instance fields
.field public final a:Z

.field public final b:LA7/e;

.field public final c:LA7/f;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    new-instance v0, LA7/g;

    sget-object v1, LA7/e;->a:LA7/e;

    sget-object v2, LA7/f;->b:LA7/f;

    const/4 v3, 0x0

    invoke-direct {v0, v3, v1, v2}, LA7/g;-><init>(ZLA7/e;LA7/f;)V

    sput-object v0, LA7/g;->d:LA7/g;

    new-instance v0, LA7/g;

    const/4 v3, 0x1

    invoke-direct {v0, v3, v1, v2}, LA7/g;-><init>(ZLA7/e;LA7/f;)V

    return-void
.end method

.method public constructor <init>(ZLA7/e;LA7/f;)V
    .locals 1

    const-string v0, "bytes"

    invoke-static {p2, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "number"

    invoke-static {p3, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, LA7/g;->a:Z

    iput-object p2, p0, LA7/g;->b:LA7/e;

    iput-object p3, p0, LA7/g;->c:LA7/f;

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "HexFormat(\n    upperCase = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, LA7/g;->a:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ",\n    bytes = BytesHexFormat(\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LA7/g;->b:LA7/e;

    const-string v2, "        "

    invoke-virtual {v1, v2, v0}, LA7/e;->a(Ljava/lang/String;Ljava/lang/StringBuilder;)V

    const/16 v1, 0xa

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v3, "    ),"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v3, "    number = NumberHexFormat("

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v3, p0, LA7/g;->c:LA7/f;

    invoke-virtual {v3, v2, v0}, LA7/f;->a(Ljava/lang/String;Ljava/lang/StringBuilder;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, "    )"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
