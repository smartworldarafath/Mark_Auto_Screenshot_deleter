.class public final synthetic LA7/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;I)V
    .locals 0

    iput p2, p0, LA7/o;->t:I

    iput-object p1, p0, LA7/o;->u:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    iget v0, p0, LA7/o;->t:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, LT0/j;

    iget-object v0, p0, LA7/o;->u:Ljava/lang/String;

    invoke-static {p1, v0}, LT0/u;->b(LT0/j;Ljava/lang/String;)V

    const/4 v0, 0x5

    invoke-static {p1, v0}, LT0/u;->c(LT0/j;I)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_0
    check-cast p1, Lv2/a;

    const-string v0, "SELECT screenshotId FROM screenshot_index_entity WHERE extractedText LIKE \'%\' || ? || \'%\' OR labels LIKE \'%\' || ? || \'%\' ORDER BY indexedAtEpochMillis DESC"

    invoke-interface {p1, v0}, Lv2/a;->d0(Ljava/lang/String;)Lv2/c;

    move-result-object p1

    iget-object v0, p0, LA7/o;->u:Ljava/lang/String;

    const/4 v1, 0x1

    if-nez v0, :cond_0

    :try_start_0
    invoke-interface {p1, v1}, Lv2/c;->d(I)V

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_4

    :cond_0
    invoke-interface {p1, v1, v0}, Lv2/c;->r(ILjava/lang/String;)V

    :goto_0
    const/4 v1, 0x2

    if-nez v0, :cond_1

    invoke-interface {p1, v1}, Lv2/c;->d(I)V

    goto :goto_1

    :cond_1
    invoke-interface {p1, v1, v0}, Lv2/c;->r(ILjava/lang/String;)V

    :goto_1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_2
    invoke-interface {p1}, Lv2/c;->Y()Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v1, 0x0

    invoke-interface {p1, v1}, Lv2/c;->isNull(I)Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v1, 0x0

    goto :goto_3

    :cond_2
    invoke-interface {p1, v1}, Lv2/c;->getLong(I)J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    :goto_3
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    :cond_3
    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V

    return-object v0

    :goto_4
    invoke-interface {p1}, Ljava/lang/AutoCloseable;->close()V

    throw v0

    :pswitch_1
    check-cast p1, Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p1, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, LA7/n;->B(Ljava/lang/CharSequence;)Z

    move-result v0

    iget-object v1, p0, LA7/o;->u:Ljava/lang/String;

    if-eqz v0, :cond_4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v0, v2, :cond_5

    move-object p1, v1

    goto :goto_5

    :cond_4
    invoke-static {v1, p1}, Lcom/google/android/gms/internal/measurement/q1;->l(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :cond_5
    :goto_5
    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
