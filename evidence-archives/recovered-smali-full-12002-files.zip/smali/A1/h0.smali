.class public LA1/h0;
.super LA1/g0;
.source "SourceFile"


# instance fields
.field public o:Lt1/b;

.field public p:Lt1/b;

.field public q:Lt1/b;


# direct methods
.method public constructor <init>(LA1/q0;LA1/h0;)V
    .locals 0

    .line 5
    invoke-direct {p0, p1, p2}, LA1/g0;-><init>(LA1/q0;LA1/g0;)V

    const/4 p1, 0x0

    .line 6
    iput-object p1, p0, LA1/h0;->o:Lt1/b;

    .line 7
    iput-object p1, p0, LA1/h0;->p:Lt1/b;

    .line 8
    iput-object p1, p0, LA1/h0;->q:Lt1/b;

    return-void
.end method

.method public constructor <init>(LA1/q0;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LA1/g0;-><init>(LA1/q0;Landroid/view/WindowInsets;)V

    const/4 p1, 0x0

    .line 2
    iput-object p1, p0, LA1/h0;->o:Lt1/b;

    .line 3
    iput-object p1, p0, LA1/h0;->p:Lt1/b;

    .line 4
    iput-object p1, p0, LA1/h0;->q:Lt1/b;

    return-void
.end method


# virtual methods
.method public i()Lt1/b;
    .locals 1

    iget-object v0, p0, LA1/h0;->p:Lt1/b;

    if-nez v0, :cond_0

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-static {v0}, LA1/Y;->v(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    move-result-object v0

    invoke-static {v0}, Lt1/b;->c(Landroid/graphics/Insets;)Lt1/b;

    move-result-object v0

    iput-object v0, p0, LA1/h0;->p:Lt1/b;

    :cond_0
    iget-object v0, p0, LA1/h0;->p:Lt1/b;

    return-object v0
.end method

.method public k()Lt1/b;
    .locals 1

    iget-object v0, p0, LA1/h0;->o:Lt1/b;

    if-nez v0, :cond_0

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-static {v0}, LA1/Y;->y(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    move-result-object v0

    invoke-static {v0}, Lt1/b;->c(Landroid/graphics/Insets;)Lt1/b;

    move-result-object v0

    iput-object v0, p0, LA1/h0;->o:Lt1/b;

    :cond_0
    iget-object v0, p0, LA1/h0;->o:Lt1/b;

    return-object v0
.end method

.method public m()Lt1/b;
    .locals 1

    iget-object v0, p0, LA1/h0;->q:Lt1/b;

    if-nez v0, :cond_0

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-static {v0}, LA1/Y;->d(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    move-result-object v0

    invoke-static {v0}, Lt1/b;->c(Landroid/graphics/Insets;)Lt1/b;

    move-result-object v0

    iput-object v0, p0, LA1/h0;->q:Lt1/b;

    :cond_0
    iget-object v0, p0, LA1/h0;->q:Lt1/b;

    return-object v0
.end method

.method public n(IIII)LA1/q0;
    .locals 1

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-static {v0, p1, p2, p3, p4}, LA1/Y;->h(Landroid/view/WindowInsets;IIII)Landroid/view/WindowInsets;

    move-result-object p1

    const/4 p2, 0x0

    invoke-static {p2, p1}, LA1/q0;->c(Landroid/view/View;Landroid/view/WindowInsets;)LA1/q0;

    move-result-object p1

    return-object p1
.end method

.method public u(Lt1/b;)V
    .locals 0

    return-void
.end method
