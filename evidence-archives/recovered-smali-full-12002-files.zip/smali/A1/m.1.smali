.class public final LA1/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc1/q;


# instance fields
.field public a:I

.field public b:I


# direct methods
.method public synthetic constructor <init>(II)V
    .locals 0

    .line 1
    iput p1, p0, LA1/m;->a:I

    iput p2, p0, LA1/m;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/google/android/gms/internal/ads/v6;II)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, LA1/m;->a:I

    iput p3, p0, LA1/m;->b:I

    return-void
.end method


# virtual methods
.method public a(I)I
    .locals 1

    if-ltz p1, :cond_0

    iget v0, p0, LA1/m;->b:I

    if-gt p1, v0, :cond_0

    iget v0, p0, LA1/m;->a:I

    invoke-static {p1, v0, p1}, LI/W;->B(III)V

    :cond_0
    return p1
.end method

.method public b(I)I
    .locals 1

    if-ltz p1, :cond_0

    iget v0, p0, LA1/m;->a:I

    if-gt p1, v0, :cond_0

    iget v0, p0, LA1/m;->b:I

    invoke-static {p1, v0, p1}, LI/W;->A(III)V

    :cond_0
    return p1
.end method

.method public c()I
    .locals 2

    iget v0, p0, LA1/m;->b:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_5

    const/4 v1, 0x5

    if-eq v0, v1, :cond_4

    const/16 v1, 0x1d

    if-eq v0, v1, :cond_3

    const/16 v1, 0x2a

    if-eq v0, v1, :cond_2

    const/16 v1, 0x16

    if-eq v0, v1, :cond_1

    const/16 v1, 0x17

    if-eq v0, v1, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    const/16 v0, 0xf

    return v0

    :cond_1
    const/high16 v0, 0x40000000    # 2.0f

    return v0

    :cond_2
    const/16 v0, 0x10

    return v0

    :cond_3
    const/16 v0, 0xc

    return v0

    :cond_4
    const/16 v0, 0xb

    return v0

    :cond_5
    const/16 v0, 0xa

    return v0
.end method
