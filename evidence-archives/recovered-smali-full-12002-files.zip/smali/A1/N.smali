.class public final LA1/N;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic a:LA1/W;

.field public final synthetic b:LA1/q0;

.field public final synthetic c:LA1/q0;

.field public final synthetic d:I

.field public final synthetic e:Landroid/view/View;


# direct methods
.method public constructor <init>(LA1/W;LA1/q0;LA1/q0;ILandroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/N;->a:LA1/W;

    iput-object p2, p0, LA1/N;->b:LA1/q0;

    iput-object p3, p0, LA1/N;->c:LA1/q0;

    iput p4, p0, LA1/N;->d:I

    iput-object p5, p0, LA1/N;->e:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 14

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedFraction()F

    move-result p1

    iget-object v0, p0, LA1/N;->a:LA1/W;

    iget-object v1, v0, LA1/W;->a:LA1/V;

    invoke-virtual {v1, p1}, LA1/V;->e(F)V

    iget-object p1, p0, LA1/N;->b:LA1/q0;

    iget-object v1, p1, LA1/q0;->a:LA1/l0;

    iget-object v2, v0, LA1/W;->a:LA1/V;

    invoke-virtual {v2}, LA1/V;->c()F

    move-result v2

    sget-object v3, LA1/S;->e:Landroid/view/animation/PathInterpolator;

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x22

    if-lt v3, v4, :cond_0

    new-instance v3, LA1/c0;

    invoke-direct {v3, p1}, LA1/c0;-><init>(LA1/q0;)V

    goto :goto_0

    :cond_0
    const/16 v4, 0x1f

    if-lt v3, v4, :cond_1

    new-instance v3, LA1/b0;

    invoke-direct {v3, p1}, LA1/b0;-><init>(LA1/q0;)V

    goto :goto_0

    :cond_1
    const/16 v4, 0x1e

    if-lt v3, v4, :cond_2

    new-instance v3, LA1/a0;

    invoke-direct {v3, p1}, LA1/a0;-><init>(LA1/q0;)V

    goto :goto_0

    :cond_2
    const/16 v4, 0x1d

    if-lt v3, v4, :cond_3

    new-instance v3, LA1/Z;

    invoke-direct {v3, p1}, LA1/Z;-><init>(LA1/q0;)V

    goto :goto_0

    :cond_3
    new-instance v3, LA1/X;

    invoke-direct {v3, p1}, LA1/X;-><init>(LA1/q0;)V

    :goto_0
    const/4 p1, 0x1

    :goto_1
    const/16 v4, 0x200

    if-gt p1, v4, :cond_5

    iget v4, p0, LA1/N;->d:I

    and-int/2addr v4, p1

    if-nez v4, :cond_4

    invoke-virtual {v1, p1}, LA1/l0;->g(I)Lt1/b;

    move-result-object v4

    invoke-virtual {v3, p1, v4}, LA1/d0;->c(ILt1/b;)V

    goto :goto_2

    :cond_4
    invoke-virtual {v1, p1}, LA1/l0;->g(I)Lt1/b;

    move-result-object v4

    iget-object v5, p0, LA1/N;->c:LA1/q0;

    iget-object v5, v5, LA1/q0;->a:LA1/l0;

    invoke-virtual {v5, p1}, LA1/l0;->g(I)Lt1/b;

    move-result-object v5

    iget v6, v4, Lt1/b;->a:I

    iget v7, v5, Lt1/b;->a:I

    sub-int/2addr v6, v7

    int-to-float v6, v6

    const/high16 v7, 0x3f800000    # 1.0f

    sub-float/2addr v7, v2

    mul-float/2addr v6, v7

    float-to-double v8, v6

    const-wide/high16 v10, 0x3fe0000000000000L    # 0.5

    add-double/2addr v8, v10

    double-to-int v6, v8

    iget v8, v4, Lt1/b;->b:I

    iget v9, v5, Lt1/b;->b:I

    sub-int/2addr v8, v9

    int-to-float v8, v8

    mul-float/2addr v8, v7

    float-to-double v8, v8

    add-double/2addr v8, v10

    double-to-int v8, v8

    iget v9, v4, Lt1/b;->c:I

    iget v12, v5, Lt1/b;->c:I

    sub-int/2addr v9, v12

    int-to-float v9, v9

    mul-float/2addr v9, v7

    float-to-double v12, v9

    add-double/2addr v12, v10

    double-to-int v9, v12

    iget v12, v4, Lt1/b;->d:I

    iget v5, v5, Lt1/b;->d:I

    sub-int/2addr v12, v5

    int-to-float v5, v12

    mul-float/2addr v5, v7

    float-to-double v12, v5

    add-double/2addr v12, v10

    double-to-int v5, v12

    invoke-static {v4, v6, v8, v9, v5}, LA1/q0;->a(Lt1/b;IIII)Lt1/b;

    move-result-object v4

    invoke-virtual {v3, p1, v4}, LA1/d0;->c(ILt1/b;)V

    :goto_2
    shl-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_5
    invoke-virtual {v3}, LA1/d0;->b()LA1/q0;

    move-result-object p1

    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    iget-object v1, p0, LA1/N;->e:Landroid/view/View;

    invoke-static {v1, p1, v0}, LA1/S;->h(Landroid/view/View;LA1/q0;Ljava/util/List;)V

    return-void
.end method
