.class public final LA1/Q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnApplyWindowInsetsListener;


# instance fields
.field public final a:LA1/M;

.field public b:LA1/q0;


# direct methods
.method public constructor <init>(Landroid/view/View;LA1/M;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LA1/Q;->a:LA1/M;

    sget-object p2, LA1/J;->a:Ljava/lang/reflect/Field;

    invoke-static {p1}, LA1/E;->a(Landroid/view/View;)LA1/q0;

    move-result-object p1

    if-eqz p1, :cond_4

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x22

    if-lt p2, v0, :cond_0

    new-instance p2, LA1/c0;

    invoke-direct {p2, p1}, LA1/c0;-><init>(LA1/q0;)V

    goto :goto_0

    :cond_0
    const/16 v0, 0x1f

    if-lt p2, v0, :cond_1

    new-instance p2, LA1/b0;

    invoke-direct {p2, p1}, LA1/b0;-><init>(LA1/q0;)V

    goto :goto_0

    :cond_1
    const/16 v0, 0x1e

    if-lt p2, v0, :cond_2

    new-instance p2, LA1/a0;

    invoke-direct {p2, p1}, LA1/a0;-><init>(LA1/q0;)V

    goto :goto_0

    :cond_2
    const/16 v0, 0x1d

    if-lt p2, v0, :cond_3

    new-instance p2, LA1/Z;

    invoke-direct {p2, p1}, LA1/Z;-><init>(LA1/q0;)V

    goto :goto_0

    :cond_3
    new-instance p2, LA1/X;

    invoke-direct {p2, p1}, LA1/X;-><init>(LA1/q0;)V

    :goto_0
    invoke-virtual {p2}, LA1/d0;->b()LA1/q0;

    move-result-object p1

    goto :goto_1

    :cond_4
    const/4 p1, 0x0

    :goto_1
    iput-object p1, p0, LA1/Q;->b:LA1/q0;

    return-void
.end method


# virtual methods
.method public final onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 19

    move-object/from16 v0, p0

    move-object/from16 v2, p1

    invoke-virtual {v2}, Landroid/view/View;->isLaidOut()Z

    move-result v1

    if-nez v1, :cond_0

    invoke-static/range {p1 .. p2}, LA1/q0;->c(Landroid/view/View;Landroid/view/WindowInsets;)LA1/q0;

    move-result-object v1

    iput-object v1, v0, LA1/Q;->b:LA1/q0;

    invoke-static/range {p1 .. p2}, LA1/S;->j(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    move-result-object v1

    return-object v1

    :cond_0
    invoke-static/range {p1 .. p2}, LA1/q0;->c(Landroid/view/View;Landroid/view/WindowInsets;)LA1/q0;

    move-result-object v3

    iget-object v1, v3, LA1/q0;->a:LA1/l0;

    iget-object v4, v0, LA1/Q;->b:LA1/q0;

    if-nez v4, :cond_1

    sget-object v4, LA1/J;->a:Ljava/lang/reflect/Field;

    invoke-static {v2}, LA1/E;->a(Landroid/view/View;)LA1/q0;

    move-result-object v4

    iput-object v4, v0, LA1/Q;->b:LA1/q0;

    :cond_1
    iget-object v4, v0, LA1/Q;->b:LA1/q0;

    if-nez v4, :cond_2

    iput-object v3, v0, LA1/Q;->b:LA1/q0;

    invoke-static/range {p1 .. p2}, LA1/S;->j(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    move-result-object v1

    return-object v1

    :cond_2
    invoke-static {v2}, LA1/S;->k(Landroid/view/View;)LA1/M;

    move-result-object v4

    if-eqz v4, :cond_3

    iget-object v4, v4, LA1/M;->u:Ljava/lang/Object;

    check-cast v4, LA1/q0;

    invoke-static {v4, v3}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-static/range {p1 .. p2}, LA1/S;->j(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    move-result-object v1

    return-object v1

    :cond_3
    const/4 v4, 0x1

    new-array v5, v4, [I

    new-array v6, v4, [I

    iget-object v7, v0, LA1/Q;->b:LA1/q0;

    move v8, v4

    :goto_0
    const/16 v9, 0x200

    if-gt v8, v9, :cond_a

    invoke-virtual {v1, v8}, LA1/l0;->g(I)Lt1/b;

    move-result-object v9

    iget-object v11, v7, LA1/q0;->a:LA1/l0;

    invoke-virtual {v11, v8}, LA1/l0;->g(I)Lt1/b;

    move-result-object v11

    iget v12, v9, Lt1/b;->a:I

    iget v13, v9, Lt1/b;->d:I

    iget v14, v9, Lt1/b;->c:I

    iget v9, v9, Lt1/b;->b:I

    iget v15, v11, Lt1/b;->a:I

    const/16 v16, 0x0

    iget v10, v11, Lt1/b;->d:I

    iget v4, v11, Lt1/b;->c:I

    iget v11, v11, Lt1/b;->b:I

    if-gt v12, v15, :cond_5

    if-gt v9, v11, :cond_5

    if-gt v14, v4, :cond_5

    if-le v13, v10, :cond_4

    goto :goto_1

    :cond_4
    move-object/from16 v17, v5

    move/from16 v5, v16

    goto :goto_2

    :cond_5
    :goto_1
    move-object/from16 v17, v5

    const/4 v5, 0x1

    :goto_2
    if-lt v12, v15, :cond_7

    if-lt v9, v11, :cond_7

    if-lt v14, v4, :cond_7

    if-ge v13, v10, :cond_6

    goto :goto_3

    :cond_6
    move/from16 v4, v16

    goto :goto_4

    :cond_7
    :goto_3
    const/4 v4, 0x1

    :goto_4
    if-eq v5, v4, :cond_9

    if-eqz v5, :cond_8

    aget v4, v17, v16

    or-int/2addr v4, v8

    aput v4, v17, v16

    goto :goto_5

    :cond_8
    aget v4, v6, v16

    or-int/2addr v4, v8

    aput v4, v6, v16

    :cond_9
    :goto_5
    shl-int/lit8 v8, v8, 0x1

    move-object/from16 v5, v17

    const/4 v4, 0x1

    goto :goto_0

    :cond_a
    move-object/from16 v17, v5

    const/16 v16, 0x0

    aget v4, v17, v16

    aget v5, v6, v16

    or-int v6, v4, v5

    if-nez v6, :cond_b

    iput-object v3, v0, LA1/Q;->b:LA1/q0;

    invoke-static/range {p1 .. p2}, LA1/S;->j(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    move-result-object v1

    return-object v1

    :cond_b
    iget-object v7, v0, LA1/Q;->b:LA1/q0;

    and-int/lit8 v8, v4, 0x8

    if-eqz v8, :cond_c

    sget-object v4, LA1/S;->e:Landroid/view/animation/PathInterpolator;

    goto :goto_6

    :cond_c
    and-int/lit8 v8, v5, 0x8

    if-eqz v8, :cond_d

    sget-object v4, LA1/S;->f:LU1/a;

    goto :goto_6

    :cond_d
    and-int/lit16 v4, v4, 0x207

    if-eqz v4, :cond_e

    sget-object v4, LA1/S;->g:Landroid/view/animation/DecelerateInterpolator;

    goto :goto_6

    :cond_e
    and-int/lit16 v4, v5, 0x207

    if-eqz v4, :cond_f

    sget-object v4, LA1/S;->h:Landroid/view/animation/AccelerateInterpolator;

    goto :goto_6

    :cond_f
    const/4 v4, 0x0

    :goto_6
    new-instance v5, LA1/W;

    and-int/lit8 v8, v6, 0x8

    if-eqz v8, :cond_10

    const-wide/16 v8, 0xa0

    goto :goto_7

    :cond_10
    const-wide/16 v8, 0xfa

    :goto_7
    invoke-direct {v5, v6, v4, v8, v9}, LA1/W;-><init>(ILandroid/view/animation/Interpolator;J)V

    iget-object v4, v5, LA1/W;->a:LA1/V;

    const/4 v8, 0x0

    invoke-virtual {v4, v8}, LA1/V;->e(F)V

    const/4 v4, 0x2

    new-array v4, v4, [F

    fill-array-data v4, :array_0

    invoke-static {v4}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v4

    iget-object v8, v5, LA1/W;->a:LA1/V;

    invoke-virtual {v8}, LA1/V;->b()J

    move-result-wide v8

    invoke-virtual {v4, v8, v9}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    move-result-object v8

    invoke-virtual {v1, v6}, LA1/l0;->g(I)Lt1/b;

    move-result-object v1

    iget-object v4, v7, LA1/q0;->a:LA1/l0;

    invoke-virtual {v4, v6}, LA1/l0;->g(I)Lt1/b;

    move-result-object v4

    iget v9, v1, Lt1/b;->a:I

    iget v10, v4, Lt1/b;->a:I

    invoke-static {v9, v10}, Ljava/lang/Math;->min(II)I

    move-result v9

    iget v10, v1, Lt1/b;->b:I

    iget v11, v4, Lt1/b;->b:I

    invoke-static {v10, v11}, Ljava/lang/Math;->min(II)I

    move-result v12

    iget v13, v1, Lt1/b;->c:I

    iget v14, v4, Lt1/b;->c:I

    invoke-static {v13, v14}, Ljava/lang/Math;->min(II)I

    move-result v15

    move/from16 v17, v6

    iget v6, v1, Lt1/b;->d:I

    move-object/from16 v18, v7

    iget v7, v4, Lt1/b;->d:I

    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v9, v12, v15, v0}, Lt1/b;->b(IIII)Lt1/b;

    move-result-object v0

    iget v1, v1, Lt1/b;->a:I

    iget v4, v4, Lt1/b;->a:I

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v10, v11}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-static {v13, v14}, Ljava/lang/Math;->max(II)I

    move-result v9

    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    move-result v6

    invoke-static {v1, v4, v9, v6}, Lt1/b;->b(IIII)Lt1/b;

    move-result-object v1

    new-instance v7, LP2/c;

    const/4 v4, 0x1

    invoke-direct {v7, v4, v0, v1}, LP2/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    move/from16 v0, v16

    invoke-static {v2, v5, v3, v0}, LA1/S;->g(Landroid/view/View;LA1/W;LA1/q0;Z)V

    new-instance v1, LA1/N;

    move-object v6, v2

    move-object v2, v5

    move/from16 v5, v17

    move-object/from16 v4, v18

    invoke-direct/range {v1 .. v6}, LA1/N;-><init>(LA1/W;LA1/q0;LA1/q0;ILandroid/view/View;)V

    move-object v0, v3

    move-object v3, v2

    move-object v2, v6

    invoke-virtual {v8, v1}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    new-instance v1, LA1/O;

    invoke-direct {v1, v3, v2}, LA1/O;-><init>(LA1/W;Landroid/view/View;)V

    invoke-virtual {v8, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    new-instance v1, LA1/P;

    const/4 v6, 0x0

    move-object v4, v7

    move-object v5, v8

    invoke-direct/range {v1 .. v6}, LA1/P;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    if-eqz v2, :cond_11

    new-instance v3, LA1/o;

    invoke-direct {v3, v2, v1}, LA1/o;-><init>(Landroid/view/View;Ljava/lang/Runnable;)V

    invoke-virtual {v2}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v1

    invoke-virtual {v1, v3}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    move-object/from16 v1, p0

    iput-object v0, v1, LA1/Q;->b:LA1/q0;

    invoke-static/range {p1 .. p2}, LA1/S;->j(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    move-result-object v0

    return-object v0

    :cond_11
    move-object/from16 v1, p0

    new-instance v0, Ljava/lang/NullPointerException;

    const-string v2, "view == null"

    invoke-direct {v0, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v0

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method
