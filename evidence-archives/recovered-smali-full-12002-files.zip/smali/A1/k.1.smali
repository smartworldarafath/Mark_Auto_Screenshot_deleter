.class public interface abstract LA1/k;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Landroidx/core/widget/NestedScrollView;IIIII)V
.end method

.method public abstract e(Landroid/view/View;Landroid/view/View;II)Z
.end method

.method public abstract f(Landroid/view/View;Landroid/view/View;II)V
.end method

.method public abstract g(Landroid/view/View;I)V
.end method

.method public abstract i(II[II)V
.end method
