.class public final LA1/P;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Ljava/lang/Object;

.field public final synthetic v:Ljava/lang/Object;

.field public final synthetic w:Ljava/lang/Object;

.field public final synthetic x:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LL4/Q0;Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x6

    iput v0, p0, LA1/P;->t:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LA1/P;->u:Ljava/lang/Object;

    iput-object p3, p0, LA1/P;->v:Ljava/lang/Object;

    iput-object p4, p0, LA1/P;->w:Ljava/lang/Object;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p1, p0, LA1/P;->x:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p5, p0, LA1/P;->t:I

    iput-object p1, p0, LA1/P;->u:Ljava/lang/Object;

    iput-object p2, p0, LA1/P;->v:Ljava/lang/Object;

    iput-object p3, p0, LA1/P;->w:Ljava/lang/Object;

    iput-object p4, p0, LA1/P;->x:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V
    .locals 0

    .line 2
    iput p5, p0, LA1/P;->t:I

    iput-object p2, p0, LA1/P;->u:Ljava/lang/Object;

    iput-object p3, p0, LA1/P;->v:Ljava/lang/Object;

    iput-object p4, p0, LA1/P;->w:Ljava/lang/Object;

    iput-object p1, p0, LA1/P;->x:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a()V
    .locals 10

    iget-object v0, p0, LA1/P;->x:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Lcom/google/android/gms/internal/ads/T6;

    iget-object v0, p0, LA1/P;->v:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/ads/Q6;

    iget-object v2, p0, LA1/P;->u:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/internal/ads/us;

    :try_start_0
    invoke-virtual {v0}, Lp4/e;->t()Landroid/os/IInterface;

    move-result-object v3

    check-cast v3, Lcom/google/android/gms/internal/ads/S6;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/ads/Q6;->A()Z

    move-result v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    iget-object v4, p0, LA1/P;->w:Ljava/lang/Object;

    check-cast v4, Lcom/google/android/gms/internal/ads/R6;

    if-eqz v0, :cond_0

    :try_start_1
    invoke-virtual {v3}, LB4/a;->e1()Landroid/os/Parcel;

    move-result-object v0

    invoke-static {v0, v4}, Lcom/google/android/gms/internal/ads/f6;->c(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    const/4 v4, 0x2

    invoke-virtual {v3, v0, v4}, LB4/a;->n2(Landroid/os/Parcel;I)Landroid/os/Parcel;

    move-result-object v0

    sget-object v3, Lcom/google/android/gms/internal/ads/O6;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {v0, v3}, Lcom/google/android/gms/internal/ads/f6;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v3

    check-cast v3, Lcom/google/android/gms/internal/ads/O6;

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    goto :goto_0

    :cond_0
    invoke-virtual {v3}, LB4/a;->e1()Landroid/os/Parcel;

    move-result-object v0

    invoke-static {v0, v4}, Lcom/google/android/gms/internal/ads/f6;->c(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    const/4 v4, 0x1

    invoke-virtual {v3, v0, v4}, LB4/a;->n2(Landroid/os/Parcel;I)Landroid/os/Parcel;

    move-result-object v0

    sget-object v3, Lcom/google/android/gms/internal/ads/O6;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {v0, v3}, Lcom/google/android/gms/internal/ads/f6;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v3

    check-cast v3, Lcom/google/android/gms/internal/ads/O6;

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    :goto_0
    invoke-virtual {v3}, Lcom/google/android/gms/internal/ads/O6;->b()Z

    move-result v0

    if-nez v0, :cond_1

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v3, "No entry contents."

    invoke-direct {v0, v3}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Lcom/google/android/gms/internal/ads/he;->d(Ljava/lang/Throwable;)V

    iget-object v0, v2, Lcom/google/android/gms/internal/ads/us;->w:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/I1;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I1;->k()V

    return-void

    :catch_0
    move-exception v0

    goto :goto_1

    :catch_1
    move-exception v0

    goto :goto_1

    :cond_1
    new-instance v4, Lcom/google/android/gms/internal/ads/U6;

    invoke-virtual {v3}, Lcom/google/android/gms/internal/ads/O6;->c()Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;

    move-result-object v0

    invoke-direct {v4, v2, v0}, Lcom/google/android/gms/internal/ads/U6;-><init>(Lcom/google/android/gms/internal/ads/us;Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;)V

    invoke-virtual {v4}, Ljava/io/PushbackInputStream;->read()I

    move-result v0

    const/4 v5, -0x1

    if-eq v0, v5, :cond_2

    invoke-virtual {v4, v0}, Ljava/io/PushbackInputStream;->unread(I)V

    monitor-enter v3
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0

    :try_start_2
    iget-boolean v5, v3, Lcom/google/android/gms/internal/ads/O6;->u:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    monitor-exit v3

    invoke-virtual {v3}, Lcom/google/android/gms/internal/ads/O6;->f()Z

    move-result v6

    monitor-enter v3
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_3} :catch_0

    :try_start_4
    iget-wide v7, v3, Lcom/google/android/gms/internal/ads/O6;->w:J
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :try_start_5
    monitor-exit v3

    invoke-virtual {v3}, Lcom/google/android/gms/internal/ads/O6;->e()Z

    move-result v9

    new-instance v3, Lcom/google/android/gms/internal/ads/W6;

    invoke-direct/range {v3 .. v9}, Lcom/google/android/gms/internal/ads/W6;-><init>(Lcom/google/android/gms/internal/ads/U6;ZZJZ)V

    invoke-virtual {v1, v3}, Lcom/google/android/gms/internal/ads/he;->c(Ljava/lang/Object;)Z
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_5 .. :try_end_5} :catch_0

    return-void

    :catchall_0
    move-exception v0

    :try_start_6
    monitor-exit v3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :try_start_7
    throw v0
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_7 .. :try_end_7} :catch_0

    :catchall_1
    move-exception v0

    :try_start_8
    monitor-exit v3
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    :try_start_9
    throw v0

    :cond_2
    new-instance v0, Ljava/io/IOException;

    const-string v3, "Unable to read from cache."

    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_9 .. :try_end_9} :catch_0

    :goto_1
    const-string v3, "Unable to obtain a cache service instance."

    invoke-static {v3, v0}, LX3/l;->f(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v1, v0}, Lcom/google/android/gms/internal/ads/he;->d(Ljava/lang/Throwable;)V

    iget-object v0, v2, Lcom/google/android/gms/internal/ads/us;->w:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/measurement/I1;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/I1;->k()V

    return-void
.end method

.method private final b()V
    .locals 9

    iget-object v0, p0, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, [B

    iget-object v1, p0, LA1/P;->u:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/internal/ads/nw;

    iget-object v2, p0, LA1/P;->v:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-object v3, p0, LA1/P;->w:Ljava/lang/Object;

    check-cast v3, Lo1/h;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v4, "application/x-protobuf"

    const-string v5, "Timeout: "

    const/4 v6, 0x0

    :try_start_0
    invoke-static {v2}, Ljava/net/URI;->create(Ljava/lang/String;)Ljava/net/URI;

    move-result-object v2

    invoke-virtual {v2}, Ljava/net/URI;->toURL()Ljava/net/URL;

    move-result-object v2

    invoke-virtual {v2}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v2

    check-cast v2, Ljava/net/HttpURLConnection;
    :try_end_0
    .catch Ljava/net/SocketTimeoutException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_7

    :try_start_1
    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v6, Lcom/google/android/gms/internal/ads/Ei;

    const/16 v7, 0x17

    invoke-direct {v6, v7, v2}, Lcom/google/android/gms/internal/ads/Ei;-><init>(ILjava/lang/Object;)V

    iget-object v7, v1, Lcom/google/android/gms/internal/ads/nw;->a:Ljava/util/concurrent/ExecutorService;

    iget-object v8, v3, Lo1/h;->c:Lo1/m;

    if-eqz v8, :cond_0

    invoke-virtual {v8, v6, v7}, Lo1/g;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    :cond_0
    const-string v6, "User-Agent"

    iget-object v7, v1, Lcom/google/android/gms/internal/ads/nw;->b:Ljava/lang/String;

    invoke-virtual {v2, v6, v7}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    iget-wide v6, v1, Lcom/google/android/gms/internal/ads/nw;->c:J

    long-to-int v1, v6

    invoke-virtual {v2, v1}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    invoke-virtual {v2, v1}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const/4 v1, 0x1

    invoke-virtual {v2, v1}, Ljava/net/URLConnection;->setDoOutput(Z)V

    const-string v1, "POST"

    invoke-virtual {v2, v1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const-string v1, "Content-Type"

    invoke-virtual {v2, v1, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Ljava/io/BufferedOutputStream;

    invoke-virtual {v2}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v4

    invoke-direct {v1, v4}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_1
    .catch Ljava/net/SocketTimeoutException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v1, v0}, Ljava/io/OutputStream;->write([B)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_5

    :try_start_3
    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V

    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    const/16 v1, 0x190

    if-ge v0, v1, :cond_1

    invoke-virtual {v2}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_8

    :catch_0
    move-exception v0

    goto :goto_9

    :cond_1
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    move-result-object v0
    :try_end_3
    .catch Ljava/net/SocketTimeoutException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :goto_0
    :try_start_4
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    if-nez v0, :cond_2

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v1

    goto :goto_5

    :cond_2
    const/16 v4, 0x1000

    :try_start_5
    new-array v4, v4, [B

    :goto_1
    invoke-virtual {v0, v4}, Ljava/io/InputStream;->read([B)I

    move-result v6

    const/4 v7, -0x1

    if-eq v6, v7, :cond_3

    const/4 v7, 0x0

    invoke-virtual {v1, v4, v7, v6}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_1

    :catchall_2
    move-exception v4

    goto :goto_3

    :cond_3
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :try_start_6
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :try_start_7
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    :goto_2
    new-instance v0, Lcom/google/android/gms/internal/ads/jv;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/ads/jv;-><init>(I)V

    invoke-virtual {v3, v0}, Lo1/h;->a(Ljava/lang/Object;)V
    :try_end_7
    .catch Ljava/net/SocketTimeoutException; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    goto :goto_d

    :goto_3
    :try_start_8
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    goto :goto_4

    :catchall_3
    move-exception v1

    :try_start_9
    invoke-virtual {v4, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4
    throw v4
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    :goto_5
    if-eqz v0, :cond_4

    :try_start_a
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    goto :goto_6

    :catchall_4
    move-exception v0

    :try_start_b
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_4
    :goto_6
    throw v1
    :try_end_b
    .catch Ljava/net/SocketTimeoutException; {:try_start_b .. :try_end_b} :catch_0
    .catchall {:try_start_b .. :try_end_b} :catchall_0

    :catchall_5
    move-exception v0

    :try_start_c
    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_6

    goto :goto_7

    :catchall_6
    move-exception v1

    :try_start_d
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_7
    throw v0
    :try_end_d
    .catch Ljava/net/SocketTimeoutException; {:try_start_d .. :try_end_d} :catch_0
    .catchall {:try_start_d .. :try_end_d} :catchall_0

    :goto_8
    move-object v6, v2

    goto :goto_a

    :goto_9
    move-object v6, v2

    goto :goto_c

    :catchall_7
    move-exception v0

    goto :goto_a

    :catch_1
    move-exception v0

    goto :goto_c

    :goto_a
    :try_start_e
    invoke-virtual {v3, v0}, Lo1/h;->b(Ljava/lang/Throwable;)V

    :goto_b
    move-object v2, v6

    goto :goto_d

    :catchall_8
    move-exception v0

    goto :goto_e

    :goto_c
    new-instance v1, Ljava/util/concurrent/TimeoutException;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    add-int/lit8 v2, v2, 0x9

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/util/concurrent/TimeoutException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Lo1/h;->b(Ljava/lang/Throwable;)V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_8

    goto :goto_b

    :goto_d
    if-eqz v2, :cond_5

    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_5
    return-void

    :goto_e
    if-eqz v6, :cond_6

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_6
    throw v0
.end method

.method private final synthetic c()V
    .locals 7

    iget-object v0, p0, LA1/P;->u:Ljava/lang/Object;

    check-cast v0, Landroid/media/AudioTrack;

    iget-object v1, p0, LA1/P;->v:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/internal/ads/et;

    iget-object v2, p0, LA1/P;->w:Ljava/lang/Object;

    check-cast v2, Landroid/os/Handler;

    iget-object v3, p0, LA1/P;->x:Ljava/lang/Object;

    check-cast v3, Lcom/google/android/gms/internal/ads/LJ;

    const/4 v4, 0x0

    :try_start_0
    invoke-virtual {v0}, Landroid/media/AudioTrack;->flush()V

    invoke-virtual {v0}, Landroid/media/AudioTrack;->release()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-eqz v1, :cond_0

    invoke-virtual {v2}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->isAlive()Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Lcom/google/android/gms/internal/ads/TJ;

    const/4 v5, 0x0

    invoke-direct {v0, v1, v3, v5}, Lcom/google/android/gms/internal/ads/TJ;-><init>(Lcom/google/android/gms/internal/ads/et;Lcom/google/android/gms/internal/ads/LJ;I)V

    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    sget-object v0, Lcom/google/android/gms/internal/ads/ZJ;->e0:Ljava/lang/Object;

    monitor-enter v0

    :try_start_1
    sget v1, Lcom/google/android/gms/internal/ads/ZJ;->g0:I

    add-int/lit8 v1, v1, -0x1

    sput v1, Lcom/google/android/gms/internal/ads/ZJ;->g0:I

    if-nez v1, :cond_1

    sget-object v1, Lcom/google/android/gms/internal/ads/ZJ;->f0:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    sput-object v4, Lcom/google/android/gms/internal/ads/ZJ;->f0:Ljava/util/concurrent/ScheduledExecutorService;

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_1
    :goto_0
    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1

    :catchall_1
    move-exception v0

    if-eqz v1, :cond_2

    invoke-virtual {v2}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v5

    invoke-virtual {v5}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Thread;->isAlive()Z

    move-result v5

    if-eqz v5, :cond_2

    new-instance v5, Lcom/google/android/gms/internal/ads/TJ;

    const/4 v6, 0x1

    invoke-direct {v5, v1, v3, v6}, Lcom/google/android/gms/internal/ads/TJ;-><init>(Lcom/google/android/gms/internal/ads/et;Lcom/google/android/gms/internal/ads/LJ;I)V

    invoke-virtual {v2, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_2
    sget-object v1, Lcom/google/android/gms/internal/ads/ZJ;->e0:Ljava/lang/Object;

    monitor-enter v1

    :try_start_2
    sget v2, Lcom/google/android/gms/internal/ads/ZJ;->g0:I

    add-int/lit8 v2, v2, -0x1

    sput v2, Lcom/google/android/gms/internal/ads/ZJ;->g0:I

    if-nez v2, :cond_3

    sget-object v2, Lcom/google/android/gms/internal/ads/ZJ;->f0:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v2}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    sput-object v4, Lcom/google/android/gms/internal/ads/ZJ;->f0:Ljava/util/concurrent/ScheduledExecutorService;

    goto :goto_2

    :catchall_2
    move-exception v0

    goto :goto_3

    :cond_3
    :goto_2
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    throw v0

    :goto_3
    :try_start_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    throw v0
.end method

.method private final d()V
    .locals 15

    iget-object v0, p0, LA1/P;->u:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;

    iget-object v1, p0, LA1/P;->v:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/n2;

    iget-object v2, p0, LA1/P;->w:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/q0;

    iget-object v3, p0, LA1/P;->x:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v2, v2, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/q0;->t:I

    invoke-static {v2}, LF4/p6;->a(I)I

    move-result v2

    iget-object v4, v1, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/n2;->t:Ljava/lang/Object;

    check-cast v4, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Y9;

    invoke-virtual {v4}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v4, v4, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v4, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z9;

    invoke-static {v4, v2}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z9;->x(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z9;I)V

    iget-object v2, v1, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/n2;->t:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Y9;

    invoke-virtual {v2}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->c()Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    move-result-object v2

    check-cast v2, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z9;

    invoke-virtual {v2}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z9;->u()Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->u()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_0

    invoke-virtual {v2}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->u()Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :cond_0
    const-string v2, "NA"

    :goto_0
    new-instance v4, Lcom/google/android/gms/internal/consent_sdk/b;

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    iget-object v5, v0, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;->a:Ljava/lang/String;

    iput-object v5, v4, Lcom/google/android/gms/internal/consent_sdk/b;->a:Ljava/lang/Object;

    iget-object v5, v0, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;->b:Ljava/lang/String;

    iput-object v5, v4, Lcom/google/android/gms/internal/consent_sdk/b;->b:Ljava/lang/Object;

    const-class v5, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;

    monitor-enter v5

    :try_start_0
    sget-object v6, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;->i:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z7;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x0

    if-eqz v6, :cond_1

    monitor-exit v5

    goto :goto_2

    :cond_1
    :try_start_1
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    move-result-object v6

    new-instance v8, Lw1/b;

    new-instance v9, Lw1/c;

    invoke-direct {v9, v6}, Lw1/c;-><init>(Landroid/os/LocaleList;)V

    invoke-direct {v8, v9}, Lw1/b;-><init>(Lw1/c;)V

    const/4 v6, 0x4

    new-array v6, v6, [Ljava/lang/Object;

    move v9, v7

    move v10, v9

    :goto_1
    iget-object v11, v8, Lw1/b;->a:Lw1/c;

    iget-object v11, v11, Lw1/c;->a:Landroid/os/LocaleList;

    invoke-virtual {v11}, Landroid/os/LocaleList;->size()I

    move-result v11

    if-ge v9, v11, :cond_5

    iget-object v11, v8, Lw1/b;->a:Lw1/c;

    iget-object v11, v11, Lw1/c;->a:Landroid/os/LocaleList;

    invoke-virtual {v11, v9}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v11

    sget-object v12, LT5/c;->a:Lj6/d;

    invoke-virtual {v11}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v12, v10, 0x1

    array-length v13, v6

    if-ge v13, v12, :cond_4

    shr-int/lit8 v14, v13, 0x1

    add-int/2addr v13, v14

    add-int/lit8 v13, v13, 0x1

    if-ge v13, v12, :cond_2

    invoke-static {v10}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v13

    add-int/2addr v13, v13

    :cond_2
    if-gez v13, :cond_3

    const v13, 0x7fffffff

    :cond_3
    invoke-static {v6, v13}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v6

    :cond_4
    aput-object v11, v6, v10

    add-int/lit8 v9, v9, 0x1

    move v10, v12

    goto :goto_1

    :cond_5
    invoke-static {v10, v6}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U7;->h(I[Ljava/lang/Object;)Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z7;

    move-result-object v6

    sput-object v6, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;->i:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z7;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v5

    :goto_2
    iput-object v6, v4, Lcom/google/android/gms/internal/consent_sdk/b;->e:Ljava/lang/Object;

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iput-object v5, v4, Lcom/google/android/gms/internal/consent_sdk/b;->g:Ljava/lang/Object;

    iput-object v2, v4, Lcom/google/android/gms/internal/consent_sdk/b;->d:Ljava/lang/Object;

    iput-object v3, v4, Lcom/google/android/gms/internal/consent_sdk/b;->c:Ljava/lang/Object;

    iget-object v2, v0, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;->f:LO4/o;

    invoke-virtual {v2}, LO4/o;->j()Z

    move-result v2

    if-eqz v2, :cond_6

    iget-object v2, v0, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;->f:LO4/o;

    invoke-virtual {v2}, LO4/o;->h()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    goto :goto_3

    :cond_6
    iget-object v2, v0, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;->d:LT5/j;

    invoke-virtual {v2}, LT5/j;->a()Ljava/lang/String;

    move-result-object v2

    :goto_3
    iput-object v2, v4, Lcom/google/android/gms/internal/consent_sdk/b;->f:Ljava/lang/Object;

    const/16 v2, 0xa

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iput-object v2, v4, Lcom/google/android/gms/internal/consent_sdk/b;->h:Ljava/lang/Object;

    iget v2, v0, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;->h:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iput-object v2, v4, Lcom/google/android/gms/internal/consent_sdk/b;->i:Ljava/lang/Object;

    const-string v2, ""

    iget-object v3, v4, Lcom/google/android/gms/internal/consent_sdk/b;->a:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    iget-object v5, v4, Lcom/google/android/gms/internal/consent_sdk/b;->b:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    iget-object v6, v4, Lcom/google/android/gms/internal/consent_sdk/b;->c:Ljava/lang/Object;

    check-cast v6, Ljava/lang/String;

    iget-object v8, v4, Lcom/google/android/gms/internal/consent_sdk/b;->d:Ljava/lang/Object;

    check-cast v8, Ljava/lang/String;

    iget-object v9, v4, Lcom/google/android/gms/internal/consent_sdk/b;->e:Ljava/lang/Object;

    check-cast v9, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z7;

    iget-object v10, v4, Lcom/google/android/gms/internal/consent_sdk/b;->f:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    iget-object v11, v4, Lcom/google/android/gms/internal/consent_sdk/b;->g:Ljava/lang/Object;

    check-cast v11, Ljava/lang/Boolean;

    iget-object v12, v4, Lcom/google/android/gms/internal/consent_sdk/b;->h:Ljava/lang/Object;

    check-cast v12, Ljava/lang/Integer;

    iget-object v4, v4, Lcom/google/android/gms/internal/consent_sdk/b;->i:Ljava/lang/Object;

    check-cast v4, Ljava/lang/Integer;

    invoke-static {}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->s()Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/V;

    move-result-object v13

    if-nez v3, :cond_7

    move-object v3, v2

    :cond_7
    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v14, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v14, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v14, v3}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->v(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;Ljava/lang/String;)V

    if-nez v5, :cond_8

    move-object v5, v2

    :cond_8
    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v3, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v3, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v3, v5}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->G(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;Ljava/lang/String;)V

    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v3, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v3, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v3}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->H(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;)V

    if-nez v6, :cond_9

    move-object v6, v2

    :cond_9
    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v3, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v3, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v3, v6}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->w(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;Ljava/lang/String;)V

    if-nez v8, :cond_a

    move-object v8, v2

    :cond_a
    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v3, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v3, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v3, v8}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->x(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;Ljava/lang/String;)V

    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v3, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v3, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v3}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->y(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;)V

    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v3, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v3, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v3}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->z(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;)V

    if-nez v10, :cond_b

    goto :goto_4

    :cond_b
    move-object v2, v10

    :goto_4
    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v3, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v3, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v3, v2}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->B(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;Ljava/lang/String;)V

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v3

    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v5, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v5, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v5, v3}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->C(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;Z)V

    invoke-virtual {v2, v11}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v2

    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v3, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v3, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v3, v2}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->D(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;Z)V

    if-nez v12, :cond_c

    move v2, v7

    goto :goto_5

    :cond_c
    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v2

    :goto_5
    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v3, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v3, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v3, v2}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->E(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;I)V

    if-nez v4, :cond_d

    goto :goto_6

    :cond_d
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v7

    :goto_6
    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v2, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v2, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v2, v7}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->F(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;I)V

    if-eqz v9, :cond_e

    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v2, v13, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v2, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v2, v9}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;->A(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z7;)V

    :cond_e
    iget-object v2, v1, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/n2;->t:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Y9;

    invoke-virtual {v2}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->f()V

    iget-object v2, v2, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->u:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    check-cast v2, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z9;

    invoke-virtual {v13}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/U1;->c()Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z1;

    move-result-object v3

    check-cast v3, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z9;->v(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/Z9;Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/W;)V

    iget-object v0, v0, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/E0;->c:Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/C0;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/C0;->a(Lcom/google/android/gms/internal/mlkit_vision_internal_vkp/n2;)V

    return-void

    :catchall_0
    move-exception v0

    :try_start_2
    monitor-exit v5
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method

.method private final e()V
    .locals 6

    iget-object v0, p0, LA1/P;->u:Ljava/lang/Object;

    check-cast v0, Ld4/m;

    iget-object v1, p0, LA1/P;->v:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    iget-object v2, p0, LA1/P;->w:Ljava/lang/Object;

    check-cast v2, Ld4/j;

    iget-object v3, p0, LA1/P;->x:Ljava/lang/Object;

    check-cast v3, Lcom/google/android/gms/internal/ads/Ud;

    iget-object v4, v0, Ld4/m;->b:Ld4/t;

    invoke-virtual {v4}, Ld4/t;->e()V

    iget-object v5, v4, Ld4/t;->d:Ljava/lang/Object;

    monitor-enter v5

    :try_start_0
    iget-object v4, v4, Ld4/t;->a:Landroid/content/SharedPreferences;

    invoke-interface {v4, v1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v1

    monitor-exit v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v1, :cond_1

    invoke-virtual {v0}, Ld4/m;->a()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, v0, Ld4/m;->a:Landroid/content/Context;

    new-instance v1, Lx4/b;

    invoke-direct {v1, v0}, Lx4/b;-><init>(Ljava/lang/Object;)V

    const/4 v0, 0x0

    invoke-virtual {v2, v1, v3, v0}, Ld4/j;->p3(Lx4/a;Lcom/google/android/gms/internal/ads/Ud;Lcom/google/android/gms/internal/ads/Nd;)V

    :cond_1
    :goto_0
    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method


# virtual methods
.method public final run()V
    .locals 28

    move-object/from16 v1, p0

    iget v0, v1, LA1/P;->t:I

    const v3, 0x7fffffff

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    packed-switch v0, :pswitch_data_0

    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, LW2/g;

    iget-object v0, v0, LW2/g;->u:Ljava/lang/Object;

    check-cast v0, Lk/e;

    iget-object v2, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v2, Lk/i;

    iget-object v3, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v3, Lk/d;

    if-eqz v3, :cond_0

    iput-boolean v6, v0, Lk/e;->S:Z

    iget-object v3, v3, Lk/d;->b:Lk/h;

    invoke-virtual {v3, v7}, Lk/h;->c(Z)V

    iput-boolean v7, v0, Lk/e;->S:Z

    :cond_0
    invoke-virtual {v2}, Lk/i;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {v2}, Lk/i;->hasSubMenu()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v0, Lk/h;

    invoke-virtual {v0, v2, v5, v4}, Lk/h;->p(Landroid/view/MenuItem;Lk/j;I)Z

    :cond_1
    return-void

    :pswitch_0
    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/ads/Zm;

    iget-object v2, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v2, LN3/g;

    iget-object v3, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    iget-object v4, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    :try_start_0
    new-instance v5, Lcom/google/android/gms/internal/ads/ud;

    invoke-direct {v5, v3, v4}, Lcom/google/android/gms/internal/ads/ud;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iget-object v2, v2, LN3/g;->a:LT3/F0;

    invoke-virtual {v5, v2, v0}, Lcom/google/android/gms/internal/ads/ud;->b(LT3/F0;Lcom/google/android/gms/internal/ads/Zm;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-static {v3}, Lcom/google/android/gms/internal/ads/Ac;->a(Landroid/content/Context;)Lcom/google/android/gms/internal/ads/Bc;

    move-result-object v2

    const-string v3, "RewardedInterstitialAd.load"

    invoke-interface {v2, v3, v0}, Lcom/google/android/gms/internal/ads/Bc;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    return-void

    :pswitch_1
    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/ads/Zm;

    iget-object v2, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v2, LN3/g;

    iget-object v3, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    iget-object v4, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    :try_start_1
    new-instance v5, Lcom/google/android/gms/internal/ads/od;

    invoke-direct {v5, v3, v4}, Lcom/google/android/gms/internal/ads/od;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iget-object v2, v2, LN3/g;->a:LT3/F0;

    invoke-virtual {v5, v2, v0}, Lcom/google/android/gms/internal/ads/od;->b(LT3/F0;Lcom/google/android/gms/internal/ads/Zm;)V
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    move-exception v0

    invoke-static {v3}, Lcom/google/android/gms/internal/ads/Ac;->a(Landroid/content/Context;)Lcom/google/android/gms/internal/ads/Bc;

    move-result-object v2

    const-string v3, "RewardedAd.load"

    invoke-interface {v2, v3, v0}, Lcom/google/android/gms/internal/ads/Bc;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_1
    return-void

    :pswitch_2
    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v0, Ld4/E;

    iget-object v2, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/internal/ads/mm;

    iget-object v3, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v3, Ljava/util/ArrayDeque;

    iget-object v4, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v4, Ljava/util/ArrayDeque;

    const-string v5, "to"

    invoke-virtual {v0, v2, v3, v5}, Ld4/E;->e(Lcom/google/android/gms/internal/ads/mm;Ljava/util/ArrayDeque;Ljava/lang/String;)V

    const-string v3, "of"

    invoke-virtual {v0, v2, v4, v3}, Ld4/E;->e(Lcom/google/android/gms/internal/ads/mm;Ljava/util/ArrayDeque;Ljava/lang/String;)V

    return-void

    :pswitch_3
    invoke-direct {v1}, LA1/P;->e()V

    return-void

    :pswitch_4
    invoke-direct {v1}, LA1/P;->d()V

    return-void

    :pswitch_5
    invoke-direct {v1}, LA1/P;->c()V

    return-void

    :pswitch_6
    invoke-direct {v1}, LA1/P;->b()V

    return-void

    :pswitch_7
    invoke-direct {v1}, LA1/P;->a()V

    return-void

    :pswitch_8
    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, LY3/b;

    iget-object v2, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v2, LN3/g;

    iget-object v3, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    iget-object v4, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    :try_start_2
    new-instance v5, Lcom/google/android/gms/internal/ads/Ga;

    invoke-direct {v5, v3, v4}, Lcom/google/android/gms/internal/ads/Ga;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iget-object v2, v2, LN3/g;->a:LT3/F0;

    invoke-virtual {v5, v2, v0}, Lcom/google/android/gms/internal/ads/Ga;->c(LT3/F0;LN3/v;)V
    :try_end_2
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_2} :catch_2

    goto :goto_2

    :catch_2
    move-exception v0

    invoke-static {v3}, Lcom/google/android/gms/internal/ads/Ac;->a(Landroid/content/Context;)Lcom/google/android/gms/internal/ads/Bc;

    move-result-object v2

    const-string v3, "InterstitialAd.load"

    invoke-interface {v2, v3, v0}, Lcom/google/android/gms/internal/ads/Bc;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_2
    return-void

    :pswitch_9
    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/ads/Zm;

    iget-object v2, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v2, LN3/g;

    iget-object v3, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    iget-object v4, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    :try_start_3
    new-instance v5, Lcom/google/android/gms/internal/ads/p2;

    iget-object v2, v2, LN3/g;->a:LT3/F0;

    invoke-direct {v5, v3, v4, v2, v0}, Lcom/google/android/gms/internal/ads/p2;-><init>(Landroid/content/Context;Ljava/lang/String;LT3/F0;Lcom/google/android/gms/internal/ads/Zm;)V

    invoke-virtual {v5}, Lcom/google/android/gms/internal/ads/p2;->a()V
    :try_end_3
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_3

    :catch_3
    move-exception v0

    invoke-static {v3}, Lcom/google/android/gms/internal/ads/Ac;->a(Landroid/content/Context;)Lcom/google/android/gms/internal/ads/Bc;

    move-result-object v2

    const-string v3, "AppOpenAd.load"

    invoke-interface {v2, v3, v0}, Lcom/google/android/gms/internal/ads/Bc;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_3
    return-void

    :pswitch_a
    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, LA1/i;

    iget-object v0, v0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LL4/J1;

    invoke-virtual {v0}, LL4/J1;->j0()LL4/P1;

    move-result-object v2

    invoke-virtual {v0}, LL4/J1;->f()Lv4/a;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    iget-object v3, v1, LA1/P;->u:Ljava/lang/Object;

    move-object v9, v3

    check-cast v9, Ljava/lang/String;

    iget-object v3, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    iget-object v4, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v4, Landroid/os/Bundle;

    const-string v5, "auto"

    const/4 v8, 0x0

    invoke-virtual/range {v2 .. v8}, LL4/P1;->j0(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;JZ)LL4/t;

    move-result-object v2

    invoke-static {v2}, Lp4/y;->h(Ljava/lang/Object;)V

    invoke-virtual {v0, v2, v9}, LL4/J1;->h(LL4/t;Ljava/lang/String;)V

    return-void

    :pswitch_b
    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, LL4/m1;

    iget-object v0, v1, LA1/P;->v:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v0, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v0, LL4/R1;

    iget-object v4, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v4, LL4/C1;

    monitor-enter v3

    :try_start_4
    iget-object v5, v2, LL4/m1;->x:LL4/D;

    if-nez v5, :cond_2

    iget-object v0, v2, LE/V;->u:Ljava/lang/Object;

    check-cast v0, LL4/m0;

    iget-object v0, v0, LL4/m0;->y:LL4/Q;

    invoke-static {v0}, LL4/m0;->l(LL4/u0;)V

    iget-object v0, v0, LL4/Q;->z:LL4/O;

    const-string v4, "[sgtm] Failed to get upload batches; not connected to service"

    invoke-virtual {v0, v4}, LL4/O;->f(Ljava/lang/String;)V
    :try_end_4
    .catch Landroid/os/RemoteException; {:try_start_4 .. :try_end_4} :catch_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :try_start_5
    monitor-exit v3
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto :goto_6

    :catchall_0
    move-exception v0

    goto :goto_7

    :catch_4
    move-exception v0

    goto :goto_4

    :cond_2
    :try_start_6
    new-instance v6, LL4/f1;

    invoke-direct {v6, v2, v3}, LL4/f1;-><init>(LL4/m1;Ljava/util/concurrent/atomic/AtomicReference;)V

    invoke-interface {v5, v0, v4, v6}, LL4/D;->a3(LL4/R1;LL4/C1;LL4/H;)V

    invoke-virtual {v2}, LL4/m1;->V()V
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_6} :catch_4
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    goto :goto_5

    :goto_4
    :try_start_7
    iget-object v2, v2, LE/V;->u:Ljava/lang/Object;

    check-cast v2, LL4/m0;

    iget-object v2, v2, LL4/m0;->y:LL4/Q;

    invoke-static {v2}, LL4/m0;->l(LL4/u0;)V

    iget-object v2, v2, LL4/Q;->z:LL4/O;

    const-string v4, "[sgtm] Failed to get upload batches; remote exception"

    invoke-virtual {v2, v0, v4}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/lang/Object;->notifyAll()V

    :goto_5
    monitor-exit v3

    :goto_6
    return-void

    :goto_7
    monitor-exit v3
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    throw v0

    :pswitch_c
    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, LL4/m1;

    iget-object v0, v1, LA1/P;->v:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v0, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v0, LL4/R1;

    iget-object v4, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v4, Landroid/os/Bundle;

    monitor-enter v3

    :try_start_8
    iget-object v5, v2, LL4/m1;->x:LL4/D;

    if-nez v5, :cond_3

    iget-object v0, v2, LE/V;->u:Ljava/lang/Object;

    check-cast v0, LL4/m0;

    iget-object v0, v0, LL4/m0;->y:LL4/Q;

    invoke-static {v0}, LL4/m0;->l(LL4/u0;)V

    iget-object v0, v0, LL4/Q;->z:LL4/O;

    const-string v4, "Failed to request trigger URIs; not connected to service"

    invoke-virtual {v0, v4}, LL4/O;->f(Ljava/lang/String;)V
    :try_end_8
    .catch Landroid/os/RemoteException; {:try_start_8 .. :try_end_8} :catch_5
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    :try_start_9
    monitor-exit v3
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    goto :goto_a

    :catchall_1
    move-exception v0

    goto :goto_b

    :catch_5
    move-exception v0

    goto :goto_8

    :cond_3
    :try_start_a
    new-instance v6, LL4/e1;

    invoke-direct {v6, v2, v3}, LL4/e1;-><init>(LL4/m1;Ljava/util/concurrent/atomic/AtomicReference;)V

    invoke-interface {v5, v0, v4, v6}, LL4/D;->c3(LL4/R1;Landroid/os/Bundle;LL4/F;)V

    invoke-virtual {v2}, LL4/m1;->V()V
    :try_end_a
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_a} :catch_5
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    goto :goto_9

    :goto_8
    :try_start_b
    iget-object v2, v2, LE/V;->u:Ljava/lang/Object;

    check-cast v2, LL4/m0;

    iget-object v2, v2, LL4/m0;->y:LL4/Q;

    invoke-static {v2}, LL4/m0;->l(LL4/u0;)V

    iget-object v2, v2, LL4/Q;->z:LL4/O;

    const-string v4, "Failed to request trigger URIs; remote exception"

    invoke-virtual {v2, v0, v4}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/lang/Object;->notifyAll()V

    :goto_9
    monitor-exit v3

    :goto_a
    return-void

    :goto_b
    monitor-exit v3
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_1

    throw v0

    :pswitch_d
    iget-object v0, v1, LA1/P;->w:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Lcom/google/android/gms/internal/measurement/L;

    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, LL4/m1;

    :try_start_c
    iget-object v0, v3, LL4/m1;->x:LL4/D;

    if-nez v0, :cond_4

    iget-object v0, v3, LE/V;->u:Ljava/lang/Object;

    check-cast v0, LL4/m0;

    iget-object v4, v0, LL4/m0;->y:LL4/Q;

    invoke-static {v4}, LL4/m0;->l(LL4/u0;)V

    iget-object v4, v4, LL4/Q;->z:LL4/O;

    const-string v6, "Discarding data. Failed to send event to service to bundle"

    invoke-virtual {v4, v6}, LL4/O;->f(Ljava/lang/String;)V
    :try_end_c
    .catch Landroid/os/RemoteException; {:try_start_c .. :try_end_c} :catch_6
    .catchall {:try_start_c .. :try_end_c} :catchall_2

    iget-object v0, v0, LL4/m0;->B:LL4/P1;

    invoke-static {v0}, LL4/m0;->j(LE/V;)V

    invoke-virtual {v0, v2, v5}, LL4/P1;->s0(Lcom/google/android/gms/internal/measurement/L;[B)V

    goto :goto_d

    :cond_4
    :try_start_d
    iget-object v4, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v4, LL4/t;

    iget-object v6, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v6, Ljava/lang/String;

    invoke-interface {v0, v4, v6}, LL4/D;->t1(LL4/t;Ljava/lang/String;)[B

    move-result-object v5

    invoke-virtual {v3}, LL4/m1;->V()V
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_d .. :try_end_d} :catch_6
    .catchall {:try_start_d .. :try_end_d} :catchall_2

    goto :goto_c

    :catchall_2
    move-exception v0

    goto :goto_e

    :catch_6
    move-exception v0

    :try_start_e
    iget-object v4, v3, LE/V;->u:Ljava/lang/Object;

    check-cast v4, LL4/m0;

    iget-object v4, v4, LL4/m0;->y:LL4/Q;

    invoke-static {v4}, LL4/m0;->l(LL4/u0;)V

    iget-object v4, v4, LL4/Q;->z:LL4/O;

    const-string v6, "Failed to send event to the service to bundle"

    invoke-virtual {v4, v0, v6}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_2

    :goto_c
    iget-object v0, v3, LE/V;->u:Ljava/lang/Object;

    check-cast v0, LL4/m0;

    iget-object v0, v0, LL4/m0;->B:LL4/P1;

    invoke-static {v0}, LL4/m0;->j(LE/V;)V

    invoke-virtual {v0, v2, v5}, LL4/P1;->s0(Lcom/google/android/gms/internal/measurement/L;[B)V

    :goto_d
    return-void

    :goto_e
    iget-object v3, v3, LE/V;->u:Ljava/lang/Object;

    check-cast v3, LL4/m0;

    iget-object v3, v3, LL4/m0;->B:LL4/P1;

    invoke-static {v3}, LL4/m0;->j(LE/V;)V

    invoke-virtual {v3, v2, v5}, LL4/P1;->s0(Lcom/google/android/gms/internal/measurement/L;[B)V

    throw v0

    :pswitch_e
    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/measurement/internal/AppMeasurementDynamiteService;

    iget-object v0, v0, Lcom/google/android/gms/measurement/internal/AppMeasurementDynamiteService;->t:LL4/m0;

    invoke-virtual {v0}, LL4/m0;->o()LL4/m1;

    move-result-object v9

    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    move-object v13, v0

    check-cast v13, Lcom/google/android/gms/internal/measurement/L;

    iget-object v0, v1, LA1/P;->v:Ljava/lang/Object;

    move-object v10, v0

    check-cast v10, Ljava/lang/String;

    iget-object v0, v1, LA1/P;->w:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v9}, LL4/x;->I()V

    invoke-virtual {v9}, LL4/C;->J()V

    invoke-virtual {v9, v7}, LL4/m1;->Y(Z)LL4/R1;

    move-result-object v12

    new-instance v8, LL4/s0;

    const/4 v14, 0x2

    invoke-direct/range {v8 .. v14}, LL4/s0;-><init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v9, v8}, LL4/m1;->W(Ljava/lang/Runnable;)V

    return-void

    :pswitch_f
    iget-object v0, v1, LA1/P;->v:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, Ljava/lang/String;

    iget-object v0, v1, LA1/P;->w:Ljava/lang/Object;

    move-object v12, v0

    check-cast v12, Ljava/lang/String;

    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, LL4/Q0;

    iget-object v0, v0, LE/V;->u:Ljava/lang/Object;

    check-cast v0, LL4/m0;

    invoke-virtual {v0}, LL4/m0;->o()LL4/m1;

    move-result-object v9

    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    move-object v10, v0

    check-cast v10, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v9}, LL4/x;->I()V

    invoke-virtual {v9}, LL4/C;->J()V

    invoke-virtual {v9, v7}, LL4/m1;->Y(Z)LL4/R1;

    move-result-object v13

    new-instance v8, LL4/s0;

    invoke-direct/range {v8 .. v13}, LL4/s0;-><init>(LL4/m1;Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/String;Ljava/lang/String;LL4/R1;)V

    invoke-virtual {v9, v8}, LL4/m1;->W(Ljava/lang/Runnable;)V

    return-void

    :pswitch_10
    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v0, LL4/t0;

    iget-object v2, v1, LA1/P;->v:Ljava/lang/Object;

    move-object v15, v2

    check-cast v15, Landroid/os/Bundle;

    iget-object v2, v1, LA1/P;->w:Ljava/lang/Object;

    move-object v9, v2

    check-cast v9, Ljava/lang/String;

    iget-object v2, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v2, LL4/R1;

    iget-object v3, v0, LL4/t0;->t:LL4/J1;

    invoke-virtual {v3}, LL4/J1;->d0()LL4/g;

    move-result-object v0

    sget-object v4, LL4/A;->V0:LL4/z;

    invoke-virtual {v0, v5, v4}, LL4/g;->S(Ljava/lang/String;LL4/z;)Z

    move-result v0

    invoke-virtual {v15}, Landroid/os/BaseBundle;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_5

    if-eqz v0, :cond_5

    iget-object v2, v3, LL4/J1;->v:LL4/m;

    invoke-static {v2}, LL4/J1;->T(LL4/E1;)V

    invoke-virtual {v2}, LE/V;->I()V

    invoke-virtual {v2}, LL4/E1;->J()V

    :try_start_f
    invoke-virtual {v2}, LL4/m;->x0()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const-string v3, "delete from default_event_params where app_id=?"

    filled-new-array {v9}, [Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_f
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_f .. :try_end_f} :catch_7

    goto/16 :goto_10

    :catch_7
    move-exception v0

    iget-object v2, v2, LE/V;->u:Ljava/lang/Object;

    check-cast v2, LL4/m0;

    iget-object v2, v2, LL4/m0;->y:LL4/Q;

    invoke-static {v2}, LL4/m0;->l(LL4/u0;)V

    iget-object v2, v2, LL4/Q;->z:LL4/O;

    const-string v3, "Error clearing default event params"

    invoke-virtual {v2, v0, v3}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    goto/16 :goto_10

    :cond_5
    iget-object v0, v3, LL4/J1;->v:LL4/m;

    invoke-static {v0}, LL4/J1;->T(LL4/E1;)V

    iget-object v4, v0, LE/V;->u:Ljava/lang/Object;

    check-cast v4, LL4/m0;

    invoke-virtual {v0}, LE/V;->I()V

    invoke-virtual {v0}, LL4/E1;->J()V

    iget-object v6, v0, LE/V;->u:Ljava/lang/Object;

    move-object v7, v6

    check-cast v7, LL4/m0;

    const-string v10, "dep"

    new-instance v6, LL4/q;

    const-string v8, ""

    const-wide/16 v11, 0x0

    const-wide/16 v13, 0x0

    invoke-direct/range {v6 .. v15}, LL4/q;-><init>(LL4/m0;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJLandroid/os/Bundle;)V

    iget-object v7, v0, LL4/A1;->v:LL4/J1;

    iget-object v7, v7, LL4/J1;->z:LL4/V;

    invoke-static {v7}, LL4/J1;->T(LL4/E1;)V

    invoke-virtual {v7, v6}, LL4/V;->k0(LL4/q;)Lcom/google/android/gms/internal/measurement/b1;

    move-result-object v6

    invoke-virtual {v6}, Lcom/google/android/gms/internal/measurement/S1;->a()[B

    move-result-object v6

    iget-object v4, v4, LL4/m0;->y:LL4/Q;

    invoke-static {v4}, LL4/m0;->l(LL4/u0;)V

    iget-object v7, v4, LL4/Q;->H:LL4/O;

    array-length v8, v6

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const-string v10, "Saving default event parameters, appId, data size"

    invoke-virtual {v7, v10, v9, v8}, LL4/O;->h(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v7, Landroid/content/ContentValues;

    invoke-direct {v7}, Landroid/content/ContentValues;-><init>()V

    const-string v8, "app_id"

    invoke-virtual {v7, v8, v9}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v8, "parameters"

    invoke-virtual {v7, v8, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    :try_start_10
    invoke-virtual {v0}, LL4/m;->x0()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const-string v6, "default_event_params"

    const/4 v8, 0x5

    invoke-virtual {v0, v6, v5, v7, v8}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide v6

    const-wide/16 v10, -0x1

    cmp-long v0, v6, v10

    if-nez v0, :cond_6

    invoke-static {v4}, LL4/m0;->l(LL4/u0;)V

    iget-object v0, v4, LL4/Q;->z:LL4/O;

    const-string v6, "Failed to insert default event parameters (got -1). appId"

    invoke-static {v9}, LL4/Q;->Q(Ljava/lang/String;)LL4/P;

    move-result-object v7

    invoke-virtual {v0, v7, v6}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_10
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_10 .. :try_end_10} :catch_8

    goto :goto_f

    :catch_8
    move-exception v0

    invoke-static {v4}, LL4/m0;->l(LL4/u0;)V

    iget-object v4, v4, LL4/Q;->z:LL4/O;

    invoke-static {v9}, LL4/Q;->Q(Ljava/lang/String;)LL4/P;

    move-result-object v6

    const-string v7, "Error storing default event parameters. appId"

    invoke-virtual {v4, v7, v6, v0}, LL4/O;->h(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_6
    :goto_f
    iget-object v4, v3, LL4/J1;->v:LL4/m;

    invoke-static {v4}, LL4/J1;->T(LL4/E1;)V

    iget-wide v6, v2, LL4/R1;->W:J

    :try_start_11
    const-string v0, "select count(*) from raw_events where app_id=? and timestamp >= ? and name not like \'!_%\' escape \'!\' limit 1;"

    invoke-static {v6, v7}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v9, v2}, [Ljava/lang/String;

    move-result-object v2

    const-wide/16 v10, 0x0

    invoke-virtual {v4, v0, v2, v10, v11}, LL4/m;->t0(Ljava/lang/String;[Ljava/lang/String;J)J

    move-result-wide v12

    cmp-long v0, v12, v10

    if-lez v0, :cond_7

    goto :goto_10

    :cond_7
    const-string v0, "select count(*) from raw_events where app_id=? and timestamp >= ? and name like \'!_%\' escape \'!\' limit 1;"

    invoke-static {v6, v7}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v9, v2}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v0, v2, v10, v11}, LL4/m;->t0(Ljava/lang/String;[Ljava/lang/String;J)J

    move-result-wide v12
    :try_end_11
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_11 .. :try_end_11} :catch_9

    cmp-long v0, v12, v10

    if-lez v0, :cond_8

    iget-object v0, v3, LL4/J1;->v:LL4/m;

    invoke-static {v0}, LL4/J1;->T(LL4/E1;)V

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v0, v9, v2, v5, v15}, LL4/m;->a0(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/String;Landroid/os/Bundle;)V

    goto :goto_10

    :catch_9
    move-exception v0

    iget-object v2, v4, LE/V;->u:Ljava/lang/Object;

    check-cast v2, LL4/m0;

    iget-object v2, v2, LL4/m0;->y:LL4/Q;

    invoke-static {v2}, LL4/m0;->l(LL4/u0;)V

    iget-object v2, v2, LL4/Q;->z:LL4/O;

    const-string v3, "Error checking backfill conditions"

    invoke-virtual {v2, v0, v3}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_8
    :goto_10
    return-void

    :pswitch_11
    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/measurement/internal/AppMeasurementDynamiteService;

    iget-object v0, v0, Lcom/google/android/gms/measurement/internal/AppMeasurementDynamiteService;->t:LL4/m0;

    invoke-virtual {v0}, LL4/m0;->o()LL4/m1;

    move-result-object v9

    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    move-object v12, v0

    check-cast v12, Lcom/google/android/gms/internal/measurement/L;

    iget-object v0, v1, LA1/P;->v:Ljava/lang/Object;

    move-object v10, v0

    check-cast v10, LL4/t;

    iget-object v0, v1, LA1/P;->w:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v9}, LL4/x;->I()V

    invoke-virtual {v9}, LL4/C;->J()V

    iget-object v0, v9, LE/V;->u:Ljava/lang/Object;

    check-cast v0, LL4/m0;

    iget-object v2, v0, LL4/m0;->B:LL4/P1;

    invoke-static {v2}, LL4/m0;->j(LE/V;)V

    iget-object v2, v2, LE/V;->u:Ljava/lang/Object;

    check-cast v2, LL4/m0;

    sget-object v3, Lm4/f;->b:Lm4/f;

    iget-object v2, v2, LL4/m0;->t:Landroid/content/Context;

    const v4, 0xbdfcb8

    invoke-virtual {v3, v2, v4}, Lm4/f;->c(Landroid/content/Context;I)I

    move-result v2

    if-eqz v2, :cond_9

    iget-object v2, v0, LL4/m0;->y:LL4/Q;

    invoke-static {v2}, LL4/m0;->l(LL4/u0;)V

    iget-object v2, v2, LL4/Q;->C:LL4/O;

    const-string v3, "Not bundling data. Service unavailable or out of date"

    invoke-virtual {v2, v3}, LL4/O;->f(Ljava/lang/String;)V

    iget-object v0, v0, LL4/m0;->B:LL4/P1;

    invoke-static {v0}, LL4/m0;->j(LE/V;)V

    new-array v2, v7, [B

    invoke-virtual {v0, v12, v2}, LL4/P1;->s0(Lcom/google/android/gms/internal/measurement/L;[B)V

    goto :goto_11

    :cond_9
    new-instance v8, LA1/P;

    const/16 v13, 0x8

    const/4 v14, 0x0

    invoke-direct/range {v8 .. v14}, LA1/P;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V

    invoke-virtual {v9, v8}, LL4/m1;->W(Ljava/lang/Runnable;)V

    :goto_11
    return-void

    :pswitch_12
    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v0, LL4/t0;

    iget-object v2, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-object v3, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v3, LL4/C1;

    iget-object v4, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v4, LL4/H;

    iget-object v6, v0, LL4/t0;->t:LL4/J1;

    invoke-virtual {v6}, LL4/J1;->B()V

    invoke-virtual {v6}, LL4/J1;->b()LL4/j0;

    move-result-object v0

    invoke-virtual {v0}, LL4/j0;->I()V

    invoke-virtual {v6}, LL4/J1;->k0()V

    iget-object v0, v6, LL4/J1;->v:LL4/m;

    invoke-static {v0}, LL4/J1;->T(LL4/E1;)V

    sget-object v8, LL4/A;->B:LL4/z;

    invoke-virtual {v8, v5}, LL4/z;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    invoke-virtual {v0, v2, v3, v8}, LL4/m;->N(Ljava/lang/String;LL4/C1;I)Ljava/util/List;

    move-result-object v0

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_12
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_11

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, LL4/L1;

    iget-object v9, v8, LL4/L1;->c:Ljava/lang/String;

    iget-wide v10, v8, LL4/L1;->h:J

    iget-wide v12, v8, LL4/L1;->a:J

    invoke-virtual {v6, v2, v9}, LL4/J1;->s(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_a

    invoke-virtual {v6}, LL4/J1;->a()LL4/Q;

    move-result-object v9

    iget-object v9, v9, LL4/Q;->H:LL4/O;

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v10

    iget-object v8, v8, LL4/L1;->c:Ljava/lang/String;

    const-string v11, "[sgtm] batch skipped due to destination in backoff. appId, rowId, url"

    invoke-virtual {v9, v11, v2, v10, v8}, LL4/O;->i(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_12

    :cond_a
    iget v9, v8, LL4/L1;->i:I

    if-gtz v9, :cond_b

    move-object/from16 v17, v6

    goto :goto_13

    :cond_b
    sget-object v14, LL4/A;->z:LL4/z;

    invoke-virtual {v14, v5}, LL4/z;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/Integer;

    invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I

    move-result v14

    if-le v9, v14, :cond_c

    move-object v8, v6

    goto/16 :goto_19

    :cond_c
    sget-object v14, LL4/A;->x:LL4/z;

    invoke-virtual {v14, v5}, LL4/z;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/Long;

    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    add-int/lit8 v9, v9, -0x1

    const-wide/16 v16, 0x1

    shl-long v16, v16, v9

    mul-long v14, v14, v16

    sget-object v9, LL4/A;->y:LL4/z;

    invoke-virtual {v9, v5}, LL4/z;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Long;

    move-object/from16 v17, v6

    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    invoke-static {v14, v15, v5, v6}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v5

    invoke-virtual/range {v17 .. v17}, LL4/J1;->f()Lv4/a;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v14

    add-long/2addr v5, v10

    cmp-long v5, v14, v5

    if-ltz v5, :cond_10

    :goto_13
    new-instance v5, Landroid/os/Bundle;

    invoke-direct {v5}, Landroid/os/Bundle;-><init>()V

    iget-object v6, v8, LL4/L1;->d:Ljava/util/HashMap;

    invoke-virtual {v6}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_14
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_d

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/Map$Entry;

    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v5, v10, v9}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_14

    :cond_d
    iget-wide v9, v8, LL4/L1;->a:J

    iget-object v6, v8, LL4/L1;->b:Lcom/google/android/gms/internal/measurement/h1;

    iget-object v11, v8, LL4/L1;->c:Ljava/lang/String;

    iget-object v12, v8, LL4/L1;->e:LL4/X0;

    iget-wide v13, v8, LL4/L1;->g:J

    new-instance v18, LL4/B1;

    invoke-virtual {v6}, Lcom/google/android/gms/internal/measurement/S1;->a()[B

    move-result-object v21

    iget v6, v12, LL4/X0;->t:I

    const-string v27, ""

    move-object/from16 v23, v5

    move/from16 v24, v6

    move-wide/from16 v19, v9

    move-object/from16 v22, v11

    move-wide/from16 v25, v13

    invoke-direct/range {v18 .. v27}, LL4/B1;-><init>(J[BLjava/lang/String;Landroid/os/Bundle;IJLjava/lang/String;)V

    move-object/from16 v5, v18

    :try_start_12
    invoke-static {}, Lcom/google/android/gms/internal/measurement/h1;->w()Lcom/google/android/gms/internal/measurement/g1;

    move-result-object v6

    iget-object v8, v5, LL4/B1;->u:[B

    invoke-static {v6, v8}, LL4/V;->v0(Lcom/google/android/gms/internal/measurement/f2;[B)Lcom/google/android/gms/internal/measurement/f2;

    move-result-object v6

    check-cast v6, Lcom/google/android/gms/internal/measurement/g1;

    move v8, v7

    :goto_15
    iget-object v9, v6, Lcom/google/android/gms/internal/measurement/f2;->u:Lcom/google/android/gms/internal/measurement/g2;

    check-cast v9, Lcom/google/android/gms/internal/measurement/h1;

    invoke-virtual {v9}, Lcom/google/android/gms/internal/measurement/h1;->q()I

    move-result v9

    if-ge v8, v9, :cond_e

    iget-object v9, v6, Lcom/google/android/gms/internal/measurement/f2;->u:Lcom/google/android/gms/internal/measurement/g2;

    check-cast v9, Lcom/google/android/gms/internal/measurement/h1;

    invoke-virtual {v9, v8}, Lcom/google/android/gms/internal/measurement/h1;->r(I)Lcom/google/android/gms/internal/measurement/j1;

    move-result-object v9

    invoke-virtual {v9}, Lcom/google/android/gms/internal/measurement/g2;->i()Lcom/google/android/gms/internal/measurement/f2;

    move-result-object v9

    check-cast v9, Lcom/google/android/gms/internal/measurement/i1;

    invoke-virtual/range {v17 .. v17}, LL4/J1;->f()Lv4/a;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    invoke-virtual {v9}, Lcom/google/android/gms/internal/measurement/f2;->b()V

    iget-object v12, v9, Lcom/google/android/gms/internal/measurement/f2;->u:Lcom/google/android/gms/internal/measurement/g2;

    check-cast v12, Lcom/google/android/gms/internal/measurement/j1;

    invoke-virtual {v12, v10, v11}, Lcom/google/android/gms/internal/measurement/j1;->f0(J)V

    invoke-virtual {v6}, Lcom/google/android/gms/internal/measurement/f2;->b()V

    iget-object v10, v6, Lcom/google/android/gms/internal/measurement/f2;->u:Lcom/google/android/gms/internal/measurement/g2;

    check-cast v10, Lcom/google/android/gms/internal/measurement/h1;

    invoke-virtual {v9}, Lcom/google/android/gms/internal/measurement/f2;->e()Lcom/google/android/gms/internal/measurement/g2;

    move-result-object v9

    check-cast v9, Lcom/google/android/gms/internal/measurement/j1;

    invoke-virtual {v10, v8, v9}, Lcom/google/android/gms/internal/measurement/h1;->y(ILcom/google/android/gms/internal/measurement/j1;)V

    add-int/lit8 v8, v8, 0x1

    goto :goto_15

    :catch_a
    move-object/from16 v8, v17

    goto :goto_18

    :cond_e
    invoke-virtual {v6}, Lcom/google/android/gms/internal/measurement/f2;->e()Lcom/google/android/gms/internal/measurement/g2;

    move-result-object v8

    check-cast v8, Lcom/google/android/gms/internal/measurement/h1;

    invoke-virtual {v8}, Lcom/google/android/gms/internal/measurement/S1;->a()[B

    move-result-object v8

    iput-object v8, v5, LL4/B1;->u:[B

    invoke-virtual/range {v17 .. v17}, LL4/J1;->a()LL4/Q;

    move-result-object v8

    invoke-virtual {v8}, LL4/Q;->S()Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x2

    invoke-static {v8, v9}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v8
    :try_end_12
    .catch Lcom/google/android/gms/internal/measurement/p2; {:try_start_12 .. :try_end_12} :catch_a

    if-eqz v8, :cond_f

    move-object/from16 v8, v17

    :try_start_13
    iget-object v9, v8, LL4/J1;->z:LL4/V;

    invoke-static {v9}, LL4/J1;->T(LL4/E1;)V

    invoke-virtual {v6}, Lcom/google/android/gms/internal/measurement/f2;->e()Lcom/google/android/gms/internal/measurement/g2;

    move-result-object v6

    check-cast v6, Lcom/google/android/gms/internal/measurement/h1;

    invoke-virtual {v9, v6}, LL4/V;->l0(Lcom/google/android/gms/internal/measurement/h1;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, v5, LL4/B1;->z:Ljava/lang/String;
    :try_end_13
    .catch Lcom/google/android/gms/internal/measurement/p2; {:try_start_13 .. :try_end_13} :catch_b

    goto :goto_16

    :cond_f
    move-object/from16 v8, v17

    :goto_16
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_17
    move-object v6, v8

    const/4 v5, 0x0

    goto/16 :goto_12

    :catch_b
    :goto_18
    invoke-virtual {v8}, LL4/J1;->a()LL4/Q;

    move-result-object v5

    iget-object v5, v5, LL4/Q;->C:LL4/O;

    const-string v6, "Failed to parse queued batch. appId"

    invoke-virtual {v5, v2, v6}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_17

    :cond_10
    move-object/from16 v8, v17

    :goto_19
    invoke-virtual {v8}, LL4/J1;->a()LL4/Q;

    move-result-object v5

    iget-object v5, v5, LL4/Q;->H:LL4/O;

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    const-string v10, "[sgtm] batch skipped waiting for next retry. appId, rowId, lastUploadMillis"

    invoke-virtual {v5, v10, v2, v6, v9}, LL4/O;->i(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_17

    :cond_11
    move-object v8, v6

    new-instance v0, LL4/D1;

    invoke-direct {v0, v3}, LL4/D1;-><init>(Ljava/util/ArrayList;)V

    :try_start_14
    invoke-interface {v4, v0}, LL4/H;->P0(LL4/D1;)V

    invoke-virtual {v8}, LL4/J1;->a()LL4/Q;

    move-result-object v0

    iget-object v0, v0, LL4/Q;->H:LL4/O;

    const-string v4, "[sgtm] Sending queued upload batches to client. appId, count"

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v4, v2, v3}, LL4/O;->h(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_14
    .catch Landroid/os/RemoteException; {:try_start_14 .. :try_end_14} :catch_c

    goto :goto_1a

    :catch_c
    move-exception v0

    invoke-virtual {v8}, LL4/J1;->a()LL4/Q;

    move-result-object v3

    iget-object v3, v3, LL4/Q;->z:LL4/O;

    const-string v4, "[sgtm] Failed to return upload batches for app"

    invoke-virtual {v3, v4, v2, v0}, LL4/O;->h(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_1a
    return-void

    :pswitch_13
    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v0, LH4/O7;

    iget-object v5, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v5, LD4/f;

    iget-object v8, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v8, LH4/y5;

    iget-object v9, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v9, Ljava/lang/String;

    iget-object v10, v5, LD4/f;->c:Ljava/lang/Object;

    check-cast v10, LT3/o;

    iput-object v8, v10, LT3/o;->u:Ljava/lang/Object;

    iget-object v8, v10, LT3/o;->t:Ljava/lang/Object;

    check-cast v8, LH4/o7;

    if-eqz v8, :cond_12

    iget-object v8, v8, LH4/o7;->d:Ljava/lang/String;

    invoke-static {v8}, LE4/q3;->b(Ljava/lang/String;)Z

    move-result v10

    if-nez v10, :cond_12

    invoke-static {v8}, Lp4/y;->h(Ljava/lang/Object;)V

    goto :goto_1b

    :cond_12
    const-string v8, "NA"

    :goto_1b
    new-instance v10, LE4/n4;

    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    iget-object v11, v0, LH4/O7;->a:Ljava/lang/String;

    iput-object v11, v10, LE4/n4;->a:Ljava/lang/Object;

    iget-object v11, v0, LH4/O7;->b:Ljava/lang/String;

    iput-object v11, v10, LE4/n4;->b:Ljava/lang/Object;

    const-class v11, LH4/O7;

    monitor-enter v11

    :try_start_15
    sget-object v12, LH4/O7;->k:LH4/x;
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_3

    if-eqz v12, :cond_13

    monitor-exit v11

    const/16 v16, 0xa

    goto :goto_1d

    :cond_13
    :try_start_16
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v12

    invoke-virtual {v12}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v12

    invoke-virtual {v12}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    move-result-object v12

    new-instance v13, Lw1/b;

    new-instance v14, Lw1/c;

    invoke-direct {v14, v12}, Lw1/c;-><init>(Landroid/os/LocaleList;)V

    invoke-direct {v13, v14}, Lw1/b;-><init>(Lw1/c;)V

    new-array v4, v4, [Ljava/lang/Object;

    move v12, v7

    :goto_1c
    iget-object v14, v13, Lw1/b;->a:Lw1/c;

    iget-object v14, v14, Lw1/c;->a:Landroid/os/LocaleList;

    invoke-virtual {v14}, Landroid/os/LocaleList;->size()I

    move-result v14

    if-ge v7, v14, :cond_17

    iget-object v14, v13, Lw1/b;->a:Lw1/c;

    iget-object v14, v14, Lw1/c;->a:Landroid/os/LocaleList;

    invoke-virtual {v14, v7}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v14

    sget-object v15, LT5/c;->a:Lj6/d;

    invoke-virtual {v14}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v15, v12, 0x1

    const/16 v16, 0xa

    array-length v2, v4

    if-ge v2, v15, :cond_16

    shr-int/lit8 v17, v2, 0x1

    add-int v2, v2, v17

    add-int/2addr v2, v6

    if-ge v2, v15, :cond_14

    invoke-static {v12}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v2

    add-int/2addr v2, v2

    :cond_14
    if-gez v2, :cond_15

    move v2, v3

    :cond_15
    invoke-static {v4, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    move-object v4, v2

    :cond_16
    aput-object v14, v4, v12

    add-int/lit8 v7, v7, 0x1

    move v12, v15

    goto :goto_1c

    :cond_17
    const/16 v16, 0xa

    invoke-static {v12, v4}, LH4/p;->h(I[Ljava/lang/Object;)LH4/x;

    move-result-object v12

    sput-object v12, LH4/O7;->k:LH4/x;
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_3

    monitor-exit v11

    :goto_1d
    iput-object v12, v10, LE4/n4;->k:Ljava/lang/Object;

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iput-object v2, v10, LE4/n4;->g:Ljava/lang/Object;

    iput-object v8, v10, LE4/n4;->d:Ljava/lang/Object;

    iput-object v9, v10, LE4/n4;->c:Ljava/lang/Object;

    iget-object v2, v0, LH4/O7;->f:LO4/o;

    invoke-virtual {v2}, LO4/o;->j()Z

    move-result v2

    if-eqz v2, :cond_18

    iget-object v2, v0, LH4/O7;->f:LO4/o;

    invoke-virtual {v2}, LO4/o;->h()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    goto :goto_1e

    :cond_18
    iget-object v2, v0, LH4/O7;->d:LT5/j;

    invoke-virtual {v2}, LT5/j;->a()Ljava/lang/String;

    move-result-object v2

    :goto_1e
    iput-object v2, v10, LE4/n4;->e:Ljava/lang/Object;

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iput-object v2, v10, LE4/n4;->i:Ljava/lang/Object;

    iget v2, v0, LH4/O7;->h:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iput-object v2, v10, LE4/n4;->j:Ljava/lang/Object;

    iput-object v10, v5, LD4/f;->d:Ljava/lang/Object;

    iget-object v0, v0, LH4/O7;->c:LH4/L7;

    invoke-virtual {v0, v5}, LH4/L7;->a(LD4/f;)V

    return-void

    :catchall_3
    move-exception v0

    :try_start_17
    monitor-exit v11
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_3

    throw v0

    :pswitch_14
    const/16 v16, 0xa

    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v0, LF4/z7;

    iget-object v2, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v2, LD4/f;

    iget-object v5, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v5, LF4/n5;

    iget-object v8, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v8, Ljava/lang/String;

    iget-object v9, v2, LD4/f;->c:Ljava/lang/Object;

    check-cast v9, LT3/o;

    iput-object v5, v9, LT3/o;->u:Ljava/lang/Object;

    iget-object v5, v9, LT3/o;->t:Ljava/lang/Object;

    check-cast v5, LF4/a7;

    if-eqz v5, :cond_19

    iget-object v5, v5, LF4/a7;->d:Ljava/lang/String;

    if-eqz v5, :cond_19

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_1a

    :cond_19
    const-string v5, "NA"

    :cond_1a
    new-instance v9, LE4/n4;

    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    iget-object v10, v0, LF4/z7;->a:Ljava/lang/String;

    iput-object v10, v9, LE4/n4;->a:Ljava/lang/Object;

    iget-object v10, v0, LF4/z7;->b:Ljava/lang/String;

    iput-object v10, v9, LE4/n4;->b:Ljava/lang/Object;

    const-class v10, LF4/z7;

    monitor-enter v10

    :try_start_18
    sget-object v11, LF4/z7;->k:LF4/o;
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_4

    if-eqz v11, :cond_1b

    monitor-exit v10

    goto :goto_20

    :cond_1b
    :try_start_19
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v11

    invoke-virtual {v11}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v11

    invoke-virtual {v11}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    move-result-object v11

    new-instance v12, Lw1/b;

    new-instance v13, Lw1/c;

    invoke-direct {v13, v11}, Lw1/c;-><init>(Landroid/os/LocaleList;)V

    invoke-direct {v12, v13}, Lw1/b;-><init>(Lw1/c;)V

    new-array v4, v4, [Ljava/lang/Object;

    move v11, v7

    :goto_1f
    iget-object v13, v12, Lw1/b;->a:Lw1/c;

    iget-object v13, v13, Lw1/c;->a:Landroid/os/LocaleList;

    invoke-virtual {v13}, Landroid/os/LocaleList;->size()I

    move-result v13

    if-ge v7, v13, :cond_1f

    iget-object v13, v12, Lw1/b;->a:Lw1/c;

    iget-object v13, v13, Lw1/c;->a:Landroid/os/LocaleList;

    invoke-virtual {v13, v7}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v13

    sget-object v14, LT5/c;->a:Lj6/d;

    invoke-virtual {v13}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v14, v11, 0x1

    array-length v15, v4

    if-ge v15, v14, :cond_1e

    shr-int/lit8 v17, v15, 0x1

    add-int v15, v15, v17

    add-int/2addr v15, v6

    if-ge v15, v14, :cond_1c

    invoke-static {v11}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v15

    add-int/2addr v15, v15

    :cond_1c
    if-gez v15, :cond_1d

    move v15, v3

    :cond_1d
    invoke-static {v4, v15}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v4

    :cond_1e
    aput-object v13, v4, v11

    add-int/lit8 v7, v7, 0x1

    move v11, v14

    goto :goto_1f

    :cond_1f
    invoke-static {v11, v4}, LF4/j;->h(I[Ljava/lang/Object;)LF4/o;

    move-result-object v11

    sput-object v11, LF4/z7;->k:LF4/o;
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_4

    monitor-exit v10

    :goto_20
    iput-object v11, v9, LE4/n4;->k:Ljava/lang/Object;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iput-object v3, v9, LE4/n4;->g:Ljava/lang/Object;

    iput-object v5, v9, LE4/n4;->d:Ljava/lang/Object;

    iput-object v8, v9, LE4/n4;->c:Ljava/lang/Object;

    iget-object v3, v0, LF4/z7;->f:LO4/o;

    invoke-virtual {v3}, LO4/o;->j()Z

    move-result v3

    if-eqz v3, :cond_20

    iget-object v3, v0, LF4/z7;->f:LO4/o;

    invoke-virtual {v3}, LO4/o;->h()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    goto :goto_21

    :cond_20
    iget-object v3, v0, LF4/z7;->d:LT5/j;

    invoke-virtual {v3}, LT5/j;->a()Ljava/lang/String;

    move-result-object v3

    :goto_21
    iput-object v3, v9, LE4/n4;->e:Ljava/lang/Object;

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iput-object v3, v9, LE4/n4;->i:Ljava/lang/Object;

    iget v3, v0, LF4/z7;->h:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iput-object v3, v9, LE4/n4;->j:Ljava/lang/Object;

    iput-object v9, v2, LD4/f;->d:Ljava/lang/Object;

    iget-object v0, v0, LF4/z7;->c:LF4/w7;

    invoke-virtual {v0, v2}, LF4/w7;->a(LD4/f;)V

    return-void

    :catchall_4
    move-exception v0

    :try_start_1a
    monitor-exit v10
    :try_end_1a
    .catchall {:try_start_1a .. :try_end_1a} :catchall_4

    throw v0

    :pswitch_15
    iget-object v0, v1, LA1/P;->u:Ljava/lang/Object;

    check-cast v0, Landroid/view/View;

    iget-object v2, v1, LA1/P;->v:Ljava/lang/Object;

    check-cast v2, LA1/W;

    iget-object v3, v1, LA1/P;->w:Ljava/lang/Object;

    check-cast v3, LP2/c;

    invoke-static {v0, v2, v3}, LA1/S;->i(Landroid/view/View;LA1/W;LP2/c;)V

    iget-object v0, v1, LA1/P;->x:Ljava/lang/Object;

    check-cast v0, Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
