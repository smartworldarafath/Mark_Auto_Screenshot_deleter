.class public final LA1/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE2/a;
.implements LE2/g;
.implements Lorg/chromium/support_lib_boundary/WebViewStartUpConfigBoundaryInterface;
.implements LI1/c;
.implements LL4/O1;
.implements LO4/e;
.implements Le3/g;
.implements Lcom/google/android/gms/internal/ads/Kf;


# instance fields
.field public final synthetic t:I

.field public u:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 1

    iput p1, p0, LA1/i;->t:I

    sparse-switch p1, :sswitch_data_0

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    new-instance p1, LL0/A0;

    sget-object v0, LL0/f;->b:LL0/n0;

    .line 10
    invoke-direct {p1, v0}, Ljava/util/TreeSet;-><init>(Ljava/util/Comparator;)V

    .line 11
    iput-object p1, p0, LA1/i;->u:Ljava/lang/Object;

    return-void

    .line 12
    :sswitch_0
    sget-object p1, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    .line 13
    const-string v0, "timeUnit"

    invoke-static {p1, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    new-instance p1, LL4/S;

    .line 15
    sget-object v0, LY7/d;->i:LY7/d;

    .line 16
    invoke-direct {p1, v0}, LL4/S;-><init>(LY7/d;)V

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    iput-object p1, p0, LA1/i;->u:Ljava/lang/Object;

    return-void

    .line 19
    :sswitch_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    new-instance p1, LO4/o;

    invoke-direct {p1}, LO4/o;-><init>()V

    iput-object p1, p0, LA1/i;->u:Ljava/lang/Object;

    return-void

    .line 21
    :sswitch_2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/EnumMap;

    const-class v0, LL4/y0;

    invoke-direct {p1, v0}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object p1, p0, LA1/i;->u:Ljava/lang/Object;

    return-void

    :sswitch_data_0
    .sparse-switch
        0xe -> :sswitch_2
        0x15 -> :sswitch_1
        0x1d -> :sswitch_0
    .end sparse-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA1/i;->t:I

    iput-object p2, p0, LA1/i;->u:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(IZ)V
    .locals 0

    .line 2
    iput p1, p0, LA1/i;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .locals 2

    const/4 v0, 0x1

    iput v0, p0, LA1/i;->t:I

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    .line 24
    new-instance v0, LA1/w;

    .line 25
    invoke-direct {v0, p1}, LA1/t;-><init>(Ljava/lang/Object;)V

    .line 26
    iput-object p1, v0, LA1/w;->u:Landroid/view/View;

    .line 27
    iput-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    goto :goto_0

    .line 28
    :cond_0
    new-instance v0, LA1/t;

    invoke-direct {v0, p1}, LA1/t;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    :goto_0
    return-void
.end method

.method public constructor <init>(Landroidx/work/impl/WorkDatabase;)V
    .locals 1

    const/16 v0, 0x18

    iput v0, p0, LA1/i;->t:I

    const-string v0, "workDatabase"

    invoke-static {p1, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/i;->u:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Runnable;)V
    .locals 0

    const/4 p1, 0x0

    iput p1, p0, LA1/i;->t:I

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 30
    new-instance p1, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object p1, p0, LA1/i;->u:Ljava/lang/Object;

    .line 31
    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/util/EnumMap;)V
    .locals 2

    const/16 v0, 0xe

    iput v0, p0, LA1/i;->t:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/EnumMap;

    const-class v1, LL4/y0;

    invoke-direct {v0, v1}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    .line 4
    invoke-virtual {v0, p1}, Ljava/util/EnumMap;->putAll(Ljava/util/Map;)V

    return-void
.end method

.method public constructor <init>(Ll/m;)V
    .locals 6

    const/16 v0, 0x17

    iput v0, p0, LA1/i;->t:I

    .line 39
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 40
    new-instance v0, LP2/e;

    .line 41
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 42
    iput-object p1, v0, LP2/e;->t:Ljava/lang/Object;

    .line 43
    new-instance v1, LQ1/i;

    invoke-direct {v1, p1}, LQ1/i;-><init>(Ll/m;)V

    iput-object v1, v0, LP2/e;->u:Ljava/lang/Object;

    .line 44
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 45
    sget-object v1, LQ1/a;->b:LQ1/a;

    if-nez v1, :cond_1

    .line 46
    sget-object v1, LQ1/a;->a:Ljava/lang/Object;

    monitor-enter v1

    .line 47
    :try_start_0
    sget-object v2, LQ1/a;->b:LQ1/a;

    if-nez v2, :cond_0

    .line 48
    new-instance v2, LQ1/a;

    .line 49
    invoke-direct {v2}, Landroid/text/Editable$Factory;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 50
    :try_start_1
    const-string v3, "android.text.DynamicLayout$ChangeWatcher"

    .line 51
    const-class v4, LQ1/a;

    invoke-virtual {v4}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v4

    const/4 v5, 0x0

    invoke-static {v3, v5, v4}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v3

    sput-object v3, LQ1/a;->c:Ljava/lang/Class;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 52
    :catchall_0
    :try_start_2
    sput-object v2, LQ1/a;->b:LQ1/a;

    goto :goto_0

    :catchall_1
    move-exception p1

    goto :goto_1

    .line 53
    :cond_0
    :goto_0
    monitor-exit v1

    goto :goto_2

    :goto_1
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw p1

    .line 54
    :cond_1
    :goto_2
    sget-object v1, LQ1/a;->b:LQ1/a;

    .line 55
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setEditableFactory(Landroid/text/Editable$Factory;)V

    .line 56
    iput-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lorg/chromium/support_lib_boundary/WebViewStartUpResultBoundaryInterface;)V
    .locals 2

    const/16 v0, 0x8

    iput v0, p0, LA1/i;->t:I

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/i;->u:Ljava/lang/Object;

    .line 33
    invoke-interface {p1}, Lorg/chromium/support_lib_boundary/WebViewStartUpResultBoundaryInterface;->getBlockingStartUpLocations()Ljava/util/List;

    move-result-object p1

    .line 34
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 35
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Throwable;

    .line 36
    new-instance v1, LF2/e;

    .line 37
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 38
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-void
.end method

.method public constructor <init>(Z)V
    .locals 1

    const/16 v0, 0x12

    iput v0, p0, LA1/i;->t:I

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0, p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    return-void
.end method

.method public static f(LA1/i;I)LE/c0;
    .locals 10

    iget-object p0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast p0, LC/B;

    invoke-static {}, LT5/p;->n()Lk0/f;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lk0/f;->e()Lr7/c;

    move-result-object v0

    :goto_0
    move-object v2, v0

    goto :goto_1

    :cond_0
    const/4 v0, 0x0

    goto :goto_0

    :goto_1
    invoke-static {v1}, LT5/p;->o(Lk0/f;)Lk0/f;

    move-result-object v3

    :try_start_0
    iget-object v0, p0, LC/B;->f:La0/h0;

    invoke-virtual {v0}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LC/r;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {v1, v3, v2}, LT5/p;->r(Lk0/f;Lk0/f;Lr7/c;)V

    iget-object v4, p0, LC/B;->p:LE/d0;

    iget-wide v6, v0, LC/r;->j:J

    iget-boolean v8, p0, LC/B;->d:Z

    new-instance v9, LC/v;

    invoke-direct {v9, p1, v0}, LC/v;-><init>(ILC/r;)V

    move v5, p1

    invoke-virtual/range {v4 .. v9}, LE/d0;->a(IJZLr7/c;)LE/c0;

    move-result-object p0

    return-object p0

    :catchall_0
    move-exception v0

    move-object p0, v0

    invoke-static {v1, v3, v2}, LT5/p;->r(Lk0/f;Lk0/f;Lr7/c;)V

    throw p0
.end method


# virtual methods
.method public synthetic H(Ljava/lang/String;ILjava/lang/String;Z)V
    .locals 0

    iget-object p1, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast p1, LV3/c;

    iget-object p1, p1, LV3/c;->w:Lcom/google/android/gms/internal/ads/rf;

    if-eqz p1, :cond_0

    invoke-interface {p1}, Lcom/google/android/gms/internal/ads/rf;->D()V

    :cond_0
    return-void
.end method

.method public a(LT2/f;)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LU2/j;

    iget-object v0, v0, LU2/j;->y:LG7/g0;

    new-instance v1, LG7/Q;

    const/4 v2, 0x4

    invoke-direct {v1, v2, v0}, LG7/Q;-><init>(ILjava/lang/Object;)V

    invoke-static {v1, p1}, LG7/W;->i(LG7/i;Lj7/c;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public b(LI1/b;)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, Lr7/c;

    invoke-interface {v0, p1}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public c(LL0/J;)V
    .locals 1

    invoke-virtual {p1}, LL0/J;->I()Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "DepthSortedSet.add called on an unattached node"

    invoke-static {v0}, LI0/a;->b(Ljava/lang/String;)V

    :cond_0
    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LL0/A0;

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public d(LL0/J;)Z
    .locals 1

    invoke-virtual {p1}, LL0/J;->I()Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "DepthSortedSet.remove called on an unattached node"

    invoke-static {v0}, LI0/a;->b(Ljava/lang/String;)V

    :cond_0
    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LL0/A0;

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public e(I)Ljava/util/ArrayList;
    .locals 22

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v1, p0

    iget-object v2, v1, LA1/i;->u:Ljava/lang/Object;

    check-cast v2, LD/A;

    invoke-static {}, LT5/p;->n()Lk0/f;

    move-result-object v3

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Lk0/f;->e()Lr7/c;

    move-result-object v4

    move-object v10, v4

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    :goto_0
    invoke-static {v3}, LT5/p;->o(Lk0/f;)Lk0/f;

    move-result-object v11

    :try_start_0
    iget-boolean v4, v2, LD/A;->b:Z

    if-eqz v4, :cond_1

    iget-object v4, v2, LD/A;->c:LD/o;

    :goto_1
    move-object v9, v4

    goto :goto_2

    :catchall_0
    move-exception v0

    goto :goto_4

    :cond_1
    iget-object v4, v2, LD/A;->e:La0/h0;

    invoke-virtual {v4}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LD/o;

    goto :goto_1

    :goto_2
    if-eqz v9, :cond_2

    new-instance v6, Ls7/s;

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x1

    iput v4, v6, Ls7/s;->t:I

    iget-object v4, v9, LD/o;->k:Lr7/c;

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v4, v7}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    move-object v7, v4

    check-cast v7, Ljava/util/List;

    invoke-interface {v7}, Ljava/util/Collection;->size()I

    move-result v12

    const/4 v4, 0x0

    move v13, v4

    :goto_3
    if-ge v13, v12, :cond_2

    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ld7/k;

    iget-object v14, v2, LD/A;->o:LE/d0;

    iget-object v8, v4, Ld7/k;->t:Ljava/lang/Object;

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    move-result v15

    iget-object v4, v4, Ld7/k;->u:Ljava/lang/Object;

    check-cast v4, Lj1/a;

    move-object/from16 v16, v6

    iget-wide v5, v4, Lj1/a;->a:J

    sget-object v4, LD/A;->w:Lj6/b;

    new-instance v19, LB5/h;

    move-wide/from16 v20, v5

    move-object/from16 v6, v16

    move-wide/from16 v16, v20

    move/from16 v8, p1

    move-object/from16 v4, v19

    const/4 v5, 0x0

    invoke-direct/range {v4 .. v9}, LB5/h;-><init>(Ljava/util/ArrayList;Ls7/s;Ljava/util/List;ILD/o;)V

    move-object/from16 v19, v4

    const/16 v18, 0x0

    invoke-virtual/range {v14 .. v19}, LE/d0;->a(IJZLr7/c;)LE/c0;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    add-int/lit8 v13, v13, 0x1

    goto :goto_3

    :cond_2
    invoke-static {v3, v11, v10}, LT5/p;->r(Lk0/f;Lk0/f;Lr7/c;)V

    return-object v0

    :goto_4
    invoke-static {v3, v11, v10}, LT5/p;->r(Lk0/f;Lk0/f;Lr7/c;)V

    throw v0
.end method

.method public g(ILjava/lang/String;Ljava/util/List;ZZ)V
    .locals 4

    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LL4/f0;

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz p1, :cond_7

    if-eq p1, v2, :cond_4

    if-eq p1, v1, :cond_3

    const/4 v3, 0x4

    if-eq p1, v3, :cond_0

    iget-object p1, v0, LE/V;->u:Ljava/lang/Object;

    check-cast p1, LL4/m0;

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->F:LL4/O;

    goto :goto_0

    :cond_0
    if-eqz p4, :cond_1

    iget-object p1, v0, LE/V;->u:Ljava/lang/Object;

    check-cast p1, LL4/m0;

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->D:LL4/O;

    goto :goto_0

    :cond_1
    if-nez p5, :cond_2

    iget-object p1, v0, LE/V;->u:Ljava/lang/Object;

    check-cast p1, LL4/m0;

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->E:LL4/O;

    goto :goto_0

    :cond_2
    iget-object p1, v0, LE/V;->u:Ljava/lang/Object;

    check-cast p1, LL4/m0;

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->C:LL4/O;

    goto :goto_0

    :cond_3
    iget-object p1, v0, LE/V;->u:Ljava/lang/Object;

    check-cast p1, LL4/m0;

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->H:LL4/O;

    goto :goto_0

    :cond_4
    if-eqz p4, :cond_5

    iget-object p1, v0, LE/V;->u:Ljava/lang/Object;

    check-cast p1, LL4/m0;

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->A:LL4/O;

    goto :goto_0

    :cond_5
    if-nez p5, :cond_6

    iget-object p1, v0, LE/V;->u:Ljava/lang/Object;

    check-cast p1, LL4/m0;

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->B:LL4/O;

    goto :goto_0

    :cond_6
    iget-object p1, v0, LE/V;->u:Ljava/lang/Object;

    check-cast p1, LL4/m0;

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->z:LL4/O;

    goto :goto_0

    :cond_7
    iget-object p1, v0, LE/V;->u:Ljava/lang/Object;

    check-cast p1, LL4/m0;

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->G:LL4/O;

    :goto_0
    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result p4

    const/4 p5, 0x0

    if-eq p4, v2, :cond_a

    const/4 v0, 0x2

    if-eq p4, v0, :cond_9

    if-eq p4, v1, :cond_8

    invoke-virtual {p1, p2}, LL4/O;->f(Ljava/lang/String;)V

    return-void

    :cond_8
    invoke-interface {p3, p5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p4

    invoke-interface {p3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p5

    invoke-interface {p3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p1, p2, p4, p5, p3}, LL4/O;->i(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_9
    invoke-interface {p3, p5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p4

    invoke-interface {p3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p1, p2, p4, p3}, LL4/O;->h(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_a
    invoke-interface {p3, p5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p1, p3, p2}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public getBackgroundExecutor()Ljava/util/concurrent/Executor;
    .locals 1

    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LE2/f;

    iget-object v0, v0, LE2/f;->u:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/Executor;

    return-object v0
.end method

.method public getTotalTimeInUiThreadMillis()Ljava/lang/Long;
    .locals 1

    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, Lorg/chromium/support_lib_boundary/WebViewStartUpResultBoundaryInterface;

    invoke-interface {v0}, Lorg/chromium/support_lib_boundary/WebViewStartUpResultBoundaryInterface;->getTotalTimeInUiThreadMillis()Ljava/lang/Long;

    move-result-object v0

    return-object v0
.end method

.method public h(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/Void;

    iget-object p1, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast p1, LA1/t;

    iget-object p1, p1, LA1/t;->t:Ljava/lang/Object;

    check-cast p1, LO4/h;

    iget-object p1, p1, LO4/h;->a:LO4/o;

    invoke-virtual {p1}, LO4/o;->n()V

    return-void
.end method

.method public i(LL4/y0;I)V
    .locals 1

    const/16 v0, -0x1e

    if-eq p2, v0, :cond_3

    const/16 v0, -0x14

    if-eq p2, v0, :cond_2

    const/16 v0, -0xa

    if-eq p2, v0, :cond_1

    if-eqz p2, :cond_2

    const/16 v0, 0x1e

    if-eq p2, v0, :cond_0

    sget-object p2, LL4/h;->u:LL4/h;

    goto :goto_0

    :cond_0
    sget-object p2, LL4/h;->y:LL4/h;

    goto :goto_0

    :cond_1
    sget-object p2, LL4/h;->x:LL4/h;

    goto :goto_0

    :cond_2
    sget-object p2, LL4/h;->z:LL4/h;

    goto :goto_0

    :cond_3
    sget-object p2, LL4/h;->A:LL4/h;

    :goto_0
    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, Ljava/util/EnumMap;

    invoke-virtual {v0, p1, p2}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public j(LL4/y0;LL4/h;)V
    .locals 1

    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, Ljava/util/EnumMap;

    invoke-virtual {v0, p1, p2}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public k0(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;)V
    .locals 8

    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LL4/J1;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object p1, v0, LL4/J1;->E:LL4/m0;

    if-eqz p1, :cond_0

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->z:LL4/O;

    const-string p2, "AppId not known when logging event"

    invoke-virtual {p1, p3, p2}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_0
    return-void

    :cond_1
    invoke-virtual {v0}, LL4/J1;->b()LL4/j0;

    move-result-object v0

    new-instance v1, LA1/P;

    const/16 v6, 0xb

    const/4 v7, 0x0

    move-object v2, p0

    move-object v3, p1

    move-object v5, p2

    move-object v4, p3

    invoke-direct/range {v1 .. v7}, LA1/P;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V

    invoke-virtual {v0, v1}, LL4/j0;->R(Ljava/lang/Runnable;)V

    return-void
.end method

.method public shouldRunUiThreadStartUpTasks()Z
    .locals 1

    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LE2/f;

    iget-boolean v0, v0, LE2/f;->t:Z

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 6

    iget v0, p0, LA1/i;->t:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "1"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, LL4/y0;->values()[LL4/y0;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_1

    aget-object v4, v1, v3

    iget-object v5, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v5, Ljava/util/EnumMap;

    invoke-virtual {v5, v4}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LL4/h;

    if-nez v4, :cond_0

    sget-object v4, LL4/h;->u:LL4/h;

    :cond_0
    iget-char v4, v4, LL4/h;->t:C

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LL0/A0;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0xd
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
