.class public abstract LA1/K;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget-object v0, LA1/q0;->b:LA1/q0;

    invoke-virtual {v0}, LA1/q0;->b()Landroid/view/WindowInsets;

    return-void
.end method
