.class public final LA1/W;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:LA1/V;


# direct methods
.method public constructor <init>(ILandroid/view/animation/Interpolator;J)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    new-instance v0, LA1/U;

    invoke-static {p1, p2, p3, p4}, LA1/u;->i(ILandroid/view/animation/Interpolator;J)Landroid/view/WindowInsetsAnimation;

    move-result-object p1

    invoke-direct {v0, p1}, LA1/U;-><init>(Landroid/view/WindowInsetsAnimation;)V

    iput-object v0, p0, LA1/W;->a:LA1/V;

    return-void

    :cond_0
    new-instance v0, LA1/S;

    invoke-direct {v0, p1, p2, p3, p4}, LA1/V;-><init>(ILandroid/view/animation/Interpolator;J)V

    iput-object v0, p0, LA1/W;->a:LA1/V;

    return-void
.end method
