.class public LA1/j0;
.super LA1/i0;
.source "SourceFile"


# direct methods
.method public constructor <init>(LA1/q0;LA1/j0;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1, p2}, LA1/i0;-><init>(LA1/q0;LA1/i0;)V

    return-void
.end method

.method public constructor <init>(LA1/q0;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LA1/i0;-><init>(LA1/q0;Landroid/view/WindowInsets;)V

    return-void
.end method
