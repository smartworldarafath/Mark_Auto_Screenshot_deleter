.class public final LA1/t0;
.super LA1/s0;
.source "SourceFile"
