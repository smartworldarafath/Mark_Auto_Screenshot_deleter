.class public LA1/Z;
.super LA1/d0;
.source "SourceFile"


# instance fields
.field public final c:Landroid/view/WindowInsets$Builder;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LA1/d0;-><init>()V

    .line 2
    invoke-static {}, LA1/Y;->e()Landroid/view/WindowInsets$Builder;

    move-result-object v0

    iput-object v0, p0, LA1/Z;->c:Landroid/view/WindowInsets$Builder;

    return-void
.end method

.method public constructor <init>(LA1/q0;)V
    .locals 0

    .line 3
    invoke-direct {p0, p1}, LA1/d0;-><init>(LA1/q0;)V

    .line 4
    invoke-virtual {p1}, LA1/q0;->b()Landroid/view/WindowInsets;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 5
    invoke-static {p1}, LA1/Y;->f(Landroid/view/WindowInsets;)Landroid/view/WindowInsets$Builder;

    move-result-object p1

    goto :goto_0

    .line 6
    :cond_0
    invoke-static {}, LA1/Y;->e()Landroid/view/WindowInsets$Builder;

    move-result-object p1

    :goto_0
    iput-object p1, p0, LA1/Z;->c:Landroid/view/WindowInsets$Builder;

    return-void
.end method


# virtual methods
.method public b()LA1/q0;
    .locals 3

    invoke-virtual {p0}, LA1/d0;->a()V

    iget-object v0, p0, LA1/Z;->c:Landroid/view/WindowInsets$Builder;

    invoke-static {v0}, LA1/Y;->g(Landroid/view/WindowInsets$Builder;)Landroid/view/WindowInsets;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, LA1/q0;->c(Landroid/view/View;Landroid/view/WindowInsets;)LA1/q0;

    move-result-object v0

    iget-object v1, p0, LA1/d0;->b:[Lt1/b;

    iget-object v2, v0, LA1/q0;->a:LA1/l0;

    invoke-virtual {v2, v1}, LA1/l0;->r([Lt1/b;)V

    return-object v0
.end method

.method public d(Lt1/b;)V
    .locals 1

    iget-object v0, p0, LA1/Z;->c:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lt1/b;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, LA1/Y;->C(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method

.method public e(Lt1/b;)V
    .locals 1

    iget-object v0, p0, LA1/Z;->c:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lt1/b;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, LA1/Y;->x(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method

.method public f(Lt1/b;)V
    .locals 1

    iget-object v0, p0, LA1/Z;->c:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lt1/b;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, LA1/Y;->A(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method

.method public g(Lt1/b;)V
    .locals 1

    iget-object v0, p0, LA1/Z;->c:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lt1/b;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, LA1/Y;->t(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method

.method public h(Lt1/b;)V
    .locals 1

    iget-object v0, p0, LA1/Z;->c:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lt1/b;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, LA1/Y;->D(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method
