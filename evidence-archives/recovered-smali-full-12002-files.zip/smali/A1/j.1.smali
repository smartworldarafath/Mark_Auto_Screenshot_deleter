.class public final LA1/j;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Z

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;

.field public e:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lr7/a;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p2, p0, LA1/j;->a:Z

    iput-object p1, p0, LA1/j;->b:Ljava/lang/Object;

    const/4 p1, 0x0

    invoke-static {p1}, Ls/d;->a(F)Ls/c;

    move-result-object p1

    iput-object p1, p0, LA1/j;->c:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LA1/j;->d:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a(ZZLjava/io/IOException;)Ljava/io/IOException;
    .locals 1

    iget-object v0, p0, LA1/j;->b:Ljava/lang/Object;

    check-cast v0, LZ7/h;

    if-eqz p3, :cond_0

    invoke-virtual {p0, p3}, LA1/j;->j(Ljava/io/IOException;)V

    :cond_0
    invoke-virtual {v0, p0, p2, p1, p3}, LZ7/h;->g(LA1/j;ZZLjava/io/IOException;)Ljava/io/IOException;

    move-result-object p1

    return-object p1
.end method

.method public b(FF)Z
    .locals 3

    iget-boolean v0, p0, LA1/j;->a:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {p0, v1}, LA1/j;->f(I)Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v2, p0, LA1/j;->d:Ljava/lang/Object;

    check-cast v2, Landroidx/core/widget/NestedScrollView;

    :try_start_0
    invoke-interface {v0, v2, p1, p2}, Landroid/view/ViewParent;->onNestedPreFling(Landroid/view/View;FF)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/AbstractMethodError; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v2, "ViewParent "

    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " does not implement interface method onNestedPreFling"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const-string v0, "ViewParentCompat"

    invoke-static {v0, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    return v1
.end method

.method public c(III[I[I)Z
    .locals 7

    iget-object v0, p0, LA1/j;->d:Ljava/lang/Object;

    check-cast v0, Landroidx/core/widget/NestedScrollView;

    iget-boolean v1, p0, LA1/j;->a:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_a

    invoke-virtual {p0, p3}, LA1/j;->f(I)Landroid/view/ViewParent;

    move-result-object v1

    if-nez v1, :cond_0

    goto/16 :goto_3

    :cond_0
    const/4 v3, 0x1

    if-nez p1, :cond_2

    if-eqz p2, :cond_1

    goto :goto_0

    :cond_1
    if-eqz p5, :cond_a

    aput v2, p5, v2

    aput v2, p5, v3

    return v2

    :cond_2
    :goto_0
    if-eqz p5, :cond_3

    invoke-virtual {v0, p5}, Landroid/view/View;->getLocationInWindow([I)V

    aget v4, p5, v2

    aget v5, p5, v3

    goto :goto_1

    :cond_3
    move v4, v2

    move v5, v4

    :goto_1
    if-nez p4, :cond_5

    iget-object p4, p0, LA1/j;->e:Ljava/lang/Object;

    check-cast p4, [I

    if-nez p4, :cond_4

    const/4 p4, 0x2

    new-array p4, p4, [I

    iput-object p4, p0, LA1/j;->e:Ljava/lang/Object;

    :cond_4
    iget-object p4, p0, LA1/j;->e:Ljava/lang/Object;

    check-cast p4, [I

    :cond_5
    aput v2, p4, v2

    aput v2, p4, v3

    instance-of v6, v1, LA1/k;

    if-eqz v6, :cond_6

    check-cast v1, LA1/k;

    invoke-interface {v1, p1, p2, p4, p3}, LA1/k;->i(II[II)V

    goto :goto_2

    :cond_6
    if-nez p3, :cond_7

    :try_start_0
    invoke-interface {v1, v0, p1, p2, p4}, Landroid/view/ViewParent;->onNestedPreScroll(Landroid/view/View;II[I)V
    :try_end_0
    .catch Ljava/lang/AbstractMethodError; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception p1

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "ViewParent "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p3, " does not implement interface method onNestedPreScroll"

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const-string p3, "ViewParentCompat"

    invoke-static {p3, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_7
    :goto_2
    if-eqz p5, :cond_8

    invoke-virtual {v0, p5}, Landroid/view/View;->getLocationInWindow([I)V

    aget p1, p5, v2

    sub-int/2addr p1, v4

    aput p1, p5, v2

    aget p1, p5, v3

    sub-int/2addr p1, v5

    aput p1, p5, v3

    :cond_8
    aget p1, p4, v2

    if-nez p1, :cond_9

    aget p1, p4, v3

    if-eqz p1, :cond_a

    :cond_9
    move v2, v3

    :cond_a
    :goto_3
    return v2
.end method

.method public d(IIII[II[I)Z
    .locals 14

    move-object/from16 v1, p5

    move/from16 v8, p6

    iget-object v0, p0, LA1/j;->d:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Landroidx/core/widget/NestedScrollView;

    iget-boolean v0, p0, LA1/j;->a:Z

    const/4 v10, 0x0

    if-eqz v0, :cond_a

    invoke-virtual {p0, v8}, LA1/j;->f(I)Landroid/view/ViewParent;

    move-result-object v2

    if-nez v2, :cond_0

    goto/16 :goto_4

    :cond_0
    const/4 v11, 0x1

    if-nez p1, :cond_2

    if-nez p2, :cond_2

    if-nez p3, :cond_2

    if-eqz p4, :cond_1

    goto :goto_0

    :cond_1
    if-eqz v1, :cond_a

    aput v10, v1, v10

    aput v10, v1, v11

    return v10

    :cond_2
    :goto_0
    if-eqz v1, :cond_3

    invoke-virtual {v3, v1}, Landroid/view/View;->getLocationInWindow([I)V

    aget v0, v1, v10

    aget v4, v1, v11

    move v12, v0

    move v13, v4

    goto :goto_1

    :cond_3
    move v12, v10

    move v13, v12

    :goto_1
    if-nez p7, :cond_5

    iget-object v0, p0, LA1/j;->e:Ljava/lang/Object;

    check-cast v0, [I

    if-nez v0, :cond_4

    const/4 v0, 0x2

    new-array v0, v0, [I

    iput-object v0, p0, LA1/j;->e:Ljava/lang/Object;

    :cond_4
    iget-object v0, p0, LA1/j;->e:Ljava/lang/Object;

    check-cast v0, [I

    aput v10, v0, v10

    aput v10, v0, v11

    move-object v9, v0

    goto :goto_2

    :cond_5
    move-object/from16 v9, p7

    :goto_2
    instance-of v0, v2, LA1/l;

    if-eqz v0, :cond_6

    check-cast v2, LA1/l;

    move v4, p1

    move/from16 v5, p2

    move/from16 v6, p3

    move/from16 v7, p4

    invoke-interface/range {v2 .. v9}, LA1/l;->h(Landroidx/core/widget/NestedScrollView;IIIII[I)V

    goto :goto_3

    :cond_6
    aget v0, v9, v10

    add-int v0, v0, p3

    aput v0, v9, v10

    aget v0, v9, v11

    add-int v0, v0, p4

    aput v0, v9, v11

    instance-of v0, v2, LA1/k;

    if-eqz v0, :cond_7

    check-cast v2, LA1/k;

    move v4, p1

    move/from16 v5, p2

    move/from16 v6, p3

    move/from16 v7, p4

    move/from16 v8, p6

    invoke-interface/range {v2 .. v8}, LA1/k;->b(Landroidx/core/widget/NestedScrollView;IIIII)V

    goto :goto_3

    :cond_7
    if-nez p6, :cond_8

    move v4, p1

    move/from16 v5, p2

    move/from16 v6, p3

    move/from16 v7, p4

    :try_start_0
    invoke-interface/range {v2 .. v7}, Landroid/view/ViewParent;->onNestedScroll(Landroid/view/View;IIII)V
    :try_end_0
    .catch Ljava/lang/AbstractMethodError; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :catch_0
    move-exception v0

    move-object p1, v0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v4, "ViewParent "

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " does not implement interface method onNestedScroll"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "ViewParentCompat"

    invoke-static {v2, v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_8
    :goto_3
    if-eqz v1, :cond_9

    invoke-virtual {v3, v1}, Landroid/view/View;->getLocationInWindow([I)V

    aget p1, v1, v10

    sub-int/2addr p1, v12

    aput p1, v1, v10

    aget p1, v1, v11

    sub-int/2addr p1, v13

    aput p1, v1, v11

    :cond_9
    return v11

    :cond_a
    :goto_4
    return v10
.end method

.method public e(LL0/L;FJ)V
    .locals 16

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    iget-object v0, v2, LL0/L;->t:Lv0/b;

    iget-object v3, v1, LA1/j;->c:Ljava/lang/Object;

    check-cast v3, Ls/c;

    invoke-virtual {v3}, Ls/c;->d()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    move-result v3

    const/4 v4, 0x0

    cmpl-float v4, v3, v4

    if-lez v4, :cond_1

    const/16 v4, 0xe

    move-wide/from16 v5, p3

    invoke-static {v5, v6, v3, v4}, Lt0/p;->b(JFI)J

    move-result-wide v3

    iget-boolean v5, v1, LA1/j;->a:Z

    if-eqz v5, :cond_0

    invoke-interface {v0}, Lv0/d;->d()J

    move-result-wide v5

    invoke-static {v5, v6}, Ls0/e;->d(J)F

    move-result v10

    invoke-interface {v0}, Lv0/d;->d()J

    move-result-wide v5

    invoke-static {v5, v6}, Ls0/e;->b(J)F

    move-result v11

    iget-object v13, v0, Lv0/b;->u:Lcom/google/android/gms/internal/play_billing/l;

    invoke-virtual {v13}, Lcom/google/android/gms/internal/play_billing/l;->l()J

    move-result-wide v14

    invoke-virtual {v13}, Lcom/google/android/gms/internal/play_billing/l;->f()Lt0/n;

    move-result-object v0

    invoke-interface {v0}, Lt0/n;->d()V

    :try_start_0
    iget-object v0, v13, Lcom/google/android/gms/internal/play_billing/l;->u:Ljava/lang/Object;

    check-cast v0, LW2/g;

    iget-object v0, v0, LW2/g;->u:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/play_billing/l;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/play_billing/l;->f()Lt0/n;

    move-result-object v7

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v12, 0x1

    invoke-interface/range {v7 .. v12}, Lt0/n;->n(FFFFI)V

    const/4 v8, 0x0

    const/16 v9, 0x7c

    const-wide/16 v6, 0x0

    move/from16 v5, p2

    invoke-static/range {v2 .. v9}, Lv0/d;->i0(Lv0/d;JFJLv0/c;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v13}, Lcom/google/android/gms/internal/play_billing/l;->f()Lt0/n;

    move-result-object v0

    invoke-interface {v0}, Lt0/n;->r()V

    invoke-virtual {v13, v14, v15}, Lcom/google/android/gms/internal/play_billing/l;->v(J)V

    return-void

    :catchall_0
    move-exception v0

    invoke-virtual {v13}, Lcom/google/android/gms/internal/play_billing/l;->f()Lt0/n;

    move-result-object v2

    invoke-interface {v2}, Lt0/n;->r()V

    invoke-virtual {v13, v14, v15}, Lcom/google/android/gms/internal/play_billing/l;->v(J)V

    throw v0

    :cond_0
    const/4 v8, 0x0

    const/16 v9, 0x7c

    const-wide/16 v6, 0x0

    move-object/from16 v2, p1

    move/from16 v5, p2

    invoke-static/range {v2 .. v9}, Lv0/d;->i0(Lv0/d;JFJLv0/c;I)V

    :cond_1
    return-void
.end method

.method public f(I)Landroid/view/ViewParent;
    .locals 1

    if-eqz p1, :cond_1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object p1, p0, LA1/j;->c:Ljava/lang/Object;

    check-cast p1, Landroid/view/ViewParent;

    return-object p1

    :cond_1
    iget-object p1, p0, LA1/j;->b:Ljava/lang/Object;

    check-cast p1, Landroid/view/ViewParent;

    return-object p1
.end method

.method public g(Ly/i;LD7/v;)V
    .locals 7

    iget-object v0, p0, LA1/j;->d:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    instance-of v1, p1, Ly/g;

    if-eqz v1, :cond_0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    instance-of v1, p1, Ly/h;

    if-eqz v1, :cond_1

    check-cast p1, Ly/h;

    iget-object p1, p1, Ly/h;->a:Ly/g;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    instance-of v1, p1, Ly/d;

    if-eqz v1, :cond_2

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    instance-of v1, p1, Ly/e;

    if-eqz v1, :cond_3

    check-cast p1, Ly/e;

    iget-object p1, p1, Ly/e;->a:Ly/d;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    instance-of v1, p1, Ly/b;

    if-eqz v1, :cond_4

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_4
    instance-of v1, p1, Ly/c;

    if-eqz v1, :cond_5

    check-cast p1, Ly/c;

    iget-object p1, p1, Ly/c;->a:Ly/b;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_5
    instance-of v1, p1, Ly/a;

    if-eqz v1, :cond_10

    check-cast p1, Ly/a;

    iget-object p1, p1, Ly/a;->a:Ly/b;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :goto_0
    invoke-static {v0}, Le7/l;->C(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ly/i;

    iget-object v0, p0, LA1/j;->e:Ljava/lang/Object;

    check-cast v0, Ly/i;

    invoke-static {v0, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_10

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz p1, :cond_c

    iget-object v3, p0, LA1/j;->b:Ljava/lang/Object;

    check-cast v3, Lr7/a;

    invoke-interface {v3}, Lr7/a;->a()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LW/f;

    instance-of v4, p1, Ly/g;

    if-eqz v4, :cond_6

    iget v3, v3, LW/f;->c:F

    goto :goto_1

    :cond_6
    instance-of v5, p1, Ly/d;

    if-eqz v5, :cond_7

    iget v3, v3, LW/f;->b:F

    goto :goto_1

    :cond_7
    instance-of v5, p1, Ly/b;

    if-eqz v5, :cond_8

    iget v3, v3, LW/f;->a:F

    goto :goto_1

    :cond_8
    const/4 v3, 0x0

    :goto_1
    sget-object v5, LW/k;->a:Ls/C0;

    if-eqz v4, :cond_9

    goto :goto_2

    :cond_9
    instance-of v4, p1, Ly/d;

    const/16 v6, 0x2d

    if-eqz v4, :cond_a

    new-instance v5, Ls/C0;

    sget-object v4, Ls/y;->c:Le5/h;

    invoke-direct {v5, v6, v4, v1}, Ls/C0;-><init>(ILs/x;I)V

    goto :goto_2

    :cond_a
    instance-of v4, p1, Ly/b;

    if-eqz v4, :cond_b

    new-instance v5, Ls/C0;

    sget-object v4, Ls/y;->c:Le5/h;

    invoke-direct {v5, v6, v4, v1}, Ls/C0;-><init>(ILs/x;I)V

    :cond_b
    :goto_2
    new-instance v1, LW/o;

    invoke-direct {v1, p0, v3, v5, v2}, LW/o;-><init>(LA1/j;FLs/l;Lh7/c;)V

    invoke-static {p2, v2, v2, v1, v0}, LD7/y;->x(LD7/v;Lh7/h;LD7/w;Lr7/e;I)LD7/B;

    goto :goto_4

    :cond_c
    iget-object v3, p0, LA1/j;->e:Ljava/lang/Object;

    check-cast v3, Ly/i;

    sget-object v4, LW/k;->a:Ls/C0;

    instance-of v5, v3, Ly/g;

    if-eqz v5, :cond_d

    goto :goto_3

    :cond_d
    instance-of v5, v3, Ly/d;

    if-eqz v5, :cond_e

    goto :goto_3

    :cond_e
    instance-of v3, v3, Ly/b;

    if-eqz v3, :cond_f

    new-instance v4, Ls/C0;

    const/16 v3, 0x96

    sget-object v5, Ls/y;->c:Le5/h;

    invoke-direct {v4, v3, v5, v1}, Ls/C0;-><init>(ILs/x;I)V

    :cond_f
    :goto_3
    new-instance v1, LW/p;

    invoke-direct {v1, p0, v4, v2}, LW/p;-><init>(LA1/j;Ls/l;Lh7/c;)V

    invoke-static {p2, v2, v2, v1, v0}, LD7/y;->x(LD7/v;Lh7/h;LD7/w;Lr7/e;I)LD7/B;

    :goto_4
    iput-object p1, p0, LA1/j;->e:Ljava/lang/Object;

    :cond_10
    return-void
.end method

.method public h(LP2/e;LM0/x;Z)I
    .locals 18

    move-object/from16 v1, p0

    iget-object v0, v1, LA1/j;->c:Ljava/lang/Object;

    check-cast v0, LF0/e;

    iget-object v2, v1, LA1/j;->e:Ljava/lang/Object;

    check-cast v2, LL0/s;

    iget-boolean v3, v1, LA1/j;->a:Z

    const/4 v4, 0x0

    if-eqz v3, :cond_0

    return v4

    :cond_0
    const/4 v3, 0x1

    :try_start_0
    iput-boolean v3, v1, LA1/j;->a:Z

    iget-object v5, v1, LA1/j;->d:Ljava/lang/Object;

    check-cast v5, LA1/t;

    move-object/from16 v6, p1

    move-object/from16 v7, p2

    invoke-virtual {v5, v6, v7}, LA1/t;->s(LP2/e;LM0/x;)Lcom/google/android/gms/internal/measurement/I1;

    move-result-object v5

    iget-object v6, v5, Lcom/google/android/gms/internal/measurement/I1;->v:Ljava/lang/Object;

    check-cast v6, Lp/r;

    invoke-virtual {v6}, Lp/r;->g()I

    move-result v7

    move v8, v4

    :goto_0
    if-ge v8, v7, :cond_3

    invoke-virtual {v6, v8}, Lp/r;->h(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LF0/u;

    iget-boolean v10, v9, LF0/u;->d:Z

    if-nez v10, :cond_2

    iget-boolean v9, v9, LF0/u;->h:Z

    if-eqz v9, :cond_1

    goto :goto_1

    :cond_1
    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    goto/16 :goto_8

    :cond_2
    :goto_1
    move v7, v4

    goto :goto_2

    :cond_3
    move v7, v3

    :goto_2
    invoke-virtual {v6}, Lp/r;->g()I

    move-result v8

    move v9, v4

    :goto_3
    if-ge v9, v8, :cond_6

    invoke-virtual {v6, v9}, Lp/r;->h(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, LF0/u;

    if-nez v7, :cond_4

    invoke-static {v10}, LF0/t;->a(LF0/u;)Z

    move-result v11

    if-eqz v11, :cond_5

    :cond_4
    iget-object v11, v1, LA1/j;->b:Ljava/lang/Object;

    move-object v12, v11

    check-cast v12, LL0/J;

    iget-wide v13, v10, LF0/u;->c:J

    iget-object v11, v1, LA1/j;->e:Ljava/lang/Object;

    move-object v15, v11

    check-cast v15, LL0/s;

    iget v11, v10, LF0/u;->i:I

    const/16 v17, 0x1

    move/from16 v16, v11

    invoke-virtual/range {v12 .. v17}, LL0/J;->A(JLL0/s;IZ)V

    iget-object v11, v2, LL0/s;->t:Lp/D;

    invoke-virtual {v11}, Lp/D;->g()Z

    move-result v11

    if-nez v11, :cond_5

    iget-wide v11, v10, LF0/u;->a:J

    invoke-static {v10}, LF0/t;->a(LF0/u;)Z

    move-result v10

    invoke-virtual {v0, v11, v12, v2, v10}, LF0/e;->a(JLjava/util/List;Z)V

    invoke-virtual {v2}, LL0/s;->clear()V

    :cond_5
    add-int/lit8 v9, v9, 0x1

    goto :goto_3

    :cond_6
    move/from16 v2, p3

    invoke-virtual {v0, v5, v2}, LF0/e;->b(Lcom/google/android/gms/internal/measurement/I1;Z)Z

    move-result v0

    iget-boolean v2, v5, Lcom/google/android/gms/internal/measurement/I1;->u:Z

    if-eqz v2, :cond_8

    :cond_7
    move v2, v4

    goto :goto_5

    :cond_8
    invoke-virtual {v6}, Lp/r;->g()I

    move-result v2

    move v5, v4

    :goto_4
    if-ge v5, v2, :cond_7

    invoke-virtual {v6, v5}, Lp/r;->h(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LF0/u;

    invoke-static {v7, v3}, LF0/t;->g(LF0/u;Z)J

    move-result-wide v8

    const-wide/16 v10, 0x0

    invoke-static {v8, v9, v10, v11}, Ls0/b;->b(JJ)Z

    move-result v8

    if-nez v8, :cond_9

    invoke-virtual {v7}, LF0/u;->b()Z

    move-result v7

    if-eqz v7, :cond_9

    move v2, v3

    goto :goto_5

    :cond_9
    add-int/lit8 v5, v5, 0x1

    goto :goto_4

    :goto_5
    invoke-virtual {v6}, Lp/r;->g()I

    move-result v5

    move v7, v4

    :goto_6
    if-ge v7, v5, :cond_b

    invoke-virtual {v6, v7}, Lp/r;->h(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, LF0/u;

    invoke-virtual {v8}, LF0/u;->b()Z

    move-result v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v8, :cond_a

    move v5, v3

    goto :goto_7

    :cond_a
    add-int/lit8 v7, v7, 0x1

    goto :goto_6

    :cond_b
    move v5, v4

    :goto_7
    shl-int/2addr v2, v3

    or-int/2addr v0, v2

    shl-int/lit8 v2, v5, 0x2

    or-int/2addr v0, v2

    iput-boolean v4, v1, LA1/j;->a:Z

    return v0

    :goto_8
    iput-boolean v4, v1, LA1/j;->a:Z

    throw v0
.end method

.method public i(Z)LV7/t;
    .locals 1

    :try_start_0
    iget-object v0, p0, LA1/j;->d:Ljava/lang/Object;

    check-cast v0, La8/d;

    invoke-interface {v0, p1}, La8/d;->b(Z)LV7/t;

    move-result-object p1

    if-eqz p1, :cond_0

    iput-object p0, p1, LV7/t;->m:LA1/j;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    goto :goto_0

    :cond_0
    return-object p1

    :goto_0
    invoke-virtual {p0, p1}, LA1/j;->j(Ljava/io/IOException;)V

    throw p1
.end method

.method public j(Ljava/io/IOException;)V
    .locals 5

    const/4 v0, 0x1

    iput-boolean v0, p0, LA1/j;->a:Z

    iget-object v1, p0, LA1/j;->c:Ljava/lang/Object;

    check-cast v1, LZ7/d;

    invoke-virtual {v1, p1}, LZ7/d;->c(Ljava/io/IOException;)V

    iget-object v1, p0, LA1/j;->d:Ljava/lang/Object;

    check-cast v1, La8/d;

    invoke-interface {v1}, La8/d;->c()LZ7/j;

    move-result-object v1

    iget-object v2, p0, LA1/j;->b:Ljava/lang/Object;

    check-cast v2, LZ7/h;

    monitor-enter v1

    :try_start_0
    instance-of v3, p1, Lc8/A;

    if-eqz v3, :cond_2

    move-object v3, p1

    check-cast v3, Lc8/A;

    iget v3, v3, Lc8/A;->t:I

    const/16 v4, 0x8

    if-ne v3, v4, :cond_0

    iget p1, v1, LZ7/j;->n:I

    add-int/2addr p1, v0

    iput p1, v1, LZ7/j;->n:I

    if-le p1, v0, :cond_5

    iput-boolean v0, v1, LZ7/j;->j:Z

    iget p1, v1, LZ7/j;->l:I

    add-int/2addr p1, v0

    iput p1, v1, LZ7/j;->l:I

    goto :goto_1

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_0
    check-cast p1, Lc8/A;

    iget p1, p1, Lc8/A;->t:I

    const/16 v3, 0x9

    if-ne p1, v3, :cond_1

    iget-boolean p1, v2, LZ7/h;->F:Z

    if-nez p1, :cond_5

    :cond_1
    iput-boolean v0, v1, LZ7/j;->j:Z

    iget p1, v1, LZ7/j;->l:I

    add-int/2addr p1, v0

    iput p1, v1, LZ7/j;->l:I

    goto :goto_1

    :cond_2
    iget-object v3, v1, LZ7/j;->g:Lc8/n;

    if-eqz v3, :cond_3

    move v3, v0

    goto :goto_0

    :cond_3
    const/4 v3, 0x0

    :goto_0
    if-eqz v3, :cond_4

    instance-of v3, p1, Lc8/a;

    if-eqz v3, :cond_5

    :cond_4
    iput-boolean v0, v1, LZ7/j;->j:Z

    iget v3, v1, LZ7/j;->m:I

    if-nez v3, :cond_5

    iget-object v2, v2, LZ7/h;->t:LV7/r;

    iget-object v3, v1, LZ7/j;->b:LV7/w;

    invoke-static {v2, v3, p1}, LZ7/j;->d(LV7/r;LV7/w;Ljava/io/IOException;)V

    iget p1, v1, LZ7/j;->l:I

    add-int/2addr p1, v0

    iput p1, v1, LZ7/j;->l:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_5
    :goto_1
    monitor-exit v1

    return-void

    :goto_2
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method
