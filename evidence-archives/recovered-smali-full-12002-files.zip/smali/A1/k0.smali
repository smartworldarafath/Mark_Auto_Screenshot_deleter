.class public final LA1/k0;
.super LA1/j0;
.source "SourceFile"


# static fields
.field public static final s:LA1/q0;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    invoke-static {}, LA1/u;->g()Landroid/view/WindowInsets;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, LA1/q0;->c(Landroid/view/View;Landroid/view/WindowInsets;)LA1/q0;

    move-result-object v0

    sput-object v0, LA1/k0;->s:LA1/q0;

    return-void
.end method

.method public constructor <init>(LA1/q0;LA1/k0;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1, p2}, LA1/j0;-><init>(LA1/q0;LA1/j0;)V

    return-void
.end method

.method public constructor <init>(LA1/q0;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LA1/j0;-><init>(LA1/q0;Landroid/view/WindowInsets;)V

    return-void
.end method


# virtual methods
.method public g(I)Lt1/b;
    .locals 1

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-static {p1}, LA1/p0;->a(I)I

    move-result p1

    invoke-static {v0, p1}, LA1/u;->e(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {p1}, Lt1/b;->c(Landroid/graphics/Insets;)Lt1/b;

    move-result-object p1

    return-object p1
.end method

.method public h(I)Lt1/b;
    .locals 1

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-static {p1}, LA1/p0;->a(I)I

    move-result p1

    invoke-static {v0, p1}, LA1/u;->u(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {p1}, Lt1/b;->c(Landroid/graphics/Insets;)Lt1/b;

    move-result-object p1

    return-object p1
.end method

.method public q(I)Z
    .locals 1

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-static {p1}, LA1/p0;->a(I)I

    move-result p1

    invoke-static {v0, p1}, LA1/u;->r(Landroid/view/WindowInsets;I)Z

    move-result p1

    return p1
.end method
