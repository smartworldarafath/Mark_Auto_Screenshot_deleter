.class public LA1/b0;
.super LA1/a0;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, LA1/a0;-><init>()V

    return-void
.end method

.method public constructor <init>(LA1/q0;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1}, LA1/a0;-><init>(LA1/q0;)V

    return-void
.end method
