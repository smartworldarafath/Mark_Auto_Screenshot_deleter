.class public interface abstract LA1/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA1/k;


# virtual methods
.method public abstract h(Landroidx/core/widget/NestedScrollView;IIIII[I)V
.end method
