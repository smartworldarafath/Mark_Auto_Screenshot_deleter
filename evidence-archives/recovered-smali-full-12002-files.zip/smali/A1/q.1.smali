.class public interface abstract LA1/q;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract onScrollLimit(IIIZ)V
.end method

.method public abstract onScrollProgress(IIII)V
.end method
