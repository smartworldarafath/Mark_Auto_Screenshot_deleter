.class public LA1/f0;
.super LA1/e0;
.source "SourceFile"


# instance fields
.field public n:Lt1/b;


# direct methods
.method public constructor <init>(LA1/q0;LA1/f0;)V
    .locals 0

    .line 3
    invoke-direct {p0, p1, p2}, LA1/e0;-><init>(LA1/q0;LA1/e0;)V

    const/4 p1, 0x0

    .line 4
    iput-object p1, p0, LA1/f0;->n:Lt1/b;

    .line 5
    iget-object p1, p2, LA1/f0;->n:Lt1/b;

    iput-object p1, p0, LA1/f0;->n:Lt1/b;

    return-void
.end method

.method public constructor <init>(LA1/q0;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LA1/e0;-><init>(LA1/q0;Landroid/view/WindowInsets;)V

    const/4 p1, 0x0

    .line 2
    iput-object p1, p0, LA1/f0;->n:Lt1/b;

    return-void
.end method


# virtual methods
.method public b()LA1/q0;
    .locals 2

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-virtual {v0}, Landroid/view/WindowInsets;->consumeStableInsets()Landroid/view/WindowInsets;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, LA1/q0;->c(Landroid/view/View;Landroid/view/WindowInsets;)LA1/q0;

    move-result-object v0

    return-object v0
.end method

.method public c()LA1/q0;
    .locals 2

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-virtual {v0}, Landroid/view/WindowInsets;->consumeSystemWindowInsets()Landroid/view/WindowInsets;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, LA1/q0;->c(Landroid/view/View;Landroid/view/WindowInsets;)LA1/q0;

    move-result-object v0

    return-object v0
.end method

.method public final j()Lt1/b;
    .locals 4

    iget-object v0, p0, LA1/f0;->n:Lt1/b;

    if-nez v0, :cond_0

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetLeft()I

    move-result v1

    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetTop()I

    move-result v2

    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetRight()I

    move-result v3

    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetBottom()I

    move-result v0

    invoke-static {v1, v2, v3, v0}, Lt1/b;->b(IIII)Lt1/b;

    move-result-object v0

    iput-object v0, p0, LA1/f0;->n:Lt1/b;

    :cond_0
    iget-object v0, p0, LA1/f0;->n:Lt1/b;

    return-object v0
.end method

.method public o()Z
    .locals 1

    iget-object v0, p0, LA1/e0;->c:Landroid/view/WindowInsets;

    invoke-virtual {v0}, Landroid/view/WindowInsets;->isConsumed()Z

    move-result v0

    return v0
.end method

.method public u(Lt1/b;)V
    .locals 0

    iput-object p1, p0, LA1/f0;->n:Lt1/b;

    return-void
.end method
