.class public abstract LA1/E;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/view/View;)LA1/q0;
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    invoke-static {v1, v0}, LA1/q0;->c(Landroid/view/View;Landroid/view/WindowInsets;)LA1/q0;

    move-result-object v0

    iget-object v1, v0, LA1/q0;->a:LA1/l0;

    invoke-virtual {v1, v0}, LA1/l0;->t(LA1/q0;)V

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object p0

    invoke-virtual {v1, p0}, LA1/l0;->d(Landroid/view/View;)V

    return-object v0
.end method
