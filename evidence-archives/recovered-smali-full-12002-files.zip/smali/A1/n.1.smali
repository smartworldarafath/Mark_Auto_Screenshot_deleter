.class public interface abstract LA1/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/view/View;LA1/q0;)LA1/q0;
.end method
