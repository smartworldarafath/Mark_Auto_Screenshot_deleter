.class public final LA1/r;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LA1/q;


# direct methods
.method public constructor <init>(Landroidx/core/widget/NestedScrollView;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x23

    if-lt v0, v1, :cond_0

    new-instance v0, LA1/p;

    invoke-direct {v0, p1}, LA1/p;-><init>(Landroidx/core/widget/NestedScrollView;)V

    iput-object v0, p0, LA1/r;->a:LA1/q;

    return-void

    :cond_0
    new-instance p1, LB5/e;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, LB5/e;-><init>(I)V

    iput-object p1, p0, LA1/r;->a:LA1/q;

    return-void
.end method
