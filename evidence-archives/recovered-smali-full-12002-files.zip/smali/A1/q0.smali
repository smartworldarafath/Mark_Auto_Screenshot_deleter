.class public final LA1/q0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:LA1/q0;


# instance fields
.field public final a:LA1/l0;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    sget-object v0, LA1/k0;->s:LA1/q0;

    sput-object v0, LA1/q0;->b:LA1/q0;

    return-void

    :cond_0
    const/16 v1, 0x1e

    if-lt v0, v1, :cond_1

    sget-object v0, LA1/i0;->r:LA1/q0;

    sput-object v0, LA1/q0;->b:LA1/q0;

    return-void

    :cond_1
    sget-object v0, LA1/l0;->b:LA1/q0;

    sput-object v0, LA1/q0;->b:LA1/q0;

    return-void
.end method

.method public constructor <init>(LA1/q0;)V
    .locals 2

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_7

    .line 10
    iget-object p1, p1, LA1/q0;->a:LA1/l0;

    .line 11
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    instance-of v1, p1, LA1/k0;

    if-eqz v1, :cond_0

    .line 12
    new-instance v0, LA1/k0;

    move-object v1, p1

    check-cast v1, LA1/k0;

    invoke-direct {v0, p0, v1}, LA1/k0;-><init>(LA1/q0;LA1/k0;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    goto/16 :goto_0

    :cond_0
    const/16 v1, 0x1f

    if-lt v0, v1, :cond_1

    .line 13
    instance-of v1, p1, LA1/j0;

    if-eqz v1, :cond_1

    .line 14
    new-instance v0, LA1/j0;

    move-object v1, p1

    check-cast v1, LA1/j0;

    invoke-direct {v0, p0, v1}, LA1/j0;-><init>(LA1/q0;LA1/j0;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    goto :goto_0

    :cond_1
    const/16 v1, 0x1e

    if-lt v0, v1, :cond_2

    .line 15
    instance-of v1, p1, LA1/i0;

    if-eqz v1, :cond_2

    .line 16
    new-instance v0, LA1/i0;

    move-object v1, p1

    check-cast v1, LA1/i0;

    invoke-direct {v0, p0, v1}, LA1/i0;-><init>(LA1/q0;LA1/i0;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    goto :goto_0

    :cond_2
    const/16 v1, 0x1d

    if-lt v0, v1, :cond_3

    .line 17
    instance-of v1, p1, LA1/h0;

    if-eqz v1, :cond_3

    .line 18
    new-instance v0, LA1/h0;

    move-object v1, p1

    check-cast v1, LA1/h0;

    invoke-direct {v0, p0, v1}, LA1/h0;-><init>(LA1/q0;LA1/h0;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    goto :goto_0

    :cond_3
    const/16 v1, 0x1c

    if-lt v0, v1, :cond_4

    .line 19
    instance-of v0, p1, LA1/g0;

    if-eqz v0, :cond_4

    .line 20
    new-instance v0, LA1/g0;

    move-object v1, p1

    check-cast v1, LA1/g0;

    invoke-direct {v0, p0, v1}, LA1/g0;-><init>(LA1/q0;LA1/g0;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    goto :goto_0

    .line 21
    :cond_4
    instance-of v0, p1, LA1/f0;

    if-eqz v0, :cond_5

    .line 22
    new-instance v0, LA1/f0;

    move-object v1, p1

    check-cast v1, LA1/f0;

    invoke-direct {v0, p0, v1}, LA1/f0;-><init>(LA1/q0;LA1/f0;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    goto :goto_0

    .line 23
    :cond_5
    instance-of v0, p1, LA1/e0;

    if-eqz v0, :cond_6

    .line 24
    new-instance v0, LA1/e0;

    move-object v1, p1

    check-cast v1, LA1/e0;

    invoke-direct {v0, p0, v1}, LA1/e0;-><init>(LA1/q0;LA1/e0;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    goto :goto_0

    .line 25
    :cond_6
    new-instance v0, LA1/l0;

    invoke-direct {v0, p0}, LA1/l0;-><init>(LA1/q0;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    .line 26
    :goto_0
    invoke-virtual {p1, p0}, LA1/l0;->e(LA1/q0;)V

    return-void

    .line 27
    :cond_7
    new-instance p1, LA1/l0;

    invoke-direct {p1, p0}, LA1/l0;-><init>(LA1/q0;)V

    iput-object p1, p0, LA1/q0;->a:LA1/l0;

    return-void
.end method

.method public constructor <init>(Landroid/view/WindowInsets;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    .line 3
    new-instance v0, LA1/k0;

    invoke-direct {v0, p0, p1}, LA1/k0;-><init>(LA1/q0;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    return-void

    :cond_0
    const/16 v1, 0x1f

    if-lt v0, v1, :cond_1

    .line 4
    new-instance v0, LA1/j0;

    invoke-direct {v0, p0, p1}, LA1/j0;-><init>(LA1/q0;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    return-void

    :cond_1
    const/16 v1, 0x1e

    if-lt v0, v1, :cond_2

    .line 5
    new-instance v0, LA1/i0;

    invoke-direct {v0, p0, p1}, LA1/i0;-><init>(LA1/q0;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    return-void

    :cond_2
    const/16 v1, 0x1d

    if-lt v0, v1, :cond_3

    .line 6
    new-instance v0, LA1/h0;

    invoke-direct {v0, p0, p1}, LA1/h0;-><init>(LA1/q0;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    return-void

    :cond_3
    const/16 v1, 0x1c

    if-lt v0, v1, :cond_4

    .line 7
    new-instance v0, LA1/g0;

    invoke-direct {v0, p0, p1}, LA1/g0;-><init>(LA1/q0;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    return-void

    .line 8
    :cond_4
    new-instance v0, LA1/f0;

    invoke-direct {v0, p0, p1}, LA1/f0;-><init>(LA1/q0;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LA1/q0;->a:LA1/l0;

    return-void
.end method

.method public static a(Lt1/b;IIII)Lt1/b;
    .locals 5

    iget v0, p0, Lt1/b;->a:I

    sub-int/2addr v0, p1

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iget v2, p0, Lt1/b;->b:I

    sub-int/2addr v2, p2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    iget v3, p0, Lt1/b;->c:I

    sub-int/2addr v3, p3

    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    iget v4, p0, Lt1/b;->d:I

    sub-int/2addr v4, p4

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v1

    if-ne v0, p1, :cond_0

    if-ne v2, p2, :cond_0

    if-ne v3, p3, :cond_0

    if-ne v1, p4, :cond_0

    return-object p0

    :cond_0
    invoke-static {v0, v2, v3, v1}, Lt1/b;->b(IIII)Lt1/b;

    move-result-object p0

    return-object p0
.end method

.method public static c(Landroid/view/View;Landroid/view/WindowInsets;)LA1/q0;
    .locals 2

    new-instance v0, LA1/q0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v0, p1}, LA1/q0;-><init>(Landroid/view/WindowInsets;)V

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result p1

    if-eqz p1, :cond_0

    sget-object p1, LA1/J;->a:Ljava/lang/reflect/Field;

    invoke-static {p0}, LA1/E;->a(Landroid/view/View;)LA1/q0;

    move-result-object p1

    iget-object v1, v0, LA1/q0;->a:LA1/l0;

    invoke-virtual {v1, p1}, LA1/l0;->t(LA1/q0;)V

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object p1

    invoke-virtual {v1, p1}, LA1/l0;->d(Landroid/view/View;)V

    invoke-virtual {p0}, Landroid/view/View;->getWindowSystemUiVisibility()I

    move-result p0

    invoke-virtual {v1, p0}, LA1/l0;->v(I)V

    :cond_0
    return-object v0
.end method


# virtual methods
.method public final b()Landroid/view/WindowInsets;
    .locals 2

    iget-object v0, p0, LA1/q0;->a:LA1/l0;

    instance-of v1, v0, LA1/e0;

    if-eqz v1, :cond_0

    check-cast v0, LA1/e0;

    iget-object v0, v0, LA1/e0;->c:Landroid/view/WindowInsets;

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    if-ne p0, p1, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    instance-of v0, p1, LA1/q0;

    if-nez v0, :cond_1

    const/4 p1, 0x0

    return p1

    :cond_1
    check-cast p1, LA1/q0;

    iget-object v0, p0, LA1/q0;->a:LA1/l0;

    iget-object p1, p1, LA1/q0;->a:LA1/l0;

    invoke-static {v0, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, LA1/q0;->a:LA1/l0;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    invoke-virtual {v0}, LA1/l0;->hashCode()I

    move-result v0

    return v0
.end method
