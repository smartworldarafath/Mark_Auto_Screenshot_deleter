.class public final LA1/O;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:LA1/W;

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public constructor <init>(LA1/W;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, LA1/O;->a:LA1/W;

    iput-object p2, p0, LA1/O;->b:Landroid/view/View;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    const/high16 p1, 0x3f800000    # 1.0f

    iget-object v0, p0, LA1/O;->a:LA1/W;

    iget-object v1, v0, LA1/W;->a:LA1/V;

    invoke-virtual {v1, p1}, LA1/V;->e(F)V

    iget-object p1, p0, LA1/O;->b:Landroid/view/View;

    invoke-static {v0, p1}, LA1/S;->f(LA1/W;Landroid/view/View;)V

    return-void
.end method
