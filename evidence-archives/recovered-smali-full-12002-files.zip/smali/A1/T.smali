.class public final LA1/T;
.super Landroid/view/WindowInsetsAnimation$Callback;
.source "SourceFile"


# instance fields
.field public final a:LA1/M;

.field public b:Ljava/util/List;

.field public c:Ljava/util/ArrayList;

.field public final d:Ljava/util/HashMap;


# direct methods
.method public constructor <init>(LA1/M;)V
    .locals 1

    iget v0, p1, LA1/M;->t:I

    invoke-direct {p0, v0}, Landroid/view/WindowInsetsAnimation$Callback;-><init>(I)V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, LA1/T;->d:Ljava/util/HashMap;

    iput-object p1, p0, LA1/T;->a:LA1/M;

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/WindowInsetsAnimation;)LA1/W;
    .locals 5

    iget-object v0, p0, LA1/T;->d:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LA1/W;

    if-nez v0, :cond_1

    new-instance v0, LA1/W;

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    invoke-direct {v0, v4, v1, v2, v3}, LA1/W;-><init>(ILandroid/view/animation/Interpolator;J)V

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1e

    if-lt v1, v2, :cond_0

    new-instance v1, LA1/U;

    invoke-direct {v1, p1}, LA1/U;-><init>(Landroid/view/WindowInsetsAnimation;)V

    iput-object v1, v0, LA1/W;->a:LA1/V;

    :cond_0
    iget-object v1, p0, LA1/T;->d:Ljava/util/HashMap;

    invoke-virtual {v1, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    return-object v0
.end method

.method public final onEnd(Landroid/view/WindowInsetsAnimation;)V
    .locals 2

    iget-object v0, p0, LA1/T;->a:LA1/M;

    invoke-virtual {p0, p1}, LA1/T;->a(Landroid/view/WindowInsetsAnimation;)LA1/W;

    move-result-object v1

    invoke-virtual {v0, v1}, LA1/M;->e(LA1/W;)V

    iget-object v0, p0, LA1/T;->d:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final onPrepare(Landroid/view/WindowInsetsAnimation;)V
    .locals 0

    invoke-virtual {p0, p1}, LA1/T;->a(Landroid/view/WindowInsetsAnimation;)LA1/W;

    iget-object p1, p0, LA1/T;->a:LA1/M;

    invoke-virtual {p1}, LA1/M;->f()V

    return-void
.end method

.method public final onProgress(Landroid/view/WindowInsets;Ljava/util/List;)Landroid/view/WindowInsets;
    .locals 4

    iget-object v0, p0, LA1/T;->c:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    iput-object v0, p0, LA1/T;->c:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, LA1/T;->b:Ljava/util/List;

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    :goto_0
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_1
    if-ltz v0, :cond_1

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, LA1/u;->j(Ljava/lang/Object;)Landroid/view/WindowInsetsAnimation;

    move-result-object v1

    invoke-virtual {p0, v1}, LA1/T;->a(Landroid/view/WindowInsetsAnimation;)LA1/W;

    move-result-object v2

    invoke-static {v1}, LA1/u;->y(Landroid/view/WindowInsetsAnimation;)F

    move-result v1

    iget-object v3, v2, LA1/W;->a:LA1/V;

    invoke-virtual {v3, v1}, LA1/V;->e(F)V

    iget-object v1, p0, LA1/T;->c:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, -0x1

    goto :goto_1

    :cond_1
    const/4 p2, 0x0

    invoke-static {p2, p1}, LA1/q0;->c(Landroid/view/View;Landroid/view/WindowInsets;)LA1/q0;

    move-result-object p1

    iget-object p2, p0, LA1/T;->b:Ljava/util/List;

    iget-object v0, p0, LA1/T;->a:LA1/M;

    invoke-virtual {v0, p1, p2}, LA1/M;->g(LA1/q0;Ljava/util/List;)LA1/q0;

    move-result-object p1

    invoke-virtual {p1}, LA1/q0;->b()Landroid/view/WindowInsets;

    move-result-object p1

    return-object p1
.end method

.method public final onStart(Landroid/view/WindowInsetsAnimation;Landroid/view/WindowInsetsAnimation$Bounds;)Landroid/view/WindowInsetsAnimation$Bounds;
    .locals 1

    invoke-virtual {p0, p1}, LA1/T;->a(Landroid/view/WindowInsetsAnimation;)LA1/W;

    move-result-object p1

    new-instance v0, LP2/c;

    invoke-direct {v0, p2}, LP2/c;-><init>(Landroid/view/WindowInsetsAnimation$Bounds;)V

    iget-object p2, p0, LA1/T;->a:LA1/M;

    invoke-virtual {p2, p1, v0}, LA1/M;->h(LA1/W;LP2/c;)LP2/c;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, LA1/u;->l()V

    iget-object p2, p1, LP2/c;->u:Ljava/lang/Object;

    check-cast p2, Lt1/b;

    invoke-virtual {p2}, Lt1/b;->d()Landroid/graphics/Insets;

    move-result-object p2

    iget-object p1, p1, LP2/c;->v:Ljava/lang/Object;

    check-cast p1, Lt1/b;

    invoke-virtual {p1}, Lt1/b;->d()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {p2, p1}, LA1/u;->h(Landroid/graphics/Insets;Landroid/graphics/Insets;)Landroid/view/WindowInsetsAnimation$Bounds;

    move-result-object p1

    return-object p1
.end method
