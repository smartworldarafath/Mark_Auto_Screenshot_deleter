.class public final synthetic LA1/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, LA1/s;->t:I

    iput-object p2, p0, LA1/s;->u:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a()V
    .locals 5

    iget-object v0, p0, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, LE/u0;

    iget-object v1, v0, LE/u0;->w:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    monitor-enter v0

    :try_start_0
    iget-object v1, v0, LE/u0;->v:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/atomic/AtomicMarkableReference;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicMarkableReference;->isMarked()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, v0, LE/u0;->v:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/atomic/AtomicMarkableReference;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicMarkableReference;->getReference()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ll5/e;

    monitor-enter v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    new-instance v2, Ljava/util/HashMap;

    iget-object v3, v1, Ll5/e;->a:Ljava/util/HashMap;

    invoke-direct {v2, v3}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    monitor-exit v1

    iget-object v1, v0, LE/u0;->v:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/atomic/AtomicMarkableReference;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicMarkableReference;->getReference()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ll5/e;

    const/4 v4, 0x0

    invoke-virtual {v1, v3, v4}, Ljava/util/concurrent/atomic/AtomicMarkableReference;->set(Ljava/lang/Object;Z)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :catchall_1
    move-exception v2

    :try_start_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    throw v2

    :cond_0
    :goto_0
    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    if-eqz v2, :cond_1

    iget-object v1, v0, LE/u0;->x:Ljava/lang/Object;

    check-cast v1, Lp5/c;

    iget-object v3, v1, Lp5/c;->u:Ljava/lang/Object;

    check-cast v3, Ll5/h;

    iget-object v1, v1, Lp5/c;->t:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    iget-boolean v0, v0, LE/u0;->u:Z

    invoke-virtual {v3, v1, v2, v0}, Ll5/h;->h(Ljava/lang/String;Ljava/util/Map;Z)V

    :cond_1
    return-void

    :goto_1
    :try_start_5
    monitor-exit v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    throw v1
.end method


# virtual methods
.method public final run()V
    .locals 22

    move-object/from16 v1, p0

    iget v0, v1, LA1/s;->t:I

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    packed-switch v0, :pswitch_data_0

    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/ads/fu;

    iget-object v0, v0, Lcom/google/android/gms/internal/ads/fu;->b:Landroid/content/Context;

    const-string v2, "Mark can\'t access screenshots. Please grant storage permissions."

    invoke-static {v0, v2}, LH4/c0;->b(Landroid/content/Context;Ljava/lang/String;)V

    return-void

    :pswitch_0
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, Lo0/c;

    invoke-virtual {v0}, Lo0/c;->e()Z

    move-result v3

    iget-object v7, v0, Lo0/c;->t:LM0/x;

    if-nez v3, :cond_0

    goto/16 :goto_4

    :cond_0
    const-string v3, "ContentCapture:changeChecker"

    invoke-static {v3}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {v7, v5}, LM0/x;->t(Z)V

    iget-object v3, v0, Lo0/c;->E:Lp/w;

    iget-object v5, v3, Lp/l;->b:[I

    iget-object v3, v3, Lp/l;->a:[J

    array-length v8, v3

    sub-int/2addr v8, v4

    if-ltz v8, :cond_4

    move v4, v6

    :goto_0
    aget-wide v9, v3, v4

    not-long v11, v9

    shl-long/2addr v11, v2

    and-long/2addr v11, v9

    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    and-long/2addr v11, v13

    cmp-long v11, v11, v13

    if-eqz v11, :cond_3

    sub-int v11, v4, v8

    not-int v11, v11

    ushr-int/lit8 v11, v11, 0x1f

    const/16 v12, 0x8

    rsub-int/lit8 v11, v11, 0x8

    move v13, v6

    :goto_1
    if-ge v13, v11, :cond_2

    const-wide/16 v14, 0xff

    and-long/2addr v14, v9

    const-wide/16 v16, 0x80

    cmp-long v14, v14, v16

    if-gez v14, :cond_1

    shl-int/lit8 v14, v4, 0x3

    add-int/2addr v14, v13

    aget v14, v5, v14

    invoke-virtual {v0}, Lo0/c;->d()Lp/l;

    move-result-object v15

    invoke-virtual {v15, v14}, Lp/l;->a(I)Z

    move-result v15

    if-nez v15, :cond_1

    iget-object v15, v0, Lo0/c;->w:Ljava/util/ArrayList;

    move-object/from16 v16, v15

    new-instance v15, Lo0/d;

    move-object/from16 v21, v3

    iget-wide v2, v0, Lo0/c;->D:J

    sget-object v19, Lo0/e;->u:Lo0/e;

    const/16 v20, 0x0

    move-wide/from16 v17, v2

    move-object/from16 v2, v16

    move/from16 v16, v14

    invoke-direct/range {v15 .. v20}, Lo0/d;-><init>(IJLo0/e;LA1/i;)V

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v2, v0, Lo0/c;->A:LF7/e;

    sget-object v3, Ld7/z;->a:Ld7/z;

    invoke-interface {v2, v3}, LF7/w;->j(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :cond_1
    move-object/from16 v21, v3

    :goto_2
    shr-long/2addr v9, v12

    add-int/lit8 v13, v13, 0x1

    move-object/from16 v3, v21

    const/4 v2, 0x7

    goto :goto_1

    :cond_2
    move-object/from16 v21, v3

    if-ne v11, v12, :cond_4

    goto :goto_3

    :cond_3
    move-object/from16 v21, v3

    :goto_3
    if-eq v4, v8, :cond_4

    add-int/lit8 v4, v4, 0x1

    move-object/from16 v3, v21

    const/4 v2, 0x7

    goto :goto_0

    :cond_4
    const-string v2, "ContentCapture:sendAppearEvents"

    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-virtual {v7}, LM0/x;->getSemanticsOwner()LT0/p;

    move-result-object v2

    invoke-virtual {v2}, LT0/p;->a()LT0/n;

    move-result-object v2

    iget-object v3, v0, Lo0/c;->F:LM0/N0;

    invoke-virtual {v0, v2, v3}, Lo0/c;->g(LT0/n;LM0/N0;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    invoke-static {}, Landroid/os/Trace;->endSection()V

    invoke-virtual {v0}, Lo0/c;->d()Lp/l;

    move-result-object v2

    invoke-virtual {v0, v2}, Lo0/c;->b(Lp/l;)V

    invoke-virtual {v0}, Lo0/c;->k()V

    iput-boolean v6, v0, Lo0/c;->G:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    :goto_4
    return-void

    :catchall_0
    move-exception v0

    goto :goto_5

    :catchall_1
    move-exception v0

    :try_start_3
    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :goto_5
    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :pswitch_1
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, Lcom/markOne/ss_app/app/service/DeleteScreenshotWorkManager;

    invoke-virtual {v0}, LG2/w;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v2, "getApplicationContext(...)"

    invoke-static {v0, v2}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Mark can\'t access screenshots. Check if the right folder is selected."

    invoke-static {v0, v2}, LH4/c0;->b(Landroid/content/Context;Ljava/lang/String;)V

    return-void

    :pswitch_2
    invoke-direct {v1}, LA1/s;->a()V

    return-void

    :pswitch_3
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, Li3/r;

    invoke-virtual {v0}, Li3/r;->c()V

    return-void

    :pswitch_4
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, Li3/k;

    iget-object v2, v0, Li3/k;->T:Ljava/util/concurrent/Semaphore;

    iget-object v3, v0, Li3/k;->B:Lr3/c;

    if-nez v3, :cond_5

    goto :goto_6

    :cond_5
    :try_start_4
    invoke-virtual {v2}, Ljava/util/concurrent/Semaphore;->acquire()V

    iget-object v0, v0, Li3/k;->u:Lu3/e;

    invoke-virtual {v0}, Lu3/e;->a()F

    move-result v0

    invoke-virtual {v3, v0}, Lr3/c;->q(F)V
    :try_end_4
    .catch Ljava/lang/InterruptedException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    :catch_0
    invoke-virtual {v2}, Ljava/util/concurrent/Semaphore;->release()V

    goto :goto_6

    :catchall_2
    move-exception v0

    invoke-virtual {v2}, Ljava/util/concurrent/Semaphore;->release()V

    throw v0

    :goto_6
    return-void

    :pswitch_5
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, LT3/H0;

    iget-object v2, v0, LT3/H0;->c:Ljava/lang/Object;

    check-cast v2, LA4/f;

    iput-object v3, v0, LT3/H0;->n:Ljava/lang/Object;

    iget-object v7, v0, LT3/H0;->m:Ljava/lang/Object;

    check-cast v7, Lc0/e;

    iget-object v0, v0, LT3/H0;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isFocused()Z

    move-result v8

    if-nez v8, :cond_6

    invoke-virtual {v0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_6

    invoke-virtual {v0}, Landroid/view/View;->onCheckIsTextEditor()Z

    move-result v0

    if-ne v0, v5, :cond_6

    invoke-virtual {v7}, Lc0/e;->h()V

    goto/16 :goto_d

    :cond_6
    iget-object v0, v7, Lc0/e;->t:[Ljava/lang/Object;

    iget v8, v7, Lc0/e;->v:I

    move-object v9, v3

    move v10, v6

    :goto_7
    if-ge v10, v8, :cond_d

    aget-object v11, v0, v10

    check-cast v11, Lc1/y;

    invoke-virtual {v11}, Ljava/lang/Enum;->ordinal()I

    move-result v12

    if-eqz v12, :cond_b

    if-eq v12, v5, :cond_a

    if-eq v12, v4, :cond_8

    const/4 v13, 0x3

    if-ne v12, v13, :cond_7

    goto :goto_8

    :cond_7
    new-instance v0, LA2/c;

    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    throw v0

    :cond_8
    :goto_8
    sget-object v12, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v3, v12}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_c

    sget-object v9, Lc1/y;->v:Lc1/y;

    if-ne v11, v9, :cond_9

    move v9, v5

    goto :goto_9

    :cond_9
    move v9, v6

    :goto_9
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    goto :goto_b

    :cond_a
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    :goto_a
    move-object v9, v3

    goto :goto_b

    :cond_b
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_a

    :cond_c
    :goto_b
    add-int/lit8 v10, v10, 0x1

    goto :goto_7

    :cond_d
    invoke-virtual {v7}, Lc0/e;->h()V

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v3, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e

    iget-object v0, v2, LA4/f;->v:Ljava/lang/Object;

    invoke-interface {v0}, Ld7/h;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    iget-object v4, v2, LA4/f;->u:Ljava/lang/Object;

    check-cast v4, Landroid/view/View;

    invoke-virtual {v0, v4}, Landroid/view/inputmethod/InputMethodManager;->restartInput(Landroid/view/View;)V

    :cond_e
    if-eqz v9, :cond_10

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_f

    iget-object v0, v2, LA4/f;->w:Ljava/lang/Object;

    check-cast v0, LA1/i;

    iget-object v0, v0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LA1/t;

    invoke-virtual {v0}, LA1/t;->u()V

    goto :goto_c

    :cond_f
    iget-object v0, v2, LA4/f;->w:Ljava/lang/Object;

    check-cast v0, LA1/i;

    iget-object v0, v0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LA1/t;

    invoke-virtual {v0}, LA1/t;->o()V

    :cond_10
    :goto_c
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v3, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11

    iget-object v0, v2, LA4/f;->v:Ljava/lang/Object;

    invoke-interface {v0}, Ld7/h;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    iget-object v2, v2, LA4/f;->u:Ljava/lang/Object;

    check-cast v2, Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/inputmethod/InputMethodManager;->restartInput(Landroid/view/View;)V

    :cond_11
    :goto_d
    return-void

    :pswitch_6
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, Lc/m;

    invoke-static {v0}, Lc/m;->b(Lc/m;)V

    return-void

    :pswitch_7
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, Lc/h;

    iget-object v2, v0, Lc/h;->u:Ljava/lang/Runnable;

    if-eqz v2, :cond_12

    invoke-interface {v2}, Ljava/lang/Runnable;->run()V

    iput-object v3, v0, Lc/h;->u:Ljava/lang/Runnable;

    :cond_12
    return-void

    :pswitch_8
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, Landroidx/lifecycle/H;

    iget-object v2, v0, Landroidx/lifecycle/H;->y:Landroidx/lifecycle/y;

    iget v3, v0, Landroidx/lifecycle/H;->u:I

    if-nez v3, :cond_13

    iput-boolean v5, v0, Landroidx/lifecycle/H;->v:Z

    sget-object v3, Landroidx/lifecycle/o;->ON_PAUSE:Landroidx/lifecycle/o;

    invoke-virtual {v2, v3}, Landroidx/lifecycle/y;->L(Landroidx/lifecycle/o;)V

    :cond_13
    iget v3, v0, Landroidx/lifecycle/H;->t:I

    if-nez v3, :cond_14

    iget-boolean v3, v0, Landroidx/lifecycle/H;->v:Z

    if-eqz v3, :cond_14

    sget-object v3, Landroidx/lifecycle/o;->ON_STOP:Landroidx/lifecycle/o;

    invoke-virtual {v2, v3}, Landroidx/lifecycle/y;->L(Landroidx/lifecycle/o;)V

    iput-boolean v5, v0, Landroidx/lifecycle/H;->w:Z

    :cond_14
    return-void

    :pswitch_9
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, LW/j;

    invoke-static {v0}, LW/j;->a(LW/j;)V

    return-void

    :pswitch_a
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, LO1/t;

    const-string v0, "fetchFonts result is not OK. ("

    iget-object v3, v2, LO1/t;->d:Ljava/lang/Object;

    monitor-enter v3

    :try_start_5
    iget-object v5, v2, LO1/t;->h:LE4/g4;

    if-nez v5, :cond_15

    monitor-exit v3

    goto/16 :goto_14

    :catchall_3
    move-exception v0

    goto/16 :goto_16

    :cond_15
    monitor-exit v3
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    :try_start_6
    invoke-virtual {v2}, LO1/t;->c()Lx1/f;

    move-result-object v3

    iget v5, v3, Lx1/f;->f:I

    if-ne v5, v4, :cond_16

    iget-object v4, v2, LO1/t;->d:Ljava/lang/Object;

    monitor-enter v4
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_5

    :try_start_7
    monitor-exit v4

    goto :goto_e

    :catchall_4
    move-exception v0

    monitor-exit v4
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    :try_start_8
    throw v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    :catchall_5
    move-exception v0

    goto/16 :goto_12

    :cond_16
    :goto_e
    if-nez v5, :cond_19

    :try_start_9
    const-string v0, "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"

    sget v4, Lw1/d;->a:I

    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    iget-object v0, v2, LO1/t;->c:LD4/w;

    iget-object v4, v2, LO1/t;->a:Landroid/content/Context;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    filled-new-array {v3}, [Lx1/f;

    move-result-object v0

    sget-object v5, Lt1/e;->a:LH4/o5;

    const-string v5, "TypefaceCompat.createFromFontInfo"

    invoke-static {v5}, LE4/q;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_8

    :try_start_a
    sget-object v5, Lt1/e;->a:LH4/o5;

    invoke-virtual {v5, v4, v0, v6}, LH4/o5;->b(Landroid/content/Context;[Lx1/f;I)Landroid/graphics/Typeface;

    move-result-object v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_9

    :try_start_b
    invoke-static {}, Landroid/os/Trace;->endSection()V

    iget-object v4, v2, LO1/t;->a:Landroid/content/Context;

    iget-object v3, v3, Lx1/f;->a:Landroid/net/Uri;

    invoke-static {v4, v3}, LH4/p5;->e(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;

    move-result-object v3
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_8

    if-eqz v3, :cond_18

    if-eqz v0, :cond_18

    :try_start_c
    const-string v4, "EmojiCompat.MetadataRepo.create"

    invoke-static {v4}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    new-instance v4, LP2/i;

    invoke-static {v3}, LE4/i4;->a(Ljava/nio/MappedByteBuffer;)LP1/b;

    move-result-object v3

    invoke-direct {v4, v0, v3}, LP2/i;-><init>(Landroid/graphics/Typeface;LP1/b;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_7

    :try_start_d
    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_8

    :try_start_e
    invoke-static {}, Landroid/os/Trace;->endSection()V

    iget-object v3, v2, LO1/t;->d:Ljava/lang/Object;

    monitor-enter v3
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_5

    :try_start_f
    iget-object v0, v2, LO1/t;->h:LE4/g4;

    if-eqz v0, :cond_17

    invoke-virtual {v0, v4}, LE4/g4;->b(LP2/i;)V

    goto :goto_f

    :catchall_6
    move-exception v0

    goto :goto_10

    :cond_17
    :goto_f
    monitor-exit v3
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_6

    :try_start_10
    invoke-virtual {v2}, LO1/t;->b()V
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_5

    goto :goto_14

    :goto_10
    :try_start_11
    monitor-exit v3
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_6

    :try_start_12
    throw v0
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_5

    :catchall_7
    move-exception v0

    :try_start_13
    sget v3, Lw1/d;->a:I

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :cond_18
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v3, "Unable to open file."

    invoke-direct {v0, v3}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :catchall_8
    move-exception v0

    goto :goto_11

    :catchall_9
    move-exception v0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_8

    :goto_11
    :try_start_14
    sget v3, Lw1/d;->a:I

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :cond_19
    new-instance v3, Ljava/lang/RuntimeException;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v3, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v3
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_5

    :goto_12
    iget-object v4, v2, LO1/t;->d:Ljava/lang/Object;

    monitor-enter v4

    :try_start_15
    iget-object v3, v2, LO1/t;->h:LE4/g4;

    if-eqz v3, :cond_1a

    invoke-virtual {v3, v0}, LE4/g4;->a(Ljava/lang/Throwable;)V

    goto :goto_13

    :catchall_a
    move-exception v0

    goto :goto_15

    :cond_1a
    :goto_13
    monitor-exit v4
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_a

    invoke-virtual {v2}, LO1/t;->b()V

    :goto_14
    return-void

    :goto_15
    :try_start_16
    monitor-exit v4
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_a

    throw v0

    :goto_16
    :try_start_17
    monitor-exit v3
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_3

    throw v0

    :pswitch_b
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, LM0/F;

    const-string v2, "measureAndLayout"

    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_18
    iget-object v2, v0, LM0/F;->d:LM0/x;

    invoke-virtual {v2, v5}, LM0/x;->t(Z)V
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_c

    invoke-static {}, Landroid/os/Trace;->endSection()V

    const-string v2, "checkForSemanticsChanges"

    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_19
    invoke-virtual {v0}, LM0/F;->i()V
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_b

    invoke-static {}, Landroid/os/Trace;->endSection()V

    iput-boolean v6, v0, LM0/F;->L:Z

    return-void

    :catchall_b
    move-exception v0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :catchall_c
    move-exception v0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :pswitch_c
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, LE0/b;

    const-string v2, "AndroidOwner:outOfFrameExecutor"

    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_1a
    invoke-virtual {v0}, LE0/b;->a()Ljava/lang/Object;
    :try_end_1a
    .catchall {:try_start_1a .. :try_end_1a} :catchall_d

    invoke-static {}, Landroid/os/Trace;->endSection()V

    return-void

    :catchall_d
    move-exception v0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :pswitch_d
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, LM0/x;

    iput-boolean v6, v0, LM0/x;->T0:Z

    iget-object v2, v0, LM0/x;->L0:Landroid/view/MotionEvent;

    invoke-static {v2}, Ls7/j;->b(Ljava/lang/Object;)V

    invoke-virtual {v2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    const/16 v4, 0xa

    if-ne v3, v4, :cond_1b

    invoke-virtual {v0, v2}, LM0/x;->G(Landroid/view/MotionEvent;)I

    return-void

    :cond_1b
    const-string v0, "The ACTION_HOVER_EXIT event was not cleared."

    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    :pswitch_e
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, LI3/m;

    iget-object v2, v0, LI3/m;->d:LK3/c;

    new-instance v3, LA3/b;

    const/4 v4, 0x7

    invoke-direct {v3, v4, v0}, LA3/b;-><init>(ILjava/lang/Object;)V

    check-cast v2, LJ3/i;

    invoke-virtual {v2, v3}, LJ3/i;->z(LK3/b;)Ljava/lang/Object;

    return-void

    :pswitch_f
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, LD7/c0;

    if-eqz v0, :cond_1c

    invoke-interface {v0, v3}, LD7/c0;->f(Ljava/util/concurrent/CancellationException;)V

    :cond_1c
    return-void

    :pswitch_10
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, LG0/e;

    new-instance v2, LT5/b;

    invoke-direct {v2, v5}, LT5/b;-><init>(I)V

    invoke-virtual {v0, v2}, LG0/e;->a(LE2/g;)V

    return-void

    :pswitch_11
    iget-object v0, v1, LA1/s;->u:Ljava/lang/Object;

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const-string v3, "input_method"

    invoke-virtual {v2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/inputmethod/InputMethodManager;

    invoke-virtual {v2, v0, v6}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
