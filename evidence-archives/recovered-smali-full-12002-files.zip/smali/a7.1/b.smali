.class public interface abstract La7/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b()Ljava/lang/Object;
.end method
