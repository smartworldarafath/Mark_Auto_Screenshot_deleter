.class public final La8/f;
.super LV2/n;
.source "SourceFile"


# instance fields
.field public final t:Ljava/lang/String;

.field public final u:J

.field public final v:Li8/B;


# direct methods
.method public constructor <init>(Ljava/lang/String;JLi8/B;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La8/f;->t:Ljava/lang/String;

    iput-wide p2, p0, La8/f;->u:J

    iput-object p4, p0, La8/f;->v:Li8/B;

    return-void
.end method


# virtual methods
.method public final c()J
    .locals 2

    iget-wide v0, p0, La8/f;->u:J

    return-wide v0
.end method

.method public final f()LV7/p;
    .locals 3

    const/4 v0, 0x0

    iget-object v1, p0, La8/f;->t:Ljava/lang/String;

    if-eqz v1, :cond_0

    sget-object v2, LV7/p;->b:Ljava/util/regex/Pattern;

    :try_start_0
    invoke-static {v1}, LF4/B4;->a(Ljava/lang/String;)LV7/p;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-object v0
.end method

.method public final n()Li8/i;
    .locals 1

    iget-object v0, p0, La8/f;->v:Li8/B;

    return-object v0
.end method
