.class public final La8/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LV7/o;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LV7/b;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, La8/a;->a:I

    const-string v0, "cookieJar"

    invoke-static {p1, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La8/a;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LV7/r;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, La8/a;->a:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La8/a;->b:Ljava/lang/Object;

    return-void
.end method

.method public static d(LV7/u;I)I
    .locals 1

    const-string v0, "Retry-After"

    invoke-static {p0, v0}, LV7/u;->c(LV7/u;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_0

    return p1

    :cond_0
    const-string p1, "\\d+"

    invoke-static {p1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object p1

    const-string v0, "compile(...)"

    invoke-static {p1, v0}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/regex/Matcher;->matches()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p0

    const-string p1, "valueOf(header)"

    invoke-static {p0, p1}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    return p0

    :cond_1
    const p0, 0x7fffffff

    return p0
.end method


# virtual methods
.method public final a(LD/w;)LV7/u;
    .locals 28

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    iget v0, v1, La8/a;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, v2, LD/w;->i:Ljava/lang/Object;

    check-cast v0, LH4/l5;

    iget-object v3, v2, LD/w;->g:Ljava/lang/Object;

    check-cast v3, LZ7/h;

    sget-object v4, Le7/t;->t:Le7/t;

    move-object v8, v4

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v4, v0

    :goto_0
    const/4 v0, 0x1

    :goto_1
    const-string v11, "request"

    invoke-static {v4, v11}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v11, v3, LZ7/h;->B:LA1/j;

    if-nez v11, :cond_f

    monitor-enter v3

    :try_start_0
    iget-boolean v11, v3, LZ7/h;->D:Z

    if-nez v11, :cond_e

    iget-boolean v11, v3, LZ7/h;->C:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-nez v11, :cond_d

    monitor-exit v3

    if-eqz v0, :cond_2

    new-instance v0, LZ7/d;

    iget-object v11, v3, LZ7/h;->v:LL4/S;

    iget-object v12, v4, LH4/l5;->u:Ljava/lang/Object;

    check-cast v12, LV7/n;

    iget-object v13, v3, LZ7/h;->t:LV7/r;

    iget-boolean v14, v12, LV7/n;->i:Z

    if-eqz v14, :cond_1

    iget-object v14, v13, LV7/r;->H:Ljavax/net/ssl/SSLSocketFactory;

    if-eqz v14, :cond_0

    iget-object v15, v13, LV7/r;->L:Lh8/c;

    iget-object v7, v13, LV7/r;->M:LV7/e;

    move-object/from16 v23, v7

    move-object/from16 v21, v14

    move-object/from16 v22, v15

    goto :goto_2

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "CLEARTEXT-only client"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    :goto_2
    new-instance v16, LV7/a;

    iget-object v7, v12, LV7/n;->d:Ljava/lang/String;

    iget v12, v12, LV7/n;->e:I

    iget-object v14, v13, LV7/r;->D:LV7/b;

    iget-object v15, v13, LV7/r;->G:Ljavax/net/SocketFactory;

    iget-object v5, v13, LV7/r;->F:LV7/b;

    iget-object v6, v13, LV7/r;->K:Ljava/util/List;

    move-object/from16 v24, v5

    iget-object v5, v13, LV7/r;->J:Ljava/util/List;

    iget-object v13, v13, LV7/r;->E:Ljava/net/ProxySelector;

    move-object/from16 v26, v5

    move-object/from16 v25, v6

    move-object/from16 v17, v7

    move/from16 v18, v12

    move-object/from16 v27, v13

    move-object/from16 v19, v14

    move-object/from16 v20, v15

    invoke-direct/range {v16 .. v27}, LV7/a;-><init>(Ljava/lang/String;ILV7/b;Ljavax/net/SocketFactory;Ljavax/net/ssl/SSLSocketFactory;Ljavax/net/ssl/HostnameVerifier;LV7/e;LV7/b;Ljava/util/List;Ljava/util/List;Ljava/net/ProxySelector;)V

    move-object/from16 v5, v16

    invoke-direct {v0, v11, v5, v3}, LZ7/d;-><init>(LL4/S;LV7/a;LZ7/h;)V

    iput-object v0, v3, LZ7/h;->z:LZ7/d;

    :cond_2
    :try_start_1
    iget-boolean v0, v3, LZ7/h;->F:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-nez v0, :cond_c

    :try_start_2
    invoke-virtual {v2, v4}, LD/w;->f(LH4/l5;)LV7/u;

    move-result-object v0
    :try_end_2
    .catch LZ7/k; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-eqz v9, :cond_4

    :try_start_3
    invoke-virtual {v0}, LV7/u;->f()LV7/t;

    move-result-object v0

    invoke-virtual {v9}, LV7/u;->f()LV7/t;

    move-result-object v4

    const/4 v5, 0x0

    iput-object v5, v4, LV7/t;->g:LV2/n;

    invoke-virtual {v4}, LV7/t;->a()LV7/u;

    move-result-object v4

    iget-object v6, v4, LV7/u;->z:LV2/n;

    if-nez v6, :cond_3

    iput-object v4, v0, LV7/t;->j:LV7/u;

    invoke-virtual {v0}, LV7/t;->a()LV7/u;

    move-result-object v0

    :goto_3
    move-object v9, v0

    goto :goto_4

    :catchall_0
    move-exception v0

    const/4 v6, 0x1

    goto/16 :goto_7

    :cond_3
    const-string v0, "priorResponse.body != null"

    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_4
    const/4 v5, 0x0

    goto :goto_3

    :goto_4
    iget-object v0, v3, LZ7/h;->B:LA1/j;

    invoke-virtual {v1, v9, v0}, La8/a;->b(LV7/u;LA1/j;)LH4/l5;

    move-result-object v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    if-nez v4, :cond_5

    const/4 v6, 0x0

    invoke-virtual {v3, v6}, LZ7/h;->e(Z)V

    return-object v9

    :cond_5
    :try_start_4
    iget-object v0, v9, LV7/u;->z:LV2/n;

    if-eqz v0, :cond_6

    invoke-static {v0}, LW7/b;->d(Ljava/io/Closeable;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :cond_6
    add-int/lit8 v10, v10, 0x1

    const/16 v0, 0x14

    if-gt v10, v0, :cond_7

    const/4 v6, 0x1

    invoke-virtual {v3, v6}, LZ7/h;->e(Z)V

    goto/16 :goto_0

    :cond_7
    :try_start_5
    new-instance v0, Ljava/net/ProtocolException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Too many follow-up requests: "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_0
    move-exception v0

    const/4 v5, 0x0

    instance-of v6, v0, Lc8/a;

    const/4 v7, 0x1

    xor-int/2addr v6, v7

    invoke-virtual {v1, v0, v3, v4, v6}, La8/a;->c(Ljava/io/IOException;LZ7/h;LH4/l5;Z)Z

    move-result v6

    if-eqz v6, :cond_8

    invoke-static {v8, v0}, Le7/l;->E(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v8
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    invoke-virtual {v3, v7}, LZ7/h;->e(Z)V

    const/4 v0, 0x0

    goto/16 :goto_1

    :cond_8
    :try_start_6
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_5
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_9

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Exception;

    invoke-static {v0, v4}, Ld7/a;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    goto :goto_5

    :cond_9
    throw v0

    :catch_1
    move-exception v0

    const/4 v5, 0x0

    iget-object v6, v0, LZ7/k;->u:Ljava/io/IOException;

    const/4 v7, 0x0

    invoke-virtual {v1, v6, v3, v4, v7}, La8/a;->c(Ljava/io/IOException;LZ7/h;LH4/l5;Z)Z

    move-result v6

    if-eqz v6, :cond_a

    iget-object v0, v0, LZ7/k;->t:Ljava/io/IOException;

    invoke-static {v8, v0}, Le7/l;->E(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v8
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    const/4 v6, 0x1

    invoke-virtual {v3, v6}, LZ7/h;->e(Z)V

    move v0, v7

    goto/16 :goto_1

    :cond_a
    :try_start_7
    iget-object v0, v0, LZ7/k;->t:Ljava/io/IOException;

    const-string v2, "<this>"

    invoke-static {v0, v2}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Exception;

    invoke-static {v0, v4}, Ld7/a;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    goto :goto_6

    :cond_b
    throw v0

    :cond_c
    new-instance v0, Ljava/io/IOException;

    const-string v2, "Canceled"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    :goto_7
    invoke-virtual {v3, v6}, LZ7/h;->e(Z)V

    throw v0

    :cond_d
    :try_start_8
    const-string v0, "Check failed."

    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    :catchall_1
    move-exception v0

    goto :goto_8

    :cond_e
    const-string v0, "cannot make a new request because the previous response is still open: please call response.close()"

    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    :goto_8
    monitor-exit v3

    throw v0

    :cond_f
    const-string v0, "Check failed."

    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    :pswitch_0
    const-string v0, "Content-Encoding"

    const-string v3, "User-Agent"

    iget-object v4, v1, La8/a;->b:Ljava/lang/Object;

    check-cast v4, LV7/b;

    const-string v5, "gzip"

    const-string v6, "Accept-Encoding"

    const-string v7, "Connection"

    const-string v8, "Host"

    const-string v9, "Content-Type"

    const-string v10, "Content-Length"

    iget-object v11, v2, LD/w;->i:Ljava/lang/Object;

    check-cast v11, LH4/l5;

    invoke-virtual {v11}, LH4/l5;->s()LP2/i;

    move-result-object v12

    iget-object v13, v11, LH4/l5;->w:Ljava/lang/Object;

    check-cast v13, LV7/l;

    iget-object v14, v11, LH4/l5;->u:Ljava/lang/Object;

    check-cast v14, LV7/n;

    invoke-virtual {v13, v8}, LV7/l;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    const/4 v1, 0x0

    if-nez v15, :cond_10

    invoke-static {v14, v1}, LW7/b;->u(LV7/n;Z)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v12, v8, v15}, LP2/i;->q(Ljava/lang/String;Ljava/lang/String;)V

    :cond_10
    invoke-virtual {v13, v7}, LV7/l;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_11

    const-string v8, "Keep-Alive"

    invoke-virtual {v12, v7, v8}, LP2/i;->q(Ljava/lang/String;Ljava/lang/String;)V

    :cond_11
    invoke-virtual {v13, v6}, LV7/l;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_12

    const-string v7, "Range"

    invoke-virtual {v13, v7}, LV7/l;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_12

    invoke-virtual {v12, v6, v5}, LP2/i;->q(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x1

    :cond_12
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v6, "url"

    invoke-static {v14, v6}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v13, v3}, LV7/l;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_13

    const-string v6, "okhttp/4.12.0"

    invoke-virtual {v12, v3, v6}, LP2/i;->q(Ljava/lang/String;Ljava/lang/String;)V

    :cond_13
    invoke-virtual {v12}, LP2/i;->f()LH4/l5;

    move-result-object v3

    invoke-virtual {v2, v3}, LD/w;->f(LH4/l5;)LV7/u;

    move-result-object v2

    iget-object v3, v2, LV7/u;->y:LV7/l;

    invoke-static {v4, v14, v3}, La8/e;->b(LV7/b;LV7/n;LV7/l;)V

    invoke-virtual {v2}, LV7/u;->f()LV7/t;

    move-result-object v4

    iput-object v11, v4, LV7/t;->a:LH4/l5;

    if-eqz v1, :cond_14

    invoke-static {v2, v0}, LV7/u;->c(LV7/u;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_14

    invoke-static {v2}, La8/e;->a(LV7/u;)Z

    move-result v1

    if-eqz v1, :cond_14

    iget-object v1, v2, LV7/u;->z:LV2/n;

    if-eqz v1, :cond_14

    new-instance v5, Li8/q;

    invoke-virtual {v1}, LV2/n;->n()Li8/i;

    move-result-object v1

    invoke-direct {v5, v1}, Li8/q;-><init>(Li8/H;)V

    invoke-virtual {v3}, LV7/l;->e()LL2/o;

    move-result-object v1

    invoke-virtual {v1, v0}, LL2/o;->q(Ljava/lang/String;)V

    invoke-virtual {v1, v10}, LL2/o;->q(Ljava/lang/String;)V

    invoke-virtual {v1}, LL2/o;->c()LV7/l;

    move-result-object v0

    invoke-virtual {v0}, LV7/l;->e()LL2/o;

    move-result-object v0

    iput-object v0, v4, LV7/t;->f:LL2/o;

    invoke-static {v2, v9}, LV7/u;->c(LV7/u;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, La8/f;

    invoke-static {v5}, LH4/K;->b(Li8/H;)Li8/B;

    move-result-object v2

    const-wide/16 v5, -0x1

    invoke-direct {v1, v0, v5, v6, v2}, La8/f;-><init>(Ljava/lang/String;JLi8/B;)V

    iput-object v1, v4, LV7/t;->g:LV2/n;

    :cond_14
    invoke-virtual {v4}, LV7/t;->a()LV7/u;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public b(LV7/u;LA1/j;)LH4/l5;
    .locals 11

    const/4 v0, 0x0

    if-eqz p2, :cond_0

    iget-object v1, p2, LA1/j;->e:Ljava/lang/Object;

    check-cast v1, LZ7/j;

    if-eqz v1, :cond_0

    iget-object v1, v1, LZ7/j;->b:LV7/w;

    goto :goto_0

    :cond_0
    move-object v1, v0

    :goto_0
    iget v2, p1, LV7/u;->w:I

    iget-object v3, p1, LV7/u;->t:LH4/l5;

    iget-object v3, v3, LH4/l5;->v:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/16 v6, 0x134

    const/16 v7, 0x133

    if-eq v2, v7, :cond_c

    if-eq v2, v6, :cond_c

    const/16 v8, 0x191

    if-eq v2, v8, :cond_b

    const/16 v8, 0x1a5

    if-eq v2, v8, :cond_9

    const/16 p2, 0x1f7

    if-eq v2, p2, :cond_7

    const/16 p2, 0x197

    if-eq v2, p2, :cond_5

    const/16 p2, 0x198

    if-eq v2, p2, :cond_1

    packed-switch v2, :pswitch_data_0

    goto/16 :goto_3

    :cond_1
    iget-object v1, p0, La8/a;->b:Ljava/lang/Object;

    check-cast v1, LV7/r;

    iget-boolean v1, v1, LV7/r;->y:Z

    if-nez v1, :cond_2

    goto/16 :goto_3

    :cond_2
    iget-object v1, p1, LV7/u;->C:LV7/u;

    if-eqz v1, :cond_3

    iget v1, v1, LV7/u;->w:I

    if-ne v1, p2, :cond_3

    goto/16 :goto_3

    :cond_3
    invoke-static {p1, v4}, La8/a;->d(LV7/u;I)I

    move-result p2

    if-lez p2, :cond_4

    goto/16 :goto_3

    :cond_4
    iget-object p1, p1, LV7/u;->t:LH4/l5;

    return-object p1

    :cond_5
    invoke-static {v1}, Ls7/j;->b(Ljava/lang/Object;)V

    iget-object p1, v1, LV7/w;->b:Ljava/net/Proxy;

    invoke-virtual {p1}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    move-result-object p1

    sget-object p2, Ljava/net/Proxy$Type;->HTTP:Ljava/net/Proxy$Type;

    if-ne p1, p2, :cond_6

    iget-object p1, p0, La8/a;->b:Ljava/lang/Object;

    check-cast p1, LV7/r;

    iget-object p1, p1, LV7/r;->F:LV7/b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0

    :cond_6
    new-instance p1, Ljava/net/ProtocolException;

    const-string p2, "Received HTTP_PROXY_AUTH (407) code while not using proxy"

    invoke-direct {p1, p2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_7
    iget-object v1, p1, LV7/u;->C:LV7/u;

    if-eqz v1, :cond_8

    iget v1, v1, LV7/u;->w:I

    if-ne v1, p2, :cond_8

    goto/16 :goto_3

    :cond_8
    const p2, 0x7fffffff

    invoke-static {p1, p2}, La8/a;->d(LV7/u;I)I

    move-result p2

    if-nez p2, :cond_11

    iget-object p1, p1, LV7/u;->t:LH4/l5;

    return-object p1

    :cond_9
    if-eqz p2, :cond_11

    iget-object v1, p2, LA1/j;->c:Ljava/lang/Object;

    check-cast v1, LZ7/d;

    iget-object v1, v1, LZ7/d;->b:LV7/a;

    iget-object v1, v1, LV7/a;->h:LV7/n;

    iget-object v1, v1, LV7/n;->d:Ljava/lang/String;

    iget-object v2, p2, LA1/j;->e:Ljava/lang/Object;

    check-cast v2, LZ7/j;

    iget-object v2, v2, LZ7/j;->b:LV7/w;

    iget-object v2, v2, LV7/w;->a:LV7/a;

    iget-object v2, v2, LV7/a;->h:LV7/n;

    iget-object v2, v2, LV7/n;->d:Ljava/lang/String;

    invoke-static {v1, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a

    goto :goto_3

    :cond_a
    iget-object p2, p2, LA1/j;->e:Ljava/lang/Object;

    check-cast p2, LZ7/j;

    monitor-enter p2

    :try_start_0
    iput-boolean v5, p2, LZ7/j;->k:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p2

    iget-object p1, p1, LV7/u;->t:LH4/l5;

    return-object p1

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    :cond_b
    iget-object p1, p0, La8/a;->b:Ljava/lang/Object;

    check-cast p1, LV7/r;

    iget-object p1, p1, LV7/r;->z:LV7/b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0

    :cond_c
    :pswitch_0
    const-string p2, "PROPFIND"

    iget-object v1, p0, La8/a;->b:Ljava/lang/Object;

    check-cast v1, LV7/r;

    iget-boolean v2, v1, LV7/r;->A:Z

    if-nez v2, :cond_d

    goto :goto_3

    :cond_d
    const-string v2, "Location"

    invoke-static {p1, v2}, LV7/u;->c(LV7/u;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-object v8, p1, LV7/u;->t:LH4/l5;

    if-nez v2, :cond_e

    goto :goto_3

    :cond_e
    iget-object v9, v8, LH4/l5;->u:Ljava/lang/Object;

    check-cast v9, LV7/n;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_2
    new-instance v10, LV7/m;

    invoke-direct {v10}, LV7/m;-><init>()V

    invoke-virtual {v10, v9, v2}, LV7/m;->c(LV7/n;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_1

    :catch_0
    move-object v10, v0

    :goto_1
    if-eqz v10, :cond_f

    invoke-virtual {v10}, LV7/m;->a()LV7/n;

    move-result-object v2

    goto :goto_2

    :cond_f
    move-object v2, v0

    :goto_2
    if-nez v2, :cond_10

    goto :goto_3

    :cond_10
    iget-object v9, v2, LV7/n;->a:Ljava/lang/String;

    iget-object v10, v8, LH4/l5;->u:Ljava/lang/Object;

    check-cast v10, LV7/n;

    iget-object v10, v10, LV7/n;->a:Ljava/lang/String;

    invoke-static {v9, v10}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_12

    iget-boolean v1, v1, LV7/r;->B:Z

    if-nez v1, :cond_12

    :cond_11
    :goto_3
    return-object v0

    :cond_12
    invoke-virtual {v8}, LH4/l5;->s()LP2/i;

    move-result-object v1

    invoke-static {v3}, LF4/k5;->a(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_16

    iget p1, p1, LV7/u;->w:I

    invoke-virtual {v3, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_13

    if-eq p1, v6, :cond_13

    if-ne p1, v7, :cond_14

    :cond_13
    move v4, v5

    :cond_14
    invoke-virtual {v3, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_15

    if-eq p1, v6, :cond_15

    if-eq p1, v7, :cond_15

    const-string p1, "GET"

    invoke-virtual {v1, p1, v0}, LP2/i;->t(Ljava/lang/String;LF4/D4;)V

    goto :goto_4

    :cond_15
    const/4 p1, 0x0

    invoke-virtual {v1, v3, p1}, LP2/i;->t(Ljava/lang/String;LF4/D4;)V

    :goto_4
    if-nez v4, :cond_16

    const-string p1, "Transfer-Encoding"

    iget-object p2, v1, LP2/i;->v:Ljava/lang/Object;

    check-cast p2, LL2/o;

    invoke-virtual {p2, p1}, LL2/o;->q(Ljava/lang/String;)V

    const-string p1, "Content-Length"

    iget-object p2, v1, LP2/i;->v:Ljava/lang/Object;

    check-cast p2, LL2/o;

    invoke-virtual {p2, p1}, LL2/o;->q(Ljava/lang/String;)V

    const-string p1, "Content-Type"

    iget-object p2, v1, LP2/i;->v:Ljava/lang/Object;

    check-cast p2, LL2/o;

    invoke-virtual {p2, p1}, LL2/o;->q(Ljava/lang/String;)V

    :cond_16
    iget-object p1, v8, LH4/l5;->u:Ljava/lang/Object;

    check-cast p1, LV7/n;

    invoke-static {p1, v2}, LW7/b;->a(LV7/n;LV7/n;)Z

    move-result p1

    if-nez p1, :cond_17

    const-string p1, "Authorization"

    iget-object p2, v1, LP2/i;->v:Ljava/lang/Object;

    check-cast p2, LL2/o;

    invoke-virtual {p2, p1}, LL2/o;->q(Ljava/lang/String;)V

    :cond_17
    iput-object v2, v1, LP2/i;->t:Ljava/lang/Object;

    invoke-virtual {v1}, LP2/i;->f()LH4/l5;

    move-result-object p1

    return-object p1

    :pswitch_data_0
    .packed-switch 0x12c
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public c(Ljava/io/IOException;LZ7/h;LH4/l5;Z)Z
    .locals 3

    iget-object p3, p0, La8/a;->b:Ljava/lang/Object;

    check-cast p3, LV7/r;

    iget-boolean p3, p3, LV7/r;->y:Z

    const/4 v0, 0x0

    if-nez p3, :cond_0

    goto/16 :goto_5

    :cond_0
    if-eqz p4, :cond_1

    instance-of p3, p1, Ljava/io/FileNotFoundException;

    if-eqz p3, :cond_1

    return v0

    :cond_1
    instance-of p3, p1, Ljava/net/ProtocolException;

    if-eqz p3, :cond_2

    return v0

    :cond_2
    instance-of p3, p1, Ljava/io/InterruptedIOException;

    if-eqz p3, :cond_3

    instance-of p1, p1, Ljava/net/SocketTimeoutException;

    if-eqz p1, :cond_10

    if-nez p4, :cond_10

    goto :goto_0

    :cond_3
    instance-of p3, p1, Ljavax/net/ssl/SSLHandshakeException;

    if-eqz p3, :cond_4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p3

    instance-of p3, p3, Ljava/security/cert/CertificateException;

    if-eqz p3, :cond_4

    goto/16 :goto_5

    :cond_4
    instance-of p1, p1, Ljavax/net/ssl/SSLPeerUnverifiedException;

    if-eqz p1, :cond_5

    return v0

    :cond_5
    :goto_0
    iget-object p1, p2, LZ7/h;->z:LZ7/d;

    invoke-static {p1}, Ls7/j;->b(Ljava/lang/Object;)V

    iget p2, p1, LZ7/d;->f:I

    const/4 p3, 0x1

    if-nez p2, :cond_6

    iget p4, p1, LZ7/d;->g:I

    if-nez p4, :cond_6

    iget p4, p1, LZ7/d;->h:I

    if-nez p4, :cond_6

    move p1, v0

    goto :goto_4

    :cond_6
    iget-object p4, p1, LZ7/d;->i:LV7/w;

    if-eqz p4, :cond_7

    goto :goto_3

    :cond_7
    const/4 p4, 0x0

    if-gt p2, p3, :cond_c

    iget p2, p1, LZ7/d;->g:I

    if-gt p2, p3, :cond_c

    iget p2, p1, LZ7/d;->h:I

    if-lez p2, :cond_8

    goto :goto_1

    :cond_8
    iget-object p2, p1, LZ7/d;->c:LZ7/h;

    iget-object p2, p2, LZ7/h;->A:LZ7/j;

    if-nez p2, :cond_9

    goto :goto_1

    :cond_9
    monitor-enter p2

    :try_start_0
    iget v1, p2, LZ7/j;->l:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v1, :cond_a

    monitor-exit p2

    goto :goto_1

    :cond_a
    :try_start_1
    iget-object v1, p2, LZ7/j;->b:LV7/w;

    iget-object v1, v1, LV7/w;->a:LV7/a;

    iget-object v1, v1, LV7/a;->h:LV7/n;

    iget-object v2, p1, LZ7/d;->b:LV7/a;

    iget-object v2, v2, LV7/a;->h:LV7/n;

    invoke-static {v1, v2}, LW7/b;->a(LV7/n;LV7/n;)Z

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-nez v1, :cond_b

    monitor-exit p2

    goto :goto_1

    :cond_b
    :try_start_2
    iget-object p4, p2, LZ7/j;->b:LV7/w;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p2

    goto :goto_1

    :catchall_0
    move-exception p1

    monitor-exit p2

    throw p1

    :cond_c
    :goto_1
    if-eqz p4, :cond_d

    iput-object p4, p1, LZ7/d;->i:LV7/w;

    :goto_2
    move p1, p3

    goto :goto_4

    :cond_d
    iget-object p2, p1, LZ7/d;->d:LZ7/l;

    if-eqz p2, :cond_e

    invoke-virtual {p2}, LZ7/l;->a()Z

    move-result p2

    if-ne p2, p3, :cond_e

    goto :goto_3

    :cond_e
    iget-object p1, p1, LZ7/d;->e:LL0/y0;

    if-nez p1, :cond_f

    :goto_3
    goto :goto_2

    :cond_f
    invoke-virtual {p1}, LL0/y0;->b()Z

    move-result p1

    :goto_4
    if-nez p1, :cond_11

    :cond_10
    :goto_5
    return v0

    :cond_11
    return p3
.end method
