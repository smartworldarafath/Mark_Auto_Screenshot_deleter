.class public final La8/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LV7/o;


# virtual methods
.method public final a(LD/w;)LV7/u;
    .locals 14

    const-string v0, "Connection"

    const-string v1, "close"

    const-string v2, "HTTP "

    iget-object v3, p1, LD/w;->h:Ljava/lang/Object;

    check-cast v3, LA1/j;

    invoke-static {v3}, Ls7/j;->b(Ljava/lang/Object;)V

    iget-object v4, v3, LA1/j;->b:Ljava/lang/Object;

    check-cast v4, LZ7/h;

    iget-object v5, v3, LA1/j;->d:Ljava/lang/Object;

    check-cast v5, La8/d;

    iget-object v6, v3, LA1/j;->e:Ljava/lang/Object;

    check-cast v6, LZ7/j;

    iget-object p1, p1, LD/w;->i:Ljava/lang/Object;

    check-cast p1, LH4/l5;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v10, 0x0

    :try_start_0
    invoke-interface {v5, p1}, La8/d;->d(LH4/l5;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2

    :try_start_1
    iget-object v11, p1, LH4/l5;->v:Ljava/lang/Object;

    check-cast v11, Ljava/lang/String;

    invoke-static {v11}, LF4/k5;->a(Ljava/lang/String;)Z

    const/4 v11, 0x1

    invoke-virtual {v4, v3, v11, v9, v10}, LZ7/h;->g(LA1/j;ZZLjava/io/IOException;)Ljava/io/IOException;
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    :try_start_2
    invoke-interface {v5}, La8/d;->a()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    move-object v4, v10

    goto :goto_1

    :catch_0
    move-exception v4

    :try_start_3
    invoke-virtual {v3, v4}, LA1/j;->j(Ljava/io/IOException;)V

    throw v4

    :catch_1
    move-exception v4

    goto :goto_0

    :catch_2
    move-exception v4

    invoke-virtual {v3, v4}, LA1/j;->j(Ljava/io/IOException;)V

    throw v4
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    :goto_0
    instance-of v11, v4, Lc8/a;

    if-nez v11, :cond_a

    iget-boolean v11, v3, LA1/j;->a:Z

    if-eqz v11, :cond_9

    :goto_1
    :try_start_4
    invoke-virtual {v3, v9}, LA1/j;->i(Z)LV7/t;

    move-result-object v11

    invoke-static {v11}, Ls7/j;->b(Ljava/lang/Object;)V

    iput-object p1, v11, LV7/t;->a:LH4/l5;

    iget-object v12, v6, LZ7/j;->e:LV7/k;

    iput-object v12, v11, LV7/t;->e:LV7/k;

    iput-wide v7, v11, LV7/t;->k:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    iput-wide v12, v11, LV7/t;->l:J

    invoke-virtual {v11}, LV7/t;->a()LV7/u;

    move-result-object v11

    iget v12, v11, LV7/u;->w:I

    const/16 v13, 0x64

    if-ne v12, v13, :cond_0

    goto :goto_2

    :cond_0
    const/16 v13, 0x66

    if-gt v13, v12, :cond_1

    const/16 v13, 0xc8

    if-ge v12, v13, :cond_1

    :goto_2
    invoke-virtual {v3, v9}, LA1/j;->i(Z)LV7/t;

    move-result-object v9

    invoke-static {v9}, Ls7/j;->b(Ljava/lang/Object;)V

    iput-object p1, v9, LV7/t;->a:LH4/l5;

    iget-object p1, v6, LZ7/j;->e:LV7/k;

    iput-object p1, v9, LV7/t;->e:LV7/k;

    iput-wide v7, v9, LV7/t;->k:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    iput-wide v6, v9, LV7/t;->l:J

    invoke-virtual {v9}, LV7/t;->a()LV7/u;

    move-result-object v11

    iget v12, v11, LV7/u;->w:I

    goto :goto_3

    :catch_3
    move-exception p1

    goto/16 :goto_5

    :cond_1
    :goto_3
    invoke-virtual {v11}, LV7/u;->f()LV7/t;

    move-result-object p1
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    :try_start_5
    const-string v6, "Content-Type"

    invoke-static {v11, v6}, LV7/u;->c(LV7/u;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v5, v11}, La8/d;->f(LV7/u;)J

    move-result-wide v7

    invoke-interface {v5, v11}, La8/d;->e(LV7/u;)Li8/H;

    move-result-object v9

    new-instance v11, LZ7/c;

    invoke-direct {v11, v3, v9, v7, v8}, LZ7/c;-><init>(LA1/j;Li8/H;J)V

    new-instance v9, La8/f;

    invoke-static {v11}, LH4/K;->b(Li8/H;)Li8/B;

    move-result-object v11

    invoke-direct {v9, v6, v7, v8, v11}, La8/f;-><init>(Ljava/lang/String;JLi8/B;)V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4

    :try_start_6
    iput-object v9, p1, LV7/t;->g:LV2/n;

    invoke-virtual {p1}, LV7/t;->a()LV7/u;

    move-result-object p1

    iget-object v3, p1, LV7/u;->t:LH4/l5;

    iget-object v3, v3, LH4/l5;->w:Ljava/lang/Object;

    check-cast v3, LV7/l;

    invoke-virtual {v3, v0}, LV7/l;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_2

    invoke-static {p1, v0}, LV7/u;->c(LV7/u;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    :cond_2
    invoke-interface {v5}, La8/d;->c()LZ7/j;

    move-result-object v0

    invoke-virtual {v0}, LZ7/j;->k()V

    :cond_3
    const/16 v0, 0xcc

    if-eq v12, v0, :cond_4

    const/16 v0, 0xcd

    if-ne v12, v0, :cond_7

    :cond_4
    iget-object v0, p1, LV7/u;->z:LV2/n;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, LV2/n;->c()J

    move-result-wide v0

    goto :goto_4

    :cond_5
    const-wide/16 v0, -0x1

    :goto_4
    const-wide/16 v5, 0x0

    cmp-long v0, v0, v5

    if-lez v0, :cond_7

    new-instance v0, Ljava/net/ProtocolException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " had non-zero Content-Length: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p1, LV7/u;->z:LV2/n;

    if-eqz p1, :cond_6

    invoke-virtual {p1}, LV2/n;->c()J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v10

    :cond_6
    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_7
    return-object p1

    :catch_4
    move-exception p1

    invoke-virtual {v3, p1}, LA1/j;->j(Ljava/io/IOException;)V

    throw p1
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_3

    :goto_5
    if-eqz v4, :cond_8

    invoke-static {v4, p1}, Ld7/a;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    throw v4

    :cond_8
    throw p1

    :cond_9
    throw v4

    :cond_a
    throw v4
.end method
