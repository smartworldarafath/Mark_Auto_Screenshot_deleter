.class public final La5/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La5/a;


# static fields
.field public static volatile c:La5/b;


# instance fields
.field public final a:LA1/t;

.field public final b:Ljava/util/concurrent/ConcurrentHashMap;


# direct methods
.method public constructor <init>(LA1/t;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lp4/y;->h(Ljava/lang/Object;)V

    iput-object p1, p0, La5/b;->a:LA1/t;

    new-instance p1, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {p1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object p1, p0, La5/b;->b:Ljava/util/concurrent/ConcurrentHashMap;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;LP2/e;)LT5/q;
    .locals 5

    sget-object v0, Lb5/a;->c:LW4/h;

    invoke-virtual {v0, p1}, LW4/d;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    iget-object v2, p0, La5/b;->b:Ljava/util/concurrent/ConcurrentHashMap;

    if-nez v0, :cond_1

    invoke-virtual {v2, p1}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {v2, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    const-string v0, "fiam"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    iget-object v3, p0, La5/b;->a:LA1/t;

    if-eqz v0, :cond_2

    new-instance v0, LR/p;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object p2, v0, LR/p;->u:Ljava/lang/Object;

    new-instance p2, Lb5/b;

    const/4 v4, 0x0

    invoke-direct {p2, v4, v0}, Lb5/b;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v3, p2}, LA1/t;->t(Lb5/b;)V

    new-instance p2, Ljava/util/HashSet;

    invoke-direct {p2}, Ljava/util/HashSet;-><init>()V

    iput-object p2, v0, LR/p;->t:Ljava/lang/Object;

    goto :goto_0

    :cond_2
    const-string v0, "clx"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    new-instance v0, LW2/g;

    invoke-direct {v0, v3, p2}, LW2/g;-><init>(LA1/t;LP2/e;)V

    goto :goto_0

    :cond_3
    move-object v0, v1

    :goto_0
    if-eqz v0, :cond_4

    invoke-virtual {v2, p1, v0}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance p1, LT5/q;

    const/4 p2, 0x4

    invoke-direct {p1, p2}, LT5/q;-><init>(I)V

    return-object p1

    :cond_4
    :goto_1
    return-object v1
.end method
