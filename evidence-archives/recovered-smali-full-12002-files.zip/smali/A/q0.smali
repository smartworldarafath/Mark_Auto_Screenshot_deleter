.class public final LA/q0;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/z;


# instance fields
.field public H:LA/A;

.field public I:Lr7/e;


# virtual methods
.method public final c(LJ0/O;LJ0/L;J)LJ0/N;
    .locals 8

    iget-object v0, p0, LA/q0;->H:LA/A;

    sget-object v1, LA/A;->t:LA/A;

    const/4 v2, 0x0

    if-eq v0, v1, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    invoke-static {p3, p4}, Lj1/a;->j(J)I

    move-result v0

    :goto_0
    iget-object v1, p0, LA/q0;->H:LA/A;

    sget-object v3, LA/A;->u:LA/A;

    if-eq v1, v3, :cond_1

    goto :goto_1

    :cond_1
    invoke-static {p3, p4}, Lj1/a;->i(J)I

    move-result v2

    :goto_1
    invoke-static {p3, p4}, Lj1/a;->h(J)I

    move-result v1

    invoke-static {p3, p4}, Lj1/a;->g(J)I

    move-result v3

    invoke-static {v0, v1, v2, v3}, Lj1/b;->a(IIII)J

    move-result-wide v0

    invoke-interface {p2, v0, v1}, LJ0/L;->D(J)LJ0/Y;

    move-result-object v5

    iget p2, v5, LJ0/Y;->t:I

    invoke-static {p3, p4}, Lj1/a;->j(J)I

    move-result v0

    invoke-static {p3, p4}, Lj1/a;->h(J)I

    move-result v1

    invoke-static {p2, v0, v1}, LH4/Z5;->c(III)I

    move-result v4

    iget p2, v5, LJ0/Y;->u:I

    invoke-static {p3, p4}, Lj1/a;->i(J)I

    move-result v0

    invoke-static {p3, p4}, Lj1/a;->g(J)I

    move-result p3

    invoke-static {p2, v0, p3}, LH4/Z5;->c(III)I

    move-result v6

    new-instance v2, LA/p0;

    move-object v3, p0

    move-object v7, p1

    invoke-direct/range {v2 .. v7}, LA/p0;-><init>(LA/q0;ILJ0/Y;ILJ0/O;)V

    sget-object p1, Le7/u;->t:Le7/u;

    invoke-interface {v7, v4, v6, p1, v2}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1
.end method
