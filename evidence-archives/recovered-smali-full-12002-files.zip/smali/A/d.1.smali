.class public abstract LA/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LA/c;

.field public static final b:LA/c;

.field public static final c:LK0/g;

.field public static final d:I = 0x9

.field public static final e:I = 0x6

.field public static final f:I = 0xa

.field public static final g:I = 0x5

.field public static final h:I = 0xf


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    new-instance v0, LA/c;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LA/c;-><init>(I)V

    sput-object v0, LA/d;->a:LA/c;

    new-instance v0, LA/c;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, LA/c;-><init>(I)V

    sput-object v0, LA/d;->b:LA/c;

    new-instance v0, LA/l0;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LA/l0;-><init>(I)V

    new-instance v1, LK0/g;

    invoke-direct {v1, v0}, LK0/g;-><init>(Lr7/a;)V

    sput-object v1, LA/d;->c:LK0/g;

    return-void
.end method

.method public static final a(La0/r;Lm0/r;)V
    .locals 5

    sget-object v0, LA/o;->c:LA/o;

    iget-wide v1, p0, La0/r;->T:J

    invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I

    move-result v1

    invoke-static {p0, p1}, Lm0/a;->c(La0/r;Lm0/r;)Lm0/r;

    move-result-object p1

    invoke-virtual {p0}, La0/r;->l()La0/n0;

    move-result-object v2

    sget-object v3, LL0/j;->b:LL0/i;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v3, LL0/i;->b:LL0/C;

    iget-object v4, p0, La0/r;->a:LL0/F0;

    invoke-virtual {p0}, La0/r;->Z()V

    iget-boolean v4, p0, La0/r;->S:Z

    if-eqz v4, :cond_0

    invoke-virtual {p0, v3}, La0/r;->k(Lr7/a;)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La0/r;->j0()V

    :goto_0
    sget-object v3, LL0/i;->e:LL0/h;

    invoke-static {p0, v0, v3}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v0, LL0/i;->d:LL0/h;

    invoke-static {p0, v2, v0}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v0, LL0/i;->c:LL0/h;

    invoke-static {p0, p1, v0}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object p1, LL0/i;->f:LL0/h;

    iget-boolean v0, p0, La0/r;->S:Z

    if-nez v0, :cond_1

    invoke-virtual {p0}, La0/r;->K()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v0, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    :cond_1
    invoke-static {v1, p0, v1, p1}, Lq3/h;->n(ILa0/r;ILL0/h;)V

    :cond_2
    const/4 p1, 0x1

    invoke-virtual {p0, p1}, La0/r;->p(Z)V

    return-void
.end method

.method public static final c(LJ0/L;)LA/Y;
    .locals 1

    invoke-interface {p0}, LJ0/L;->G()Ljava/lang/Object;

    move-result-object p0

    instance-of v0, p0, LA/Y;

    if-eqz v0, :cond_0

    check-cast p0, LA/Y;

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static final d(LA/Y;)F
    .locals 0

    if-eqz p0, :cond_0

    iget p0, p0, LA/Y;->a:F

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public static e(LA/X;IIIIILJ0/O;Ljava/util/List;[LJ0/Y;I)LJ0/N;
    .locals 22

    move-object/from16 v0, p0

    move/from16 v1, p3

    move/from16 v2, p4

    move/from16 v3, p5

    move-object/from16 v4, p7

    move/from16 v5, p9

    int-to-long v6, v3

    new-array v8, v5, [I

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    :goto_0
    if-ge v11, v5, :cond_5

    invoke-interface {v4, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v9, v17

    check-cast v9, LJ0/L;

    invoke-static {v9}, LA/d;->c(LJ0/L;)LA/Y;

    move-result-object v17

    invoke-static/range {v17 .. v17}, LA/d;->d(LA/Y;)F

    move-result v17

    cmpl-float v18, v17, v16

    if-lez v18, :cond_0

    add-float v15, v15, v17

    add-int/lit8 v12, v12, 0x1

    move-wide/from16 v18, v6

    move/from16 v20, v11

    goto :goto_5

    :cond_0
    sub-int v14, v1, v13

    aget-object v17, p8, v11

    move-wide/from16 v18, v6

    if-nez v17, :cond_3

    const v6, 0x7fffffff

    if-ne v1, v6, :cond_1

    move/from16 v20, v11

    move/from16 v21, v12

    const v6, 0x7fffffff

    :goto_1
    const/4 v7, 0x0

    goto :goto_2

    :cond_1
    move/from16 v20, v11

    move/from16 v21, v12

    if-gez v14, :cond_2

    const/4 v6, 0x0

    goto :goto_1

    :cond_2
    move v6, v14

    goto :goto_1

    :goto_2
    invoke-interface {v0, v7, v6, v2, v7}, LA/X;->b(IIIZ)J

    move-result-wide v11

    invoke-interface {v9, v11, v12}, LJ0/L;->D(J)LJ0/Y;

    move-result-object v17

    :goto_3
    move-object/from16 v6, v17

    goto :goto_4

    :cond_3
    move/from16 v20, v11

    move/from16 v21, v12

    goto :goto_3

    :goto_4
    invoke-interface {v0, v6}, LA/X;->a(LJ0/Y;)I

    move-result v7

    invoke-interface {v0, v6}, LA/X;->i(LJ0/Y;)I

    move-result v9

    aput v7, v8, v20

    sub-int v11, v14, v7

    if-gez v11, :cond_4

    const/4 v11, 0x0

    :cond_4
    invoke-static {v3, v11}, Ljava/lang/Math;->min(II)I

    move-result v14

    add-int/2addr v7, v14

    add-int/2addr v13, v7

    invoke-static {v10, v9}, Ljava/lang/Math;->max(II)I

    move-result v10

    aput-object v6, p8, v20

    move/from16 v12, v21

    :goto_5
    add-int/lit8 v11, v20, 0x1

    move-wide/from16 v6, v18

    goto :goto_0

    :cond_5
    move-wide/from16 v18, v6

    move/from16 v21, v12

    if-nez v21, :cond_6

    sub-int/2addr v13, v14

    const/4 v7, 0x0

    goto/16 :goto_f

    :cond_6
    const v6, 0x7fffffff

    if-eq v1, v6, :cond_7

    move v3, v1

    goto :goto_6

    :cond_7
    move/from16 v3, p1

    :goto_6
    const/4 v6, 0x1

    add-int/lit8 v12, v21, -0x1

    int-to-long v11, v12

    mul-long v11, v11, v18

    sub-int/2addr v3, v13

    int-to-long v6, v3

    sub-long/2addr v6, v11

    const-wide/16 v18, 0x0

    cmp-long v3, v6, v18

    if-gez v3, :cond_8

    move-wide/from16 v6, v18

    :cond_8
    long-to-float v3, v6

    div-float/2addr v3, v15

    const/4 v9, 0x0

    :goto_7
    if-ge v9, v5, :cond_9

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, LJ0/L;

    invoke-static {v14}, LA/d;->c(LJ0/L;)LA/Y;

    move-result-object v14

    invoke-static {v14}, LA/d;->d(LA/Y;)F

    move-result v14

    mul-float/2addr v14, v3

    invoke-static {v14}, Ljava/lang/Math;->round(F)I

    move-result v14

    int-to-long v14, v14

    sub-long/2addr v6, v14

    add-int/lit8 v9, v9, 0x1

    goto :goto_7

    :cond_9
    move v14, v10

    const/4 v9, 0x0

    const/4 v10, 0x0

    :goto_8
    if-ge v9, v5, :cond_f

    aget-object v15, p8, v9

    if-nez v15, :cond_e

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, LJ0/L;

    invoke-static {v15}, LA/d;->c(LJ0/L;)LA/Y;

    move-result-object v1

    invoke-static {v1}, LA/d;->d(LA/Y;)F

    move-result v17

    cmpl-float v18, v17, v16

    if-lez v18, :cond_a

    :goto_9
    move/from16 v18, v3

    goto :goto_a

    :cond_a
    const-string v18, "All weights <= 0 should have placeables"

    invoke-static/range {v18 .. v18}, LB/a;->b(Ljava/lang/String;)V

    goto :goto_9

    :goto_a
    invoke-static {v6, v7}, Ljava/lang/Long;->signum(J)I

    move-result v3

    move-wide/from16 v19, v6

    int-to-long v6, v3

    sub-long v6, v19, v6

    mul-float v17, v17, v18

    invoke-static/range {v17 .. v17}, Ljava/lang/Math;->round(F)I

    move-result v17

    add-int v3, v17, v3

    const/4 v4, 0x0

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    if-eqz v1, :cond_b

    iget-boolean v1, v1, LA/Y;->b:Z

    goto :goto_b

    :cond_b
    const/4 v1, 0x1

    :goto_b
    if-eqz v1, :cond_c

    const v1, 0x7fffffff

    if-eq v3, v1, :cond_d

    move v4, v3

    :goto_c
    const/4 v1, 0x1

    goto :goto_d

    :cond_c
    const v1, 0x7fffffff

    :cond_d
    const/4 v4, 0x0

    goto :goto_c

    :goto_d
    invoke-interface {v0, v4, v3, v2, v1}, LA/X;->b(IIIZ)J

    move-result-wide v3

    invoke-interface {v15, v3, v4}, LJ0/L;->D(J)LJ0/Y;

    move-result-object v3

    invoke-interface {v0, v3}, LA/X;->a(LJ0/Y;)I

    move-result v4

    invoke-interface {v0, v3}, LA/X;->i(LJ0/Y;)I

    move-result v15

    aput v4, v8, v9

    add-int/2addr v10, v4

    invoke-static {v14, v15}, Ljava/lang/Math;->max(II)I

    move-result v4

    aput-object v3, p8, v9

    move v14, v4

    goto :goto_e

    :cond_e
    move/from16 v18, v3

    move-wide/from16 v19, v6

    const/4 v1, 0x1

    :goto_e
    add-int/lit8 v9, v9, 0x1

    move/from16 v1, p3

    move-object/from16 v4, p7

    move/from16 v3, v18

    goto :goto_8

    :cond_f
    int-to-long v1, v10

    add-long/2addr v1, v11

    long-to-int v7, v1

    sub-int v1, p3, v13

    if-gez v7, :cond_10

    const/4 v7, 0x0

    :cond_10
    if-le v7, v1, :cond_11

    move v7, v1

    :cond_11
    move v10, v14

    :goto_f
    add-int/2addr v7, v13

    if-gez v7, :cond_12

    const/4 v7, 0x0

    :cond_12
    move/from16 v1, p1

    invoke-static {v7, v1}, Ljava/lang/Math;->max(II)I

    move-result v4

    move/from16 v1, p2

    const/4 v7, 0x0

    invoke-static {v1, v7}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v10, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    new-array v3, v5, [I

    move-object/from16 v2, p6

    invoke-interface {v0, v4, v2, v8, v3}, LA/X;->f(ILJ0/O;[I[I)V

    move v5, v1

    move-object/from16 v1, p8

    invoke-interface/range {v0 .. v5}, LA/X;->j([LJ0/Y;LJ0/O;[III)LJ0/N;

    move-result-object v0

    return-object v0
.end method

.method public static final f(Lm0/r;)Lm0/r;
    .locals 2

    new-instance v0, LA/n0;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, LA/n0;-><init>(I)V

    invoke-static {p0, v0}, Lm0/a;->a(Lm0/r;Lr7/f;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final g(Lt1/b;)LA/J;
    .locals 4

    new-instance v0, LA/J;

    iget v1, p0, Lt1/b;->a:I

    iget v2, p0, Lt1/b;->b:I

    iget v3, p0, Lt1/b;->c:I

    iget p0, p0, Lt1/b;->d:I

    invoke-direct {v0, v1, v2, v3, p0}, LA/J;-><init>(IIII)V

    return-object v0
.end method

.method public static final h(Ljava/lang/String;Ljava/lang/StringBuilder;)V
    .locals 1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-lez v0, :cond_0

    const/16 v0, 0x2b

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_0
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void
.end method


# virtual methods
.method public abstract b(ILj1/m;)I
.end method
