.class public final LA/j0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/G;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    iput p1, p0, LA/j0;->a:I

    iput-object p2, p0, LA/j0;->b:Ljava/lang/Object;

    iput-object p3, p0, LA/j0;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 5

    iget v0, p0, LA/j0;->a:I

    const/4 v1, 0x0

    iget-object v2, p0, LA/j0;->c:Ljava/lang/Object;

    iget-object v3, p0, LA/j0;->b:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_0

    check-cast v3, Ls/w0;

    check-cast v2, Ls/t0;

    iget-object v0, v3, Ls/w0;->i:Lk0/o;

    invoke-virtual {v0, v2}, Lk0/o;->remove(Ljava/lang/Object;)Z

    return-void

    :pswitch_0
    check-cast v3, Ls/w0;

    check-cast v2, Ls/q0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v2, Ls/q0;->b:La0/h0;

    invoke-virtual {v0}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ls/p0;

    if-eqz v0, :cond_0

    iget-object v0, v0, Ls/p0;->t:Ls/t0;

    iget-object v1, v3, Ls/w0;->i:Lk0/o;

    invoke-virtual {v1, v0}, Lk0/o;->remove(Ljava/lang/Object;)Z

    :cond_0
    return-void

    :pswitch_1
    check-cast v3, Ls/w0;

    check-cast v2, Ls/w0;

    iget-object v0, v3, Ls/w0;->j:Lk0/o;

    invoke-virtual {v0, v2}, Lk0/o;->remove(Ljava/lang/Object;)Z

    return-void

    :pswitch_2
    check-cast v3, Ls/H;

    check-cast v2, Ls/E;

    iget-object v0, v3, Ls/H;->a:Lc0/e;

    invoke-virtual {v0, v2}, Lc0/e;->l(Ljava/lang/Object;)Z

    return-void

    :pswitch_3
    check-cast v3, La0/W0;

    invoke-interface {v3}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lb2/e;

    move-object v3, v2

    check-cast v3, Lc2/i;

    invoke-virtual {v3}, Lb2/y;->b()Lb2/h;

    move-result-object v3

    invoke-virtual {v3, v1}, Lb2/h;->c(Lb2/e;)V

    goto :goto_0

    :cond_1
    return-void

    :pswitch_4
    check-cast v3, Lb2/e;

    iget-object v0, v3, Lb2/e;->A:Le2/c;

    iget-object v0, v0, Le2/c;->j:Landroidx/lifecycle/y;

    check-cast v2, Lc2/k;

    invoke-virtual {v0, v2}, Landroidx/lifecycle/y;->z(Landroidx/lifecycle/v;)V

    return-void

    :pswitch_5
    check-cast v3, Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    check-cast v2, LM0/S;

    invoke-virtual {v0, v2}, Landroid/content/Context;->unregisterComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    return-void

    :pswitch_6
    check-cast v3, Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    check-cast v2, LM0/Q;

    invoke-virtual {v0, v2}, Landroid/content/Context;->unregisterComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    return-void

    :pswitch_7
    check-cast v3, LI/I0;

    iget-object v0, v3, LI/I0;->c:Lk0/o;

    check-cast v2, Lr7/c;

    invoke-interface {v0, v2}, Ljava/util/Collection;->remove(Ljava/lang/Object;)Z

    return-void

    :pswitch_8
    check-cast v3, La0/Z;

    invoke-interface {v3}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ly/l;

    if-eqz v0, :cond_3

    new-instance v4, Ly/k;

    invoke-direct {v4, v0}, Ly/k;-><init>(Ly/l;)V

    check-cast v2, Ly/j;

    if-eqz v2, :cond_2

    invoke-virtual {v2, v4}, Ly/j;->b(Ly/i;)V

    :cond_2
    invoke-interface {v3, v1}, La0/Z;->setValue(Ljava/lang/Object;)V

    :cond_3
    return-void

    :pswitch_9
    check-cast v3, LE/q0;

    iget-object v0, v3, LE/q0;->v:Lp/I;

    invoke-virtual {v0, v2}, Lp/I;->j(Ljava/lang/Object;)V

    return-void

    :pswitch_a
    check-cast v3, LA/k0;

    check-cast v2, Landroid/view/View;

    iget v0, v3, LA/k0;->t:I

    add-int/lit8 v0, v0, -0x1

    iput v0, v3, LA/k0;->t:I

    if-nez v0, :cond_4

    sget-object v0, LA1/J;->a:Ljava/lang/reflect/Field;

    invoke-static {v2, v1}, LA1/D;->g(Landroid/view/View;LA1/n;)V

    invoke-static {v2, v1}, LA1/J;->f(Landroid/view/View;LA1/M;)V

    iget-object v0, v3, LA/k0;->u:LA/F;

    invoke-virtual {v2, v0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :cond_4
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
