.class public final LA/F;
.super LA1/M;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;
.implements LA1/n;
.implements Landroid/view/View$OnAttachStateChangeListener;


# instance fields
.field public final v:LA/k0;

.field public w:Z

.field public x:Z

.field public y:LA1/q0;


# direct methods
.method public constructor <init>(LA/k0;)V
    .locals 1

    iget-boolean v0, p1, LA/k0;->s:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-direct {p0, v0}, LA1/M;-><init>(I)V

    iput-object p1, p0, LA/F;->v:LA/k0;

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;LA1/q0;)LA1/q0;
    .locals 5

    iput-object p2, p0, LA/F;->y:LA1/q0;

    iget-object v0, p0, LA/F;->v:LA/k0;

    iget-object v1, v0, LA/k0;->q:LA/g0;

    iget-object v2, p2, LA1/q0;->a:LA1/l0;

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, LA1/l0;->g(I)Lt1/b;

    move-result-object v4

    invoke-static {v4}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object v4

    invoke-virtual {v1, v4}, LA/g0;->f(LA/J;)V

    iget-boolean v1, p0, LA/F;->w:Z

    if-eqz v1, :cond_0

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1e

    if-ne v1, v2, :cond_1

    invoke-virtual {p1, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto :goto_0

    :cond_0
    iget-boolean p1, p0, LA/F;->x:Z

    if-nez p1, :cond_1

    iget-object p1, v0, LA/k0;->r:LA/g0;

    invoke-virtual {v2, v3}, LA1/l0;->g(I)Lt1/b;

    move-result-object v1

    invoke-static {v1}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object v1

    invoke-virtual {p1, v1}, LA/g0;->f(LA/J;)V

    invoke-static {v0, p2}, LA/k0;->a(LA/k0;LA1/q0;)V

    :cond_1
    :goto_0
    iget-boolean p1, v0, LA/k0;->s:Z

    if-eqz p1, :cond_2

    sget-object p1, LA1/q0;->b:LA1/q0;

    return-object p1

    :cond_2
    return-object p2
.end method

.method public final e(LA1/W;)V
    .locals 5

    const/4 v0, 0x0

    iput-boolean v0, p0, LA/F;->w:Z

    iput-boolean v0, p0, LA/F;->x:Z

    iget-object v0, p0, LA/F;->y:LA1/q0;

    iget-object p1, p1, LA1/W;->a:LA1/V;

    invoke-virtual {p1}, LA1/V;->b()J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long p1, v1, v3

    if-lez p1, :cond_0

    if-eqz v0, :cond_0

    iget-object p1, v0, LA1/q0;->a:LA1/l0;

    iget-object v1, p0, LA/F;->v:LA/k0;

    iget-object v2, v1, LA/k0;->r:LA/g0;

    const/16 v3, 0x8

    invoke-virtual {p1, v3}, LA1/l0;->g(I)Lt1/b;

    move-result-object v4

    invoke-static {v4}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object v4

    invoke-virtual {v2, v4}, LA/g0;->f(LA/J;)V

    iget-object v2, v1, LA/k0;->q:LA/g0;

    invoke-virtual {p1, v3}, LA1/l0;->g(I)Lt1/b;

    move-result-object p1

    invoke-static {p1}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object p1

    invoke-virtual {v2, p1}, LA/g0;->f(LA/J;)V

    invoke-static {v1, v0}, LA/k0;->a(LA/k0;LA1/q0;)V

    :cond_0
    const/4 p1, 0x0

    iput-object p1, p0, LA/F;->y:LA1/q0;

    return-void
.end method

.method public final f()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, LA/F;->w:Z

    iput-boolean v0, p0, LA/F;->x:Z

    return-void
.end method

.method public final g(LA1/q0;Ljava/util/List;)LA1/q0;
    .locals 0

    iget-object p2, p0, LA/F;->v:LA/k0;

    invoke-static {p2, p1}, LA/k0;->a(LA/k0;LA1/q0;)V

    iget-boolean p2, p2, LA/k0;->s:Z

    if-eqz p2, :cond_0

    sget-object p1, LA1/q0;->b:LA1/q0;

    :cond_0
    return-object p1
.end method

.method public final h(LA1/W;LP2/c;)LP2/c;
    .locals 0

    const/4 p1, 0x0

    iput-boolean p1, p0, LA/F;->w:Z

    return-object p2
.end method

.method public final onViewAttachedToWindow(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p1}, Landroid/view/View;->requestApplyInsets()V

    return-void
.end method

.method public final onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public final run()V
    .locals 5

    iget-boolean v0, p0, LA/F;->w:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    iput-boolean v0, p0, LA/F;->w:Z

    iput-boolean v0, p0, LA/F;->x:Z

    iget-object v0, p0, LA/F;->y:LA1/q0;

    if-eqz v0, :cond_0

    iget-object v1, p0, LA/F;->v:LA/k0;

    iget-object v2, v1, LA/k0;->r:LA/g0;

    const/16 v3, 0x8

    iget-object v4, v0, LA1/q0;->a:LA1/l0;

    invoke-virtual {v4, v3}, LA1/l0;->g(I)Lt1/b;

    move-result-object v3

    invoke-static {v3}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object v3

    invoke-virtual {v2, v3}, LA/g0;->f(LA/J;)V

    invoke-static {v1, v0}, LA/k0;->a(LA/k0;LA1/q0;)V

    const/4 v0, 0x0

    iput-object v0, p0, LA/F;->y:LA1/q0;

    :cond_0
    return-void
.end method
