.class public final synthetic LA/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Lm0/r;

.field public final synthetic v:I


# direct methods
.method public synthetic constructor <init>(Lm0/r;I)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, LA/n;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/n;->u:Lm0/r;

    iput p2, p0, LA/n;->v:I

    return-void
.end method

.method public synthetic constructor <init>(Lm0/r;III)V
    .locals 0

    .line 2
    iput p4, p0, LA/n;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/n;->u:Lm0/r;

    packed-switch p4, :pswitch_data_0

    iput p3, p0, LA/n;->v:I

    return-void

    :pswitch_0
    iput p2, p0, LA/n;->v:I

    return-void

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    iget v0, p0, LA/n;->t:I

    check-cast p1, La0/r;

    check-cast p2, Ljava/lang/Integer;

    packed-switch v0, :pswitch_data_0

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p2, 0x1

    invoke-static {p2}, La0/b;->B(I)I

    move-result p2

    iget v0, p0, LA/n;->v:I

    iget-object v1, p0, LA/n;->u:Lm0/r;

    invoke-static {v0, p2, p1, v1}, LH4/T5;->a(IILa0/r;Lm0/r;)V

    :goto_0
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_0
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p2, 0x1

    invoke-static {p2}, La0/b;->B(I)I

    move-result p2

    iget v0, p0, LA/n;->v:I

    iget-object v1, p0, LA/n;->u:Lm0/r;

    invoke-static {p2, v0, p1, v1}, LI/c;->b(IILa0/r;Lm0/r;)V

    goto :goto_0

    :pswitch_1
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    iget p2, p0, LA/n;->v:I

    or-int/lit8 p2, p2, 0x1

    invoke-static {p2}, La0/b;->B(I)I

    move-result p2

    iget-object v0, p0, LA/n;->u:Lm0/r;

    invoke-static {v0, p1, p2}, LA/p;->a(Lm0/r;La0/r;I)V

    goto :goto_0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
