.class public final LA/H;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJ0/x;
.implements LK0/c;
.implements Lm0/p;


# instance fields
.field public final a:LA/i0;

.field public final b:La0/h0;

.field public final c:La0/h0;


# direct methods
.method public constructor <init>(LA/i0;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/H;->a:LA/i0;

    invoke-static {p1}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v0

    iput-object v0, p0, LA/H;->b:La0/h0;

    invoke-static {p1}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object p1

    iput-object p1, p0, LA/H;->c:La0/h0;

    return-void
.end method


# virtual methods
.method public final c(LJ0/O;LJ0/L;J)LJ0/N;
    .locals 6

    iget-object v0, p0, LA/H;->b:La0/h0;

    invoke-virtual {v0}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LA/i0;

    invoke-interface {p1}, LJ0/q;->getLayoutDirection()Lj1/m;

    move-result-object v2

    invoke-interface {v1, p1, v2}, LA/i0;->a(Lj1/c;Lj1/m;)I

    move-result v1

    invoke-virtual {v0}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LA/i0;

    invoke-interface {v2, p1}, LA/i0;->c(Lj1/c;)I

    move-result v2

    invoke-virtual {v0}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LA/i0;

    invoke-interface {p1}, LJ0/q;->getLayoutDirection()Lj1/m;

    move-result-object v4

    invoke-interface {v3, p1, v4}, LA/i0;->b(Lj1/c;Lj1/m;)I

    move-result v3

    invoke-virtual {v0}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LA/i0;

    invoke-interface {v0, p1}, LA/i0;->d(Lj1/c;)I

    move-result v0

    add-int/2addr v3, v1

    add-int/2addr v0, v2

    neg-int v4, v3

    neg-int v5, v0

    invoke-static {v4, v5, p3, p4}, Lj1/b;->i(IIJ)J

    move-result-wide v4

    invoke-interface {p2, v4, v5}, LJ0/L;->D(J)LJ0/Y;

    move-result-object p2

    iget v4, p2, LJ0/Y;->t:I

    add-int/2addr v4, v3

    invoke-static {v4, p3, p4}, Lj1/b;->g(IJ)I

    move-result v3

    iget v4, p2, LJ0/Y;->u:I

    add-int/2addr v4, v0

    invoke-static {v4, p3, p4}, Lj1/b;->f(IJ)I

    move-result p3

    new-instance p4, LA/G;

    const/4 v0, 0x0

    invoke-direct {p4, p2, v1, v2, v0}, LA/G;-><init>(Ljava/lang/Object;III)V

    sget-object p2, Le7/u;->t:Le7/u;

    invoke-interface {p1, v3, p3, p2, p4}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    if-ne p0, p1, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    instance-of v0, p1, LA/H;

    if-nez v0, :cond_1

    const/4 p1, 0x0

    return p1

    :cond_1
    check-cast p1, LA/H;

    iget-object p1, p1, LA/H;->a:LA/i0;

    iget-object v0, p0, LA/H;->a:LA/i0;

    invoke-static {p1, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final f(LK0/f;)V
    .locals 3

    sget-object v0, LA/d;->c:LK0/g;

    invoke-interface {p1, v0}, LK0/f;->e(LK0/g;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LA/i0;

    new-instance v0, LA/B;

    iget-object v1, p0, LA/H;->a:LA/i0;

    invoke-direct {v0, v1, p1}, LA/B;-><init>(LA/i0;LA/i0;)V

    iget-object v2, p0, LA/H;->b:La0/h0;

    invoke-virtual {v2, v0}, La0/h0;->setValue(Ljava/lang/Object;)V

    new-instance v0, LA/e0;

    invoke-direct {v0, p1, v1}, LA/e0;-><init>(LA/i0;LA/i0;)V

    iget-object p1, p0, LA/H;->c:La0/h0;

    invoke-virtual {p1, v0}, La0/h0;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, LA/H;->a:LA/i0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method
