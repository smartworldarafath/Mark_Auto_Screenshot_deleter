.class public final synthetic LA/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:LJ0/Y;


# direct methods
.method public synthetic constructor <init>(LJ0/Y;I)V
    .locals 0

    iput p2, p0, LA/k;->t:I

    iput-object p1, p0, LA/k;->u:LJ0/Y;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    iget v0, p0, LA/k;->t:I

    check-cast p1, LJ0/X;

    packed-switch v0, :pswitch_data_0

    const/4 v0, 0x0

    iget-object v1, p0, LA/k;->u:LJ0/Y;

    invoke-static {p1, v1, v0, v0}, LJ0/X;->j(LJ0/X;LJ0/Y;II)V

    :goto_0
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_0
    const/4 v0, 0x0

    iget-object v1, p0, LA/k;->u:LJ0/Y;

    invoke-static {p1, v1, v0, v0}, LJ0/X;->j(LJ0/X;LJ0/Y;II)V

    goto :goto_0

    :pswitch_1
    const/4 v0, 0x0

    iget-object v1, p0, LA/k;->u:LJ0/Y;

    invoke-static {p1, v1, v0, v0}, LJ0/X;->l(LJ0/X;LJ0/Y;II)V

    goto :goto_0

    :pswitch_2
    const/4 v0, 0x0

    iget-object v1, p0, LA/k;->u:LJ0/Y;

    invoke-static {p1, v1, v0, v0}, LJ0/X;->j(LJ0/X;LJ0/Y;II)V

    goto :goto_0

    :pswitch_3
    const/4 v0, 0x0

    iget-object v1, p0, LA/k;->u:LJ0/Y;

    invoke-static {p1, v1, v0, v0}, LJ0/X;->l(LJ0/X;LJ0/Y;II)V

    goto :goto_0

    :pswitch_4
    const/4 v0, 0x0

    iget-object v1, p0, LA/k;->u:LJ0/Y;

    invoke-static {p1, v1, v0, v0}, LJ0/X;->l(LJ0/X;LJ0/Y;II)V

    goto :goto_0

    :pswitch_5
    invoke-virtual {p1}, LJ0/X;->e()Lj1/m;

    move-result-object v0

    sget-object v1, Lj1/m;->t:Lj1/m;

    iget-object v2, p0, LA/k;->u:LJ0/Y;

    const-wide/16 v3, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eq v0, v1, :cond_1

    invoke-virtual {p1}, LJ0/X;->g()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p1}, LJ0/X;->g()I

    move-result v0

    iget v1, v2, LJ0/Y;->t:I

    sub-int/2addr v0, v1

    long-to-int v1, v3

    sub-int/2addr v0, v1

    int-to-long v3, v0

    const/16 v0, 0x20

    shl-long/2addr v3, v0

    int-to-long v0, v1

    const-wide v7, 0xffffffffL

    and-long/2addr v0, v7

    or-long/2addr v0, v3

    invoke-static {p1, v2}, LJ0/X;->b(LJ0/X;LJ0/Y;)V

    iget-wide v3, v2, LJ0/Y;->x:J

    invoke-static {v0, v1, v3, v4}, Lj1/j;->d(JJ)J

    move-result-wide v0

    invoke-virtual {v2, v0, v1, v5, v6}, LJ0/Y;->g0(JFLr7/c;)V

    goto :goto_2

    :cond_1
    :goto_1
    invoke-static {p1, v2}, LJ0/X;->b(LJ0/X;LJ0/Y;)V

    iget-wide v0, v2, LJ0/Y;->x:J

    invoke-static {v3, v4, v0, v1}, Lj1/j;->d(JJ)J

    move-result-wide v0

    invoke-virtual {v2, v0, v1, v5, v6}, LJ0/Y;->g0(JFLr7/c;)V

    :goto_2
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_6
    const/4 v0, 0x0

    iget-object v1, p0, LA/k;->u:LJ0/Y;

    invoke-static {p1, v1, v0, v0}, LJ0/X;->l(LJ0/X;LJ0/Y;II)V

    goto :goto_0

    :pswitch_7
    const/4 v0, 0x0

    iget-object v1, p0, LA/k;->u:LJ0/Y;

    invoke-static {p1, v1, v0, v0}, LJ0/X;->l(LJ0/X;LJ0/Y;II)V

    goto :goto_0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
