.class public final LA/T;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/z;


# instance fields
.field public H:F

.field public I:F

.field public J:F

.field public K:F

.field public L:Z


# virtual methods
.method public final c(LJ0/O;LJ0/L;J)LJ0/N;
    .locals 5

    iget v0, p0, LA/T;->H:F

    invoke-interface {p1, v0}, Lj1/c;->j0(F)I

    move-result v0

    iget v1, p0, LA/T;->J:F

    invoke-interface {p1, v1}, Lj1/c;->j0(F)I

    move-result v1

    add-int/2addr v1, v0

    iget v0, p0, LA/T;->I:F

    invoke-interface {p1, v0}, Lj1/c;->j0(F)I

    move-result v0

    iget v2, p0, LA/T;->K:F

    invoke-interface {p1, v2}, Lj1/c;->j0(F)I

    move-result v2

    add-int/2addr v2, v0

    neg-int v0, v1

    neg-int v3, v2

    invoke-static {v0, v3, p3, p4}, Lj1/b;->i(IIJ)J

    move-result-wide v3

    invoke-interface {p2, v3, v4}, LJ0/L;->D(J)LJ0/Y;

    move-result-object p2

    iget v0, p2, LJ0/Y;->t:I

    add-int/2addr v0, v1

    invoke-static {v0, p3, p4}, Lj1/b;->g(IJ)I

    move-result v0

    iget v1, p2, LJ0/Y;->u:I

    add-int/2addr v1, v2

    invoke-static {v1, p3, p4}, Lj1/b;->f(IJ)I

    move-result p3

    new-instance p4, LA/Q;

    const/4 v1, 0x1

    invoke-direct {p4, v1, p0, p2}, LA/Q;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    sget-object p2, Le7/u;->t:Le7/u;

    invoke-interface {p1, v0, p3, p2, p4}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1
.end method
