.class public final LA/O;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/t0;


# instance fields
.field public H:F

.field public I:Z


# virtual methods
.method public final A(Lj1/c;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    instance-of p1, p2, LA/Y;

    if-eqz p1, :cond_0

    check-cast p2, LA/Y;

    goto :goto_0

    :cond_0
    const/4 p2, 0x0

    :goto_0
    if-nez p2, :cond_1

    new-instance p2, LA/Y;

    invoke-direct {p2}, LA/Y;-><init>()V

    :cond_1
    iget p1, p0, LA/O;->H:F

    iput p1, p2, LA/Y;->a:F

    iget-boolean p1, p0, LA/O;->I:Z

    iput-boolean p1, p2, LA/Y;->b:Z

    return-object p2
.end method
