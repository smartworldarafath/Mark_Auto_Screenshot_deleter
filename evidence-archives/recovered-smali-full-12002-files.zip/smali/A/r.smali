.class public final synthetic LA/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:[LJ0/Y;

.field public final synthetic u:Ljava/util/List;

.field public final synthetic v:LJ0/O;

.field public final synthetic w:Ls7/s;

.field public final synthetic x:Ls7/s;

.field public final synthetic y:LA/s;


# direct methods
.method public synthetic constructor <init>([LJ0/Y;Ljava/util/List;LJ0/O;Ls7/s;Ls7/s;LA/s;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/r;->t:[LJ0/Y;

    iput-object p2, p0, LA/r;->u:Ljava/util/List;

    iput-object p3, p0, LA/r;->v:LJ0/O;

    iput-object p4, p0, LA/r;->w:Ls7/s;

    iput-object p5, p0, LA/r;->x:Ls7/s;

    iput-object p6, p0, LA/r;->y:LA/s;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    move-object v0, p1

    check-cast v0, LJ0/X;

    iget-object p1, p0, LA/r;->t:[LJ0/Y;

    array-length v7, p1

    const/4 v1, 0x0

    move v8, v1

    :goto_0
    if-ge v8, v7, :cond_0

    move v2, v1

    aget-object v1, p1, v8

    add-int/lit8 v9, v2, 0x1

    const-string v3, "null cannot be cast to non-null type androidx.compose.ui.layout.Placeable"

    invoke-static {v1, v3}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v3, p0, LA/r;->u:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LJ0/L;

    iget-object v3, p0, LA/r;->v:LJ0/O;

    invoke-interface {v3}, LJ0/q;->getLayoutDirection()Lj1/m;

    move-result-object v3

    iget-object v4, p0, LA/r;->w:Ls7/s;

    iget v4, v4, Ls7/s;->t:I

    iget-object v5, p0, LA/r;->x:Ls7/s;

    iget v5, v5, Ls7/s;->t:I

    iget-object v6, p0, LA/r;->y:LA/s;

    iget-object v6, v6, LA/s;->a:Lm0/j;

    invoke-static/range {v0 .. v6}, LA/p;->b(LJ0/X;LJ0/Y;LJ0/L;Lj1/m;IILm0/j;)V

    add-int/lit8 v8, v8, 0x1

    move v1, v9

    goto :goto_0

    :cond_0
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1
.end method
