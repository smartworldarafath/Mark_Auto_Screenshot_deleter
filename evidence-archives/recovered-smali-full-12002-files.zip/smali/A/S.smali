.class public final LA/S;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/z;


# instance fields
.field public H:F

.field public I:F

.field public J:Z


# virtual methods
.method public final c(LJ0/O;LJ0/L;J)LJ0/N;
    .locals 2

    invoke-interface {p2, p3, p4}, LJ0/L;->D(J)LJ0/Y;

    move-result-object p2

    iget p3, p2, LJ0/Y;->t:I

    iget p4, p2, LJ0/Y;->u:I

    new-instance v0, LA/Q;

    const/4 v1, 0x0

    invoke-direct {v0, v1, p0, p2}, LA/Q;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    sget-object p2, Le7/u;->t:Le7/u;

    invoke-interface {p1, p3, p4, p2, v0}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1
.end method

.method public final z0()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
