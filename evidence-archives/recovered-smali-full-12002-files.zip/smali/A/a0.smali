.class public final synthetic LA/a0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:I

.field public final synthetic v:Ljava/lang/Object;

.field public final synthetic w:Ljava/lang/Object;

.field public final synthetic x:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
    .locals 0

    .line 1
    iput p5, p0, LA/a0;->t:I

    iput-object p1, p0, LA/a0;->v:Ljava/lang/Object;

    iput-object p2, p0, LA/a0;->w:Ljava/lang/Object;

    iput-object p3, p0, LA/a0;->x:Ljava/lang/Object;

    iput p4, p0, LA/a0;->u:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>([LJ0/Y;LA/b0;I[I)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    iput v0, p0, LA/a0;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/a0;->v:Ljava/lang/Object;

    iput-object p2, p0, LA/a0;->w:Ljava/lang/Object;

    iput p3, p0, LA/a0;->u:I

    iput-object p4, p0, LA/a0;->x:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    iget v0, p0, LA/a0;->t:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LA/a0;->v:Ljava/lang/Object;

    check-cast v0, La0/E;

    iget-object v1, p0, LA/a0;->w:Ljava/lang/Object;

    check-cast v1, Li0/e;

    iget-object v2, p0, LA/a0;->x:Ljava/lang/Object;

    check-cast v2, Lp/C;

    if-eq p1, v0, :cond_2

    instance-of v0, p1, Lk0/t;

    if-eqz v0, :cond_1

    iget v0, v1, Li0/e;->a:I

    iget v1, p0, LA/a0;->u:I

    sub-int/2addr v0, v1

    invoke-virtual {v2, p1}, Lp/C;->d(Ljava/lang/Object;)I

    move-result v1

    if-ltz v1, :cond_0

    iget-object v3, v2, Lp/C;->c:[I

    aget v1, v3, v1

    goto :goto_0

    :cond_0
    const v1, 0x7fffffff

    :goto_0
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-virtual {v2, v0, p1}, Lp/C;->h(ILjava/lang/Object;)V

    :cond_1
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "A derived state calculation cannot read itself"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :pswitch_0
    iget-object v0, p0, LA/a0;->v:Ljava/lang/Object;

    check-cast v0, LI/Q;

    iget-object v1, p0, LA/a0;->w:Ljava/lang/Object;

    check-cast v1, LJ0/O;

    iget-object v2, p0, LA/a0;->x:Ljava/lang/Object;

    check-cast v2, LJ0/Y;

    move-object v3, p1

    check-cast v3, LJ0/X;

    iget v4, v0, LI/Q;->b:I

    iget-object p1, v0, LI/Q;->a:LI/D0;

    iget-object v5, v0, LI/Q;->c:Lc1/C;

    iget-object v0, v0, LI/Q;->d:Lr7/a;

    invoke-interface {v0}, Lr7/a;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LI/F0;

    if-eqz v0, :cond_3

    iget-object v0, v0, LI/F0;->a:LW0/I;

    :goto_1
    move-object v6, v0

    goto :goto_2

    :cond_3
    const/4 v0, 0x0

    goto :goto_1

    :goto_2
    invoke-interface {v1}, LJ0/q;->getLayoutDirection()Lj1/m;

    move-result-object v0

    sget-object v1, Lj1/m;->u:Lj1/m;

    const/4 v9, 0x0

    if-ne v0, v1, :cond_4

    const/4 v0, 0x1

    move v7, v0

    goto :goto_3

    :cond_4
    move v7, v9

    :goto_3
    iget v8, v2, LJ0/Y;->t:I

    invoke-static/range {v3 .. v8}, LI/W;->k(LJ0/X;ILc1/C;LW0/I;ZI)Ls0/c;

    move-result-object v0

    sget-object v1, Lw/h0;->u:Lw/h0;

    iget v4, v2, LJ0/Y;->t:I

    iget v5, p0, LA/a0;->u:I

    invoke-virtual {p1, v1, v0, v5, v4}, LI/D0;->a(Lw/h0;Ls0/c;II)V

    iget-object p1, p1, LI/D0;->a:La0/d0;

    invoke-virtual {p1}, La0/d0;->h()F

    move-result p1

    neg-float p1, p1

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-static {v3, v2, p1, v9}, LJ0/X;->l(LJ0/X;LJ0/Y;II)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_1
    iget-object v0, p0, LA/a0;->v:Ljava/lang/Object;

    check-cast v0, [LJ0/Y;

    iget-object v1, p0, LA/a0;->w:Ljava/lang/Object;

    check-cast v1, LA/b0;

    iget-object v2, p0, LA/a0;->x:Ljava/lang/Object;

    check-cast v2, [I

    check-cast p1, LJ0/X;

    array-length v3, v0

    const/4 v4, 0x0

    move v5, v4

    move v6, v5

    :goto_4
    if-ge v5, v3, :cond_8

    aget-object v7, v0, v5

    add-int/lit8 v8, v6, 0x1

    invoke-static {v7}, Ls7/j;->b(Ljava/lang/Object;)V

    invoke-virtual {v7}, LJ0/Y;->G()Ljava/lang/Object;

    move-result-object v9

    instance-of v10, v9, LA/Y;

    const/4 v11, 0x0

    if-eqz v10, :cond_5

    check-cast v9, LA/Y;

    goto :goto_5

    :cond_5
    move-object v9, v11

    :goto_5
    if-eqz v9, :cond_6

    iget-object v11, v9, LA/Y;->c:LA/d;

    :cond_6
    iget v9, p0, LA/a0;->u:I

    if-eqz v11, :cond_7

    iget v10, v7, LJ0/Y;->u:I

    sub-int/2addr v9, v10

    sget-object v10, Lj1/m;->t:Lj1/m;

    invoke-virtual {v11, v9, v10}, LA/d;->b(ILj1/m;)I

    move-result v9

    goto :goto_6

    :cond_7
    iget-object v10, v1, LA/b0;->b:Lm0/i;

    iget v11, v7, LJ0/Y;->u:I

    sub-int/2addr v9, v11

    invoke-virtual {v10, v4, v9}, Lm0/i;->a(II)I

    move-result v9

    :goto_6
    aget v6, v2, v6

    invoke-static {p1, v7, v6, v9}, LJ0/X;->j(LJ0/X;LJ0/Y;II)V

    add-int/lit8 v5, v5, 0x1

    move v6, v8

    goto :goto_4

    :cond_8
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
