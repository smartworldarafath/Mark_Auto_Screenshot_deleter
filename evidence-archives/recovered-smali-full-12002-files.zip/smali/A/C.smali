.class public final LA/C;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/z;


# instance fields
.field public H:LA/A;

.field public I:F


# virtual methods
.method public final c(LJ0/O;LJ0/L;J)LJ0/N;
    .locals 4

    invoke-static {p3, p4}, Lj1/a;->d(J)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, LA/C;->H:LA/A;

    sget-object v1, LA/A;->t:LA/A;

    if-eq v0, v1, :cond_2

    invoke-static {p3, p4}, Lj1/a;->h(J)I

    move-result v0

    int-to-float v0, v0

    iget v1, p0, LA/C;->I:F

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-static {p3, p4}, Lj1/a;->j(J)I

    move-result v1

    invoke-static {p3, p4}, Lj1/a;->h(J)I

    move-result v2

    if-ge v0, v1, :cond_0

    move v0, v1

    :cond_0
    if-le v0, v2, :cond_1

    goto :goto_0

    :cond_1
    move v2, v0

    :goto_0
    move v0, v2

    goto :goto_1

    :cond_2
    invoke-static {p3, p4}, Lj1/a;->j(J)I

    move-result v2

    invoke-static {p3, p4}, Lj1/a;->h(J)I

    move-result v0

    :goto_1
    invoke-static {p3, p4}, Lj1/a;->c(J)Z

    move-result v1

    if-eqz v1, :cond_5

    iget-object v1, p0, LA/C;->H:LA/A;

    sget-object v3, LA/A;->u:LA/A;

    if-eq v1, v3, :cond_5

    invoke-static {p3, p4}, Lj1/a;->g(J)I

    move-result v1

    int-to-float v1, v1

    iget v3, p0, LA/C;->I:F

    mul-float/2addr v1, v3

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-static {p3, p4}, Lj1/a;->i(J)I

    move-result v3

    invoke-static {p3, p4}, Lj1/a;->g(J)I

    move-result p3

    if-ge v1, v3, :cond_3

    move v1, v3

    :cond_3
    if-le v1, p3, :cond_4

    goto :goto_2

    :cond_4
    move p3, v1

    :goto_2
    move p4, p3

    goto :goto_3

    :cond_5
    invoke-static {p3, p4}, Lj1/a;->i(J)I

    move-result v1

    invoke-static {p3, p4}, Lj1/a;->g(J)I

    move-result p3

    move p4, p3

    move p3, v1

    :goto_3
    invoke-static {v2, v0, p3, p4}, Lj1/b;->a(IIII)J

    move-result-wide p3

    invoke-interface {p2, p3, p4}, LJ0/L;->D(J)LJ0/Y;

    move-result-object p2

    iget p3, p2, LJ0/Y;->t:I

    iget p4, p2, LJ0/Y;->u:I

    new-instance v0, LA/k;

    const/4 v1, 0x1

    invoke-direct {v0, p2, v1}, LA/k;-><init>(LJ0/Y;I)V

    sget-object p2, Le7/u;->t:Le7/u;

    invoke-interface {p1, p3, p4, p2, v0}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1
.end method
