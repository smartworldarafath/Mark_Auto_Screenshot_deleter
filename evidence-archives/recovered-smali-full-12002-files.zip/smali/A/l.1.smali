.class public final LA/l;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/z;


# instance fields
.field public H:F


# virtual methods
.method public final K0(ZJ)J
    .locals 4

    invoke-static {p2, p3}, Lj1/a;->g(J)I

    move-result v0

    const v1, 0x7fffffff

    if-eq v0, v1, :cond_1

    int-to-float v1, v0

    iget v2, p0, LA/l;->H:F

    mul-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    if-lez v1, :cond_1

    if-eqz p1, :cond_0

    invoke-static {v1, v0, p2, p3}, Landroidx/compose/foundation/layout/a;->g(IIJ)Z

    move-result p1

    if-eqz p1, :cond_1

    :cond_0
    int-to-long p1, v1

    const/16 p3, 0x20

    shl-long/2addr p1, p3

    int-to-long v0, v0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    or-long/2addr p1, v0

    return-wide p1

    :cond_1
    const-wide/16 p1, 0x0

    return-wide p1
.end method

.method public final L0(ZJ)J
    .locals 4

    invoke-static {p2, p3}, Lj1/a;->h(J)I

    move-result v0

    const v1, 0x7fffffff

    if-eq v0, v1, :cond_1

    int-to-float v1, v0

    iget v2, p0, LA/l;->H:F

    div-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    if-lez v1, :cond_1

    if-eqz p1, :cond_0

    invoke-static {v0, v1, p2, p3}, Landroidx/compose/foundation/layout/a;->g(IIJ)Z

    move-result p1

    if-eqz p1, :cond_1

    :cond_0
    int-to-long p1, v0

    const/16 p3, 0x20

    shl-long/2addr p1, p3

    int-to-long v0, v1

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    or-long/2addr p1, v0

    return-wide p1

    :cond_1
    const-wide/16 p1, 0x0

    return-wide p1
.end method

.method public final M0(ZJ)J
    .locals 4

    invoke-static {p2, p3}, Lj1/a;->i(J)I

    move-result v0

    int-to-float v1, v0

    iget v2, p0, LA/l;->H:F

    mul-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    if-lez v1, :cond_1

    if-eqz p1, :cond_0

    invoke-static {v1, v0, p2, p3}, Landroidx/compose/foundation/layout/a;->g(IIJ)Z

    move-result p1

    if-eqz p1, :cond_1

    :cond_0
    int-to-long p1, v1

    const/16 p3, 0x20

    shl-long/2addr p1, p3

    int-to-long v0, v0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    or-long/2addr p1, v0

    return-wide p1

    :cond_1
    const-wide/16 p1, 0x0

    return-wide p1
.end method

.method public final N0(ZJ)J
    .locals 4

    invoke-static {p2, p3}, Lj1/a;->j(J)I

    move-result v0

    int-to-float v1, v0

    iget v2, p0, LA/l;->H:F

    div-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    if-lez v1, :cond_1

    if-eqz p1, :cond_0

    invoke-static {v0, v1, p2, p3}, Landroidx/compose/foundation/layout/a;->g(IIJ)Z

    move-result p1

    if-eqz p1, :cond_1

    :cond_0
    int-to-long p1, v0

    const/16 p3, 0x20

    shl-long/2addr p1, p3

    int-to-long v0, v1

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    or-long/2addr p1, v0

    return-wide p1

    :cond_1
    const-wide/16 p1, 0x0

    return-wide p1
.end method

.method public final S(LL0/S;LJ0/L;I)I
    .locals 0

    const p1, 0x7fffffff

    if-eq p3, p1, :cond_0

    int-to-float p1, p3

    iget p2, p0, LA/l;->H:F

    div-float/2addr p1, p2

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1

    :cond_0
    invoke-interface {p2, p3}, LJ0/L;->U(I)I

    move-result p1

    return p1
.end method

.method public final c(LJ0/O;LJ0/L;J)LJ0/N;
    .locals 7

    const/4 v0, 0x1

    invoke-virtual {p0, v0, p3, p4}, LA/l;->L0(ZJ)J

    move-result-wide v1

    const-wide/16 v3, 0x0

    invoke-static {v1, v2, v3, v4}, Lj1/l;->a(JJ)Z

    move-result v5

    const/4 v6, 0x0

    if-nez v5, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v0, p3, p4}, LA/l;->K0(ZJ)J

    move-result-wide v1

    invoke-static {v1, v2, v3, v4}, Lj1/l;->a(JJ)Z

    move-result v5

    if-nez v5, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v0, p3, p4}, LA/l;->N0(ZJ)J

    move-result-wide v1

    invoke-static {v1, v2, v3, v4}, Lj1/l;->a(JJ)Z

    move-result v5

    if-nez v5, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {p0, v0, p3, p4}, LA/l;->M0(ZJ)J

    move-result-wide v1

    invoke-static {v1, v2, v3, v4}, Lj1/l;->a(JJ)Z

    move-result v5

    if-nez v5, :cond_3

    goto :goto_0

    :cond_3
    invoke-virtual {p0, v6, p3, p4}, LA/l;->L0(ZJ)J

    move-result-wide v1

    invoke-static {v1, v2, v3, v4}, Lj1/l;->a(JJ)Z

    move-result v5

    if-nez v5, :cond_4

    goto :goto_0

    :cond_4
    invoke-virtual {p0, v6, p3, p4}, LA/l;->K0(ZJ)J

    move-result-wide v1

    invoke-static {v1, v2, v3, v4}, Lj1/l;->a(JJ)Z

    move-result v5

    if-nez v5, :cond_5

    goto :goto_0

    :cond_5
    invoke-virtual {p0, v6, p3, p4}, LA/l;->N0(ZJ)J

    move-result-wide v1

    invoke-static {v1, v2, v3, v4}, Lj1/l;->a(JJ)Z

    move-result v5

    if-nez v5, :cond_6

    goto :goto_0

    :cond_6
    invoke-virtual {p0, v6, p3, p4}, LA/l;->M0(ZJ)J

    move-result-wide v1

    invoke-static {v1, v2, v3, v4}, Lj1/l;->a(JJ)Z

    move-result v5

    if-nez v5, :cond_7

    goto :goto_0

    :cond_7
    move-wide v1, v3

    :goto_0
    invoke-static {v1, v2, v3, v4}, Lj1/l;->a(JJ)Z

    move-result v3

    if-nez v3, :cond_b

    const/16 p3, 0x20

    shr-long p3, v1, p3

    long-to-int p3, p3

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    long-to-int p4, v1

    if-ltz p3, :cond_8

    move v1, v0

    goto :goto_1

    :cond_8
    move v1, v6

    :goto_1
    if-ltz p4, :cond_9

    goto :goto_2

    :cond_9
    move v0, v6

    :goto_2
    and-int/2addr v0, v1

    if-nez v0, :cond_a

    const-string v0, "width and height must be >= 0"

    invoke-static {v0}, Lj1/i;->a(Ljava/lang/String;)V

    :cond_a
    invoke-static {p3, p3, p4, p4}, Lj1/b;->h(IIII)J

    move-result-wide p3

    :cond_b
    invoke-interface {p2, p3, p4}, LJ0/L;->D(J)LJ0/Y;

    move-result-object p2

    iget p3, p2, LJ0/Y;->t:I

    iget p4, p2, LJ0/Y;->u:I

    new-instance v0, LA/k;

    const/4 v1, 0x0

    invoke-direct {v0, p2, v1}, LA/k;-><init>(LJ0/Y;I)V

    sget-object p2, Le7/u;->t:Le7/u;

    invoke-interface {p1, p3, p4, p2, v0}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1
.end method

.method public final m0(LL0/S;LJ0/L;I)I
    .locals 0

    const p1, 0x7fffffff

    if-eq p3, p1, :cond_0

    int-to-float p1, p3

    iget p2, p0, LA/l;->H:F

    mul-float/2addr p1, p2

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1

    :cond_0
    invoke-interface {p2, p3}, LJ0/L;->A(I)I

    move-result p1

    return p1
.end method

.method public final w(LL0/S;LJ0/L;I)I
    .locals 0

    const p1, 0x7fffffff

    if-eq p3, p1, :cond_0

    int-to-float p1, p3

    iget p2, p0, LA/l;->H:F

    div-float/2addr p1, p2

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1

    :cond_0
    invoke-interface {p2, p3}, LJ0/L;->c(I)I

    move-result p1

    return p1
.end method

.method public final w0(LL0/S;LJ0/L;I)I
    .locals 0

    const p1, 0x7fffffff

    if-eq p3, p1, :cond_0

    int-to-float p1, p3

    iget p2, p0, LA/l;->H:F

    mul-float/2addr p1, p2

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1

    :cond_0
    invoke-interface {p2, p3}, LJ0/L;->w(I)I

    move-result p1

    return p1
.end method
