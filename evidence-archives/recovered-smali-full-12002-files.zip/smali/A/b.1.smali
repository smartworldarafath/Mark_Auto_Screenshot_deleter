.class public final synthetic LA/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, LA/b;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    iget v0, p0, LA/b;->t:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, Lj0/c;

    check-cast p2, LW0/e;

    iget-object v0, p2, LW0/e;->a:Ljava/lang/Object;

    instance-of v1, v0, LW0/t;

    if-eqz v1, :cond_0

    sget-object v1, LW0/i;->t:LW0/i;

    goto :goto_0

    :cond_0
    instance-of v1, v0, LW0/D;

    if-eqz v1, :cond_1

    sget-object v1, LW0/i;->u:LW0/i;

    goto :goto_0

    :cond_1
    instance-of v1, v0, LW0/N;

    if-eqz v1, :cond_2

    sget-object v1, LW0/i;->v:LW0/i;

    goto :goto_0

    :cond_2
    instance-of v1, v0, LW0/M;

    if-eqz v1, :cond_3

    sget-object v1, LW0/i;->w:LW0/i;

    goto :goto_0

    :cond_3
    instance-of v1, v0, LW0/l;

    if-eqz v1, :cond_4

    sget-object v1, LW0/i;->x:LW0/i;

    goto :goto_0

    :cond_4
    instance-of v1, v0, LW0/k;

    if-eqz v1, :cond_5

    sget-object v1, LW0/i;->y:LW0/i;

    goto :goto_0

    :cond_5
    instance-of v1, v0, LW0/F;

    if-eqz v1, :cond_6

    sget-object v1, LW0/i;->z:LW0/i;

    :goto_0
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    packed-switch v2, :pswitch_data_1

    new-instance p1, LA2/c;

    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    throw p1

    :pswitch_0
    const-string p1, "null cannot be cast to non-null type androidx.compose.ui.text.StringAnnotation"

    invoke-static {v0, p1}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, LW0/F;

    iget-object p1, v0, LW0/F;->a:Ljava/lang/String;

    goto :goto_1

    :pswitch_1
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.LinkAnnotation.Clickable"

    invoke-static {v0, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, LW0/k;

    sget-object v2, LW0/B;->f:Lj6/b;

    invoke-static {v0, v2, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object p1

    goto :goto_1

    :pswitch_2
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.LinkAnnotation.Url"

    invoke-static {v0, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, LW0/l;

    sget-object v2, LW0/B;->e:Lj6/b;

    invoke-static {v0, v2, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object p1

    goto :goto_1

    :pswitch_3
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.UrlAnnotation"

    invoke-static {v0, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, LW0/M;

    sget-object v2, LW0/B;->d:Lj6/b;

    invoke-static {v0, v2, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object p1

    goto :goto_1

    :pswitch_4
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.VerbatimTtsAnnotation"

    invoke-static {v0, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, LW0/N;

    sget-object v2, LW0/B;->c:Lj6/b;

    invoke-static {v0, v2, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object p1

    goto :goto_1

    :pswitch_5
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.SpanStyle"

    invoke-static {v0, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, LW0/D;

    sget-object v2, LW0/B;->h:Lj6/b;

    invoke-static {v0, v2, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object p1

    goto :goto_1

    :pswitch_6
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.ParagraphStyle"

    invoke-static {v0, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, LW0/t;

    sget-object v2, LW0/B;->g:Lj6/b;

    invoke-static {v0, v2, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object p1

    :goto_1
    iget v0, p2, LW0/e;->b:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget v2, p2, LW0/e;->c:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget-object p2, p2, LW0/e;->d:Ljava/lang/String;

    filled-new-array {v1, p1, v0, v2, p2}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Le7/m;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1

    :cond_6
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_7
    check-cast p1, Lj0/c;

    check-cast p2, Li1/i;

    iget p1, p2, Li1/i;->a:F

    new-instance v0, Li1/f;

    invoke-direct {v0, p1}, Li1/f;-><init>(F)V

    iget p1, p2, Li1/i;->b:I

    new-instance p2, Li1/h;

    invoke-direct {p2, p1}, Li1/h;-><init>(I)V

    new-instance p1, Li1/g;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    filled-new-array {v0, p2, p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Le7/m;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1

    :pswitch_8
    check-cast p1, Lj0/c;

    check-cast p2, Le1/a;

    iget-object p1, p2, Le1/a;->a:Ljava/util/Locale;

    invoke-virtual {p1}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_9
    check-cast p1, Lj0/c;

    check-cast p2, Le1/b;

    iget-object p2, p2, Le1/b;->t:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p2}, Ljava/util/Collection;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_2
    if-ge v2, v1, :cond_7

    invoke-interface {p2, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Le1/a;

    sget-object v4, LW0/B;->t:Lj6/b;

    invoke-static {v3, v4, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_7
    return-object v0

    :pswitch_a
    check-cast p1, Lj0/c;

    check-cast p2, Ls0/b;

    if-nez p2, :cond_8

    const/4 p1, 0x0

    goto :goto_3

    :cond_8
    iget-wide v0, p2, Ls0/b;->a:J

    const-wide v2, 0x7fc000007fc00000L    # 2.247117487993712E307

    invoke-static {v0, v1, v2, v3}, Ls0/b;->b(JJ)Z

    move-result p1

    :goto_3
    if-eqz p1, :cond_9

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_4

    :cond_9
    iget-wide v0, p2, Ls0/b;->a:J

    const/16 p1, 0x20

    shr-long/2addr v0, p1

    long-to-int p1, v0

    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    iget-wide v0, p2, Ls0/b;->a:J

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    long-to-int p2, v0

    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p2

    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p2

    filled-new-array {p1, p2}, [Ljava/lang/Float;

    move-result-object p1

    invoke-static {p1}, Le7/m;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p1

    :goto_4
    return-object p1

    :pswitch_b
    check-cast p1, Lj0/c;

    check-cast p2, Lj1/o;

    sget-wide v0, Lj1/o;->c:J

    if-nez p2, :cond_a

    const/4 p1, 0x0

    goto :goto_5

    :cond_a
    iget-wide v2, p2, Lj1/o;->a:J

    invoke-static {v2, v3, v0, v1}, Lj1/o;->a(JJ)Z

    move-result p1

    :goto_5
    if-eqz p1, :cond_b

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_6

    :cond_b
    iget-wide v0, p2, Lj1/o;->a:J

    invoke-static {v0, v1}, Lj1/o;->c(J)F

    move-result p1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    iget-wide v0, p2, Lj1/o;->a:J

    invoke-static {v0, v1}, Lj1/o;->b(J)J

    move-result-wide v0

    new-instance p2, Lj1/p;

    invoke-direct {p2, v0, v1}, Lj1/p;-><init>(J)V

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Le7/m;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p1

    :goto_6
    return-object p1

    :pswitch_c
    check-cast p1, Lj0/c;

    check-cast p2, Lt0/G;

    iget-wide v0, p2, Lt0/G;->a:J

    new-instance v2, Lt0/p;

    invoke-direct {v2, v0, v1}, Lt0/p;-><init>(J)V

    sget-object v0, LW0/B;->p:LW0/A;

    invoke-static {v2, v0, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object v0

    iget-wide v1, p2, Lt0/G;->b:J

    new-instance v3, Ls0/b;

    invoke-direct {v3, v1, v2}, Ls0/b;-><init>(J)V

    sget-object v1, LW0/B;->r:LW0/A;

    invoke-static {v3, v1, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object p1

    iget p2, p2, Lt0/G;->c:F

    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p2

    filled-new-array {v0, p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Le7/m;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1

    :pswitch_d
    check-cast p1, Lj0/c;

    check-cast p2, LW0/K;

    iget-wide v0, p2, LW0/K;->a:J

    const/16 p1, 0x20

    shr-long/2addr v0, p1

    long-to-int p1, v0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iget-wide v0, p2, LW0/K;->a:J

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    long-to-int p2, v0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    filled-new-array {p1, p2}, [Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p1}, Le7/m;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1

    :pswitch_e
    check-cast p1, Lj0/c;

    check-cast p2, Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p2}, Ljava/util/Collection;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_7
    if-ge v2, v1, :cond_c

    invoke-interface {p2, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LW0/e;

    sget-object v4, LW0/B;->b:Lj6/b;

    invoke-static {v3, v4, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_c
    return-object v0

    :pswitch_f
    check-cast p1, Lj0/c;

    check-cast p2, Li1/a;

    iget p1, p2, Li1/a;->a:F

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    return-object p1

    :pswitch_10
    check-cast p1, Lj0/c;

    check-cast p2, LW0/l;

    iget-object v0, p2, LW0/l;->a:Ljava/lang/String;

    iget-object p2, p2, LW0/l;->b:LW0/J;

    sget-object v1, LW0/B;->i:Lj6/b;

    invoke-static {p2, v1, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object p1

    filled-new-array {v0, p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Le7/m;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1

    :pswitch_11
    check-cast p1, Lj0/c;

    check-cast p2, La1/w;

    iget p1, p2, La1/w;->t:I

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    return-object p1

    :pswitch_12
    check-cast p1, Lj0/c;

    check-cast p2, Li1/q;

    iget-wide v0, p2, Li1/q;->a:J

    new-instance v2, Lj1/o;

    invoke-direct {v2, v0, v1}, Lj1/o;-><init>(J)V

    sget-object v0, LW0/B;->q:LW0/A;

    invoke-static {v2, v0, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object v1

    iget-wide v2, p2, Li1/q;->b:J

    new-instance p2, Lj1/o;

    invoke-direct {p2, v2, v3}, Lj1/o;-><init>(J)V

    invoke-static {p2, v0, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object p1

    filled-new-array {v1, p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Le7/m;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1

    :pswitch_13
    check-cast p1, Lj0/c;

    check-cast p2, Li1/p;

    iget p1, p2, Li1/p;->a:F

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    iget p2, p2, Li1/p;->b:F

    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p2

    filled-new-array {p1, p2}, [Ljava/lang/Float;

    move-result-object p1

    invoke-static {p1}, Le7/m;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1

    :pswitch_14
    check-cast p1, Lj0/c;

    check-cast p2, Li1/l;

    iget p1, p2, Li1/l;->a:I

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    return-object p1

    :pswitch_15
    check-cast p1, Lj0/c;

    check-cast p2, LW0/g;

    iget-object v0, p2, LW0/g;->u:Ljava/lang/String;

    iget-object p2, p2, LW0/g;->t:Ljava/util/List;

    sget-object v1, LW0/B;->a:Lj6/b;

    invoke-static {p2, v1, p1}, LW0/B;->a(Ljava/lang/Object;Lj0/k;Lj0/c;)Ljava/lang/Object;

    move-result-object p1

    filled-new-array {v0, p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Le7/m;->d([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p1

    return-object p1

    :pswitch_16
    check-cast p1, Lj0/c;

    check-cast p2, LK6/o;

    const-string v0, "$this$Saver"

    invoke-static {p1, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "it"

    invoke-static {p2, p1}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, p2, LK6/o;->a:La0/h0;

    invoke-virtual {p1}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object p1

    move-object v0, p1

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    iget-object p1, p2, LK6/o;->b:La0/h0;

    invoke-virtual {p1}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object p1

    move-object v1, p1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    iget-object p1, p2, LK6/o;->c:La0/h0;

    invoke-virtual {p1}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object p1

    move-object v2, p1

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    iget-object p1, p2, LK6/o;->d:La0/h0;

    invoke-virtual {p1}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object p1

    move-object v3, p1

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    iget-object p1, p2, LK6/o;->e:La0/h0;

    invoke-virtual {p1}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object p1

    move-object v4, p1

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    iget-object p1, p2, LK6/o;->f:La0/h0;

    invoke-virtual {p1}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object p1

    move-object v5, p1

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    iget-object p1, p2, LK6/o;->g:La0/h0;

    invoke-virtual {p1}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object p1

    move-object v6, p1

    check-cast v6, Ljava/lang/String;

    iget-object p1, p2, LK6/o;->h:La0/h0;

    invoke-virtual {p1}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object p1

    move-object v7, p1

    check-cast v7, Ljava/lang/Boolean;

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    iget-object p1, p2, LK6/o;->i:La0/e0;

    invoke-virtual {p1}, La0/e0;->h()I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    filled-new-array/range {v0 .. v8}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Le7/m;->g([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    return-object p1

    :pswitch_17
    check-cast p1, LI7/y;

    check-cast p2, Lh7/f;

    instance-of v0, p2, LI7/v;

    if-eqz v0, :cond_d

    check-cast p2, LI7/v;

    iget-object v0, p1, LI7/y;->a:Lh7/h;

    invoke-virtual {p2, v0}, LI7/v;->b(Lh7/h;)Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p1, LI7/y;->b:[Ljava/lang/Object;

    iget v2, p1, LI7/y;->d:I

    aput-object v0, v1, v2

    iget-object v0, p1, LI7/y;->c:[LI7/v;

    add-int/lit8 v1, v2, 0x1

    iput v1, p1, LI7/y;->d:I

    aput-object p2, v0, v2

    :cond_d
    return-object p1

    :pswitch_18
    check-cast p1, LI7/v;

    check-cast p2, Lh7/f;

    if-eqz p1, :cond_e

    goto :goto_8

    :cond_e
    instance-of p1, p2, LI7/v;

    if-eqz p1, :cond_f

    move-object p1, p2

    check-cast p1, LI7/v;

    goto :goto_8

    :cond_f
    const/4 p1, 0x0

    :goto_8
    return-object p1

    :pswitch_19
    check-cast p2, Lh7/f;

    instance-of v0, p2, LI7/v;

    if-eqz v0, :cond_13

    instance-of v0, p1, Ljava/lang/Integer;

    if-eqz v0, :cond_10

    check-cast p1, Ljava/lang/Integer;

    goto :goto_9

    :cond_10
    const/4 p1, 0x0

    :goto_9
    const/4 v0, 0x1

    if-eqz p1, :cond_11

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    goto :goto_a

    :cond_11
    move p1, v0

    :goto_a
    if-nez p1, :cond_12

    move-object p1, p2

    goto :goto_b

    :cond_12
    add-int/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    :cond_13
    :goto_b
    return-object p1

    :pswitch_1a
    check-cast p1, Lj0/c;

    check-cast p2, LI/D0;

    iget-object p1, p2, LI/D0;->a:La0/d0;

    invoke-virtual {p1}, La0/d0;->h()F

    move-result p1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    iget-object p2, p2, LI/D0;->f:La0/h0;

    invoke-virtual {p2}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lw/h0;

    sget-object v0, Lw/h0;->t:Lw/h0;

    if-ne p2, v0, :cond_14

    const/4 p2, 0x1

    goto :goto_c

    :cond_14
    const/4 p2, 0x0

    :goto_c
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Le7/m;->g([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    return-object p1

    :pswitch_1b
    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    check-cast p2, Lh7/f;

    add-int/lit8 p1, p1, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    return-object p1

    :pswitch_1c
    check-cast p1, Lj0/c;

    check-cast p2, LE/q0;

    invoke-virtual {p2}, LE/q0;->d()Ljava/util/Map;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_15

    const/4 p1, 0x0

    :cond_15
    return-object p1

    :pswitch_1d
    check-cast p1, Lh7/h;

    check-cast p2, Lh7/f;

    invoke-interface {p1, p2}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object p1

    return-object p1

    :pswitch_1e
    check-cast p1, Lh7/h;

    check-cast p2, Lh7/f;

    invoke-interface {p1, p2}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object p1

    return-object p1

    :pswitch_1f
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    check-cast p2, Lh7/f;

    return-object p1

    :pswitch_20
    check-cast p1, Lj0/c;

    check-cast p2, LD/A;

    iget-object p1, p2, LD/A;->d:LC/t;

    iget-object p1, p1, LC/t;->b:La0/e0;

    invoke-virtual {p1}, La0/e0;->h()I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iget-object p2, p2, LD/A;->d:LC/t;

    iget-object p2, p2, LC/t;->c:La0/e0;

    invoke-virtual {p2}, La0/e0;->h()I

    move-result p2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    filled-new-array {p1, p2}, [Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p1}, Le7/m;->g([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    return-object p1

    :pswitch_21
    check-cast p1, LD/u;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    const/4 p1, 0x1

    invoke-static {p1}, LE4/G;->a(I)J

    move-result-wide p1

    new-instance v0, LD/b;

    invoke-direct {v0, p1, p2}, LD/b;-><init>(J)V

    return-object v0

    :pswitch_22
    check-cast p1, Lj0/c;

    check-cast p2, LC/B;

    iget-object p1, p2, LC/B;->e:LC/t;

    iget-object p1, p1, LC/t;->b:La0/e0;

    invoke-virtual {p1}, La0/e0;->h()I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iget-object p2, p2, LC/B;->e:LC/t;

    iget-object p2, p2, LC/t;->c:La0/e0;

    invoke-virtual {p2}, La0/e0;->h()I

    move-result p2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    filled-new-array {p1, p2}, [Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p1}, Le7/m;->g([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    return-object p1

    :pswitch_23
    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    check-cast p2, Lj1/m;

    int-to-float p1, p1

    const/high16 v0, 0x40000000    # 2.0f

    div-float/2addr p1, v0

    sget-object v0, Lj1/m;->t:Lj1/m;

    const/high16 v1, -0x40800000    # -1.0f

    if-ne p2, v0, :cond_16

    goto :goto_d

    :cond_16
    const/4 p2, -0x1

    int-to-float p2, p2

    mul-float/2addr v1, p2

    :goto_d
    const/4 p2, 0x1

    int-to-float p2, p2

    add-float/2addr p2, v1

    mul-float/2addr p2, p1

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
