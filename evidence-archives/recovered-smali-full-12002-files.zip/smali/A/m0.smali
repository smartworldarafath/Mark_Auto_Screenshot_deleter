.class public final LA/m0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/f;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, LA/m0;->t:I

    iput-object p2, p0, LA/m0;->u:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 36

    move-object/from16 v0, p0

    iget v1, v0, LA/m0;->t:I

    const-string v2, "$this$AnimatedVisibility"

    const/4 v3, 0x3

    const/16 v4, 0x30

    sget-object v5, LN/p;->a:LN/p;

    sget-object v6, Lm0/o;->a:Lm0/o;

    const/16 v7, 0x10

    const/16 v8, 0x11

    sget-object v9, La0/m;->a:La0/U;

    sget-object v11, Ld7/z;->a:Ld7/z;

    iget-object v12, v0, LA/m0;->u:Ljava/lang/Object;

    const/4 v13, 0x0

    packed-switch v1, :pswitch_data_0

    move-object/from16 v1, p1

    check-cast v1, LA/w;

    move-object/from16 v2, p2

    check-cast v2, La0/r;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    const-string v4, "$this$Card"

    invoke-static {v1, v4}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    and-int/lit8 v1, v3, 0x11

    if-ne v1, v7, :cond_1

    invoke-virtual {v2}, La0/r;->z()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v2}, La0/r;->Q()V

    move-object/from16 v35, v11

    goto/16 :goto_2

    :cond_1
    :goto_0
    sget-object v1, Lm0/c;->x:Lm0/j;

    check-cast v12, LW0/g;

    invoke-static {v1, v13}, LA/p;->d(Lm0/j;Z)LJ0/M;

    move-result-object v1

    iget-wide v3, v2, La0/r;->T:J

    invoke-static {v3, v4}, Ljava/lang/Long;->hashCode(J)I

    move-result v3

    invoke-virtual {v2}, La0/r;->l()La0/n0;

    move-result-object v4

    invoke-static {v2, v6}, Lm0/a;->c(La0/r;Lm0/r;)Lm0/r;

    move-result-object v5

    sget-object v7, LL0/j;->b:LL0/i;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v7, LL0/i;->b:LL0/C;

    invoke-virtual {v2}, La0/r;->Z()V

    iget-boolean v8, v2, La0/r;->S:Z

    if-eqz v8, :cond_2

    invoke-virtual {v2, v7}, La0/r;->k(Lr7/a;)V

    goto :goto_1

    :cond_2
    invoke-virtual {v2}, La0/r;->j0()V

    :goto_1
    sget-object v7, LL0/i;->e:LL0/h;

    invoke-static {v2, v1, v7}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v1, LL0/i;->d:LL0/h;

    invoke-static {v2, v4, v1}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v1, LL0/i;->f:LL0/h;

    iget-boolean v4, v2, La0/r;->S:Z

    if-nez v4, :cond_3

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v4

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v4, v7}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4

    :cond_3
    invoke-static {v3, v2, v3, v1}, Lq3/h;->n(ILa0/r;ILL0/h;)V

    :cond_4
    sget-object v1, LL0/i;->c:LL0/h;

    invoke-static {v2, v5, v1}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    const v1, 0x7f080077

    const/4 v3, 0x6

    invoke-static {v1, v2, v3}, LE4/D4;->a(ILa0/r;I)Ly0/b;

    move-result-object v14

    sget-object v1, Landroidx/compose/foundation/layout/b;->a:Landroidx/compose/foundation/layout/b;

    invoke-virtual {v1}, Landroidx/compose/foundation/layout/b;->b()Lm0/r;

    move-result-object v16

    const/16 v19, 0x0

    const/16 v21, 0x6030

    const/4 v15, 0x0

    const/16 v17, 0x0

    sget-object v18, LJ0/i;->a:LJ0/S;

    move-object/from16 v20, v2

    invoke-static/range {v14 .. v21}, LH4/C5;->a(Ly0/b;Ljava/lang/String;Lm0/r;Lm0/e;LJ0/S;FLa0/r;I)V

    invoke-virtual {v1}, Landroidx/compose/foundation/layout/b;->b()Lm0/r;

    move-result-object v1

    invoke-static {v2}, LX/g0;->a(La0/r;)LX/J;

    move-result-object v3

    iget-wide v3, v3, LX/J;->a:J

    const/high16 v5, 0x3f000000    # 0.5f

    const/16 v7, 0xe

    invoke-static {v3, v4, v5, v7}, Lt0/p;->b(JFI)J

    move-result-wide v3

    new-instance v5, Lt0/p;

    invoke-direct {v5, v3, v4}, Lt0/p;-><init>(J)V

    invoke-static {v2}, LX/g0;->a(La0/r;)LX/J;

    move-result-object v3

    iget-wide v3, v3, LX/J;->a:J

    const/16 v7, 0xf

    const/4 v8, 0x0

    invoke-static {v3, v4, v8, v7}, Lt0/p;->b(JFI)J

    move-result-wide v3

    new-instance v7, Lt0/p;

    invoke-direct {v7, v3, v4}, Lt0/p;-><init>(J)V

    filled-new-array {v5, v7}, [Lt0/p;

    move-result-object v3

    invoke-static {v3}, Le7/m;->g([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v15

    invoke-static {v8}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v3

    int-to-long v3, v3

    invoke-static {v8}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v5

    move/from16 p1, v8

    int-to-long v8, v5

    const/16 v5, 0x20

    shl-long/2addr v3, v5

    const-wide v16, 0xffffffffL

    and-long v7, v8, v16

    or-long/2addr v3, v7

    invoke-static/range {p1 .. p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v7

    int-to-long v7, v7

    const/high16 v9, 0x437a0000    # 250.0f

    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v9

    move-object/from16 v35, v11

    int-to-long v10, v9

    shl-long/2addr v7, v5

    and-long v9, v10, v16

    or-long v18, v7, v9

    new-instance v14, Lt0/x;

    move-wide/from16 v16, v3

    invoke-direct/range {v14 .. v19}, Lt0/x;-><init>(Ljava/util/List;JJ)V

    invoke-static {v1, v14}, Landroidx/compose/foundation/a;->a(Lm0/r;Lt0/x;)Lm0/r;

    move-result-object v1

    invoke-static {v1, v2, v13}, LA/p;->a(Lm0/r;La0/r;I)V

    invoke-static {v2}, LP6/c;->a(La0/r;)LP6/b;

    move-result-object v1

    iget v1, v1, LP6/b;->c:F

    invoke-static {v6, v1}, Landroidx/compose/foundation/layout/a;->j(Lm0/r;F)Lm0/r;

    move-result-object v15

    const/16 v32, 0x0

    const v33, 0x3fffc

    const-wide/16 v16, 0x0

    const-wide/16 v18, 0x0

    const-wide/16 v20, 0x0

    const-wide/16 v22, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    move-object/from16 v31, v2

    move-object v14, v12

    invoke-static/range {v14 .. v33}, LX/c2;->c(LW0/g;Lm0/r;JJJJIZIILjava/util/Map;Lr7/c;LW0/L;La0/r;II)V

    const/4 v1, 0x1

    invoke-virtual {v2, v1}, La0/r;->p(Z)V

    :goto_2
    return-object v35

    :pswitch_0
    move-object/from16 v1, p1

    check-cast v1, Lm0/r;

    move-object/from16 v2, p2

    check-cast v2, La0/r;

    move-object/from16 v3, p3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    check-cast v12, LT/d0;

    const v3, 0x760d4197

    invoke-virtual {v2, v3}, La0/r;->V(I)V

    sget-object v3, LM0/r0;->h:La0/X0;

    invoke-virtual {v2, v3}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lj1/c;

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v4

    if-ne v4, v9, :cond_5

    new-instance v4, Lj1/l;

    const-wide/16 v5, 0x0

    invoke-direct {v4, v5, v6}, Lj1/l;-><init>(J)V

    invoke-static {v4}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v4

    invoke-virtual {v2, v4}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_5
    check-cast v4, La0/Z;

    invoke-virtual {v2, v12}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v5

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v6

    if-nez v5, :cond_6

    if-ne v6, v9, :cond_7

    :cond_6
    new-instance v6, LD/j;

    invoke-direct {v6, v8, v12, v4}, LD/j;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, v6}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_7
    check-cast v6, Lr7/a;

    invoke-virtual {v2, v3}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v5

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v7

    if-nez v5, :cond_8

    if-ne v7, v9, :cond_9

    :cond_8
    new-instance v7, LT/i0;

    invoke-direct {v7, v3, v4, v13}, LT/i0;-><init>(Lj1/c;La0/Z;I)V

    invoke-virtual {v2, v7}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_9
    check-cast v7, Lr7/c;

    sget-object v3, LT/M;->a:Ls/o;

    new-instance v3, LI/z0;

    invoke-direct {v3, v6, v7}, LI/z0;-><init>(Lr7/a;Lr7/c;)V

    invoke-static {v1, v3}, Lm0/a;->a(Lm0/r;Lr7/f;)Lm0/r;

    move-result-object v1

    invoke-virtual {v2, v13}, La0/r;->p(Z)V

    return-object v1

    :pswitch_1
    move-object/from16 v35, v11

    move-object/from16 v1, p1

    check-cast v1, Lt0/p;

    iget-wide v1, v1, Lt0/p;->a:J

    move-object/from16 v1, p2

    check-cast v1, La0/r;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    and-int/lit8 v3, v2, 0x11

    if-eq v3, v7, :cond_a

    const/4 v13, 0x1

    :cond_a
    const/16 v34, 0x1

    and-int/lit8 v2, v2, 0x1

    invoke-virtual {v1, v2, v13}, La0/r;->N(IZ)Z

    move-result v2

    if-eqz v2, :cond_b

    check-cast v12, Landroid/app/RemoteAction;

    invoke-virtual {v12}, Landroid/app/RemoteAction;->getIcon()Landroid/graphics/drawable/Icon;

    move-result-object v2

    invoke-virtual {v5, v2, v1, v4}, LN/p;->b(Landroid/graphics/drawable/Icon;La0/r;I)V

    goto :goto_3

    :cond_b
    invoke-virtual {v1}, La0/r;->Q()V

    :goto_3
    return-object v35

    :pswitch_2
    move-object/from16 v35, v11

    move-object/from16 v1, p1

    check-cast v1, Lt0/p;

    iget-wide v1, v1, Lt0/p;->a:J

    move-object/from16 v1, p2

    check-cast v1, La0/r;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    and-int/lit8 v3, v2, 0x11

    if-eq v3, v7, :cond_c

    const/4 v13, 0x1

    :cond_c
    const/16 v34, 0x1

    and-int/lit8 v2, v2, 0x1

    invoke-virtual {v1, v2, v13}, La0/r;->N(IZ)Z

    move-result v2

    if-eqz v2, :cond_d

    check-cast v12, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v5, v12, v1, v4}, LN/p;->a(Landroid/graphics/drawable/Drawable;La0/r;I)V

    goto :goto_4

    :cond_d
    invoke-virtual {v1}, La0/r;->Q()V

    :goto_4
    return-object v35

    :pswitch_3
    move-object/from16 v35, v11

    move-object/from16 v1, p1

    check-cast v1, Lt0/p;

    iget-wide v1, v1, Lt0/p;->a:J

    move-object/from16 v4, p2

    check-cast v4, La0/r;

    move-object/from16 v5, p3

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v5

    and-int/lit8 v6, v5, 0x6

    if-nez v6, :cond_f

    invoke-virtual {v4, v1, v2}, La0/r;->e(J)Z

    move-result v6

    if-eqz v6, :cond_e

    const/4 v6, 0x4

    goto :goto_5

    :cond_e
    const/4 v6, 0x2

    :goto_5
    or-int/2addr v5, v6

    :cond_f
    and-int/lit8 v6, v5, 0x13

    const/16 v7, 0x12

    if-eq v6, v7, :cond_10

    const/4 v10, 0x1

    goto :goto_6

    :cond_10
    move v10, v13

    :goto_6
    and-int/lit8 v6, v5, 0x1

    invoke-virtual {v4, v6, v10}, La0/r;->N(IZ)Z

    move-result v6

    if-eqz v6, :cond_11

    check-cast v12, LL/b;

    check-cast v12, LL/d;

    iget v6, v12, LL/d;->c:I

    shl-int/lit8 v3, v5, 0x3

    and-int/lit8 v3, v3, 0x70

    invoke-static {v6, v1, v2, v4, v3}, LN/k;->b(IJLa0/r;I)V

    goto :goto_7

    :cond_11
    invoke-virtual {v4}, La0/r;->Q()V

    :goto_7
    return-object v35

    :pswitch_4
    move-object/from16 v1, p1

    check-cast v1, Lm0/r;

    move-object/from16 v1, p2

    check-cast v1, La0/r;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    const v2, 0x5e56a525

    invoke-virtual {v1, v2}, La0/r;->V(I)V

    sget-object v2, LM0/r0;->h:La0/X0;

    invoke-virtual {v1, v2}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lj1/c;

    sget-object v3, LM0/r0;->k:La0/X0;

    invoke-virtual {v1, v3}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La1/l;

    sget-object v4, LM0/r0;->n:La0/X0;

    invoke-virtual {v1, v4}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lj1/m;

    check-cast v12, LW0/L;

    invoke-virtual {v1, v12}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v5

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v7

    invoke-virtual {v1, v7}, La0/r;->d(I)Z

    move-result v7

    or-int/2addr v5, v7

    invoke-virtual {v1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v7

    if-nez v5, :cond_12

    if-ne v7, v9, :cond_13

    :cond_12
    invoke-static {v12, v4}, LW0/C;->h(LW0/L;Lj1/m;)LW0/L;

    move-result-object v7

    invoke-virtual {v1, v7}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_13
    check-cast v7, LW0/L;

    invoke-virtual {v1, v3}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v5

    invoke-virtual {v1, v7}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v8

    or-int/2addr v5, v8

    invoke-virtual {v1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v8

    if-nez v5, :cond_14

    if-ne v8, v9, :cond_18

    :cond_14
    iget-object v5, v7, LW0/L;->a:LW0/D;

    iget-object v8, v5, LW0/D;->f:La1/m;

    iget-object v10, v5, LW0/D;->c:La1/w;

    if-nez v10, :cond_15

    sget-object v10, La1/w;->x:La1/w;

    :cond_15
    iget-object v11, v5, LW0/D;->d:La1/t;

    if-eqz v11, :cond_16

    iget v11, v11, La1/t;->a:I

    goto :goto_8

    :cond_16
    move v11, v13

    :goto_8
    iget-object v5, v5, LW0/D;->e:La1/u;

    if-eqz v5, :cond_17

    iget v5, v5, La1/u;->a:I

    goto :goto_9

    :cond_17
    const v5, 0xffff

    :goto_9
    move-object v14, v3

    check-cast v14, La1/n;

    invoke-virtual {v14, v8, v10, v11, v5}, La1/n;->b(La1/m;La1/w;II)La1/G;

    move-result-object v8

    invoke-virtual {v1, v8}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_18
    check-cast v8, La0/W0;

    invoke-virtual {v1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v9, :cond_19

    new-instance v5, LI/E0;

    invoke-interface {v8}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v10

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    iput-object v4, v5, LI/E0;->a:Lj1/m;

    iput-object v2, v5, LI/E0;->b:Lj1/c;

    iput-object v3, v5, LI/E0;->c:La1/l;

    iput-object v12, v5, LI/E0;->d:LW0/L;

    iput-object v10, v5, LI/E0;->e:Ljava/lang/Object;

    invoke-static {v12, v2, v3}, LI/r0;->b(LW0/L;Lj1/c;La1/l;)J

    move-result-wide v10

    iput-wide v10, v5, LI/E0;->f:J

    invoke-virtual {v1, v5}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_19
    check-cast v5, LI/E0;

    invoke-interface {v8}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v8

    iget-object v10, v5, LI/E0;->a:Lj1/m;

    if-ne v4, v10, :cond_1a

    iget-object v10, v5, LI/E0;->b:Lj1/c;

    invoke-static {v2, v10}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_1a

    iget-object v10, v5, LI/E0;->c:La1/l;

    invoke-static {v3, v10}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_1a

    iget-object v10, v5, LI/E0;->d:LW0/L;

    invoke-static {v7, v10}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_1a

    iget-object v10, v5, LI/E0;->e:Ljava/lang/Object;

    invoke-static {v8, v10}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1b

    :cond_1a
    iput-object v4, v5, LI/E0;->a:Lj1/m;

    iput-object v2, v5, LI/E0;->b:Lj1/c;

    iput-object v3, v5, LI/E0;->c:La1/l;

    iput-object v7, v5, LI/E0;->d:LW0/L;

    iput-object v8, v5, LI/E0;->e:Ljava/lang/Object;

    invoke-static {v7, v2, v3}, LI/r0;->b(LW0/L;Lj1/c;La1/l;)J

    move-result-wide v2

    iput-wide v2, v5, LI/E0;->f:J

    :cond_1b
    invoke-virtual {v1, v5}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v2

    invoke-virtual {v1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v3

    if-nez v2, :cond_1c

    if-ne v3, v9, :cond_1d

    :cond_1c
    new-instance v3, LD7/g;

    const/4 v2, 0x1

    invoke-direct {v3, v2, v5}, LD7/g;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v1, v3}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_1d
    check-cast v3, Lr7/f;

    invoke-static {v6, v3}, Landroidx/compose/ui/layout/a;->b(Lm0/r;Lr7/f;)Lm0/r;

    move-result-object v2

    invoke-virtual {v1, v13}, La0/r;->p(Z)V

    return-object v2

    :pswitch_5
    move-object/from16 v35, v11

    move-object/from16 v1, p1

    check-cast v1, Lr/v;

    move-object/from16 v3, p2

    check-cast v3, La0/r;

    move-object/from16 v4, p3

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    invoke-static {v1, v2}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v12, Ljava/lang/String;

    if-nez v12, :cond_1e

    const-string v12, ""

    :cond_1e
    filled-new-array {v12}, [Ljava/lang/Object;

    move-result-object v1

    const v2, 0x7f0f0127

    invoke-static {v2, v1, v3}, LE4/E4;->b(I[Ljava/lang/Object;La0/r;)Ljava/lang/String;

    move-result-object v13

    sget-object v1, LX/k2;->a:La0/X0;

    invoke-virtual {v3, v1}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LX/j2;

    iget-object v1, v1, LX/j2;->o:LW0/L;

    sget-object v2, LX/L;->a:La0/X0;

    invoke-virtual {v3, v2}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LX/J;

    iget-wide v4, v2, LX/J;->j:J

    const/16 v32, 0x0

    const v33, 0xfffa

    const/4 v14, 0x0

    const-wide/16 v17, 0x0

    const/16 v19, 0x0

    const-wide/16 v20, 0x0

    const/16 v22, 0x0

    const-wide/16 v23, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v31, 0x0

    move-object/from16 v29, v1

    move-object/from16 v30, v3

    move-wide v15, v4

    invoke-static/range {v13 .. v33}, LX/c2;->b(Ljava/lang/String;Lm0/r;JJLa1/w;JLi1/k;JIZIILW0/L;La0/r;III)V

    return-object v35

    :pswitch_6
    move-object/from16 v35, v11

    move-object/from16 v1, p1

    check-cast v1, Lr/v;

    move-object/from16 v4, p2

    check-cast v4, La0/r;

    move-object/from16 v5, p3

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    invoke-static {v1, v2}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v1, Lm0/c;->G:Lm0/h;

    new-instance v2, Landroidx/compose/foundation/layout/HorizontalAlignElement;

    invoke-direct {v2, v1}, Landroidx/compose/foundation/layout/HorizontalAlignElement;-><init>(Lm0/h;)V

    const/16 v1, 0x1e

    int-to-float v1, v1

    invoke-static {v2, v1}, Landroidx/compose/foundation/layout/c;->j(Lm0/r;F)Lm0/r;

    move-result-object v1

    const v2, -0x513e8ad8

    invoke-virtual {v4, v2}, La0/r;->V(I)V

    check-cast v12, La0/Z;

    invoke-virtual {v4, v12}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v2

    invoke-virtual {v4}, La0/r;->K()Ljava/lang/Object;

    move-result-object v5

    if-nez v2, :cond_1f

    if-ne v5, v9, :cond_20

    :cond_1f
    new-instance v5, LC/k;

    invoke-direct {v5, v12, v3}, LC/k;-><init>(La0/Z;I)V

    invoke-virtual {v4, v5}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_20
    check-cast v5, Lr7/a;

    invoke-virtual {v4, v13}, La0/r;->p(Z)V

    invoke-static {v1, v5, v4}, LE4/r;->a(Lm0/r;Lr7/a;La0/r;)Lm0/r;

    move-result-object v15

    const-wide/16 v17, 0x0

    const/16 v20, 0x6

    const v14, 0x7f0e0006

    const/16 v16, 0x0

    move-object/from16 v19, v4

    invoke-static/range {v14 .. v20}, LE4/l;->b(ILm0/r;IJLa0/r;I)V

    return-object v35

    :pswitch_7
    move-object/from16 v1, p1

    check-cast v1, Lm0/r;

    move-object/from16 v1, p2

    check-cast v1, La0/r;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    const v2, -0x5461a65a

    invoke-virtual {v1, v2}, La0/r;->V(I)V

    check-cast v12, LA/i0;

    invoke-virtual {v1, v12}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v2

    invoke-virtual {v1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v3

    if-nez v2, :cond_21

    if-ne v3, v9, :cond_22

    :cond_21
    new-instance v3, LA/H;

    invoke-direct {v3, v12}, LA/H;-><init>(LA/i0;)V

    invoke-virtual {v1, v3}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_22
    check-cast v3, LA/H;

    invoke-virtual {v1, v13}, La0/r;->p(Z)V

    return-object v3

    :pswitch_8
    move-object/from16 v1, p1

    check-cast v1, Lm0/r;

    move-object/from16 v1, p2

    check-cast v1, La0/r;

    move-object/from16 v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    const v2, -0x5fda9847

    invoke-virtual {v1, v2}, La0/r;->V(I)V

    check-cast v12, Lr7/c;

    invoke-virtual {v1, v12}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v2

    invoke-virtual {v1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v3

    if-nez v2, :cond_23

    if-ne v3, v9, :cond_24

    :cond_23
    new-instance v3, LA/x;

    invoke-direct {v3, v12}, LA/x;-><init>(Lr7/c;)V

    invoke-virtual {v1, v3}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_24
    check-cast v3, LA/x;

    invoke-virtual {v1, v13}, La0/r;->p(Z)V

    return-object v3

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
