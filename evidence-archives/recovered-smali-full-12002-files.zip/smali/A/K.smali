.class public final LA/K;
.super LA/M;
.source "SourceFile"


# instance fields
.field public I:LA/L;

.field public J:Z


# virtual methods
.method public final K0(LJ0/L;J)J
    .locals 2

    iget-object v0, p0, LA/K;->I:LA/L;

    sget-object v1, LA/L;->t:LA/L;

    if-ne v0, v1, :cond_0

    invoke-static {p2, p3}, Lj1/a;->h(J)I

    move-result p2

    invoke-interface {p1, p2}, LJ0/L;->U(I)I

    move-result p1

    goto :goto_0

    :cond_0
    invoke-static {p2, p3}, Lj1/a;->h(J)I

    move-result p2

    invoke-interface {p1, p2}, LJ0/L;->c(I)I

    move-result p1

    :goto_0
    const/4 p2, 0x0

    if-gez p1, :cond_1

    move p1, p2

    :cond_1
    if-ltz p1, :cond_2

    goto :goto_1

    :cond_2
    const-string p3, "height must be >= 0"

    invoke-static {p3}, Lj1/i;->a(Ljava/lang/String;)V

    :goto_1
    const p3, 0x7fffffff

    invoke-static {p2, p3, p1, p1}, Lj1/b;->h(IIII)J

    move-result-wide p1

    return-wide p1
.end method

.method public final L0()Z
    .locals 1

    iget-boolean v0, p0, LA/K;->J:Z

    return v0
.end method

.method public final S(LL0/S;LJ0/L;I)I
    .locals 1

    iget-object p1, p0, LA/K;->I:LA/L;

    sget-object v0, LA/L;->t:LA/L;

    if-ne p1, v0, :cond_0

    invoke-interface {p2, p3}, LJ0/L;->U(I)I

    move-result p1

    return p1

    :cond_0
    invoke-interface {p2, p3}, LJ0/L;->c(I)I

    move-result p1

    return p1
.end method

.method public final w(LL0/S;LJ0/L;I)I
    .locals 1

    iget-object p1, p0, LA/K;->I:LA/L;

    sget-object v0, LA/L;->t:LA/L;

    if-ne p1, v0, :cond_0

    invoke-interface {p2, p3}, LJ0/L;->U(I)I

    move-result p1

    return p1

    :cond_0
    invoke-interface {p2, p3}, LJ0/L;->c(I)I

    move-result p1

    return p1
.end method
