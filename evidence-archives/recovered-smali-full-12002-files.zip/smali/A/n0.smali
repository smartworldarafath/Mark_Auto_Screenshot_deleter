.class public final LA/n0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/f;


# instance fields
.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, LA/n0;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    iget v0, p0, LA/n0;->t:I

    const/4 v1, 0x0

    sget-object v2, La0/m;->a:La0/U;

    const v3, 0x15733969

    packed-switch v0, :pswitch_data_0

    check-cast p1, Lm0/r;

    check-cast p2, La0/r;

    check-cast p3, Ljava/lang/Number;

    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    invoke-virtual {p2, v3}, La0/r;->V(I)V

    sget-object p1, LA/k0;->v:Ljava/util/WeakHashMap;

    invoke-static {p2}, LA/c;->e(La0/r;)LA/k0;

    move-result-object p1

    invoke-virtual {p2, p1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p3

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v0

    if-nez p3, :cond_0

    if-ne v0, v2, :cond_1

    :cond_0
    iget-object p1, p1, LA/k0;->f:LA/a;

    new-instance v0, LA/H;

    invoke-direct {v0, p1}, LA/H;-><init>(LA/i0;)V

    invoke-virtual {p2, v0}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_1
    check-cast v0, LA/H;

    invoke-virtual {p2, v1}, La0/r;->p(Z)V

    return-object v0

    :pswitch_0
    check-cast p1, Lm0/r;

    check-cast p2, La0/r;

    check-cast p3, Ljava/lang/Number;

    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    invoke-virtual {p2, v3}, La0/r;->V(I)V

    sget-object p1, LA/k0;->v:Ljava/util/WeakHashMap;

    invoke-static {p2}, LA/c;->e(La0/r;)LA/k0;

    move-result-object p1

    invoke-virtual {p2, p1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p3

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v0

    if-nez p3, :cond_2

    if-ne v0, v2, :cond_3

    :cond_2
    iget-object p1, p1, LA/k0;->e:LA/a;

    new-instance v0, LA/H;

    invoke-direct {v0, p1}, LA/H;-><init>(LA/i0;)V

    invoke-virtual {p2, v0}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_3
    check-cast v0, LA/H;

    invoke-virtual {p2, v1}, La0/r;->p(Z)V

    return-object v0

    :pswitch_1
    check-cast p1, Lm0/r;

    check-cast p2, La0/r;

    check-cast p3, Ljava/lang/Number;

    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    invoke-virtual {p2, v3}, La0/r;->V(I)V

    sget-object p1, LA/k0;->v:Ljava/util/WeakHashMap;

    invoke-static {p2}, LA/c;->e(La0/r;)LA/k0;

    move-result-object p1

    invoke-virtual {p2, p1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p3

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v0

    if-nez p3, :cond_4

    if-ne v0, v2, :cond_5

    :cond_4
    iget-object p1, p1, LA/k0;->c:LA/a;

    new-instance v0, LA/H;

    invoke-direct {v0, p1}, LA/H;-><init>(LA/i0;)V

    invoke-virtual {p2, v0}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_5
    check-cast v0, LA/H;

    invoke-virtual {p2, v1}, La0/r;->p(Z)V

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
