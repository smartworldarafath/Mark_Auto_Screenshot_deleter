.class public final synthetic LA/l0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/a;


# instance fields
.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LA/l0;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LR7/L;)V
    .locals 0

    .line 2
    const/16 p1, 0xd

    iput p1, p0, LA/l0;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 8

    iget v0, p0, LA/l0;->t:I

    const-wide/16 v1, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v5, "forLanguageTag(...)"

    packed-switch v0, :pswitch_data_0

    sget-object v0, Ljava/util/Locale;->FRENCH:Ljava/util/Locale;

    const-string v1, "FRENCH"

    invoke-static {v0, v1}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_0
    const-string v0, "es"

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    invoke-static {v0, v5}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_1
    const-string v0, "fa"

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    invoke-static {v0, v5}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_2
    const-string v0, "nl"

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    invoke-static {v0, v5}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_3
    const-string v0, "ar"

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    invoke-static {v0, v5}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_4
    const-string v0, "uk"

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    invoke-static {v0, v5}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_5
    const-string v0, "pl"

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    invoke-static {v0, v5}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_6
    const-string v0, "th"

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    invoke-static {v0, v5}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_7
    sget-object v0, Ljava/util/Locale;->ITALIAN:Ljava/util/Locale;

    const-string v1, "ITALIAN"

    invoke-static {v0, v1}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_8
    const-string v0, "vi"

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    invoke-static {v0, v5}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_9
    const-string v0, "tr"

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    invoke-static {v0, v5}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_a
    sget-object v0, Ljava/util/Locale;->JAPANESE:Ljava/util/Locale;

    const-string v1, "JAPANESE"

    invoke-static {v0, v1}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_b
    new-instance v0, Ljava/util/Locale;

    const-string v1, "in"

    invoke-direct {v0, v1}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    return-object v0

    :pswitch_c
    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    const-string v1, "ENGLISH"

    invoke-static {v0, v1}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_d
    sget-object v0, Ljava/util/Locale;->KOREAN:Ljava/util/Locale;

    const-string v1, "KOREAN"

    invoke-static {v0, v1}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_e
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const-string v1, "getDefault(...)"

    invoke-static {v0, v1}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_f
    move v0, v4

    sget-object v4, LP7/j;->e:LP7/j;

    new-array v0, v0, [LP7/f;

    const-string v3, "kotlin.Unit"

    invoke-static {v3}, LA7/n;->B(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    sget-object v1, LP7/j;->b:LP7/j;

    invoke-virtual {v4, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    new-instance v7, LP7/a;

    invoke-direct {v7, v3}, LP7/a;-><init>(Ljava/lang/String;)V

    new-instance v2, LP7/g;

    iget-object v1, v7, LP7/a;->b:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v5

    invoke-static {v0}, Le7/k;->y([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    invoke-direct/range {v2 .. v7}, LP7/g;-><init>(Ljava/lang/String;LE4/u4;ILjava/util/List;LP7/a;)V

    return-object v2

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "For StructureKind.CLASS please use \'buildClassSerialDescriptor\' instead"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Blank serial names are prohibited"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_10
    new-instance v0, LP6/b;

    invoke-direct {v0}, LP6/b;-><init>()V

    return-object v0

    :pswitch_11
    sget-object v0, LP/f;->a:La0/B;

    return-object v3

    :pswitch_12
    new-instance v0, Lj1/j;

    invoke-direct {v0, v1, v2}, Lj1/j;-><init>(J)V

    return-object v0

    :pswitch_13
    new-instance v0, Lj1/j;

    invoke-direct {v0, v1, v2}, Lj1/j;-><init>(J)V

    return-object v0

    :pswitch_14
    sget-object v0, LI/s;->a:La0/X0;

    return-object v3

    :pswitch_15
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v0

    return-object v0

    :pswitch_16
    const-string v0, ""

    invoke-static {v0}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v0

    return-object v0

    :pswitch_17
    sget-object v0, Lv6/d;->y:Lv6/d;

    invoke-static {v0}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v0

    return-object v0

    :pswitch_18
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v0

    return-object v0

    :pswitch_19
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_1a
    move v0, v4

    new-instance v1, LD/A;

    invoke-direct {v1, v0, v0}, LD/A;-><init>(II)V

    return-object v1

    :pswitch_1b
    move v0, v4

    new-instance v1, LC/B;

    invoke-direct {v1, v0, v0}, LC/B;-><init>(II)V

    return-object v1

    :pswitch_1c
    new-instance v0, LA/D;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
