.class public abstract LA/M;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/z;


# instance fields
.field public final synthetic H:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, LA/M;->H:I

    invoke-direct {p0}, Lm0/q;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract K0(LJ0/L;J)J
.end method

.method public abstract L0()Z
.end method

.method public S(LL0/S;LJ0/L;I)I
    .locals 0

    iget p1, p0, LA/M;->H:I

    packed-switch p1, :pswitch_data_0

    invoke-interface {p2, p3}, LJ0/L;->U(I)I

    move-result p1

    return p1

    :pswitch_0
    invoke-interface {p2, p3}, LJ0/L;->U(I)I

    move-result p1

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public c(LJ0/O;LJ0/L;J)LJ0/N;
    .locals 3

    invoke-virtual {p0, p2, p3, p4}, LA/M;->K0(LJ0/L;J)J

    move-result-wide v0

    invoke-virtual {p0}, LA/M;->L0()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-static {p3, p4, v0, v1}, Lj1/b;->e(JJ)J

    move-result-wide v0

    :cond_0
    invoke-interface {p2, v0, v1}, LJ0/L;->D(J)LJ0/Y;

    move-result-object p2

    iget p3, p2, LJ0/Y;->t:I

    iget p4, p2, LJ0/Y;->u:I

    new-instance v0, LA/k;

    const/4 v1, 0x2

    invoke-direct {v0, p2, v1}, LA/k;-><init>(LJ0/Y;I)V

    sget-object p2, Le7/u;->t:Le7/u;

    invoke-interface {p1, p3, p4, p2, v0}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1
.end method

.method public m0(LL0/S;LJ0/L;I)I
    .locals 0

    iget p1, p0, LA/M;->H:I

    packed-switch p1, :pswitch_data_0

    invoke-interface {p2, p3}, LJ0/L;->A(I)I

    move-result p1

    return p1

    :pswitch_0
    invoke-interface {p2, p3}, LJ0/L;->A(I)I

    move-result p1

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public w(LL0/S;LJ0/L;I)I
    .locals 0

    iget p1, p0, LA/M;->H:I

    packed-switch p1, :pswitch_data_0

    invoke-interface {p2, p3}, LJ0/L;->c(I)I

    move-result p1

    return p1

    :pswitch_0
    invoke-interface {p2, p3}, LJ0/L;->c(I)I

    move-result p1

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public w0(LL0/S;LJ0/L;I)I
    .locals 0

    iget p1, p0, LA/M;->H:I

    packed-switch p1, :pswitch_data_0

    invoke-interface {p2, p3}, LJ0/L;->w(I)I

    move-result p1

    return p1

    :pswitch_0
    invoke-interface {p2, p3}, LJ0/L;->w(I)I

    move-result p1

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
