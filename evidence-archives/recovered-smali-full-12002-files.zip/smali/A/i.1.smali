.class public interface abstract LA/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public a()F
    .locals 1

    const/4 v0, 0x0

    int-to-float v0, v0

    return v0
.end method

.method public abstract b(ILJ0/O;[I[I)V
.end method
