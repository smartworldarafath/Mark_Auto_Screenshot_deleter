.class public final LA/P;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA/i0;


# instance fields
.field public final a:LA/i0;

.field public final b:I


# direct methods
.method public constructor <init>(LA/i0;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/P;->a:LA/i0;

    iput p2, p0, LA/P;->b:I

    return-void
.end method


# virtual methods
.method public final a(Lj1/c;Lj1/m;)I
    .locals 2

    sget-object v0, Lj1/m;->t:Lj1/m;

    if-ne p2, v0, :cond_0

    const/16 v0, 0x8

    goto :goto_0

    :cond_0
    const/4 v0, 0x2

    :goto_0
    iget v1, p0, LA/P;->b:I

    and-int/2addr v0, v1

    if-eqz v0, :cond_1

    iget-object v0, p0, LA/P;->a:LA/i0;

    invoke-interface {v0, p1, p2}, LA/i0;->a(Lj1/c;Lj1/m;)I

    move-result p1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public final b(Lj1/c;Lj1/m;)I
    .locals 2

    sget-object v0, Lj1/m;->t:Lj1/m;

    if-ne p2, v0, :cond_0

    const/4 v0, 0x4

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    :goto_0
    iget v1, p0, LA/P;->b:I

    and-int/2addr v0, v1

    if-eqz v0, :cond_1

    iget-object v0, p0, LA/P;->a:LA/i0;

    invoke-interface {v0, p1, p2}, LA/i0;->b(Lj1/c;Lj1/m;)I

    move-result p1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public final c(Lj1/c;)I
    .locals 1

    iget v0, p0, LA/P;->b:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_0

    iget-object v0, p0, LA/P;->a:LA/i0;

    invoke-interface {v0, p1}, LA/i0;->c(Lj1/c;)I

    move-result p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public final d(Lj1/c;)I
    .locals 1

    iget v0, p0, LA/P;->b:I

    and-int/lit8 v0, v0, 0x20

    if-eqz v0, :cond_0

    iget-object v0, p0, LA/P;->a:LA/i0;

    invoke-interface {v0, p1}, LA/i0;->d(Lj1/c;)I

    move-result p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, LA/P;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, LA/P;

    iget-object v1, p1, LA/P;->a:LA/i0;

    iget-object v3, p0, LA/P;->a:LA/i0;

    invoke-static {v3, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    iget v1, p0, LA/P;->b:I

    iget p1, p1, LA/P;->b:I

    if-ne v1, p1, :cond_2

    return v0

    :cond_2
    return v2
.end method

.method public final hashCode()I
    .locals 2

    iget-object v0, p0, LA/P;->a:LA/i0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, LA/P;->b:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method

.method public final toString()Ljava/lang/String;
    .locals 6

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LA/P;->a:LA/i0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " only "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "WindowInsetsSides("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget v3, LA/d;->d:I

    iget v4, p0, LA/P;->b:I

    and-int v5, v4, v3

    if-ne v5, v3, :cond_0

    const-string v3, "Start"

    invoke-static {v3, v2}, LA/d;->h(Ljava/lang/String;Ljava/lang/StringBuilder;)V

    :cond_0
    sget v3, LA/d;->f:I

    and-int v5, v4, v3

    if-ne v5, v3, :cond_1

    const-string v3, "Left"

    invoke-static {v3, v2}, LA/d;->h(Ljava/lang/String;Ljava/lang/StringBuilder;)V

    :cond_1
    and-int/lit8 v3, v4, 0x10

    const/16 v5, 0x10

    if-ne v3, v5, :cond_2

    const-string v3, "Top"

    invoke-static {v3, v2}, LA/d;->h(Ljava/lang/String;Ljava/lang/StringBuilder;)V

    :cond_2
    sget v3, LA/d;->e:I

    and-int v5, v4, v3

    if-ne v5, v3, :cond_3

    const-string v3, "End"

    invoke-static {v3, v2}, LA/d;->h(Ljava/lang/String;Ljava/lang/StringBuilder;)V

    :cond_3
    sget v3, LA/d;->g:I

    and-int v5, v4, v3

    if-ne v5, v3, :cond_4

    const-string v3, "Right"

    invoke-static {v3, v2}, LA/d;->h(Ljava/lang/String;Ljava/lang/StringBuilder;)V

    :cond_4
    const/16 v3, 0x20

    and-int/2addr v4, v3

    if-ne v4, v3, :cond_5

    const-string v3, "Bottom"

    invoke-static {v3, v2}, LA/d;->h(Ljava/lang/String;Ljava/lang/StringBuilder;)V

    :cond_5
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "toString(...)"

    invoke-static {v2, v3}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x29

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
