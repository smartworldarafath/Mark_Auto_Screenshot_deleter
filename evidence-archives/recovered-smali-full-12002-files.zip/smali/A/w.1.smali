.class public final LA/w;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LA/w;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LA/w;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LA/w;->a:LA/w;

    return-void
.end method

.method public static a(Lm0/r;)Lm0/r;
    .locals 5

    const/high16 v0, 0x3f800000    # 1.0f

    float-to-double v1, v0

    const-wide/16 v3, 0x0

    cmpl-double v1, v1, v3

    if-lez v1, :cond_0

    goto :goto_0

    :cond_0
    const-string v1, "invalid weight; must be greater than zero"

    invoke-static {v1}, LB/a;->a(Ljava/lang/String;)V

    :goto_0
    new-instance v1, Landroidx/compose/foundation/layout/LayoutWeightElement;

    const/4 v2, 0x1

    invoke-direct {v1, v0, v2}, Landroidx/compose/foundation/layout/LayoutWeightElement;-><init>(FZ)V

    invoke-interface {p0, v1}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method
