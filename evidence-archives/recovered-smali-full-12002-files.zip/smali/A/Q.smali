.class public final synthetic LA/Q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Ljava/lang/Object;

.field public final synthetic v:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA/Q;->t:I

    iput-object p2, p0, LA/Q;->v:Ljava/lang/Object;

    iput-object p3, p0, LA/Q;->u:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LI/I0;LW0/e;LI/a0;)V
    .locals 0

    .line 2
    const/16 p1, 0xc

    iput p1, p0, LA/Q;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LA/Q;->v:Ljava/lang/Object;

    iput-object p3, p0, LA/Q;->u:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    iget v2, v1, LA/Q;->t:I

    const-wide/16 v3, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    packed-switch v2, :pswitch_data_0

    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Ljava/util/ArrayList;

    check-cast v0, Lv2/a;

    invoke-interface {v0, v2}, Lv2/a;->d0(Ljava/lang/String;)Lv2/c;

    move-result-object v2

    :try_start_0
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    :goto_0
    if-ge v9, v4, :cond_1

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    add-int/lit8 v9, v9, 0x1

    check-cast v5, Ljava/lang/Long;

    if-nez v5, :cond_0

    invoke-interface {v2, v10}, Lv2/c;->d(I)V

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_2

    :cond_0
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    invoke-interface {v2, v10, v5, v6}, Lv2/c;->b(IJ)V

    :goto_1
    add-int/lit8 v10, v10, 0x1

    goto :goto_0

    :cond_1
    invoke-interface {v2}, Lv2/c;->Y()Z

    invoke-static {v0}, LH4/R4;->a(Lv2/a;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    return-object v0

    :goto_2
    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    throw v0

    :pswitch_0
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, Lj6/b;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Lk6/a;

    check-cast v0, Lv2/a;

    iget-object v2, v2, Lj6/b;->b:Ljava/lang/Object;

    check-cast v2, Lj6/a;

    const-string v4, "connection"

    invoke-static {v0, v4}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "INSERT OR REPLACE INTO `scheduled_screenshot_entity` (`id`,`filePath`,`deleteTime`,`timeUnit`,`workManagerId`,`createdAtEpochMillis`,`screenshotId`) VALUES (nullif(?, 0),?,?,?,?,?,?)"

    invoke-interface {v0, v4}, Lv2/a;->d0(Ljava/lang/String;)Lv2/c;

    move-result-object v4

    :try_start_1
    invoke-virtual {v2, v4, v3}, Lj6/a;->a(Lv2/c;Ljava/lang/Object;)V

    invoke-interface {v4}, Lv2/c;->Y()Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    invoke-static {v4, v8}, LH4/F4;->a(Lv2/c;Ljava/lang/Throwable;)V

    invoke-static {v0}, LH4/R4;->a(Lv2/a;)I

    move-result v2

    if-nez v2, :cond_2

    const-wide/16 v2, -0x1

    goto :goto_3

    :cond_2
    const-string v2, "SELECT last_insert_rowid()"

    invoke-interface {v0, v2}, Lv2/a;->d0(Ljava/lang/String;)Lv2/c;

    move-result-object v2

    :try_start_2
    invoke-interface {v2}, Lv2/c;->Y()Z

    invoke-interface {v2, v9}, Lv2/c;->getLong(I)J

    move-result-wide v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    invoke-static {v2, v8}, LH4/F4;->a(Lv2/c;Ljava/lang/Throwable;)V

    move-wide v2, v3

    :goto_3
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    return-object v0

    :catchall_1
    move-exception v0

    move-object v3, v0

    :try_start_3
    throw v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :catchall_2
    move-exception v0

    invoke-static {v2, v3}, LH4/F4;->a(Lv2/c;Ljava/lang/Throwable;)V

    throw v0

    :catchall_3
    move-exception v0

    move-object v2, v0

    :try_start_4
    throw v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    :catchall_4
    move-exception v0

    invoke-static {v4, v2}, LH4/F4;->a(Lv2/c;Ljava/lang/Throwable;)V

    throw v0

    :pswitch_1
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, Lb2/t;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Landroidx/lifecycle/w;

    check-cast v0, La0/H;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "owner"

    invoke-static {v3, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v2, Lb2/t;->b:Le2/f;

    iget-object v2, v0, Le2/f;->r:Le2/d;

    iget-object v4, v0, Le2/f;->n:Landroidx/lifecycle/w;

    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    goto :goto_4

    :cond_3
    iget-object v4, v0, Le2/f;->n:Landroidx/lifecycle/w;

    if-eqz v4, :cond_4

    invoke-interface {v4}, Landroidx/lifecycle/w;->g()LE/V;

    move-result-object v4

    if-eqz v4, :cond_4

    invoke-virtual {v4, v2}, LE/V;->z(Landroidx/lifecycle/v;)V

    :cond_4
    iput-object v3, v0, Le2/f;->n:Landroidx/lifecycle/w;

    invoke-interface {v3}, Landroidx/lifecycle/w;->g()LE/V;

    move-result-object v0

    invoke-virtual {v0, v2}, LE/V;->l(Landroidx/lifecycle/v;)V

    :goto_4
    new-instance v0, Lc2/y;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    return-object v0

    :pswitch_2
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, La0/W0;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Lc2/i;

    check-cast v0, La0/H;

    new-instance v0, LA/j0;

    const/4 v4, 0x7

    invoke-direct {v0, v4, v2, v3}, LA/j0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    return-object v0

    :pswitch_3
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, Lb2/p;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Lb2/t;

    iget-object v3, v3, Lb2/t;->b:Le2/f;

    check-cast v0, Lb2/w;

    const-string v4, "$this$navOptions"

    invoke-static {v0, v4}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v4, v0, Lb2/w;->a:LA1/m;

    iput v9, v4, LA1/m;->a:I

    iput v9, v4, LA1/m;->b:I

    instance-of v4, v2, Lb2/q;

    if-eqz v4, :cond_8

    sget v4, Lb2/p;->x:I

    invoke-static {v2}, LF4/B5;->b(Lb2/p;)Lz7/f;

    move-result-object v2

    invoke-interface {v2}, Lz7/f;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_5
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_7

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lb2/p;

    invoke-virtual {v3}, Le2/f;->f()Lb2/p;

    move-result-object v5

    if-eqz v5, :cond_6

    iget-object v5, v5, Lb2/p;->v:Lb2/q;

    goto :goto_5

    :cond_6
    move-object v5, v8

    :goto_5
    invoke-static {v4, v5}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5

    goto :goto_6

    :cond_7
    sget v2, Lb2/q;->z:I

    invoke-virtual {v3}, Le2/f;->g()Lb2/q;

    move-result-object v2

    invoke-static {v2}, LF4/C5;->a(Lb2/q;)Lb2/p;

    move-result-object v2

    iget-object v2, v2, Lb2/p;->u:LL0/y0;

    iget v2, v2, LL0/y0;->a:I

    iput v2, v0, Lb2/w;->d:I

    iput-boolean v10, v0, Lb2/w;->e:Z

    :cond_8
    :goto_6
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_4
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LP2/e;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, La1/D;

    check-cast v0, La1/G;

    iget-object v4, v2, LP2/e;->t:Ljava/lang/Object;

    check-cast v4, LT5/q;

    monitor-enter v4

    :try_start_5
    invoke-interface {v0}, La1/G;->a()Z

    move-result v5

    if-eqz v5, :cond_9

    iget-object v2, v2, LP2/e;->u:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/internal/ads/bM;

    invoke-virtual {v2, v3, v0}, Lcom/google/android/gms/internal/ads/bM;->d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La1/G;

    goto :goto_7

    :catchall_5
    move-exception v0

    goto :goto_8

    :cond_9
    iget-object v0, v2, LP2/e;->u:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/ads/bM;

    invoke-virtual {v0, v3}, Lcom/google/android/gms/internal/ads/bM;->e(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La1/G;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    :goto_7
    monitor-exit v4

    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :goto_8
    monitor-exit v4

    throw v0

    :pswitch_5
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, La1/n;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    move-object v14, v3

    check-cast v14, La1/D;

    move-object/from16 v16, v0

    check-cast v16, Lr7/c;

    iget-object v0, v2, La1/n;->d:La1/s;

    iget-object v3, v2, La1/n;->a:LL4/K1;

    iget-object v4, v2, La1/n;->f:LA7/j;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v5, v14, La1/D;->a:La1/m;

    instance-of v6, v5, La1/p;

    if-nez v6, :cond_a

    move-object v0, v8

    goto/16 :goto_21

    :cond_a
    check-cast v5, La1/p;

    iget-object v5, v5, La1/p;->v:Ljava/util/List;

    iget-object v6, v14, La1/D;->b:La1/w;

    iget v7, v14, La1/D;->c:I

    new-instance v11, Ljava/util/ArrayList;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v12

    invoke-direct {v11, v12}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v12

    move v13, v9

    :goto_9
    if-ge v13, v12, :cond_c

    invoke-interface {v5, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    move-object v9, v15

    check-cast v9, Lb1/b;

    iget-object v9, v9, Lb1/b;->c:La1/w;

    invoke-static {v9, v6}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_b

    if-nez v7, :cond_b

    invoke-virtual {v11, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_b
    add-int/lit8 v13, v13, 0x1

    const/4 v9, 0x0

    goto :goto_9

    :cond_c
    invoke-virtual {v11}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_d

    goto/16 :goto_1b

    :cond_d
    new-instance v9, Ljava/util/ArrayList;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v11

    invoke-direct {v9, v11}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v11

    const/4 v12, 0x0

    :goto_a
    if-ge v12, v11, :cond_f

    invoke-interface {v5, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    move-object v15, v13

    check-cast v15, Lb1/b;

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez v7, :cond_e

    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_e
    add-int/lit8 v12, v12, 0x1

    goto :goto_a

    :cond_f
    invoke-virtual {v9}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_10

    goto :goto_b

    :cond_10
    move-object v5, v9

    :goto_b
    sget-object v7, La1/w;->u:La1/w;

    invoke-virtual {v6, v7}, La1/w;->a(La1/w;)I

    move-result v7

    iget v9, v6, La1/w;->t:I

    if-gez v7, :cond_1a

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v6

    move-object v11, v8

    move-object v12, v11

    const/4 v7, 0x0

    :goto_c
    if-ge v7, v6, :cond_16

    invoke-interface {v5, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lb1/b;

    iget-object v13, v13, Lb1/b;->c:La1/w;

    iget v15, v13, La1/w;->t:I

    invoke-static {v15, v9}, Ls7/j;->f(II)I

    move-result v18

    if-gez v18, :cond_12

    if-eqz v11, :cond_11

    iget v8, v11, La1/w;->t:I

    invoke-static {v15, v8}, Ls7/j;->f(II)I

    move-result v8

    if-lez v8, :cond_14

    :cond_11
    move-object v11, v13

    goto :goto_d

    :cond_12
    invoke-static {v15, v9}, Ls7/j;->f(II)I

    move-result v8

    if-lez v8, :cond_15

    if-eqz v12, :cond_13

    iget v8, v12, La1/w;->t:I

    invoke-static {v15, v8}, Ls7/j;->f(II)I

    move-result v8

    if-gez v8, :cond_14

    :cond_13
    move-object v12, v13

    :cond_14
    :goto_d
    add-int/lit8 v7, v7, 0x1

    const/4 v8, 0x0

    goto :goto_c

    :cond_15
    move-object v11, v13

    move-object v12, v11

    :cond_16
    if-nez v11, :cond_17

    move-object v11, v12

    :cond_17
    new-instance v6, Ljava/util/ArrayList;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v7

    const/4 v8, 0x0

    :goto_e
    if-ge v8, v7, :cond_19

    invoke-interface {v5, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    move-object v12, v9

    check-cast v12, Lb1/b;

    iget-object v12, v12, Lb1/b;->c:La1/w;

    invoke-static {v12, v11}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_18

    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_18
    add-int/lit8 v8, v8, 0x1

    goto :goto_e

    :cond_19
    move-object v11, v6

    goto/16 :goto_1b

    :cond_1a
    sget-object v7, La1/w;->v:La1/w;

    invoke-virtual {v6, v7}, La1/w;->a(La1/w;)I

    move-result v6

    if-lez v6, :cond_23

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v6

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v11, 0x0

    :goto_f
    if-ge v7, v6, :cond_20

    invoke-interface {v5, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lb1/b;

    iget-object v12, v12, Lb1/b;->c:La1/w;

    iget v13, v12, La1/w;->t:I

    invoke-static {v13, v9}, Ls7/j;->f(II)I

    move-result v15

    if-gez v15, :cond_1c

    if-eqz v8, :cond_1b

    iget v15, v8, La1/w;->t:I

    invoke-static {v13, v15}, Ls7/j;->f(II)I

    move-result v13

    if-lez v13, :cond_1e

    :cond_1b
    move-object v8, v12

    goto :goto_10

    :cond_1c
    invoke-static {v13, v9}, Ls7/j;->f(II)I

    move-result v15

    if-lez v15, :cond_1f

    if-eqz v11, :cond_1d

    iget v15, v11, La1/w;->t:I

    invoke-static {v13, v15}, Ls7/j;->f(II)I

    move-result v13

    if-gez v13, :cond_1e

    :cond_1d
    move-object v11, v12

    :cond_1e
    :goto_10
    add-int/lit8 v7, v7, 0x1

    goto :goto_f

    :cond_1f
    move-object v8, v12

    move-object v11, v8

    :cond_20
    if-nez v11, :cond_21

    goto :goto_11

    :cond_21
    move-object v8, v11

    :goto_11
    new-instance v11, Ljava/util/ArrayList;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v6

    invoke-direct {v11, v6}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v6

    const/4 v7, 0x0

    :goto_12
    if-ge v7, v6, :cond_37

    invoke-interface {v5, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    move-object v12, v9

    check-cast v12, Lb1/b;

    iget-object v12, v12, Lb1/b;->c:La1/w;

    invoke-static {v12, v8}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_22

    invoke-virtual {v11, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_22
    add-int/lit8 v7, v7, 0x1

    goto :goto_12

    :cond_23
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v6

    const/4 v8, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    :goto_13
    if-ge v8, v6, :cond_2a

    invoke-interface {v5, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lb1/b;

    iget-object v13, v13, Lb1/b;->c:La1/w;

    iget v15, v13, La1/w;->t:I

    iget v10, v7, La1/w;->t:I

    invoke-static {v15, v10}, Ls7/j;->f(II)I

    move-result v10

    if-lez v10, :cond_24

    goto :goto_14

    :cond_24
    iget v10, v13, La1/w;->t:I

    invoke-static {v10, v9}, Ls7/j;->f(II)I

    move-result v15

    if-gez v15, :cond_26

    if-eqz v11, :cond_25

    iget v15, v11, La1/w;->t:I

    invoke-static {v10, v15}, Ls7/j;->f(II)I

    move-result v10

    if-lez v10, :cond_28

    :cond_25
    move-object v11, v13

    goto :goto_14

    :cond_26
    invoke-static {v10, v9}, Ls7/j;->f(II)I

    move-result v15

    if-lez v15, :cond_29

    if-eqz v12, :cond_27

    iget v15, v12, La1/w;->t:I

    invoke-static {v10, v15}, Ls7/j;->f(II)I

    move-result v10

    if-gez v10, :cond_28

    :cond_27
    move-object v12, v13

    :cond_28
    :goto_14
    add-int/lit8 v8, v8, 0x1

    const/4 v10, 0x1

    goto :goto_13

    :cond_29
    move-object v11, v13

    move-object v12, v11

    :cond_2a
    if-nez v12, :cond_2b

    goto :goto_15

    :cond_2b
    move-object v11, v12

    :goto_15
    new-instance v6, Ljava/util/ArrayList;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v7

    const/4 v8, 0x0

    :goto_16
    if-ge v8, v7, :cond_2d

    invoke-interface {v5, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    move-object v12, v10

    check-cast v12, Lb1/b;

    iget-object v12, v12, Lb1/b;->c:La1/w;

    invoke-static {v12, v11}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_2c

    invoke-virtual {v6, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2c
    add-int/lit8 v8, v8, 0x1

    goto :goto_16

    :cond_2d
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_19

    sget-object v6, La1/w;->v:La1/w;

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v7

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    :goto_17
    if-ge v8, v7, :cond_34

    invoke-interface {v5, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lb1/b;

    iget-object v12, v12, Lb1/b;->c:La1/w;

    if-eqz v6, :cond_2e

    iget v13, v12, La1/w;->t:I

    iget v15, v6, La1/w;->t:I

    invoke-static {v13, v15}, Ls7/j;->f(II)I

    move-result v13

    if-gez v13, :cond_2e

    goto :goto_18

    :cond_2e
    iget v13, v12, La1/w;->t:I

    invoke-static {v13, v9}, Ls7/j;->f(II)I

    move-result v15

    if-gez v15, :cond_30

    if-eqz v10, :cond_2f

    iget v15, v10, La1/w;->t:I

    invoke-static {v13, v15}, Ls7/j;->f(II)I

    move-result v13

    if-lez v13, :cond_32

    :cond_2f
    move-object v10, v12

    goto :goto_18

    :cond_30
    invoke-static {v13, v9}, Ls7/j;->f(II)I

    move-result v15

    if-lez v15, :cond_33

    if-eqz v11, :cond_31

    iget v15, v11, La1/w;->t:I

    invoke-static {v13, v15}, Ls7/j;->f(II)I

    move-result v13

    if-gez v13, :cond_32

    :cond_31
    move-object v11, v12

    :cond_32
    :goto_18
    add-int/lit8 v8, v8, 0x1

    goto :goto_17

    :cond_33
    move-object v10, v12

    move-object v11, v10

    :cond_34
    if-nez v11, :cond_35

    goto :goto_19

    :cond_35
    move-object v10, v11

    :goto_19
    new-instance v11, Ljava/util/ArrayList;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v6

    invoke-direct {v11, v6}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v6

    const/4 v7, 0x0

    :goto_1a
    if-ge v7, v6, :cond_37

    invoke-interface {v5, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    move-object v9, v8

    check-cast v9, Lb1/b;

    iget-object v9, v9, Lb1/b;->c:La1/w;

    invoke-static {v9, v10}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_36

    invoke-virtual {v11, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_36
    add-int/lit8 v7, v7, 0x1

    goto :goto_1a

    :cond_37
    :goto_1b
    iget-object v5, v0, La1/s;->a:LA4/f;

    invoke-interface {v11}, Ljava/util/Collection;->size()I

    move-result v6

    const/4 v7, 0x0

    const/4 v9, 0x0

    :goto_1c
    if-ge v9, v6, :cond_3c

    invoke-interface {v11, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lb1/b;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, La1/h;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v10, v8}, La1/h;-><init>(Lb1/b;)V

    iget-object v12, v5, LA4/f;->w:Ljava/lang/Object;

    check-cast v12, LT5/q;

    monitor-enter v12

    :try_start_6
    iget-object v13, v5, LA4/f;->u:Ljava/lang/Object;

    check-cast v13, Lcom/google/android/gms/internal/ads/bM;

    invoke-virtual {v13, v10}, Lcom/google/android/gms/internal/ads/bM;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La1/g;

    if-nez v13, :cond_38

    iget-object v13, v5, LA4/f;->v:Ljava/lang/Object;

    check-cast v13, Lp/H;

    invoke-virtual {v13, v10}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    move-object v13, v10

    check-cast v13, La1/g;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_6

    goto :goto_1d

    :catchall_6
    move-exception v0

    goto :goto_1f

    :cond_38
    :goto_1d
    monitor-exit v12

    if-nez v13, :cond_3a

    if-nez v7, :cond_39

    filled-new-array {v8}, [Lb1/b;

    move-result-object v7

    invoke-static {v7}, Le7/m;->h([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v7

    goto :goto_1e

    :cond_39
    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1e

    :cond_3a
    iget-object v10, v13, La1/g;->a:Ljava/lang/Object;

    if-nez v10, :cond_3b

    :goto_1e
    add-int/lit8 v9, v9, 0x1

    goto :goto_1c

    :cond_3b
    iget v4, v14, La1/D;->d:I

    iget-object v5, v14, La1/D;->b:La1/w;

    iget v6, v14, La1/D;->c:I

    invoke-static {v4, v10, v8, v5, v6}, LF4/i5;->a(ILjava/lang/Object;Lb1/b;La1/w;I)Ljava/lang/Object;

    move-result-object v4

    new-instance v5, Ld7/k;

    invoke-direct {v5, v7, v4}, Ld7/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_20

    :goto_1f
    monitor-exit v12

    throw v0

    :cond_3c
    invoke-virtual {v4, v14}, LA7/j;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    new-instance v5, Ld7/k;

    invoke-direct {v5, v7, v4}, Ld7/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_20
    iget-object v4, v5, Ld7/k;->t:Ljava/lang/Object;

    move-object v12, v4

    check-cast v12, Ljava/util/List;

    iget-object v13, v5, Ld7/k;->u:Ljava/lang/Object;

    if-nez v12, :cond_3d

    new-instance v0, La1/F;

    const/4 v4, 0x1

    invoke-direct {v0, v13, v4}, La1/F;-><init>(Ljava/lang/Object;Z)V

    goto :goto_21

    :cond_3d
    const/4 v4, 0x1

    new-instance v11, La1/f;

    iget-object v15, v0, La1/s;->a:LA4/f;

    move-object/from16 v17, v3

    invoke-direct/range {v11 .. v17}, La1/f;-><init>(Ljava/util/List;Ljava/lang/Object;La1/D;LA4/f;Lr7/c;LL4/K1;)V

    iget-object v0, v0, La1/s;->b:LI7/d;

    sget-object v3, LD7/w;->w:LD7/w;

    new-instance v5, La1/q;

    const/4 v6, 0x0

    invoke-direct {v5, v11, v6}, La1/q;-><init>(La1/f;Lh7/c;)V

    invoke-static {v0, v6, v3, v5, v4}, LD7/y;->x(LD7/v;Lh7/h;LD7/w;Lr7/e;I)LD7/B;

    new-instance v0, La1/E;

    invoke-direct {v0, v11}, La1/E;-><init>(La1/f;)V

    :goto_21
    if-nez v0, :cond_42

    iget-object v0, v2, La1/n;->e:LU2/h;

    iget-object v0, v0, LU2/h;->t:Ljava/lang/Object;

    check-cast v0, La1/B;

    iget-object v2, v14, La1/D;->a:La1/m;

    iget v3, v14, La1/D;->c:I

    iget-object v4, v14, La1/D;->b:La1/w;

    if-eqz v2, :cond_40

    instance-of v5, v2, La1/j;

    if-eqz v5, :cond_3e

    goto :goto_22

    :cond_3e
    instance-of v5, v2, La1/y;

    if-eqz v5, :cond_3f

    check-cast v2, La1/y;

    invoke-interface {v0, v2, v4, v3}, La1/B;->m(La1/y;La1/w;I)Landroid/graphics/Typeface;

    move-result-object v0

    goto :goto_23

    :cond_3f
    const/4 v8, 0x0

    goto :goto_24

    :cond_40
    :goto_22
    invoke-interface {v0, v4, v3}, La1/B;->a(La1/w;I)Landroid/graphics/Typeface;

    move-result-object v0

    :goto_23
    new-instance v8, La1/F;

    const/4 v4, 0x1

    invoke-direct {v8, v0, v4}, La1/F;-><init>(Ljava/lang/Object;Z)V

    :goto_24
    if-eqz v8, :cond_41

    move-object v0, v8

    goto :goto_25

    :cond_41
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "Could not load font"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_42
    :goto_25
    return-object v0

    :pswitch_6
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, La0/y0;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Throwable;

    check-cast v0, Ljava/lang/Throwable;

    iget-object v4, v2, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v4

    if-eqz v3, :cond_44

    if-eqz v0, :cond_45

    :try_start_7
    instance-of v5, v0, Ljava/util/concurrent/CancellationException;

    if-nez v5, :cond_43

    goto :goto_26

    :cond_43
    const/4 v0, 0x0

    :goto_26
    if-eqz v0, :cond_45

    invoke-static {v3, v0}, Ld7/a;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    goto :goto_27

    :catchall_7
    move-exception v0

    goto :goto_28

    :cond_44
    const/4 v3, 0x0

    :cond_45
    :goto_27
    iput-object v3, v2, La0/y0;->d:Ljava/lang/Throwable;

    iget-object v0, v2, La0/y0;->t:LG7/g0;

    sget-object v2, La0/s0;->t:La0/s0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v6, 0x0

    invoke-virtual {v0, v6, v2}, LG7/g0;->j(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_7

    monitor-exit v4

    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :goto_28
    monitor-exit v4

    throw v0

    :pswitch_7
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, La0/x;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Lp/I;

    invoke-virtual {v2, v0}, La0/x;->A(Ljava/lang/Object;)V

    if-eqz v3, :cond_46

    invoke-virtual {v3, v0}, Lp/I;->a(Ljava/lang/Object;)Z

    :cond_46
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_8
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, Lr7/a;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Lr7/a;

    check-cast v0, LL/g;

    invoke-interface {v2}, Lr7/a;->a()Ljava/lang/Object;

    if-eqz v3, :cond_47

    invoke-interface {v3}, Lr7/a;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v10

    goto :goto_29

    :cond_47
    const/4 v10, 0x1

    :goto_29
    if-eqz v10, :cond_48

    invoke-interface {v0}, LL/g;->close()V

    :cond_48
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_9
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LM6/f;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, La0/Z;

    check-cast v0, LD/h;

    const-string v4, "$this$LazyVerticalGrid"

    invoke-static {v0, v4}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, v2, LM6/f;->e:Ljava/util/List;

    new-instance v4, LC/v;

    const/16 v6, 0x19

    invoke-direct {v4, v6}, LC/v;-><init>(I)V

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v6

    new-instance v8, LI/L;

    invoke-direct {v8, v5, v4, v2}, LI/L;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    new-instance v4, LI6/m;

    invoke-direct {v4, v7, v2}, LI6/m;-><init>(ILjava/util/List;)V

    new-instance v5, LH6/I;

    invoke-direct {v5, v2, v3}, LH6/I;-><init>(Ljava/util/List;La0/Z;)V

    new-instance v2, Li0/d;

    const v3, -0x4297e015

    const/4 v7, 0x1

    invoke-direct {v2, v3, v5, v7}, Li0/d;-><init>(ILjava/lang/Object;Z)V

    invoke-virtual {v0, v6, v8, v4, v2}, LD/h;->o(ILr7/c;Lr7/c;Li0/d;)V

    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_a
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LK6/o;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    check-cast v0, Lf/a;

    const-string v4, "it"

    invoke-static {v0, v4}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v3}, LK6/o;->a(Landroid/content/Context;)V

    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_b
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LK6/o;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, LO6/a;

    check-cast v0, Ld7/k;

    const-string v4, " "

    const-string v5, "time"

    invoke-static {v0, v5}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v5, v0, Ld7/k;->u:Ljava/lang/Object;

    iget-object v6, v0, Ld7/k;->t:Ljava/lang/Object;

    iget-object v8, v2, LK6/o;->i:La0/e0;

    invoke-virtual {v8}, La0/e0;->h()I

    move-result v8

    if-eqz v8, :cond_4b

    const/4 v9, 0x1

    if-eq v8, v9, :cond_4a

    if-eq v8, v7, :cond_49

    goto/16 :goto_2a

    :cond_49
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v3, LO6/a;->a:LT6/b;

    sget-object v8, LT6/a;->C:LT6/a;

    invoke-virtual {v7, v8, v0}, LT6/b;->h(LT6/a;Ld7/k;)V

    iget-object v7, v3, LO6/a;->i:La0/h0;

    invoke-virtual {v7, v0}, La0/h0;->setValue(Ljava/lang/Object;)V

    const-string v0, "chip3_setup"

    check-cast v5, Lv6/d;

    iget-object v5, v5, Lv6/d;->t:Ljava/lang/String;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, LO6/a;->g()Z

    move-result v5

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v3}, LO6/a;->h()Z

    move-result v6

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    iget-object v3, v3, LO6/a;->e:La0/e0;

    invoke-virtual {v3}, La0/e0;->h()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v0, v4, v5, v6, v3}, Lp6/b;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V

    goto/16 :goto_2a

    :cond_4a
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v3, LO6/a;->a:LT6/b;

    sget-object v8, LT6/a;->B:LT6/a;

    invoke-virtual {v7, v8, v0}, LT6/b;->h(LT6/a;Ld7/k;)V

    iget-object v7, v3, LO6/a;->h:La0/h0;

    invoke-virtual {v7, v0}, La0/h0;->setValue(Ljava/lang/Object;)V

    const-string v0, "chip2_setup"

    check-cast v5, Lv6/d;

    iget-object v5, v5, Lv6/d;->t:Ljava/lang/String;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, LO6/a;->g()Z

    move-result v5

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v3}, LO6/a;->h()Z

    move-result v6

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    iget-object v3, v3, LO6/a;->e:La0/e0;

    invoke-virtual {v3}, La0/e0;->h()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v0, v4, v5, v6, v3}, Lp6/b;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V

    goto :goto_2a

    :cond_4b
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v3, LO6/a;->a:LT6/b;

    sget-object v8, LT6/a;->A:LT6/a;

    invoke-virtual {v7, v8, v0}, LT6/b;->h(LT6/a;Ld7/k;)V

    iget-object v7, v3, LO6/a;->g:La0/h0;

    invoke-virtual {v7, v0}, La0/h0;->setValue(Ljava/lang/Object;)V

    const-string v0, "chip1_setup"

    check-cast v5, Lv6/d;

    iget-object v5, v5, Lv6/d;->t:Ljava/lang/String;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, LO6/a;->g()Z

    move-result v5

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v3}, LO6/a;->h()Z

    move-result v6

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    iget-object v3, v3, LO6/a;->e:La0/e0;

    invoke-virtual {v3}, La0/e0;->h()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v0, v4, v5, v6, v3}, Lp6/b;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;)V

    :goto_2a
    const/4 v0, -0x1

    const/4 v3, 0x0

    invoke-virtual {v2, v0, v3}, LK6/o;->b(IZ)V

    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_c
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LJ6/f;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, La0/Z;

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    invoke-interface {v3, v0}, La0/Z;->setValue(Ljava/lang/Object;)V

    iget-object v0, v2, LJ6/f;->c:LT6/b;

    sget-object v2, LT6/a;->y:LT6/a;

    invoke-virtual {v0, v2, v4}, LT6/b;->e(LT6/a;Z)V

    if-eqz v4, :cond_4c

    const-string v0, "no_dialog_feature_enabled"

    goto :goto_2b

    :cond_4c
    const-string v0, "no_dialog_feature_disabled"

    :goto_2b
    sget-object v2, Le7/u;->t:Le7/u;

    invoke-static {v0, v2}, Lp6/b;->c(Ljava/lang/String;Ljava/util/Map;)V

    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_d
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    move-object v9, v2

    check-cast v9, LI6/F;

    iget-object v2, v1, LA/Q;->u:Ljava/lang/Object;

    move-object v10, v2

    check-cast v10, Landroid/content/Context;

    move-object v12, v0

    check-cast v12, Ld7/k;

    const-string v0, "timePair"

    invoke-static {v12, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "context"

    invoke-static {v10, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v9}, LI6/F;->h()Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_4d

    goto :goto_2c

    :cond_4d
    invoke-static {v9}, Landroidx/lifecycle/U;->h(Landroidx/lifecycle/a0;)La2/a;

    move-result-object v0

    sget-object v2, LD7/I;->a:LK7/e;

    new-instance v8, LI6/C;

    const/4 v13, 0x0

    invoke-direct/range {v8 .. v13}, LI6/C;-><init>(LI6/F;Landroid/content/Context;Ljava/util/ArrayList;Ld7/k;Lh7/c;)V

    const/4 v6, 0x0

    invoke-static {v0, v2, v6, v8, v7}, LD7/y;->x(LD7/v;Lh7/h;LD7/w;Lr7/e;I)LD7/B;

    const-string v0, "bulk_timer_set"

    sget-object v2, Le7/u;->t:Le7/u;

    invoke-static {v0, v2}, Lp6/b;->c(Ljava/lang/String;Ljava/util/Map;)V

    :goto_2c
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_e
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, Ljava/util/List;

    iget-object v5, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    check-cast v0, LJ0/X;

    if-eqz v2, :cond_4e

    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v6

    const/4 v7, 0x0

    :goto_2d
    if-ge v7, v6, :cond_4e

    invoke-interface {v2, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld7/k;

    iget-object v9, v8, Ld7/k;->t:Ljava/lang/Object;

    check-cast v9, LJ0/Y;

    iget-object v8, v8, Ld7/k;->u:Ljava/lang/Object;

    check-cast v8, Lj1/j;

    iget-wide v10, v8, Lj1/j;->a:J

    invoke-static {v0, v9, v10, v11}, LJ0/X;->k(LJ0/X;LJ0/Y;J)V

    add-int/lit8 v7, v7, 0x1

    goto :goto_2d

    :cond_4e
    if-eqz v5, :cond_50

    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v2

    const/4 v9, 0x0

    :goto_2e
    if-ge v9, v2, :cond_50

    invoke-interface {v5, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld7/k;

    iget-object v7, v6, Ld7/k;->t:Ljava/lang/Object;

    check-cast v7, LJ0/Y;

    iget-object v6, v6, Ld7/k;->u:Ljava/lang/Object;

    check-cast v6, Lr7/a;

    if-eqz v6, :cond_4f

    invoke-interface {v6}, Lr7/a;->a()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lj1/j;

    iget-wide v10, v6, Lj1/j;->a:J

    goto :goto_2f

    :cond_4f
    move-wide v10, v3

    :goto_2f
    invoke-static {v0, v7, v10, v11}, LJ0/X;->k(LJ0/X;LJ0/Y;J)V

    add-int/lit8 v9, v9, 0x1

    goto :goto_2e

    :cond_50
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_f
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LI/I0;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, LW0/e;

    check-cast v0, Lt0/E;

    iget-object v4, v2, LI/I0;->b:LW0/g;

    iget-object v2, v2, LI/I0;->a:La0/h0;

    invoke-virtual {v2}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LW0/I;

    if-eqz v5, :cond_51

    iget-object v5, v5, LW0/I;->a:LW0/H;

    if-eqz v5, :cond_51

    iget-object v5, v5, LW0/H;->a:LW0/g;

    goto :goto_30

    :cond_51
    const/4 v5, 0x0

    :goto_30
    invoke-static {v4, v5}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_53

    :cond_52
    :goto_31
    const/4 v6, 0x0

    goto/16 :goto_33

    :cond_53
    invoke-virtual {v2}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LW0/I;

    if-eqz v2, :cond_52

    iget-object v4, v2, LW0/I;->b:LW0/o;

    invoke-static {v3, v2}, LI/I0;->c(LW0/e;LW0/I;)LW0/e;

    move-result-object v3

    if-nez v3, :cond_54

    goto :goto_31

    :cond_54
    iget v5, v3, LW0/e;->c:I

    iget v3, v3, LW0/e;->b:I

    invoke-virtual {v2, v3, v5}, LW0/I;->h(II)Lt0/h;

    move-result-object v7

    invoke-virtual {v2, v3}, LW0/I;->b(I)Ls0/c;

    move-result-object v8

    const/16 v19, 0x1

    add-int/lit8 v5, v5, -0x1

    invoke-virtual {v2, v5}, LW0/I;->b(I)Ls0/c;

    move-result-object v2

    invoke-virtual {v4, v3}, LW0/o;->d(I)I

    move-result v3

    invoke-virtual {v4, v5}, LW0/o;->d(I)I

    move-result v4

    if-ne v3, v4, :cond_55

    iget v2, v2, Ls0/c;->a:F

    iget v3, v8, Ls0/c;->a:F

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v6

    :cond_55
    iget v2, v8, Ls0/c;->b:F

    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v3

    int-to-long v3, v3

    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v2

    int-to-long v5, v2

    const/16 v2, 0x20

    shl-long/2addr v3, v2

    const-wide v8, 0xffffffffL

    and-long/2addr v5, v8

    or-long/2addr v3, v5

    const-wide v5, -0x7fffffff80000000L    # -1.0609978955E-314

    xor-long/2addr v3, v5

    iget-object v5, v7, Lt0/h;->d:Landroid/graphics/Matrix;

    if-nez v5, :cond_56

    new-instance v5, Landroid/graphics/Matrix;

    invoke-direct {v5}, Landroid/graphics/Matrix;-><init>()V

    iput-object v5, v7, Lt0/h;->d:Landroid/graphics/Matrix;

    goto :goto_32

    :cond_56
    invoke-virtual {v5}, Landroid/graphics/Matrix;->reset()V

    :goto_32
    iget-object v5, v7, Lt0/h;->d:Landroid/graphics/Matrix;

    invoke-static {v5}, Ls7/j;->b(Ljava/lang/Object;)V

    shr-long v10, v3, v2

    long-to-int v2, v10

    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v2

    and-long/2addr v3, v8

    long-to-int v3, v3

    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v3

    invoke-virtual {v5, v2, v3}, Landroid/graphics/Matrix;->setTranslate(FF)V

    iget-object v2, v7, Lt0/h;->a:Landroid/graphics/Path;

    iget-object v3, v7, Lt0/h;->d:Landroid/graphics/Matrix;

    invoke-static {v3}, Ls7/j;->b(Ljava/lang/Object;)V

    invoke-virtual {v2, v3}, Landroid/graphics/Path;->transform(Landroid/graphics/Matrix;)V

    move-object v6, v7

    :goto_33
    if-eqz v6, :cond_57

    new-instance v8, LI/H0;

    invoke-direct {v8, v6}, LI/H0;-><init>(Lt0/h;)V

    goto :goto_34

    :cond_57
    const/4 v8, 0x0

    :goto_34
    if-eqz v8, :cond_58

    invoke-virtual {v0, v8}, Lt0/E;->l(Lt0/H;)V

    const/4 v4, 0x1

    invoke-virtual {v0, v4}, Lt0/E;->e(Z)V

    :cond_58
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_10
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LW0/e;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, LI/a0;

    iget-object v3, v3, LI/a0;->b:La0/e0;

    check-cast v0, LI/j0;

    iget-object v4, v2, LW0/e;->a:Ljava/lang/Object;

    check-cast v4, LW0/m;

    invoke-virtual {v4}, LW0/m;->a()LW0/J;

    move-result-object v6

    if-eqz v6, :cond_59

    iget-object v6, v6, LW0/J;->a:LW0/D;

    goto :goto_35

    :cond_59
    const/4 v6, 0x0

    :goto_35
    invoke-virtual {v3}, La0/e0;->h()I

    move-result v8

    const/16 v19, 0x1

    and-int/lit8 v8, v8, 0x1

    if-eqz v8, :cond_5a

    invoke-virtual {v4}, LW0/m;->a()LW0/J;

    move-result-object v8

    if-eqz v8, :cond_5a

    iget-object v8, v8, LW0/J;->b:LW0/D;

    goto :goto_36

    :cond_5a
    const/4 v8, 0x0

    :goto_36
    if-eqz v6, :cond_5b

    invoke-virtual {v6, v8}, LW0/D;->d(LW0/D;)LW0/D;

    move-result-object v8

    :cond_5b
    invoke-virtual {v3}, La0/e0;->h()I

    move-result v6

    and-int/2addr v6, v7

    if-eqz v6, :cond_5c

    invoke-virtual {v4}, LW0/m;->a()LW0/J;

    move-result-object v6

    if-eqz v6, :cond_5c

    iget-object v6, v6, LW0/J;->c:LW0/D;

    goto :goto_37

    :cond_5c
    const/4 v6, 0x0

    :goto_37
    if-eqz v8, :cond_5d

    invoke-virtual {v8, v6}, LW0/D;->d(LW0/D;)LW0/D;

    move-result-object v6

    :cond_5d
    invoke-virtual {v3}, La0/e0;->h()I

    move-result v3

    and-int/2addr v3, v5

    if-eqz v3, :cond_5e

    invoke-virtual {v4}, LW0/m;->a()LW0/J;

    move-result-object v3

    if-eqz v3, :cond_5e

    iget-object v8, v3, LW0/J;->d:LW0/D;

    goto :goto_38

    :cond_5e
    const/4 v8, 0x0

    :goto_38
    if-eqz v6, :cond_5f

    invoke-virtual {v6, v8}, LW0/D;->d(LW0/D;)LW0/D;

    move-result-object v8

    :cond_5f
    new-instance v3, Ls7/q;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    iget-object v4, v0, LI/j0;->a:LW0/g;

    new-instance v5, LI/i;

    invoke-direct {v5, v3, v2, v8, v7}, LI/i;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, LW0/d;

    invoke-direct {v2, v4}, LW0/d;-><init>(LW0/g;)V

    iget-object v3, v2, LW0/d;->v:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v9, 0x0

    :goto_39
    if-ge v9, v4, :cond_60

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LW0/c;

    const/high16 v7, -0x80000000

    invoke-virtual {v6, v7}, LW0/c;->a(I)LW0/e;

    move-result-object v6

    invoke-virtual {v5, v6}, LI/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LW0/e;

    new-instance v7, LW0/c;

    iget-object v8, v6, LW0/e;->a:Ljava/lang/Object;

    iget v10, v6, LW0/e;->b:I

    iget v11, v6, LW0/e;->c:I

    iget-object v6, v6, LW0/e;->d:Ljava/lang/String;

    invoke-direct {v7, v8, v10, v11, v6}, LW0/c;-><init>(Ljava/lang/Object;IILjava/lang/String;)V

    invoke-virtual {v3, v9, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v9, v9, 0x1

    goto :goto_39

    :cond_60
    invoke-virtual {v2}, LW0/d;->e()LW0/g;

    move-result-object v2

    iput-object v2, v0, LI/j0;->b:LW0/g;

    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_11
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, La0/Z;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Ly/j;

    check-cast v0, La0/H;

    new-instance v0, LA/j0;

    invoke-direct {v0, v7, v2, v3}, LA/j0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    return-object v0

    :pswitch_12
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, Ljava/util/List;

    iget-object v5, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v5, LI/b0;

    check-cast v0, LJ0/X;

    iget-object v5, v5, LI/b0;->a:Lr7/a;

    invoke-static {v2, v5}, LI/W;->m(Ljava/util/List;Lr7/a;)Ljava/util/ArrayList;

    move-result-object v2

    if-eqz v2, :cond_62

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v5

    const/4 v9, 0x0

    :goto_3a
    if-ge v9, v5, :cond_62

    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld7/k;

    iget-object v7, v6, Ld7/k;->t:Ljava/lang/Object;

    check-cast v7, LJ0/Y;

    iget-object v6, v6, Ld7/k;->u:Ljava/lang/Object;

    check-cast v6, Lr7/a;

    if-eqz v6, :cond_61

    invoke-interface {v6}, Lr7/a;->a()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lj1/j;

    iget-wide v10, v6, Lj1/j;->a:J

    goto :goto_3b

    :cond_61
    move-wide v10, v3

    :goto_3b
    invoke-static {v0, v7, v10, v11}, LJ0/X;->k(LJ0/X;LJ0/Y;J)V

    add-int/lit8 v9, v9, 0x1

    goto :goto_3a

    :cond_62
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_13
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, La0/Z;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, La0/Z;

    check-cast v0, LD/h;

    const-string v4, "$this$LazyVerticalGrid"

    invoke-static {v0, v4}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v2}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    new-instance v5, LH6/I;

    invoke-direct {v5, v2, v3}, LH6/I;-><init>(La0/Z;La0/Z;)V

    new-instance v2, Li0/d;

    const v3, -0x112ef5ca

    const/4 v7, 0x1

    invoke-direct {v2, v3, v5, v7}, Li0/d;-><init>(ILjava/lang/Object;Z)V

    sget-object v3, LD/r;->t:LD/r;

    const/4 v6, 0x0

    invoke-virtual {v0, v4, v6, v3, v2}, LD/h;->o(ILr7/c;Lr7/c;Li0/d;)V

    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_14
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, Lr0/i;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, LM0/O0;

    check-cast v0, Ls0/b;

    check-cast v2, Lr0/j;

    const/16 v0, 0x8

    const/4 v4, 0x0

    const/4 v7, 0x1

    invoke-virtual {v2, v0, v4, v7}, Lr0/j;->b(IZZ)Z

    if-eqz v3, :cond_63

    check-cast v3, LM0/s0;

    invoke-virtual {v3}, LM0/s0;->a()V

    :cond_63
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_15
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LE7/d;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, LE2/d;

    check-cast v0, Ljava/lang/Throwable;

    iget-object v0, v2, LE7/d;->v:Landroid/os/Handler;

    invoke-virtual {v0, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_16
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, Lj0/g;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Lj0/d;

    check-cast v0, Ljava/util/Map;

    new-instance v4, LE/q0;

    invoke-direct {v4, v2, v0, v3}, LE/q0;-><init>(Lj0/g;Ljava/util/Map;Lj0/d;)V

    return-object v4

    :pswitch_17
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LE/q0;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v0, La0/H;

    iget-object v0, v2, LE/q0;->v:Lp/I;

    invoke-virtual {v0, v3}, Lp/I;->i(Ljava/lang/Object;)V

    new-instance v0, LA/j0;

    const/4 v4, 0x1

    invoke-direct {v0, v4, v2, v3}, LA/j0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    return-object v0

    :pswitch_18
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LD/n;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    move-object v4, v3

    check-cast v4, LD/m;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v5

    iget-object v0, v2, LD/n;->y:Ljava/lang/Object;

    check-cast v0, LD/w;

    iget v3, v0, LD/w;->f:I

    invoke-virtual {v0, v5}, LD/w;->g(I)I

    move-result v7

    const/4 v3, 0x0

    invoke-virtual {v2, v3, v7}, LD/n;->b(II)J

    move-result-wide v9

    const/4 v6, 0x0

    iget v8, v4, LD/m;->x:I

    invoke-virtual/range {v4 .. v10}, LD/m;->J(IIIIJ)LD/p;

    move-result-object v0

    return-object v0

    :pswitch_19
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LD/w;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, LD/n;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {v2, v0}, LD/w;->c(I)LD/v;

    move-result-object v0

    iget v2, v0, LD/v;->a:I

    new-instance v4, Ljava/util/ArrayList;

    iget-object v0, v0, LD/v;->b:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v5

    const/4 v6, 0x0

    const/4 v9, 0x0

    :goto_3c
    if-ge v9, v5, :cond_64

    invoke-interface {v0, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LD/b;

    iget-wide v7, v7, LD/b;->a:J

    long-to-int v7, v7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v3, v6, v7}, LD/n;->b(II)J

    move-result-wide v10

    new-instance v12, Lj1/a;

    invoke-direct {v12, v10, v11}, Lj1/a;-><init>(J)V

    new-instance v10, Ld7/k;

    invoke-direct {v10, v8, v12}, Ld7/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v4, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v19, 0x1

    add-int/lit8 v2, v2, 0x1

    add-int/2addr v6, v7

    add-int/lit8 v9, v9, 0x1

    goto :goto_3c

    :cond_64
    return-object v4

    :pswitch_1a
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LA/k0;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, Landroid/view/View;

    check-cast v0, La0/H;

    iget-object v0, v2, LA/k0;->u:LA/F;

    iget v4, v2, LA/k0;->t:I

    if-nez v4, :cond_66

    sget-object v4, LA1/J;->a:Ljava/lang/reflect/Field;

    invoke-static {v3, v0}, LA1/D;->g(Landroid/view/View;LA1/n;)V

    invoke-virtual {v3}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v4

    if-eqz v4, :cond_65

    invoke-virtual {v3}, Landroid/view/View;->requestApplyInsets()V

    :cond_65
    invoke-virtual {v3, v0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    invoke-static {v3, v0}, LA1/J;->f(Landroid/view/View;LA1/M;)V

    :cond_66
    iget v0, v2, LA/k0;->t:I

    const/16 v19, 0x1

    add-int/lit8 v0, v0, 0x1

    iput v0, v2, LA/k0;->t:I

    new-instance v0, LA/j0;

    const/4 v4, 0x0

    invoke-direct {v0, v4, v2, v3}, LA/j0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    return-object v0

    :pswitch_1b
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LA/T;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, LJ0/Y;

    check-cast v0, LJ0/X;

    iget-boolean v4, v2, LA/T;->L:Z

    if-eqz v4, :cond_67

    iget v4, v2, LA/T;->H:F

    invoke-interface {v0, v4}, Lj1/c;->j0(F)I

    move-result v4

    iget v2, v2, LA/T;->I:F

    invoke-interface {v0, v2}, Lj1/c;->j0(F)I

    move-result v2

    invoke-static {v0, v3, v4, v2}, LJ0/X;->l(LJ0/X;LJ0/Y;II)V

    goto :goto_3d

    :cond_67
    iget v4, v2, LA/T;->H:F

    invoke-interface {v0, v4}, Lj1/c;->j0(F)I

    move-result v4

    iget v2, v2, LA/T;->I:F

    invoke-interface {v0, v2}, Lj1/c;->j0(F)I

    move-result v2

    invoke-virtual {v0, v3, v4, v2, v6}, LJ0/X;->h(LJ0/Y;IIF)V

    :goto_3d
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_1c
    iget-object v2, v1, LA/Q;->v:Ljava/lang/Object;

    check-cast v2, LA/S;

    iget-object v3, v1, LA/Q;->u:Ljava/lang/Object;

    check-cast v3, LJ0/Y;

    check-cast v0, LJ0/X;

    iget-boolean v4, v2, LA/S;->J:Z

    if-eqz v4, :cond_68

    iget v4, v2, LA/S;->H:F

    invoke-interface {v0, v4}, Lj1/c;->j0(F)I

    move-result v4

    iget v2, v2, LA/S;->I:F

    invoke-interface {v0, v2}, Lj1/c;->j0(F)I

    move-result v2

    invoke-static {v0, v3, v4, v2}, LJ0/X;->l(LJ0/X;LJ0/Y;II)V

    goto :goto_3e

    :cond_68
    iget v4, v2, LA/S;->H:F

    invoke-interface {v0, v4}, Lj1/c;->j0(F)I

    move-result v4

    iget v2, v2, LA/S;->I:F

    invoke-interface {v0, v2}, Lj1/c;->j0(F)I

    move-result v2

    invoke-virtual {v0, v3, v4, v2, v6}, LJ0/X;->h(LJ0/Y;IIF)V

    :goto_3e
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
