.class public abstract LA/p;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lp/H;

.field public static final b:Lp/H;

.field public static final c:LA/o;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x1

    invoke-static {v0}, LA/p;->c(Z)Lp/H;

    move-result-object v0

    sput-object v0, LA/p;->a:Lp/H;

    const/4 v0, 0x0

    invoke-static {v0}, LA/p;->c(Z)Lp/H;

    move-result-object v0

    sput-object v0, LA/p;->b:Lp/H;

    sget-object v0, LA/o;->b:LA/o;

    sput-object v0, LA/p;->c:LA/o;

    return-void
.end method

.method public static final a(Lm0/r;La0/r;I)V
    .locals 6

    const v0, -0xc96ce69

    invoke-virtual {p1, v0}, La0/r;->X(I)La0/r;

    and-int/lit8 v0, p2, 0x6

    const/4 v1, 0x2

    if-nez v0, :cond_1

    invoke-virtual {p1, p0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x4

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    or-int/2addr v0, p2

    goto :goto_1

    :cond_1
    move v0, p2

    :goto_1
    and-int/lit8 v2, v0, 0x3

    const/4 v3, 0x1

    if-eq v2, v1, :cond_2

    move v1, v3

    goto :goto_2

    :cond_2
    const/4 v1, 0x0

    :goto_2
    and-int/2addr v0, v3

    invoke-virtual {p1, v0, v1}, La0/r;->N(IZ)Z

    move-result v0

    if-eqz v0, :cond_6

    iget-wide v0, p1, La0/r;->T:J

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    invoke-static {p1, p0}, Lm0/a;->c(La0/r;Lm0/r;)Lm0/r;

    move-result-object v1

    invoke-virtual {p1}, La0/r;->l()La0/n0;

    move-result-object v2

    sget-object v4, LL0/j;->b:LL0/i;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v4, LL0/i;->b:LL0/C;

    invoke-virtual {p1}, La0/r;->Z()V

    iget-boolean v5, p1, La0/r;->S:Z

    if-eqz v5, :cond_3

    invoke-virtual {p1, v4}, La0/r;->k(Lr7/a;)V

    goto :goto_3

    :cond_3
    invoke-virtual {p1}, La0/r;->j0()V

    :goto_3
    sget-object v4, LL0/i;->e:LL0/h;

    sget-object v5, LA/p;->c:LA/o;

    invoke-static {p1, v5, v4}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v4, LL0/i;->d:LL0/h;

    invoke-static {p1, v2, v4}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v2, LL0/i;->c:LL0/h;

    invoke-static {p1, v1, v2}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v1, LL0/i;->f:LL0/h;

    iget-boolean v2, p1, La0/r;->S:Z

    if-nez v2, :cond_4

    invoke-virtual {p1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v2, v4}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_5

    :cond_4
    invoke-static {v0, p1, v0, v1}, Lq3/h;->n(ILa0/r;ILL0/h;)V

    :cond_5
    invoke-virtual {p1, v3}, La0/r;->p(Z)V

    goto :goto_4

    :cond_6
    invoke-virtual {p1}, La0/r;->Q()V

    :goto_4
    invoke-virtual {p1}, La0/r;->r()La0/r0;

    move-result-object p1

    if-eqz p1, :cond_7

    new-instance v0, LA/n;

    invoke-direct {v0, p0, p2}, LA/n;-><init>(Lm0/r;I)V

    iput-object v0, p1, La0/r0;->d:Lr7/e;

    :cond_7
    return-void
.end method

.method public static final b(LJ0/X;LJ0/Y;LJ0/L;Lj1/m;IILm0/j;)V
    .locals 7

    invoke-interface {p2}, LJ0/L;->G()Ljava/lang/Object;

    move-result-object p2

    instance-of v0, p2, LA/m;

    if-eqz v0, :cond_0

    check-cast p2, LA/m;

    goto :goto_0

    :cond_0
    const/4 p2, 0x0

    :goto_0
    if-eqz p2, :cond_2

    iget-object p2, p2, LA/m;->H:Lm0/j;

    if-nez p2, :cond_1

    goto :goto_1

    :cond_1
    move-object v0, p2

    goto :goto_2

    :cond_2
    :goto_1
    move-object v0, p6

    :goto_2
    iget p2, p1, LJ0/Y;->t:I

    iget p6, p1, LJ0/Y;->u:I

    int-to-long v1, p2

    const/16 p2, 0x20

    shl-long/2addr v1, p2

    int-to-long v3, p6

    const-wide v5, 0xffffffffL

    and-long/2addr v3, v5

    or-long/2addr v1, v3

    int-to-long v3, p4

    shl-long/2addr v3, p2

    int-to-long p4, p5

    and-long/2addr p4, v5

    or-long/2addr v3, p4

    move-object v5, p3

    invoke-virtual/range {v0 .. v5}, Lm0/j;->a(JJLj1/m;)J

    move-result-wide p2

    invoke-static {p0, p1, p2, p3}, LJ0/X;->k(LJ0/X;LJ0/Y;J)V

    return-void
.end method

.method public static final c(Z)Lp/H;
    .locals 3

    new-instance v0, Lp/H;

    const/16 v1, 0x9

    invoke-direct {v0, v1}, Lp/H;-><init>(I)V

    sget-object v1, Lm0/c;->t:Lm0/j;

    new-instance v2, LA/s;

    invoke-direct {v2, v1, p0}, LA/s;-><init>(Lm0/j;Z)V

    invoke-virtual {v0, v1, v2}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v1, Lm0/c;->u:Lm0/j;

    new-instance v2, LA/s;

    invoke-direct {v2, v1, p0}, LA/s;-><init>(Lm0/j;Z)V

    invoke-virtual {v0, v1, v2}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v1, Lm0/c;->v:Lm0/j;

    new-instance v2, LA/s;

    invoke-direct {v2, v1, p0}, LA/s;-><init>(Lm0/j;Z)V

    invoke-virtual {v0, v1, v2}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v1, Lm0/c;->w:Lm0/j;

    new-instance v2, LA/s;

    invoke-direct {v2, v1, p0}, LA/s;-><init>(Lm0/j;Z)V

    invoke-virtual {v0, v1, v2}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v1, Lm0/c;->x:Lm0/j;

    new-instance v2, LA/s;

    invoke-direct {v2, v1, p0}, LA/s;-><init>(Lm0/j;Z)V

    invoke-virtual {v0, v1, v2}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v1, Lm0/c;->y:Lm0/j;

    new-instance v2, LA/s;

    invoke-direct {v2, v1, p0}, LA/s;-><init>(Lm0/j;Z)V

    invoke-virtual {v0, v1, v2}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v1, Lm0/c;->z:Lm0/j;

    new-instance v2, LA/s;

    invoke-direct {v2, v1, p0}, LA/s;-><init>(Lm0/j;Z)V

    invoke-virtual {v0, v1, v2}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v1, Lm0/c;->A:Lm0/j;

    new-instance v2, LA/s;

    invoke-direct {v2, v1, p0}, LA/s;-><init>(Lm0/j;Z)V

    invoke-virtual {v0, v1, v2}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object v1, Lm0/c;->B:Lm0/j;

    new-instance v2, LA/s;

    invoke-direct {v2, v1, p0}, LA/s;-><init>(Lm0/j;Z)V

    invoke-virtual {v0, v1, v2}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v0
.end method

.method public static final d(Lm0/j;Z)LJ0/M;
    .locals 1

    if-eqz p1, :cond_0

    sget-object v0, LA/p;->a:Lp/H;

    goto :goto_0

    :cond_0
    sget-object v0, LA/p;->b:Lp/H;

    :goto_0
    invoke-virtual {v0, p0}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LJ0/M;

    if-nez v0, :cond_1

    new-instance v0, LA/s;

    invoke-direct {v0, p0, p1}, LA/s;-><init>(Lm0/j;Z)V

    :cond_1
    return-object v0
.end method
