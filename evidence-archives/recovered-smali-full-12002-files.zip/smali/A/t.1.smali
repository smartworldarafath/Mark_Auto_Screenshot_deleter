.class public abstract LA/t;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LA/v;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, LA/v;

    sget-object v1, LA/j;->b:LA/e;

    sget-object v2, Lm0/c;->F:Lm0/h;

    invoke-direct {v0, v1, v2}, LA/v;-><init>(LA/i;Lm0/h;)V

    sput-object v0, LA/t;->a:LA/v;

    return-void
.end method

.method public static final a(LA/i;Lm0/h;La0/r;I)LA/v;
    .locals 5

    sget-object v0, LA/j;->b:LA/e;

    invoke-static {p0, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    sget-object v0, Lm0/c;->F:Lm0/h;

    invoke-virtual {p1, v0}, Lm0/h;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const p0, -0x5638e738

    invoke-virtual {p2, p0}, La0/r;->V(I)V

    invoke-virtual {p2, v1}, La0/r;->p(Z)V

    sget-object p0, LA/t;->a:LA/v;

    return-object p0

    :cond_0
    const v0, -0x563814e1

    invoke-virtual {p2, v0}, La0/r;->V(I)V

    and-int/lit8 v0, p3, 0xe

    xor-int/lit8 v0, v0, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-le v0, v3, :cond_1

    invoke-virtual {p2, p0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    :cond_1
    and-int/lit8 v0, p3, 0x6

    if-ne v0, v3, :cond_3

    :cond_2
    move v0, v2

    goto :goto_0

    :cond_3
    move v0, v1

    :goto_0
    and-int/lit8 v3, p3, 0x70

    xor-int/lit8 v3, v3, 0x30

    const/16 v4, 0x20

    if-le v3, v4, :cond_4

    invoke-virtual {p2, p1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_6

    :cond_4
    and-int/lit8 p3, p3, 0x30

    if-ne p3, v4, :cond_5

    goto :goto_1

    :cond_5
    move v2, v1

    :cond_6
    :goto_1
    or-int p3, v0, v2

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v0

    if-nez p3, :cond_7

    sget-object p3, La0/m;->a:La0/U;

    if-ne v0, p3, :cond_8

    :cond_7
    new-instance v0, LA/v;

    invoke-direct {v0, p0, p1}, LA/v;-><init>(LA/i;Lm0/h;)V

    invoke-virtual {p2, v0}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_8
    check-cast v0, LA/v;

    invoke-virtual {p2, v1}, La0/r;->p(Z)V

    return-object v0
.end method
