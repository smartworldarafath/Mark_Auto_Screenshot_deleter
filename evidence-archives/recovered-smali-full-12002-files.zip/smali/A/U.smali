.class public interface abstract LA/U;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()F
.end method

.method public abstract b(Lj1/m;)F
.end method

.method public abstract c(Lj1/m;)F
.end method

.method public abstract d()F
.end method
