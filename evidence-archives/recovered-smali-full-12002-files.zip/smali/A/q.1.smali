.class public final synthetic LA/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:LJ0/Y;

.field public final synthetic u:LJ0/L;

.field public final synthetic v:LJ0/O;

.field public final synthetic w:I

.field public final synthetic x:I

.field public final synthetic y:LA/s;


# direct methods
.method public synthetic constructor <init>(LJ0/Y;LJ0/L;LJ0/O;IILA/s;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/q;->t:LJ0/Y;

    iput-object p2, p0, LA/q;->u:LJ0/L;

    iput-object p3, p0, LA/q;->v:LJ0/O;

    iput p4, p0, LA/q;->w:I

    iput p5, p0, LA/q;->x:I

    iput-object p6, p0, LA/q;->y:LA/s;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    move-object v0, p1

    check-cast v0, LJ0/X;

    iget-object p1, p0, LA/q;->v:LJ0/O;

    invoke-interface {p1}, LJ0/q;->getLayoutDirection()Lj1/m;

    move-result-object v3

    iget-object p1, p0, LA/q;->y:LA/s;

    iget-object v6, p1, LA/s;->a:Lm0/j;

    iget-object v1, p0, LA/q;->t:LJ0/Y;

    iget-object v2, p0, LA/q;->u:LJ0/L;

    iget v4, p0, LA/q;->w:I

    iget v5, p0, LA/q;->x:I

    invoke-static/range {v0 .. v6}, LA/p;->b(LJ0/X;LJ0/Y;LJ0/L;Lj1/m;IILm0/j;)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1
.end method
