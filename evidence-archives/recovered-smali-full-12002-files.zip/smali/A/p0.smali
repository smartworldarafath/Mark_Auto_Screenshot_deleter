.class public final synthetic LA/p0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:LA/q0;

.field public final synthetic u:I

.field public final synthetic v:LJ0/Y;

.field public final synthetic w:I

.field public final synthetic x:LJ0/O;


# direct methods
.method public synthetic constructor <init>(LA/q0;ILJ0/Y;ILJ0/O;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/p0;->t:LA/q0;

    iput p2, p0, LA/p0;->u:I

    iput-object p3, p0, LA/p0;->v:LJ0/Y;

    iput p4, p0, LA/p0;->w:I

    iput-object p5, p0, LA/p0;->x:LJ0/O;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    check-cast p1, LJ0/X;

    iget-object v0, p0, LA/p0;->t:LA/q0;

    iget-object v0, v0, LA/q0;->I:Lr7/e;

    iget-object v1, p0, LA/p0;->v:LJ0/Y;

    iget v2, v1, LJ0/Y;->t:I

    iget v3, p0, LA/p0;->u:I

    sub-int/2addr v3, v2

    iget v2, v1, LJ0/Y;->u:I

    iget v4, p0, LA/p0;->w:I

    sub-int/2addr v4, v2

    int-to-long v2, v3

    const/16 v5, 0x20

    shl-long/2addr v2, v5

    int-to-long v4, v4

    const-wide v6, 0xffffffffL

    and-long/2addr v4, v6

    or-long/2addr v2, v4

    new-instance v4, Lj1/l;

    invoke-direct {v4, v2, v3}, Lj1/l;-><init>(J)V

    iget-object v2, p0, LA/p0;->x:LJ0/O;

    invoke-interface {v2}, LJ0/q;->getLayoutDirection()Lj1/m;

    move-result-object v2

    invoke-interface {v0, v4, v2}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lj1/j;

    iget-wide v2, v0, Lj1/j;->a:J

    invoke-static {p1, v1, v2, v3}, LJ0/X;->k(LJ0/X;LJ0/Y;J)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1
.end method
