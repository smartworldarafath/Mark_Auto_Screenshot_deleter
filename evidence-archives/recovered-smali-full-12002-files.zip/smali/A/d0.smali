.class public final LA/d0;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/z;


# instance fields
.field public H:F

.field public I:F

.field public J:F

.field public K:F

.field public L:Z


# virtual methods
.method public final K0(LJ0/O;)J
    .locals 6

    iget v0, p0, LA/d0;->J:F

    invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z

    move-result v0

    const v1, 0x7fffffff

    const/4 v2, 0x0

    if-nez v0, :cond_0

    iget v0, p0, LA/d0;->J:F

    invoke-interface {p1, v0}, Lj1/c;->j0(F)I

    move-result v0

    if-gez v0, :cond_1

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :cond_1
    :goto_0
    iget v3, p0, LA/d0;->K:F

    invoke-static {v3}, Ljava/lang/Float;->isNaN(F)Z

    move-result v3

    if-nez v3, :cond_2

    iget v3, p0, LA/d0;->K:F

    invoke-interface {p1, v3}, Lj1/c;->j0(F)I

    move-result v3

    if-gez v3, :cond_3

    move v3, v2

    goto :goto_1

    :cond_2
    move v3, v1

    :cond_3
    :goto_1
    iget v4, p0, LA/d0;->H:F

    invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z

    move-result v4

    if-nez v4, :cond_6

    iget v4, p0, LA/d0;->H:F

    invoke-interface {p1, v4}, Lj1/c;->j0(F)I

    move-result v4

    if-gez v4, :cond_4

    move v4, v2

    :cond_4
    if-le v4, v0, :cond_5

    move v4, v0

    :cond_5
    if-eq v4, v1, :cond_6

    goto :goto_2

    :cond_6
    move v4, v2

    :goto_2
    iget v5, p0, LA/d0;->I:F

    invoke-static {v5}, Ljava/lang/Float;->isNaN(F)Z

    move-result v5

    if-nez v5, :cond_9

    iget v5, p0, LA/d0;->I:F

    invoke-interface {p1, v5}, Lj1/c;->j0(F)I

    move-result p1

    if-gez p1, :cond_7

    move p1, v2

    :cond_7
    if-le p1, v3, :cond_8

    move p1, v3

    :cond_8
    if-eq p1, v1, :cond_9

    move v2, p1

    :cond_9
    invoke-static {v4, v0, v2, v3}, Lj1/b;->a(IIII)J

    move-result-wide v0

    return-wide v0
.end method

.method public final S(LL0/S;LJ0/L;I)I
    .locals 2

    invoke-virtual {p0, p1}, LA/d0;->K0(LJ0/O;)J

    move-result-wide v0

    invoke-static {v0, v1}, Lj1/a;->e(J)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-static {v0, v1}, Lj1/a;->g(J)I

    move-result p1

    return p1

    :cond_0
    iget-boolean p1, p0, LA/d0;->L:Z

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    invoke-static {p3, v0, v1}, Lj1/b;->g(IJ)I

    move-result p3

    :goto_0
    invoke-interface {p2, p3}, LJ0/L;->U(I)I

    move-result p1

    invoke-static {p1, v0, v1}, Lj1/b;->f(IJ)I

    move-result p1

    return p1
.end method

.method public final c(LJ0/O;LJ0/L;J)LJ0/N;
    .locals 6

    invoke-virtual {p0, p1}, LA/d0;->K0(LJ0/O;)J

    move-result-wide v0

    iget-boolean v2, p0, LA/d0;->L:Z

    if-eqz v2, :cond_0

    invoke-static {p3, p4, v0, v1}, Lj1/b;->e(JJ)J

    move-result-wide p3

    goto :goto_4

    :cond_0
    iget v2, p0, LA/d0;->H:F

    invoke-static {v2}, Ljava/lang/Float;->isNaN(F)Z

    move-result v2

    if-nez v2, :cond_1

    invoke-static {v0, v1}, Lj1/a;->j(J)I

    move-result v2

    goto :goto_0

    :cond_1
    invoke-static {p3, p4}, Lj1/a;->j(J)I

    move-result v2

    invoke-static {v0, v1}, Lj1/a;->h(J)I

    move-result v3

    if-le v2, v3, :cond_2

    move v2, v3

    :cond_2
    :goto_0
    iget v3, p0, LA/d0;->J:F

    invoke-static {v3}, Ljava/lang/Float;->isNaN(F)Z

    move-result v3

    if-nez v3, :cond_3

    invoke-static {v0, v1}, Lj1/a;->h(J)I

    move-result v3

    goto :goto_1

    :cond_3
    invoke-static {p3, p4}, Lj1/a;->h(J)I

    move-result v3

    invoke-static {v0, v1}, Lj1/a;->j(J)I

    move-result v4

    if-ge v3, v4, :cond_4

    move v3, v4

    :cond_4
    :goto_1
    iget v4, p0, LA/d0;->I:F

    invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z

    move-result v4

    if-nez v4, :cond_5

    invoke-static {v0, v1}, Lj1/a;->i(J)I

    move-result v4

    goto :goto_2

    :cond_5
    invoke-static {p3, p4}, Lj1/a;->i(J)I

    move-result v4

    invoke-static {v0, v1}, Lj1/a;->g(J)I

    move-result v5

    if-le v4, v5, :cond_6

    move v4, v5

    :cond_6
    :goto_2
    iget v5, p0, LA/d0;->K:F

    invoke-static {v5}, Ljava/lang/Float;->isNaN(F)Z

    move-result v5

    if-nez v5, :cond_7

    invoke-static {v0, v1}, Lj1/a;->g(J)I

    move-result p3

    goto :goto_3

    :cond_7
    invoke-static {p3, p4}, Lj1/a;->g(J)I

    move-result p3

    invoke-static {v0, v1}, Lj1/a;->i(J)I

    move-result p4

    if-ge p3, p4, :cond_8

    move p3, p4

    :cond_8
    :goto_3
    invoke-static {v2, v3, v4, p3}, Lj1/b;->a(IIII)J

    move-result-wide p3

    :goto_4
    invoke-interface {p2, p3, p4}, LJ0/L;->D(J)LJ0/Y;

    move-result-object p2

    iget p3, p2, LJ0/Y;->t:I

    iget p4, p2, LJ0/Y;->u:I

    new-instance v0, LA/k;

    const/4 v1, 0x3

    invoke-direct {v0, p2, v1}, LA/k;-><init>(LJ0/Y;I)V

    sget-object p2, Le7/u;->t:Le7/u;

    invoke-interface {p1, p3, p4, p2, v0}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1
.end method

.method public final m0(LL0/S;LJ0/L;I)I
    .locals 2

    invoke-virtual {p0, p1}, LA/d0;->K0(LJ0/O;)J

    move-result-wide v0

    invoke-static {v0, v1}, Lj1/a;->f(J)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-static {v0, v1}, Lj1/a;->h(J)I

    move-result p1

    return p1

    :cond_0
    iget-boolean p1, p0, LA/d0;->L:Z

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    invoke-static {p3, v0, v1}, Lj1/b;->f(IJ)I

    move-result p3

    :goto_0
    invoke-interface {p2, p3}, LJ0/L;->A(I)I

    move-result p1

    invoke-static {p1, v0, v1}, Lj1/b;->g(IJ)I

    move-result p1

    return p1
.end method

.method public final w(LL0/S;LJ0/L;I)I
    .locals 2

    invoke-virtual {p0, p1}, LA/d0;->K0(LJ0/O;)J

    move-result-wide v0

    invoke-static {v0, v1}, Lj1/a;->e(J)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-static {v0, v1}, Lj1/a;->g(J)I

    move-result p1

    return p1

    :cond_0
    iget-boolean p1, p0, LA/d0;->L:Z

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    invoke-static {p3, v0, v1}, Lj1/b;->g(IJ)I

    move-result p3

    :goto_0
    invoke-interface {p2, p3}, LJ0/L;->c(I)I

    move-result p1

    invoke-static {p1, v0, v1}, Lj1/b;->f(IJ)I

    move-result p1

    return p1
.end method

.method public final w0(LL0/S;LJ0/L;I)I
    .locals 2

    invoke-virtual {p0, p1}, LA/d0;->K0(LJ0/O;)J

    move-result-wide v0

    invoke-static {v0, v1}, Lj1/a;->f(J)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-static {v0, v1}, Lj1/a;->h(J)I

    move-result p1

    return p1

    :cond_0
    iget-boolean p1, p0, LA/d0;->L:Z

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    invoke-static {p3, v0, v1}, Lj1/b;->f(IJ)I

    move-result p3

    :goto_0
    invoke-interface {p2, p3}, LJ0/L;->w(I)I

    move-result p1

    invoke-static {p1, v0, v1}, Lj1/b;->g(IJ)I

    move-result p1

    return p1
.end method
