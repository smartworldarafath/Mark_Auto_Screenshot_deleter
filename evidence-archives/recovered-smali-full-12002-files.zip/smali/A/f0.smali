.class public final LA/f0;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/z;


# instance fields
.field public H:F

.field public I:F


# virtual methods
.method public final S(LL0/S;LJ0/L;I)I
    .locals 0

    invoke-interface {p2, p3}, LJ0/L;->U(I)I

    move-result p2

    iget p3, p0, LA/f0;->I:F

    invoke-static {p3}, Ljava/lang/Float;->isNaN(F)Z

    move-result p3

    if-nez p3, :cond_0

    iget p3, p0, LA/f0;->I:F

    invoke-interface {p1, p3}, Lj1/c;->j0(F)I

    move-result p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    if-ge p2, p1, :cond_1

    return p1

    :cond_1
    return p2
.end method

.method public final c(LJ0/O;LJ0/L;J)LJ0/N;
    .locals 5

    iget v0, p0, LA/f0;->H:F

    invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_2

    invoke-static {p3, p4}, Lj1/a;->j(J)I

    move-result v0

    if-nez v0, :cond_2

    iget v0, p0, LA/f0;->H:F

    invoke-interface {p1, v0}, Lj1/c;->j0(F)I

    move-result v0

    invoke-static {p3, p4}, Lj1/a;->h(J)I

    move-result v2

    if-gez v0, :cond_0

    move v0, v1

    :cond_0
    if-le v0, v2, :cond_1

    goto :goto_0

    :cond_1
    move v2, v0

    goto :goto_0

    :cond_2
    invoke-static {p3, p4}, Lj1/a;->j(J)I

    move-result v2

    :goto_0
    invoke-static {p3, p4}, Lj1/a;->h(J)I

    move-result v0

    iget v3, p0, LA/f0;->I:F

    invoke-static {v3}, Ljava/lang/Float;->isNaN(F)Z

    move-result v3

    if-nez v3, :cond_5

    invoke-static {p3, p4}, Lj1/a;->i(J)I

    move-result v3

    if-nez v3, :cond_5

    iget v3, p0, LA/f0;->I:F

    invoke-interface {p1, v3}, Lj1/c;->j0(F)I

    move-result v3

    invoke-static {p3, p4}, Lj1/a;->g(J)I

    move-result v4

    if-gez v3, :cond_3

    goto :goto_1

    :cond_3
    move v1, v3

    :goto_1
    if-le v1, v4, :cond_4

    goto :goto_2

    :cond_4
    move v4, v1

    goto :goto_2

    :cond_5
    invoke-static {p3, p4}, Lj1/a;->i(J)I

    move-result v4

    :goto_2
    invoke-static {p3, p4}, Lj1/a;->g(J)I

    move-result p3

    invoke-static {v2, v0, v4, p3}, Lj1/b;->a(IIII)J

    move-result-wide p3

    invoke-interface {p2, p3, p4}, LJ0/L;->D(J)LJ0/Y;

    move-result-object p2

    iget p3, p2, LJ0/Y;->t:I

    iget p4, p2, LJ0/Y;->u:I

    new-instance v0, LA/k;

    const/4 v1, 0x4

    invoke-direct {v0, p2, v1}, LA/k;-><init>(LJ0/Y;I)V

    sget-object p2, Le7/u;->t:Le7/u;

    invoke-interface {p1, p3, p4, p2, v0}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1
.end method

.method public final m0(LL0/S;LJ0/L;I)I
    .locals 0

    invoke-interface {p2, p3}, LJ0/L;->A(I)I

    move-result p2

    iget p3, p0, LA/f0;->H:F

    invoke-static {p3}, Ljava/lang/Float;->isNaN(F)Z

    move-result p3

    if-nez p3, :cond_0

    iget p3, p0, LA/f0;->H:F

    invoke-interface {p1, p3}, Lj1/c;->j0(F)I

    move-result p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    if-ge p2, p1, :cond_1

    return p1

    :cond_1
    return p2
.end method

.method public final w(LL0/S;LJ0/L;I)I
    .locals 0

    invoke-interface {p2, p3}, LJ0/L;->c(I)I

    move-result p2

    iget p3, p0, LA/f0;->I:F

    invoke-static {p3}, Ljava/lang/Float;->isNaN(F)Z

    move-result p3

    if-nez p3, :cond_0

    iget p3, p0, LA/f0;->I:F

    invoke-interface {p1, p3}, Lj1/c;->j0(F)I

    move-result p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    if-ge p2, p1, :cond_1

    return p1

    :cond_1
    return p2
.end method

.method public final w0(LL0/S;LJ0/L;I)I
    .locals 0

    invoke-interface {p2, p3}, LJ0/L;->w(I)I

    move-result p2

    iget p3, p0, LA/f0;->H:F

    invoke-static {p3}, Ljava/lang/Float;->isNaN(F)Z

    move-result p3

    if-nez p3, :cond_0

    iget p3, p0, LA/f0;->H:F

    invoke-interface {p1, p3}, Lj1/c;->j0(F)I

    move-result p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    if-ge p2, p1, :cond_1

    return p1

    :cond_1
    return p2
.end method
