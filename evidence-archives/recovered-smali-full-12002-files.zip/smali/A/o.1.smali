.class public final LA/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJ0/M;


# static fields
.field public static final b:LA/o;

.field public static final c:LA/o;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    new-instance v0, LA/o;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LA/o;-><init>(I)V

    sput-object v0, LA/o;->b:LA/o;

    new-instance v0, LA/o;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, LA/o;-><init>(I)V

    sput-object v0, LA/o;->c:LA/o;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, LA/o;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final d(LJ0/O;Ljava/util/List;J)LJ0/N;
    .locals 2

    iget p2, p0, LA/o;->a:I

    packed-switch p2, :pswitch_data_0

    invoke-static {p3, p4}, Lj1/a;->f(J)Z

    move-result p2

    const/4 v0, 0x0

    if-eqz p2, :cond_0

    invoke-static {p3, p4}, Lj1/a;->h(J)I

    move-result p2

    goto :goto_0

    :cond_0
    move p2, v0

    :goto_0
    invoke-static {p3, p4}, Lj1/a;->e(J)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-static {p3, p4}, Lj1/a;->g(J)I

    move-result v0

    :cond_1
    new-instance p3, Ls/E0;

    const/16 p4, 0xe

    invoke-direct {p3, p4}, Ls/E0;-><init>(I)V

    sget-object p4, Le7/u;->t:Le7/u;

    invoke-interface {p1, p2, v0, p4, p3}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1

    :pswitch_0
    invoke-static {p3, p4}, Lj1/a;->j(J)I

    move-result p2

    invoke-static {p3, p4}, Lj1/a;->i(J)I

    move-result p3

    new-instance p4, Ls/E0;

    const/16 v0, 0xe

    invoke-direct {p4, v0}, Ls/E0;-><init>(I)V

    sget-object v0, Le7/u;->t:Le7/u;

    invoke-interface {p1, p2, p3, v0, p4}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
