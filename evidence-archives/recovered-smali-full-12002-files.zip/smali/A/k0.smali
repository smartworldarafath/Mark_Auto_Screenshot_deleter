.class public final LA/k0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final v:Ljava/util/WeakHashMap;


# instance fields
.field public final a:LA/a;

.field public final b:LA/a;

.field public final c:LA/a;

.field public final d:LA/a;

.field public final e:LA/a;

.field public final f:LA/a;

.field public final g:LA/a;

.field public final h:LA/a;

.field public final i:LA/a;

.field public final j:LA/g0;

.field public final k:LA/e0;

.field public final l:LA/g0;

.field public final m:LA/g0;

.field public final n:LA/g0;

.field public final o:LA/g0;

.field public final p:LA/g0;

.field public final q:LA/g0;

.field public final r:LA/g0;

.field public final s:Z

.field public t:I

.field public final u:LA/F;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, LA/k0;->v:Ljava/util/WeakHashMap;

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .locals 16

    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const-string v1, "captionBar"

    const/4 v2, 0x4

    invoke-static {v2, v1}, LA/c;->b(ILjava/lang/String;)LA/a;

    move-result-object v1

    iput-object v1, v0, LA/k0;->a:LA/a;

    const/16 v1, 0x80

    const-string v3, "displayCutout"

    invoke-static {v1, v3}, LA/c;->b(ILjava/lang/String;)LA/a;

    move-result-object v1

    iput-object v1, v0, LA/k0;->b:LA/a;

    const-string v3, "ime"

    const/16 v4, 0x8

    invoke-static {v4, v3}, LA/c;->b(ILjava/lang/String;)LA/a;

    move-result-object v3

    iput-object v3, v0, LA/k0;->c:LA/a;

    const/16 v5, 0x20

    const-string v6, "mandatorySystemGestures"

    invoke-static {v5, v6}, LA/c;->b(ILjava/lang/String;)LA/a;

    move-result-object v5

    iput-object v5, v0, LA/k0;->d:LA/a;

    const-string v6, "navigationBars"

    const/4 v7, 0x2

    invoke-static {v7, v6}, LA/c;->b(ILjava/lang/String;)LA/a;

    move-result-object v6

    iput-object v6, v0, LA/k0;->e:LA/a;

    const-string v6, "statusBars"

    const/4 v8, 0x1

    invoke-static {v8, v6}, LA/c;->b(ILjava/lang/String;)LA/a;

    move-result-object v6

    iput-object v6, v0, LA/k0;->f:LA/a;

    const-string v6, "systemBars"

    const/16 v9, 0x207

    invoke-static {v9, v6}, LA/c;->b(ILjava/lang/String;)LA/a;

    move-result-object v6

    iput-object v6, v0, LA/k0;->g:LA/a;

    const/16 v10, 0x10

    const-string v11, "systemGestures"

    invoke-static {v10, v11}, LA/c;->b(ILjava/lang/String;)LA/a;

    move-result-object v10

    iput-object v10, v0, LA/k0;->h:LA/a;

    const-string v11, "tappableElement"

    const/16 v12, 0x40

    invoke-static {v12, v11}, LA/c;->b(ILjava/lang/String;)LA/a;

    move-result-object v11

    iput-object v11, v0, LA/k0;->i:LA/a;

    new-instance v13, LA/g0;

    new-instance v14, LA/J;

    const/4 v15, 0x0

    invoke-direct {v14, v15, v15, v15, v15}, LA/J;-><init>(IIII)V

    const-string v15, "waterfall"

    invoke-direct {v13, v14, v15}, LA/g0;-><init>(LA/J;Ljava/lang/String;)V

    iput-object v13, v0, LA/k0;->j:LA/g0;

    new-instance v14, LA/e0;

    invoke-direct {v14, v6, v3}, LA/e0;-><init>(LA/i0;LA/i0;)V

    new-instance v3, LA/e0;

    invoke-direct {v3, v14, v1}, LA/e0;-><init>(LA/i0;LA/i0;)V

    iput-object v3, v0, LA/k0;->k:LA/e0;

    new-instance v1, LA/e0;

    invoke-direct {v1, v11, v5}, LA/e0;-><init>(LA/i0;LA/i0;)V

    new-instance v3, LA/e0;

    invoke-direct {v3, v1, v10}, LA/e0;-><init>(LA/i0;LA/i0;)V

    new-instance v1, LA/e0;

    invoke-direct {v1, v3, v13}, LA/e0;-><init>(LA/i0;LA/i0;)V

    const-string v1, "captionBarIgnoringVisibility"

    invoke-static {v2, v1}, LA/c;->d(ILjava/lang/String;)LA/g0;

    move-result-object v1

    iput-object v1, v0, LA/k0;->l:LA/g0;

    const-string v1, "navigationBarsIgnoringVisibility"

    invoke-static {v7, v1}, LA/c;->d(ILjava/lang/String;)LA/g0;

    move-result-object v1

    iput-object v1, v0, LA/k0;->m:LA/g0;

    const-string v1, "statusBarsIgnoringVisibility"

    invoke-static {v8, v1}, LA/c;->d(ILjava/lang/String;)LA/g0;

    move-result-object v1

    iput-object v1, v0, LA/k0;->n:LA/g0;

    const-string v1, "systemBarsIgnoringVisibility"

    invoke-static {v9, v1}, LA/c;->d(ILjava/lang/String;)LA/g0;

    move-result-object v1

    iput-object v1, v0, LA/k0;->o:LA/g0;

    const-string v1, "tappableElementIgnoringVisibility"

    invoke-static {v12, v1}, LA/c;->d(ILjava/lang/String;)LA/g0;

    move-result-object v1

    iput-object v1, v0, LA/k0;->p:LA/g0;

    const-string v1, "imeAnimationTarget"

    invoke-static {v4, v1}, LA/c;->d(ILjava/lang/String;)LA/g0;

    move-result-object v1

    iput-object v1, v0, LA/k0;->q:LA/g0;

    const-string v1, "imeAnimationSource"

    invoke-static {v4, v1}, LA/c;->d(ILjava/lang/String;)LA/g0;

    move-result-object v1

    iput-object v1, v0, LA/k0;->r:LA/g0;

    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v2, v1, Landroid/view/View;

    const/4 v3, 0x0

    if-eqz v2, :cond_0

    check-cast v1, Landroid/view/View;

    goto :goto_0

    :cond_0
    move-object v1, v3

    :goto_0
    if-eqz v1, :cond_1

    const v2, 0x7f09007d

    invoke-virtual {v1, v2}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v1

    goto :goto_1

    :cond_1
    move-object v1, v3

    :goto_1
    instance-of v2, v1, Ljava/lang/Boolean;

    if-eqz v2, :cond_2

    move-object v3, v1

    check-cast v3, Ljava/lang/Boolean;

    :cond_2
    if-eqz v3, :cond_3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v15

    goto :goto_2

    :cond_3
    const/4 v15, 0x0

    :goto_2
    iput-boolean v15, v0, LA/k0;->s:Z

    new-instance v1, LA/F;

    invoke-direct {v1, v0}, LA/F;-><init>(LA/k0;)V

    iput-object v1, v0, LA/k0;->u:LA/F;

    return-void
.end method

.method public static a(LA/k0;LA1/q0;)V
    .locals 5

    iget-object v0, p0, LA/k0;->a:LA/a;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, LA/a;->f(LA1/q0;I)V

    iget-object v0, p0, LA/k0;->c:LA/a;

    invoke-virtual {v0, p1, v1}, LA/a;->f(LA1/q0;I)V

    iget-object v0, p0, LA/k0;->b:LA/a;

    invoke-virtual {v0, p1, v1}, LA/a;->f(LA1/q0;I)V

    iget-object v0, p0, LA/k0;->e:LA/a;

    invoke-virtual {v0, p1, v1}, LA/a;->f(LA1/q0;I)V

    iget-object v0, p0, LA/k0;->f:LA/a;

    invoke-virtual {v0, p1, v1}, LA/a;->f(LA1/q0;I)V

    iget-object v0, p0, LA/k0;->g:LA/a;

    invoke-virtual {v0, p1, v1}, LA/a;->f(LA1/q0;I)V

    iget-object v0, p0, LA/k0;->h:LA/a;

    invoke-virtual {v0, p1, v1}, LA/a;->f(LA1/q0;I)V

    iget-object v0, p0, LA/k0;->i:LA/a;

    invoke-virtual {v0, p1, v1}, LA/a;->f(LA1/q0;I)V

    iget-object v0, p0, LA/k0;->d:LA/a;

    invoke-virtual {v0, p1, v1}, LA/a;->f(LA1/q0;I)V

    iget-object v0, p0, LA/k0;->l:LA/g0;

    const/4 v2, 0x4

    iget-object v3, p1, LA1/q0;->a:LA1/l0;

    invoke-virtual {v3, v2}, LA1/l0;->h(I)Lt1/b;

    move-result-object v2

    invoke-static {v2}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object v2

    invoke-virtual {v0, v2}, LA/g0;->f(LA/J;)V

    iget-object v0, p0, LA/k0;->m:LA/g0;

    iget-object v2, p1, LA1/q0;->a:LA1/l0;

    const/4 v3, 0x2

    invoke-virtual {v2, v3}, LA1/l0;->h(I)Lt1/b;

    move-result-object v2

    invoke-static {v2}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object v2

    invoke-virtual {v0, v2}, LA/g0;->f(LA/J;)V

    iget-object v0, p0, LA/k0;->n:LA/g0;

    iget-object v2, p1, LA1/q0;->a:LA1/l0;

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, LA1/l0;->h(I)Lt1/b;

    move-result-object v2

    invoke-static {v2}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object v2

    invoke-virtual {v0, v2}, LA/g0;->f(LA/J;)V

    iget-object v0, p0, LA/k0;->o:LA/g0;

    const/16 v2, 0x207

    iget-object v4, p1, LA1/q0;->a:LA1/l0;

    invoke-virtual {v4, v2}, LA1/l0;->h(I)Lt1/b;

    move-result-object v2

    invoke-static {v2}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object v2

    invoke-virtual {v0, v2}, LA/g0;->f(LA/J;)V

    iget-object v0, p0, LA/k0;->p:LA/g0;

    const/16 v2, 0x40

    iget-object v4, p1, LA1/q0;->a:LA1/l0;

    invoke-virtual {v4, v2}, LA1/l0;->h(I)Lt1/b;

    move-result-object v2

    invoke-static {v2}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object v2

    invoke-virtual {v0, v2}, LA/g0;->f(LA/J;)V

    iget-object p1, p1, LA1/q0;->a:LA1/l0;

    invoke-virtual {p1}, LA1/l0;->f()LA1/h;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p1}, LA1/h;->a()Lt1/b;

    move-result-object p1

    iget-object p0, p0, LA/k0;->j:LA/g0;

    invoke-static {p1}, LA/d;->g(Lt1/b;)LA/J;

    move-result-object p1

    invoke-virtual {p0, p1}, LA/g0;->f(LA/J;)V

    :cond_0
    sget-object p0, Lk0/l;->c:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object p1, Lk0/l;->j:Lk0/a;

    iget-object p1, p1, Lk0/b;->h:Lp/I;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Lp/I;->h()Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-ne p1, v3, :cond_1

    move v1, v3

    :cond_1
    monitor-exit p0

    if-eqz v1, :cond_2

    invoke-static {}, Lk0/l;->a()V

    :cond_2
    return-void

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method
