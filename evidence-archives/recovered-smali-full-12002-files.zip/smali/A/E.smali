.class public final LA/E;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/t0;


# instance fields
.field public H:Lm0/h;


# virtual methods
.method public final A(Lj1/c;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    instance-of p1, p2, LA/Y;

    if-eqz p1, :cond_0

    check-cast p2, LA/Y;

    goto :goto_0

    :cond_0
    const/4 p2, 0x0

    :goto_0
    if-nez p2, :cond_1

    new-instance p2, LA/Y;

    invoke-direct {p2}, LA/Y;-><init>()V

    :cond_1
    iget-object p1, p0, LA/E;->H:Lm0/h;

    new-instance v0, LA/y;

    invoke-direct {v0, p1}, LA/y;-><init>(Lm0/h;)V

    iput-object v0, p2, LA/Y;->c:LA/d;

    return-object p2
.end method
