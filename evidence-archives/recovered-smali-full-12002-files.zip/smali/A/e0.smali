.class public final LA/e0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA/i0;


# instance fields
.field public final a:LA/i0;

.field public final b:LA/i0;


# direct methods
.method public constructor <init>(LA/i0;LA/i0;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/e0;->a:LA/i0;

    iput-object p2, p0, LA/e0;->b:LA/i0;

    return-void
.end method


# virtual methods
.method public final a(Lj1/c;Lj1/m;)I
    .locals 2

    iget-object v0, p0, LA/e0;->a:LA/i0;

    invoke-interface {v0, p1, p2}, LA/i0;->a(Lj1/c;Lj1/m;)I

    move-result v0

    iget-object v1, p0, LA/e0;->b:LA/i0;

    invoke-interface {v1, p1, p2}, LA/i0;->a(Lj1/c;Lj1/m;)I

    move-result p1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    return p1
.end method

.method public final b(Lj1/c;Lj1/m;)I
    .locals 2

    iget-object v0, p0, LA/e0;->a:LA/i0;

    invoke-interface {v0, p1, p2}, LA/i0;->b(Lj1/c;Lj1/m;)I

    move-result v0

    iget-object v1, p0, LA/e0;->b:LA/i0;

    invoke-interface {v1, p1, p2}, LA/i0;->b(Lj1/c;Lj1/m;)I

    move-result p1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    return p1
.end method

.method public final c(Lj1/c;)I
    .locals 2

    iget-object v0, p0, LA/e0;->a:LA/i0;

    invoke-interface {v0, p1}, LA/i0;->c(Lj1/c;)I

    move-result v0

    iget-object v1, p0, LA/e0;->b:LA/i0;

    invoke-interface {v1, p1}, LA/i0;->c(Lj1/c;)I

    move-result p1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    return p1
.end method

.method public final d(Lj1/c;)I
    .locals 2

    iget-object v0, p0, LA/e0;->a:LA/i0;

    invoke-interface {v0, p1}, LA/i0;->d(Lj1/c;)I

    move-result v0

    iget-object v1, p0, LA/e0;->b:LA/i0;

    invoke-interface {v1, p1}, LA/i0;->d(Lj1/c;)I

    move-result p1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, LA/e0;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, LA/e0;

    iget-object v1, p1, LA/e0;->a:LA/i0;

    iget-object v3, p0, LA/e0;->a:LA/i0;

    invoke-static {v1, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object p1, p1, LA/e0;->b:LA/i0;

    iget-object v1, p0, LA/e0;->b:LA/i0;

    invoke-static {p1, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    return v0

    :cond_2
    return v2
.end method

.method public final hashCode()I
    .locals 2

    iget-object v0, p0, LA/e0;->a:LA/i0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    iget-object v1, p0, LA/e0;->b:LA/i0;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    mul-int/lit8 v1, v1, 0x1f

    add-int/2addr v1, v0

    return v1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LA/e0;->a:LA/i0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " \u222a "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LA/e0;->b:LA/i0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
