.class public final synthetic LA/G;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Ljava/lang/Object;

.field public final synthetic v:I

.field public final synthetic w:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;III)V
    .locals 0

    iput p4, p0, LA/G;->t:I

    iput-object p1, p0, LA/G;->u:Ljava/lang/Object;

    iput p2, p0, LA/G;->v:I

    iput p3, p0, LA/G;->w:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    iget v0, p0, LA/G;->t:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LA/G;->u:Ljava/lang/Object;

    check-cast v0, Lt0/h;

    check-cast p1, LW0/q;

    iget-object v1, p1, LW0/q;->a:LW0/a;

    iget v2, p0, LA/G;->v:I

    invoke-virtual {p1, v2}, LW0/q;->d(I)I

    move-result v2

    iget v3, p0, LA/G;->w:I

    invoke-virtual {p1, v3}, LW0/q;->d(I)I

    move-result v3

    iget-object v4, v1, LW0/a;->e:Ljava/lang/CharSequence;

    if-ltz v2, :cond_0

    if-gt v2, v3, :cond_0

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-gt v3, v5, :cond_0

    goto :goto_0

    :cond_0
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "start("

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, ") or end("

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, ") is out of range [0.."

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "], or start > end!"

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ld1/a;->a(Ljava/lang/String;)V

    :goto_0
    new-instance v4, Landroid/graphics/Path;

    invoke-direct {v4}, Landroid/graphics/Path;-><init>()V

    iget-object v1, v1, LW0/a;->d:LX0/i;

    iget-object v5, v1, LX0/i;->f:Landroid/text/Layout;

    invoke-virtual {v5, v2, v3, v4}, Landroid/text/Layout;->getSelectionPath(IILandroid/graphics/Path;)V

    iget v1, v1, LX0/i;->h:I

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    invoke-virtual {v4}, Landroid/graphics/Path;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_1

    int-to-float v1, v1

    invoke-virtual {v4, v2, v1}, Landroid/graphics/Path;->offset(FF)V

    :cond_1
    iget p1, p1, LW0/q;->f:F

    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v1

    int-to-long v1, v1

    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p1

    int-to-long v5, p1

    const/16 p1, 0x20

    shl-long/2addr v1, p1

    const-wide v7, 0xffffffffL

    and-long/2addr v5, v7

    or-long/2addr v1, v5

    new-instance v3, Landroid/graphics/Matrix;

    invoke-direct {v3}, Landroid/graphics/Matrix;-><init>()V

    shr-long v5, v1, p1

    long-to-int p1, v5

    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    and-long/2addr v1, v7

    long-to-int v1, v1

    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    invoke-virtual {v3, p1, v1}, Landroid/graphics/Matrix;->setTranslate(FF)V

    invoke-virtual {v4, v3}, Landroid/graphics/Path;->transform(Landroid/graphics/Matrix;)V

    iget-object p1, v0, Lt0/h;->a:Landroid/graphics/Path;

    const-wide/16 v0, 0x0

    long-to-int v0, v0

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    invoke-virtual {p1, v4, v1, v0}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;FF)V

    :goto_1
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :pswitch_0
    iget-object v0, p0, LA/G;->u:Ljava/lang/Object;

    check-cast v0, LJ0/Y;

    iget v1, p0, LA/G;->w:I

    check-cast p1, LJ0/X;

    iget v2, p0, LA/G;->v:I

    invoke-static {p1, v0, v2, v1}, LJ0/X;->j(LJ0/X;LJ0/Y;II)V

    goto :goto_1

    :pswitch_1
    iget-object v0, p0, LA/G;->u:Ljava/lang/Object;

    check-cast v0, LJ0/Y;

    iget v1, p0, LA/G;->w:I

    check-cast p1, LJ0/X;

    iget v2, p0, LA/G;->v:I

    invoke-static {p1, v0, v2, v1}, LJ0/X;->j(LJ0/X;LJ0/Y;II)V

    goto :goto_1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
