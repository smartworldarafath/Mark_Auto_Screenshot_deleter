.class public final LA/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA/g;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, LA/c;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final b(ILjava/lang/String;)LA/a;
    .locals 1

    sget-object v0, LA/k0;->v:Ljava/util/WeakHashMap;

    new-instance v0, LA/a;

    invoke-direct {v0, p0, p1}, LA/a;-><init>(ILjava/lang/String;)V

    return-object v0
.end method

.method public static final d(ILjava/lang/String;)LA/g0;
    .locals 2

    sget-object p0, LA/k0;->v:Ljava/util/WeakHashMap;

    new-instance p0, LA/g0;

    new-instance v0, LA/J;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1, v1, v1}, LA/J;-><init>(IIII)V

    invoke-direct {p0, v0, p1}, LA/g0;-><init>(LA/J;Ljava/lang/String;)V

    return-object p0
.end method

.method public static e(La0/r;)LA/k0;
    .locals 4

    sget-object v0, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->f:La0/X0;

    invoke-virtual {p0, v0}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    sget-object v1, LA/k0;->v:Ljava/util/WeakHashMap;

    monitor-enter v1

    :try_start_0
    invoke-virtual {v1, v0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_0

    new-instance v2, LA/k0;

    invoke-direct {v2, v0}, LA/k0;-><init>(Landroid/view/View;)V

    invoke-virtual {v1, v0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    check-cast v2, LA/k0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    invoke-virtual {p0, v2}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v1

    invoke-virtual {p0, v0}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v1, v3

    invoke-virtual {p0}, La0/r;->K()Ljava/lang/Object;

    move-result-object v3

    if-nez v1, :cond_1

    sget-object v1, La0/m;->a:La0/U;

    if-ne v3, v1, :cond_2

    :cond_1
    new-instance v3, LA/Q;

    const/4 v1, 0x2

    invoke-direct {v3, v1, v2, v0}, LA/Q;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0, v3}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_2
    check-cast v3, Lr7/c;

    invoke-static {v2, v3, p0}, La0/b;->e(Ljava/lang/Object;Lr7/c;La0/r;)V

    return-object v2

    :goto_1
    monitor-exit v1

    throw p0
.end method


# virtual methods
.method public c(Lj1/c;I[ILj1/m;[I)V
    .locals 0

    iget p1, p0, LA/c;->a:I

    packed-switch p1, :pswitch_data_0

    sget-object p1, Lj1/m;->t:Lj1/m;

    if-ne p4, p1, :cond_0

    const/4 p1, 0x0

    invoke-static {p3, p5, p1}, LA/j;->b([I[IZ)V

    goto :goto_0

    :cond_0
    const/4 p1, 0x1

    invoke-static {p2, p3, p5, p1}, LA/j;->c(I[I[IZ)V

    :goto_0
    return-void

    :pswitch_0
    const/4 p1, 0x0

    invoke-static {p2, p3, p5, p1}, LA/j;->c(I[I[IZ)V

    return-void

    :pswitch_1
    const/4 p1, 0x0

    invoke-static {p3, p5, p1}, LA/j;->b([I[IZ)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    iget v0, p0, LA/c;->a:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_0
    const-string v0, "Arrangement#Start"

    return-object v0

    :pswitch_1
    const-string v0, "AbsoluteArrangement#Right"

    return-object v0

    :pswitch_2
    const-string v0, "AbsoluteArrangement#Left"

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
