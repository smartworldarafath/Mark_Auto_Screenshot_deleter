.class public final LA/m;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/t0;


# instance fields
.field public H:Lm0/j;

.field public I:Z


# virtual methods
.method public final A(Lj1/c;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    return-object p0
.end method
