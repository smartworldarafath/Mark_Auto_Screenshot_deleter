.class public final LA/W;
.super Lm0/q;
.source "SourceFile"

# interfaces
.implements LL0/z;


# instance fields
.field public H:LA/U;


# virtual methods
.method public final c(LJ0/O;LJ0/L;J)LJ0/N;
    .locals 9

    iget-object v0, p0, LA/W;->H:LA/U;

    invoke-interface {p1}, LJ0/q;->getLayoutDirection()Lj1/m;

    move-result-object v1

    invoke-interface {v0, v1}, LA/U;->c(Lj1/m;)F

    move-result v0

    iget-object v1, p0, LA/W;->H:LA/U;

    invoke-interface {v1}, LA/U;->d()F

    move-result v1

    iget-object v2, p0, LA/W;->H:LA/U;

    invoke-interface {p1}, LJ0/q;->getLayoutDirection()Lj1/m;

    move-result-object v3

    invoke-interface {v2, v3}, LA/U;->b(Lj1/m;)F

    move-result v2

    iget-object v3, p0, LA/W;->H:LA/U;

    invoke-interface {v3}, LA/U;->a()F

    move-result v3

    const/4 v4, 0x0

    int-to-float v5, v4

    invoke-static {v0, v5}, Ljava/lang/Float;->compare(FF)I

    move-result v6

    const/4 v7, 0x1

    if-ltz v6, :cond_0

    move v6, v7

    goto :goto_0

    :cond_0
    move v6, v4

    :goto_0
    invoke-static {v1, v5}, Ljava/lang/Float;->compare(FF)I

    move-result v8

    if-ltz v8, :cond_1

    move v8, v7

    goto :goto_1

    :cond_1
    move v8, v4

    :goto_1
    and-int/2addr v6, v8

    invoke-static {v2, v5}, Ljava/lang/Float;->compare(FF)I

    move-result v8

    if-ltz v8, :cond_2

    move v8, v7

    goto :goto_2

    :cond_2
    move v8, v4

    :goto_2
    and-int/2addr v6, v8

    invoke-static {v3, v5}, Ljava/lang/Float;->compare(FF)I

    move-result v5

    if-ltz v5, :cond_3

    move v4, v7

    :cond_3
    and-int/2addr v4, v6

    if-nez v4, :cond_4

    const-string v4, "Padding must be non-negative"

    invoke-static {v4}, LB/a;->a(Ljava/lang/String;)V

    :cond_4
    invoke-interface {p1, v0}, Lj1/c;->j0(F)I

    move-result v0

    invoke-interface {p1, v2}, Lj1/c;->j0(F)I

    move-result v2

    add-int/2addr v2, v0

    invoke-interface {p1, v1}, Lj1/c;->j0(F)I

    move-result v1

    invoke-interface {p1, v3}, Lj1/c;->j0(F)I

    move-result v3

    add-int/2addr v3, v1

    neg-int v4, v2

    neg-int v5, v3

    invoke-static {v4, v5, p3, p4}, Lj1/b;->i(IIJ)J

    move-result-wide v4

    invoke-interface {p2, v4, v5}, LJ0/L;->D(J)LJ0/Y;

    move-result-object p2

    iget v4, p2, LJ0/Y;->t:I

    add-int/2addr v4, v2

    invoke-static {v4, p3, p4}, Lj1/b;->g(IJ)I

    move-result v2

    iget v4, p2, LJ0/Y;->u:I

    add-int/2addr v4, v3

    invoke-static {v4, p3, p4}, Lj1/b;->f(IJ)I

    move-result p3

    new-instance p4, LA/G;

    const/4 v3, 0x1

    invoke-direct {p4, p2, v0, v1, v3}, LA/G;-><init>(Ljava/lang/Object;III)V

    sget-object p2, Le7/u;->t:Le7/u;

    invoke-interface {p1, v2, p3, p2, p4}, LJ0/O;->p(IILjava/util/Map;Lr7/c;)LJ0/N;

    move-result-object p1

    return-object p1
.end method
