.class public final LA/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LK0/c;


# instance fields
.field public final a:Lr7/c;

.field public b:LA/i0;


# direct methods
.method public constructor <init>(Lr7/c;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/x;->a:Lr7/c;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, LA/x;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, LA/x;

    iget-object p1, p1, LA/x;->a:Lr7/c;

    iget-object v1, p0, LA/x;->a:Lr7/c;

    if-ne p1, v1, :cond_2

    return v0

    :cond_2
    return v2
.end method

.method public final f(LK0/f;)V
    .locals 1

    sget-object v0, LA/d;->c:LK0/g;

    invoke-interface {p1, v0}, LK0/f;->e(LK0/g;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LA/i0;

    iget-object v0, p0, LA/x;->b:LA/i0;

    invoke-static {p1, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iput-object p1, p0, LA/x;->b:LA/i0;

    iget-object v0, p0, LA/x;->a:Lr7/c;

    invoke-interface {v0, p1}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-void
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, LA/x;->a:Lr7/c;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method
