.class public interface abstract LA/i0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lj1/c;Lj1/m;)I
.end method

.method public abstract b(Lj1/c;Lj1/m;)I
.end method

.method public abstract c(Lj1/c;)I
.end method

.method public abstract d(Lj1/c;)I
.end method
