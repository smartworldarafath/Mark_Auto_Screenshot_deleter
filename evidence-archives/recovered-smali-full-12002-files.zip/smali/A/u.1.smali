.class public final synthetic LA/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:[LJ0/Y;

.field public final synthetic u:LA/v;

.field public final synthetic v:I

.field public final synthetic w:LJ0/O;

.field public final synthetic x:[I


# direct methods
.method public synthetic constructor <init>([LJ0/Y;LA/v;ILJ0/O;[I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA/u;->t:[LJ0/Y;

    iput-object p2, p0, LA/u;->u:LA/v;

    iput p3, p0, LA/u;->v:I

    iput-object p4, p0, LA/u;->w:LJ0/O;

    iput-object p5, p0, LA/u;->x:[I

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    check-cast p1, LJ0/X;

    iget-object v0, p0, LA/u;->t:[LJ0/Y;

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    move v4, v3

    :goto_0
    if-ge v3, v1, :cond_3

    aget-object v5, v0, v3

    add-int/lit8 v6, v4, 0x1

    invoke-static {v5}, Ls7/j;->b(Ljava/lang/Object;)V

    invoke-virtual {v5}, LJ0/Y;->G()Ljava/lang/Object;

    move-result-object v7

    instance-of v8, v7, LA/Y;

    const/4 v9, 0x0

    if-eqz v8, :cond_0

    check-cast v7, LA/Y;

    goto :goto_1

    :cond_0
    move-object v7, v9

    :goto_1
    iget-object v8, p0, LA/u;->w:LJ0/O;

    invoke-interface {v8}, LJ0/q;->getLayoutDirection()Lj1/m;

    move-result-object v8

    if-eqz v7, :cond_1

    iget-object v9, v7, LA/Y;->c:LA/d;

    :cond_1
    iget v7, p0, LA/u;->v:I

    if-eqz v9, :cond_2

    iget v10, v5, LJ0/Y;->t:I

    sub-int/2addr v7, v10

    invoke-virtual {v9, v7, v8}, LA/d;->b(ILj1/m;)I

    move-result v7

    goto :goto_2

    :cond_2
    iget-object v9, p0, LA/u;->u:LA/v;

    iget-object v9, v9, LA/v;->b:Lm0/h;

    iget v10, v5, LJ0/Y;->t:I

    sub-int/2addr v7, v10

    invoke-virtual {v9, v2, v7, v8}, Lm0/h;->a(IILj1/m;)I

    move-result v7

    :goto_2
    iget-object v8, p0, LA/u;->x:[I

    aget v4, v8, v4

    invoke-static {p1, v5, v7, v4}, LJ0/X;->j(LJ0/X;LJ0/Y;II)V

    add-int/lit8 v3, v3, 0x1

    move v4, v6

    goto :goto_0

    :cond_3
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1
.end method
