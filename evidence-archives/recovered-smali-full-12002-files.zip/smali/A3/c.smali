.class public final LA3/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/internal/ads/Vj;
.implements Lcom/google/android/gms/internal/ads/gl;


# instance fields
.field public final synthetic t:I

.field public u:J

.field public v:I

.field public w:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>()V
    .locals 1

    .line 1
    const/4 v0, 0x3

    iput v0, p0, LA3/c;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(ILjava/net/URL;J)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LA3/c;->t:I

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iput p1, p0, LA3/c;->v:I

    .line 6
    iput-object p2, p0, LA3/c;->w:Ljava/lang/Object;

    .line 7
    iput-wide p3, p0, LA3/c;->u:J

    return-void
.end method

.method public synthetic constructor <init>(Lcom/google/android/gms/internal/ads/g2;JI)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, LA3/c;->t:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA3/c;->w:Ljava/lang/Object;

    iput-wide p2, p0, LA3/c;->u:J

    iput p4, p0, LA3/c;->v:I

    return-void
.end method

.method public synthetic constructor <init>(Lcom/google/android/gms/internal/ads/sJ;IJJ)V
    .locals 0

    const/4 p5, 0x2

    iput p5, p0, LA3/c;->t:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA3/c;->w:Ljava/lang/Object;

    iput p2, p0, LA3/c;->v:I

    iput-wide p3, p0, LA3/c;->u:J

    return-void
.end method


# virtual methods
.method public c(Ljava/lang/Object;)V
    .locals 20

    move-object/from16 v0, p0

    iget v1, v0, LA3/c;->t:I

    packed-switch v1, :pswitch_data_0

    move-object/from16 v1, p1

    check-cast v1, Lcom/google/android/gms/internal/ads/tJ;

    iget-object v2, v0, LA3/c;->w:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/internal/ads/sJ;

    iget v3, v0, LA3/c;->v:I

    iget-wide v4, v0, LA3/c;->u:J

    invoke-interface {v1, v2, v3, v4, v5}, Lcom/google/android/gms/internal/ads/tJ;->g(Lcom/google/android/gms/internal/ads/sJ;IJ)V

    return-void

    :pswitch_0
    iget-object v1, v0, LA3/c;->w:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/internal/ads/g2;

    iget-wide v2, v0, LA3/c;->u:J

    iget v4, v0, LA3/c;->v:I

    move-object/from16 v5, p1

    check-cast v5, Lcom/google/android/gms/internal/ads/b2;

    iget-object v6, v1, Lcom/google/android/gms/internal/ads/g2;->h:Lcom/google/android/gms/internal/ads/KK;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v6, v5, Lcom/google/android/gms/internal/ads/b2;->a:Lcom/google/android/gms/internal/ads/mz;

    iget-wide v7, v5, Lcom/google/android/gms/internal/ads/b2;->c:J

    new-instance v9, Ljava/util/ArrayList;

    invoke-interface {v6}, Ljava/util/Collection;->size()I

    move-result v10

    invoke-direct {v9, v10}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v10, 0x0

    invoke-virtual {v6, v10}, Lcom/google/android/gms/internal/ads/mz;->t(I)Lcom/google/android/gms/internal/ads/kz;

    move-result-object v6

    :goto_0
    invoke-virtual {v6}, Lcom/google/android/gms/internal/ads/kz;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_7

    invoke-virtual {v6}, Lcom/google/android/gms/internal/ads/kz;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/google/android/gms/internal/ads/Dg;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v13, Landroid/os/Bundle;

    invoke-direct {v13}, Landroid/os/Bundle;-><init>()V

    iget-object v14, v11, Lcom/google/android/gms/internal/ads/Dg;->a:Ljava/lang/CharSequence;

    if-eqz v14, :cond_4

    sget-object v15, Lcom/google/android/gms/internal/ads/Dg;->q:Ljava/lang/String;

    invoke-virtual {v13, v15, v14}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    instance-of v15, v14, Landroid/text/Spanned;

    if-eqz v15, :cond_4

    check-cast v14, Landroid/text/Spanned;

    sget-object v15, Lcom/google/android/gms/internal/ads/jh;->a:Ljava/lang/String;

    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v12

    const-class v0, Lcom/google/android/gms/internal/ads/wh;

    invoke-interface {v14, v10, v12, v0}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/google/android/gms/internal/ads/wh;

    array-length v12, v0

    :goto_1
    if-ge v10, v12, :cond_0

    move-object/from16 v16, v0

    aget-object v0, v16, v10

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-wide/from16 v17, v2

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    sget-object v3, Lcom/google/android/gms/internal/ads/wh;->c:Ljava/lang/String;

    move/from16 v19, v4

    iget-object v4, v0, Lcom/google/android/gms/internal/ads/wh;->a:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v3, Lcom/google/android/gms/internal/ads/wh;->d:Ljava/lang/String;

    iget v4, v0, Lcom/google/android/gms/internal/ads/wh;->b:I

    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x1

    invoke-static {v14, v0, v3, v2}, Lcom/google/android/gms/internal/ads/jh;->a(Landroid/text/Spanned;Ljava/lang/Object;ILandroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v10, 0x1

    move-object/from16 v0, v16

    move-wide/from16 v2, v17

    move/from16 v4, v19

    goto :goto_1

    :cond_0
    move-wide/from16 v17, v2

    move/from16 v19, v4

    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const-class v2, Lcom/google/android/gms/internal/ads/Sh;

    const/4 v3, 0x0

    invoke-interface {v14, v3, v0, v2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/google/android/gms/internal/ads/Sh;

    array-length v2, v0

    const/4 v3, 0x0

    :goto_2
    if-ge v3, v2, :cond_1

    aget-object v4, v0, v3

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Landroid/os/Bundle;

    invoke-direct {v10}, Landroid/os/Bundle;-><init>()V

    sget-object v12, Lcom/google/android/gms/internal/ads/Sh;->d:Ljava/lang/String;

    move-object/from16 p1, v0

    iget v0, v4, Lcom/google/android/gms/internal/ads/Sh;->a:I

    invoke-virtual {v10, v12, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    sget-object v0, Lcom/google/android/gms/internal/ads/Sh;->e:Ljava/lang/String;

    iget v12, v4, Lcom/google/android/gms/internal/ads/Sh;->b:I

    invoke-virtual {v10, v0, v12}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    sget-object v0, Lcom/google/android/gms/internal/ads/Sh;->f:Ljava/lang/String;

    iget v12, v4, Lcom/google/android/gms/internal/ads/Sh;->c:I

    invoke-virtual {v10, v0, v12}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v0, 0x2

    invoke-static {v14, v4, v0, v10}, Lcom/google/android/gms/internal/ads/jh;->a(Landroid/text/Spanned;Ljava/lang/Object;ILandroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    move-object/from16 v0, p1

    goto :goto_2

    :cond_1
    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const-class v2, Lcom/google/android/gms/internal/ads/th;

    const/4 v3, 0x0

    invoke-interface {v14, v3, v0, v2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/google/android/gms/internal/ads/th;

    array-length v2, v0

    const/4 v3, 0x0

    :goto_3
    if-ge v3, v2, :cond_2

    aget-object v4, v0, v3

    const/4 v10, 0x3

    const/4 v12, 0x0

    invoke-static {v14, v4, v10, v12}, Lcom/google/android/gms/internal/ads/jh;->a(Landroid/text/Spanned;Ljava/lang/Object;ILandroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v4

    invoke-virtual {v15, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_2
    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const-class v2, Lcom/google/android/gms/internal/ads/ai;

    const/4 v3, 0x0

    invoke-interface {v14, v3, v0, v2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/google/android/gms/internal/ads/ai;

    array-length v2, v0

    const/4 v3, 0x0

    :goto_4
    if-ge v3, v2, :cond_3

    aget-object v4, v0, v3

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Landroid/os/Bundle;

    invoke-direct {v10}, Landroid/os/Bundle;-><init>()V

    sget-object v12, Lcom/google/android/gms/internal/ads/ai;->b:Ljava/lang/String;

    move-object/from16 p1, v0

    iget-object v0, v4, Lcom/google/android/gms/internal/ads/ai;->a:Ljava/lang/String;

    invoke-virtual {v10, v12, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x4

    invoke-static {v14, v4, v0, v10}, Lcom/google/android/gms/internal/ads/jh;->a(Landroid/text/Spanned;Ljava/lang/Object;ILandroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    move-object/from16 v0, p1

    goto :goto_4

    :cond_3
    invoke-virtual {v15}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_5

    sget-object v0, Lcom/google/android/gms/internal/ads/Dg;->r:Ljava/lang/String;

    invoke-virtual {v13, v0, v15}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    goto :goto_5

    :cond_4
    move-wide/from16 v17, v2

    move/from16 v19, v4

    :cond_5
    :goto_5
    iget-object v0, v11, Lcom/google/android/gms/internal/ads/Dg;->b:Landroid/text/Layout$Alignment;

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->s:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V

    iget-object v0, v11, Lcom/google/android/gms/internal/ads/Dg;->c:Landroid/text/Layout$Alignment;

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->t:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/Bundle;->putSerializable(Ljava/lang/String;Ljava/io/Serializable;)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->e:F

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->v:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->f:I

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->w:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->g:I

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->x:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->h:F

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->y:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->i:I

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->z:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->l:I

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->A:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->m:F

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->B:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->j:F

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->C:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->k:F

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->D:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    sget-object v0, Lcom/google/android/gms/internal/ads/Dg;->F:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-virtual {v13, v0, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    sget-object v0, Lcom/google/android/gms/internal/ads/Dg;->E:Ljava/lang/String;

    const/high16 v2, -0x1000000

    invoke-virtual {v13, v0, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->n:I

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->G:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->o:F

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->H:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    iget v0, v11, Lcom/google/android/gms/internal/ads/Dg;->p:I

    sget-object v2, Lcom/google/android/gms/internal/ads/Dg;->I:Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    iget-object v0, v11, Lcom/google/android/gms/internal/ads/Dg;->d:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_6

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/4 v4, 0x0

    invoke-virtual {v0, v3, v4, v2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    move-result v0

    invoke-static {v0}, Lcom/google/android/gms/internal/ads/dn;->S(Z)V

    sget-object v0, Lcom/google/android/gms/internal/ads/Dg;->u:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    invoke-virtual {v13, v0, v2}, Landroid/os/Bundle;->putByteArray(Ljava/lang/String;[B)V

    :cond_6
    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, p0

    move-wide/from16 v2, v17

    move/from16 v4, v19

    const/4 v10, 0x0

    goto/16 :goto_0

    :cond_7
    move-wide/from16 v17, v2

    move/from16 v19, v4

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v2, "c"

    invoke-virtual {v0, v2, v9}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    const-string v2, "d"

    invoke-virtual {v0, v2, v7, v8}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V

    invoke-virtual {v2}, Landroid/os/Parcel;->marshall()[B

    move-result-object v0

    invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V

    iget-object v2, v1, Lcom/google/android/gms/internal/ads/g2;->c:Lcom/google/android/gms/internal/ads/Ao;

    array-length v10, v0

    invoke-virtual {v2, v10, v0}, Lcom/google/android/gms/internal/ads/Ao;->y(I[B)V

    iget-object v6, v1, Lcom/google/android/gms/internal/ads/g2;->a:Lcom/google/android/gms/internal/ads/o0;

    const/4 v3, 0x0

    invoke-interface {v6, v2, v10, v3}, Lcom/google/android/gms/internal/ads/o0;->b(Lcom/google/android/gms/internal/ads/Ao;II)V

    iget-wide v4, v5, Lcom/google/android/gms/internal/ads/b2;->b:J

    const-wide v7, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v0, v4, v7

    const-wide v7, 0x7fffffffffffffffL

    if-nez v0, :cond_9

    iget-object v0, v1, Lcom/google/android/gms/internal/ads/g2;->h:Lcom/google/android/gms/internal/ads/KK;

    iget-wide v0, v0, Lcom/google/android/gms/internal/ads/KK;->r:J

    cmp-long v0, v0, v7

    if-nez v0, :cond_8

    const/4 v3, 0x1

    :cond_8
    invoke-static {v3}, Lcom/google/android/gms/internal/ads/dn;->S(Z)V

    move-wide/from16 v7, v17

    :goto_6
    const/4 v3, 0x1

    goto :goto_8

    :cond_9
    iget-object v0, v1, Lcom/google/android/gms/internal/ads/g2;->h:Lcom/google/android/gms/internal/ads/KK;

    iget-wide v0, v0, Lcom/google/android/gms/internal/ads/KK;->r:J

    cmp-long v2, v0, v7

    if-nez v2, :cond_a

    add-long v2, v17, v4

    :goto_7
    move-wide v7, v2

    goto :goto_6

    :cond_a
    add-long v2, v4, v0

    goto :goto_7

    :goto_8
    or-int/lit8 v9, v19, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-interface/range {v6 .. v12}, Lcom/google/android/gms/internal/ads/o0;->c(JIIILcom/google/android/gms/internal/ads/n0;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method
