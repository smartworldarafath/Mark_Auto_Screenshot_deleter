.class public final synthetic LA3/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld5/c;
.implements Lw2/b;
.implements LK3/b;
.implements Lf/b;
.implements Lo1/i;
.implements LC5/a;
.implements LO4/a;
.implements LO4/c;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, LA3/b;->t:I

    iput-object p2, p0, LA3/b;->u:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    iget-object v0, p0, LA3/b;->u:Ljava/lang/Object;

    check-cast v0, La0/Z;

    invoke-interface {v0}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lr7/c;

    invoke-interface {v0, p1}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public b()Ljava/lang/Object;
    .locals 10

    iget v0, p0, LA3/b;->t:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v4, p0, LA3/b;->u:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_0

    check-cast v4, LI3/m;

    iget-object v0, v4, LI3/m;->b:LJ3/d;

    check-cast v0, LJ3/i;

    new-instance v5, LA1/c;

    const/4 v6, 0x6

    invoke-direct {v5, v6}, LA1/c;-><init>(I)V

    invoke-virtual {v0, v5}, LJ3/i;->l(LJ3/g;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LC3/k;

    iget-object v6, v4, LI3/m;->c:LI3/d;

    invoke-virtual {v6, v5, v2, v3}, LI3/d;->a(LC3/k;IZ)V

    goto :goto_0

    :cond_0
    return-object v1

    :pswitch_0
    check-cast v4, LI3/k;

    iget-object v0, v4, LI3/k;->i:LJ3/c;

    check-cast v0, LJ3/i;

    invoke-virtual {v0}, LJ3/i;->c()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v2

    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    :try_start_0
    const-string v3, "DELETE FROM log_event_dropped"

    invoke-virtual {v2, v3}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object v3

    invoke-virtual {v3}, Landroid/database/sqlite/SQLiteStatement;->execute()V

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "UPDATE global_log_event_state SET last_metrics_upload_ms="

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, v0, LJ3/i;->u:LL3/a;

    invoke-interface {v0}, LL3/a;->c()J

    move-result-wide v4

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object v0

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteStatement;->execute()V

    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    return-object v1

    :catchall_0
    move-exception v0

    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    throw v0

    :pswitch_1
    check-cast v4, LJ3/d;

    check-cast v4, LJ3/i;

    iget-object v0, v4, LJ3/i;->u:LL3/a;

    invoke-interface {v0}, LL3/a;->c()J

    move-result-wide v0

    iget-object v5, v4, LJ3/i;->w:LJ3/a;

    iget-wide v5, v5, LJ3/a;->d:J

    sub-long/2addr v0, v5

    invoke-virtual {v4}, LJ3/i;->c()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v5

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    :try_start_1
    const-string v6, "SELECT COUNT(*), transport_name FROM events WHERE timestamp_ms < ? GROUP BY transport_name"

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v6, v0}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_1
    :try_start_2
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getInt(I)I

    move-result v6

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v7

    int-to-long v8, v6

    sget-object v6, LF3/c;->v:LF3/c;

    invoke-virtual {v4, v8, v9, v6, v7}, LJ3/i;->q(JLF3/c;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    goto :goto_1

    :cond_1
    :try_start_3
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    const-string v1, "events"

    const-string v2, "timestamp_ms < ?"

    invoke-virtual {v5, v1, v2, v0}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    :catchall_1
    move-exception v0

    goto :goto_2

    :catchall_2
    move-exception v0

    :try_start_4
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :goto_2
    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    throw v0

    :pswitch_2
    check-cast v4, LJ3/c;

    check-cast v4, LJ3/i;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v0, LF3/a;->e:I

    new-instance v0, LP2/n;

    invoke-direct {v0, v2, v3}, LP2/n;-><init>(IZ)V

    iput-object v1, v0, LP2/n;->u:Ljava/lang/Object;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, LP2/n;->v:Ljava/lang/Object;

    iput-object v1, v0, LP2/n;->w:Ljava/lang/Object;

    const-string v1, ""

    iput-object v1, v0, LP2/n;->x:Ljava/lang/Object;

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const-string v2, "SELECT log_source, reason, events_dropped_count FROM log_event_dropped"

    invoke-virtual {v4}, LJ3/i;->c()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v5

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    :try_start_5
    new-array v3, v3, [Ljava/lang/String;

    invoke-virtual {v5, v2, v3}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    new-instance v3, LG2/p;

    const/4 v6, 0x5

    invoke-direct {v3, v4, v1, v0, v6}, LG2/p;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v2, v3}, LJ3/i;->C(Landroid/database/Cursor;LJ3/g;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LF3/a;

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    return-object v0

    :catchall_3
    move-exception v0

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    throw v0

    nop

    :pswitch_data_0
    .packed-switch 0x4
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public c(LC5/b;)V
    .locals 4

    iget-object v0, p0, LA3/b;->u:Ljava/lang/Object;

    check-cast v0, Lg5/a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "FirebaseCrashlytics"

    const/4 v2, 0x3

    invoke-static {v1, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v2

    if-eqz v2, :cond_0

    const-string v2, "Crashlytics native component now available."

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    iget-object v0, v0, Lg5/a;->b:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-interface {p1}, LC5/b;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lg5/a;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    return-void
.end method

.method public d(LA4/f;)LA3/c;
    .locals 21

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    iget-object v2, v1, LA3/b;->u:Ljava/lang/Object;

    check-cast v2, LA3/d;

    iget-object v3, v0, LA4/f;->u:Ljava/lang/Object;

    check-cast v3, Ljava/net/URL;

    const-string v4, "TRuntime."

    const-string v5, "CctTransportBackend"

    invoke-virtual {v4, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x4

    invoke-static {v6, v7}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v8

    if-eqz v8, :cond_0

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v8

    const-string v9, "Making request to: %s"

    invoke-static {v9, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v6, v8}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v3

    check-cast v3, Ljava/net/HttpURLConnection;

    const/16 v6, 0x7530

    invoke-virtual {v3, v6}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    iget v6, v2, LA3/d;->g:I

    invoke-virtual {v3, v6}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const/4 v6, 0x1

    invoke-virtual {v3, v6}, Ljava/net/URLConnection;->setDoOutput(Z)V

    const/4 v6, 0x0

    invoke-virtual {v3, v6}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    const-string v6, "POST"

    invoke-virtual {v3, v6}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const-string v6, "User-Agent"

    const-string v8, "datatransport/3.3.0 android/"

    invoke-virtual {v3, v6, v8}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "Content-Encoding"

    const-string v8, "gzip"

    invoke-virtual {v3, v6, v8}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v9, "application/json"

    const-string v10, "Content-Type"

    invoke-virtual {v3, v10, v9}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v9, "Accept-Encoding"

    invoke-virtual {v3, v9, v8}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v9, v0, LA4/f;->w:Ljava/lang/Object;

    check-cast v9, Ljava/lang/String;

    if-eqz v9, :cond_1

    const-string v11, "X-Goog-Api-Key"

    invoke-virtual {v3, v11, v9}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :try_start_0
    invoke-virtual {v3}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v13
    :try_end_0
    .catch Ljava/net/ConnectException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/net/UnknownHostException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Lw5/b; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    new-instance v14, Ljava/util/zip/GZIPOutputStream;

    invoke-direct {v14, v13}, Ljava/util/zip/GZIPOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    :try_start_2
    iget-object v2, v2, LA3/d;->a:Lw/a;

    iget-object v0, v0, LA4/f;->v:Ljava/lang/Object;

    check-cast v0, LB3/m;

    new-instance v15, Ljava/io/BufferedWriter;

    new-instance v9, Ljava/io/OutputStreamWriter;

    invoke-direct {v9, v14}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;)V

    invoke-direct {v15, v9}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V

    move-object/from16 v16, v15

    new-instance v15, Ly5/e;

    iget-object v2, v2, Lw/a;->t:Ljava/lang/Object;

    check-cast v2, Ly5/d;

    iget-object v9, v2, Ly5/d;->t:Ljava/util/HashMap;

    iget-object v11, v2, Ly5/d;->u:Ljava/util/HashMap;

    iget-object v12, v2, Ly5/d;->v:Ly5/a;

    iget-boolean v2, v2, Ly5/d;->w:Z

    move/from16 v20, v2

    move-object/from16 v17, v9

    move-object/from16 v18, v11

    move-object/from16 v19, v12

    invoke-direct/range {v15 .. v20}, Ly5/e;-><init>(Ljava/io/Writer;Ljava/util/Map;Ljava/util/Map;Lw5/d;Z)V

    invoke-virtual {v15, v0}, Ly5/e;->h(Ljava/lang/Object;)Ly5/e;

    invoke-virtual {v15}, Ly5/e;->j()V

    iget-object v0, v15, Ly5/e;->b:Landroid/util/JsonWriter;

    invoke-virtual {v0}, Landroid/util/JsonWriter;->flush()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_5

    :try_start_3
    invoke-virtual {v14}, Ljava/io/OutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    if-eqz v13, :cond_2

    :try_start_4
    invoke-virtual {v13}, Ljava/io/OutputStream;->close()V
    :try_end_4
    .catch Ljava/net/ConnectException; {:try_start_4 .. :try_end_4} :catch_3
    .catch Ljava/net/UnknownHostException; {:try_start_4 .. :try_end_4} :catch_2
    .catch Lw5/b; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    goto/16 :goto_d

    :catch_1
    move-exception v0

    goto/16 :goto_d

    :catch_2
    move-exception v0

    :goto_0
    const-wide/16 v3, 0x0

    const/4 v7, 0x0

    goto/16 :goto_e

    :catch_3
    move-exception v0

    goto :goto_0

    :cond_2
    :goto_1
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v4, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v7}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v7

    if-eqz v7, :cond_3

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v7, "Status Code: %d"

    invoke-static {v7, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    const-string v2, "Content-Type: %s"

    invoke-virtual {v3, v10}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v5, v2, v4}, LE4/a3;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const-string v2, "Content-Encoding: %s"

    invoke-virtual {v3, v6}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v5, v2, v4}, LE4/a3;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v2, 0x12e

    if-eq v0, v2, :cond_b

    const/16 v2, 0x12d

    if-eq v0, v2, :cond_b

    const/16 v2, 0x133

    if-ne v0, v2, :cond_4

    goto :goto_7

    :cond_4
    const/16 v2, 0xc8

    if-eq v0, v2, :cond_5

    new-instance v2, LA3/c;

    const-wide/16 v3, 0x0

    const/4 v5, 0x0

    invoke-direct {v2, v0, v5, v3, v4}, LA3/c;-><init>(ILjava/net/URL;J)V

    return-object v2

    :cond_5
    invoke-virtual {v3}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2

    :try_start_5
    invoke-virtual {v3, v6}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6

    new-instance v3, Ljava/util/zip/GZIPInputStream;

    invoke-direct {v3, v2}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto :goto_2

    :cond_6
    move-object v3, v2

    :goto_2
    :try_start_6
    new-instance v4, Ljava/io/BufferedReader;

    new-instance v5, Ljava/io/InputStreamReader;

    invoke-direct {v5, v3}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v4, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    invoke-static {v4}, LB3/u;->a(Ljava/io/BufferedReader;)LB3/u;

    move-result-object v4

    iget-wide v4, v4, LB3/u;->a:J

    new-instance v6, LA3/c;

    const/4 v7, 0x0

    invoke-direct {v6, v0, v7, v4, v5}, LA3/c;-><init>(ILjava/net/URL;J)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    if-eqz v3, :cond_7

    :try_start_7
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    goto :goto_3

    :catchall_0
    move-exception v0

    move-object v3, v0

    goto :goto_5

    :cond_7
    :goto_3
    if-eqz v2, :cond_8

    invoke-virtual {v2}, Ljava/io/InputStream;->close()V

    :cond_8
    return-object v6

    :catchall_1
    move-exception v0

    move-object v4, v0

    if-eqz v3, :cond_9

    :try_start_8
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    goto :goto_4

    :catchall_2
    move-exception v0

    :try_start_9
    invoke-virtual {v4, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_9
    :goto_4
    throw v4
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    :goto_5
    if-eqz v2, :cond_a

    :try_start_a
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    goto :goto_6

    :catchall_3
    move-exception v0

    invoke-virtual {v3, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_a
    :goto_6
    throw v3

    :cond_b
    :goto_7
    const-string v2, "Location"

    invoke-virtual {v3, v2}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, LA3/c;

    new-instance v4, Ljava/net/URL;

    invoke-direct {v4, v2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const-wide/16 v5, 0x0

    invoke-direct {v3, v0, v4, v5, v6}, LA3/c;-><init>(ILjava/net/URL;J)V

    return-object v3

    :catchall_4
    move-exception v0

    move-object v2, v0

    goto :goto_b

    :goto_8
    move-object v2, v0

    goto :goto_9

    :catchall_5
    move-exception v0

    goto :goto_8

    :goto_9
    :try_start_b
    invoke-virtual {v14}, Ljava/io/OutputStream;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_6

    goto :goto_a

    :catchall_6
    move-exception v0

    :try_start_c
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_a
    throw v2
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    :goto_b
    if-eqz v13, :cond_c

    :try_start_d
    invoke-virtual {v13}, Ljava/io/OutputStream;->close()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_7

    goto :goto_c

    :catchall_7
    move-exception v0

    :try_start_e
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_c
    :goto_c
    throw v2
    :try_end_e
    .catch Ljava/net/ConnectException; {:try_start_e .. :try_end_e} :catch_3
    .catch Ljava/net/UnknownHostException; {:try_start_e .. :try_end_e} :catch_2
    .catch Lw5/b; {:try_start_e .. :try_end_e} :catch_1
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_e} :catch_0

    :goto_d
    const-string v2, "Couldn\'t encode request, returning with 400"

    invoke-static {v5, v2, v0}, LE4/a3;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    new-instance v0, LA3/c;

    const/16 v2, 0x190

    const-wide/16 v3, 0x0

    const/4 v7, 0x0

    invoke-direct {v0, v2, v7, v3, v4}, LA3/c;-><init>(ILjava/net/URL;J)V

    goto :goto_f

    :goto_e
    const-string v2, "Couldn\'t open connection, returning with 500"

    invoke-static {v5, v2, v0}, LE4/a3;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    new-instance v0, LA3/c;

    const/16 v2, 0x1f4

    invoke-direct {v0, v2, v7, v3, v4}, LA3/c;-><init>(ILjava/net/URL;J)V

    :goto_f
    return-object v0
.end method

.method public e(LO4/o;)V
    .locals 2

    iget-object v0, p0, LA3/b;->u:Ljava/lang/Object;

    check-cast v0, Ln6/k;

    const-string v1, "<unused var>"

    invoke-static {p1, v1}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p1, v0, Ln6/k;->a:LT6/b;

    sget-object v0, LT6/a;->J:LT6/a;

    const/4 v1, 0x1

    invoke-virtual {p1, v0, v1}, LT6/b;->e(LT6/a;Z)V

    const-string p1, "review_dialog_shown"

    sget-object v0, Le7/u;->t:Le7/u;

    invoke-static {p1, v0}, Lp6/b;->c(Ljava/lang/String;Ljava/util/Map;)V

    return-void
.end method

.method public f(LT3/o;)Ljava/lang/Object;
    .locals 49

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    iget v2, v1, LA3/b;->t:I

    sparse-switch v2, :sswitch_data_0

    iget-object v2, v1, LA3/b;->u:Ljava/lang/Object;

    check-cast v2, Lcom/google/firebase/crashlytics/CrashlyticsRegistrar;

    sget v3, Lcom/google/firebase/crashlytics/CrashlyticsRegistrar;->d:I

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const-class v5, LY4/f;

    invoke-virtual {v0, v5}, LT3/o;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    move-object v7, v5

    check-cast v7, LY4/f;

    const-class v5, LD5/e;

    invoke-virtual {v0, v5}, LT3/o;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LD5/e;

    const-class v6, Lg5/a;

    invoke-virtual {v0, v6}, LT3/o;->k(Ljava/lang/Class;)Ld5/o;

    move-result-object v6

    const-class v8, La5/a;

    invoke-virtual {v0, v8}, LT3/o;->k(Ljava/lang/Class;)Ld5/o;

    move-result-object v8

    const-class v9, LJ5/a;

    invoke-virtual {v0, v9}, LT3/o;->k(Ljava/lang/Class;)Ld5/o;

    move-result-object v9

    iget-object v10, v2, Lcom/google/firebase/crashlytics/CrashlyticsRegistrar;->a:Ld5/q;

    invoke-virtual {v0, v10}, LT3/o;->f(Ld5/q;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/concurrent/ExecutorService;

    iget-object v11, v2, Lcom/google/firebase/crashlytics/CrashlyticsRegistrar;->b:Ld5/q;

    invoke-virtual {v0, v11}, LT3/o;->f(Ld5/q;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/util/concurrent/ExecutorService;

    iget-object v2, v2, Lcom/google/firebase/crashlytics/CrashlyticsRegistrar;->c:Ld5/q;

    invoke-virtual {v0, v2}, LT3/o;->f(Ld5/q;)Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Ljava/util/concurrent/ExecutorService;

    const-string v12, ""

    const-string v13, "FirebaseCrashlytics"

    invoke-virtual {v7}, LY4/f;->a()V

    iget-object v14, v7, LY4/f;->a:Landroid/content/Context;

    invoke-virtual {v14}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v15

    new-instance v0, Ljava/lang/StringBuilder;

    move-wide/from16 v17, v3

    const-string v3, "Initializing Firebase Crashlytics 20.0.1 for "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    invoke-static {v13, v0, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    new-instance v4, Lk5/c;

    invoke-direct {v4, v10, v11}, Lk5/c;-><init>(Ljava/util/concurrent/ExecutorService;Ljava/util/concurrent/ExecutorService;)V

    move-object v10, v13

    new-instance v13, Lp5/c;

    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    sget-object v0, Lg5/b;->b:Lg5/b;

    invoke-virtual {v0, v14}, Lg5/b;->d(Landroid/content/Context;)Lm5/D0;

    move-result-object v0

    check-cast v0, Lm5/a0;

    iget-object v0, v0, Lm5/a0;->a:Ljava/lang/String;

    iput-object v0, v13, Lp5/c;->t:Ljava/lang/Object;

    invoke-virtual {v14}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v11

    iput-object v11, v13, Lp5/c;->u:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v16

    if-nez v16, :cond_1

    new-instance v3, Ljava/lang/StringBuilder;

    move-object/from16 v16, v4

    const-string v4, ".crashlytics.v3"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v4, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    move-object/from16 v19, v10

    const/16 v10, 0x28

    if-le v4, v10, :cond_0

    invoke-static {v0}, Lj5/f;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const-string v4, "[^a-zA-Z0-9.]"

    const-string v10, "_"

    invoke-virtual {v0, v4, v10}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_1
    move-object/from16 v16, v4

    move-object/from16 v19, v10

    const-string v0, ".com.google.firebase.crashlytics.files.v1"

    :goto_1
    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v11, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v3}, Lp5/c;->j(Ljava/io/File;)V

    iput-object v3, v13, Lp5/c;->v:Ljava/lang/Object;

    new-instance v0, Ljava/io/File;

    const-string v4, "open-sessions"

    invoke-direct {v0, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0}, Lp5/c;->j(Ljava/io/File;)V

    iput-object v0, v13, Lp5/c;->w:Ljava/lang/Object;

    new-instance v0, Ljava/io/File;

    const-string v4, "reports"

    invoke-direct {v0, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0}, Lp5/c;->j(Ljava/io/File;)V

    iput-object v0, v13, Lp5/c;->x:Ljava/lang/Object;

    new-instance v0, Ljava/io/File;

    const-string v4, "priority-reports"

    invoke-direct {v0, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0}, Lp5/c;->j(Ljava/io/File;)V

    iput-object v0, v13, Lp5/c;->y:Ljava/lang/Object;

    new-instance v0, Ljava/io/File;

    const-string v4, "native-reports"

    invoke-direct {v0, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0}, Lp5/c;->j(Ljava/io/File;)V

    iput-object v0, v13, Lp5/c;->z:Ljava/lang/Object;

    new-instance v10, LV3/q;

    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, v10, LV3/q;->v:Ljava/lang/Object;

    new-instance v0, LO4/h;

    invoke-direct {v0}, LO4/h;-><init>()V

    iput-object v0, v10, LV3/q;->w:Ljava/lang/Object;

    const/4 v3, 0x0

    iput-boolean v3, v10, LV3/q;->t:Z

    new-instance v0, LO4/h;

    invoke-direct {v0}, LO4/h;-><init>()V

    iput-object v0, v10, LV3/q;->y:Ljava/lang/Object;

    invoke-virtual {v7}, LY4/f;->a()V

    iget-object v0, v7, LY4/f;->a:Landroid/content/Context;

    iput-object v7, v10, LV3/q;->u:Ljava/lang/Object;

    const-string v4, "com.google.firebase.crashlytics"

    invoke-virtual {v0, v4, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v4

    const-string v11, "firebase_crashlytics_collection_enabled"

    invoke-interface {v4, v11}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v20

    const/4 v1, 0x1

    if-eqz v20, :cond_2

    iput-boolean v3, v10, LV3/q;->t:Z

    invoke-interface {v4, v11, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    goto :goto_2

    :cond_2
    const/4 v4, 0x0

    :goto_2
    if-nez v4, :cond_5

    const-string v4, "firebase_crashlytics_collection_enabled"

    :try_start_0
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v11

    if-eqz v11, :cond_3

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x80

    invoke-virtual {v11, v0, v1}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    if-eqz v0, :cond_3

    iget-object v1, v0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    if-eqz v1, :cond_3

    invoke-virtual {v1, v4}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    invoke-virtual {v0, v4}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :catch_0
    move-exception v0

    const-string v1, "Could not read data collection permission from manifest"

    const-string v4, "FirebaseCrashlytics"

    invoke-static {v4, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_3
    const/4 v0, 0x0

    :goto_3
    if-nez v0, :cond_4

    iput-boolean v3, v10, LV3/q;->t:Z

    const/4 v0, 0x0

    goto :goto_4

    :cond_4
    const/4 v1, 0x1

    iput-boolean v1, v10, LV3/q;->t:Z

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v1, v0}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    :goto_4
    move-object v4, v0

    :cond_5
    iput-object v4, v10, LV3/q;->x:Ljava/lang/Object;

    iget-object v1, v10, LV3/q;->v:Ljava/lang/Object;

    monitor-enter v1

    :try_start_1
    invoke-virtual {v10}, LV3/q;->b()Z

    move-result v0

    if-eqz v0, :cond_6

    iget-object v0, v10, LV3/q;->w:Ljava/lang/Object;

    check-cast v0, LO4/h;

    const/4 v4, 0x0

    invoke-virtual {v0, v4}, LO4/h;->d(Ljava/lang/Object;)V

    goto :goto_5

    :catchall_0
    move-exception v0

    goto/16 :goto_1d

    :cond_6
    :goto_5
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    new-instance v0, Lj5/v;

    invoke-direct {v0, v14, v15, v5, v10}, Lj5/v;-><init>(Landroid/content/Context;Ljava/lang/String;LD5/e;LV3/q;)V

    new-instance v1, Lg5/a;

    invoke-direct {v1, v6}, Lg5/a;-><init>(Ld5/o;)V

    new-instance v4, LO1/f;

    invoke-direct {v4, v8}, LO1/f;-><init>(Ld5/o;)V

    move-object v5, v14

    new-instance v14, Lj5/i;

    invoke-direct {v14, v10, v13}, Lj5/i;-><init>(LV3/q;Lp5/c;)V

    sget-object v6, LL5/c;->a:LL5/c;

    const-string v6, "Subscriber "

    const-string v8, "FirebaseSessions"

    sget-object v11, LL5/d;->t:LL5/d;

    sget-object v15, LL5/c;->a:LL5/c;

    invoke-static {v11}, LL5/c;->a(LL5/d;)LL5/a;

    move-result-object v15

    iget-object v3, v15, LL5/a;->b:Lj5/i;

    if-eqz v3, :cond_7

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, " already registered."

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v8, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_6

    :cond_7
    iput-object v14, v15, LL5/a;->b:Lj5/i;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, " registered."

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v8, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v3, v15, LL5/a;->a:LL7/c;

    const/4 v6, 0x0

    invoke-virtual {v3, v6}, LL7/c;->f(Ljava/lang/Object;)V

    :goto_6
    new-instance v15, LW2/g;

    const/16 v3, 0xb

    invoke-direct {v15, v3, v9}, LW2/g;-><init>(ILjava/lang/Object;)V

    new-instance v6, Lj5/p;

    new-instance v11, Lf5/a;

    invoke-direct {v11, v4}, Lf5/a;-><init>(LO1/f;)V

    move-object v3, v12

    new-instance v12, Lf5/a;

    invoke-direct {v12, v4}, Lf5/a;-><init>(LO1/f;)V

    move-object v8, v0

    move-object v9, v1

    move-object v4, v5

    move-object/from16 v1, v19

    invoke-direct/range {v6 .. v16}, Lj5/p;-><init>(LY4/f;Lj5/v;Lg5/a;LV3/q;Lf5/a;Lf5/a;Lp5/c;Lj5/i;LW2/g;Lk5/c;)V

    move-object v5, v6

    move-object v15, v10

    move-object/from16 v14, v16

    iget-object v0, v5, Lj5/p;->o:Lk5/c;

    invoke-virtual {v7}, LY4/f;->a()V

    iget-object v6, v7, LY4/f;->c:LY4/h;

    iget-object v6, v6, LY4/h;->b:Ljava/lang/String;

    const-string v7, "com.google.firebase.crashlytics.mapping_file_id"

    const-string v9, "string"

    invoke-static {v4, v7, v9}, Lj5/f;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v7

    if-nez v7, :cond_8

    const-string v7, "com.crashlytics.android.build_id"

    invoke-static {v4, v7, v9}, Lj5/f;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v7

    :cond_8
    if-eqz v7, :cond_9

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    invoke-virtual {v9, v7}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v7

    goto :goto_7

    :cond_9
    const/4 v7, 0x0

    :goto_7
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    const-string v10, "com.google.firebase.crashlytics.build_ids_lib"

    const-string v11, "array"

    invoke-static {v4, v10, v11}, Lj5/f;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v10

    const-string v12, "com.google.firebase.crashlytics.build_ids_arch"

    invoke-static {v4, v12, v11}, Lj5/f;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v12

    move-object/from16 v16, v5

    const-string v5, "com.google.firebase.crashlytics.build_ids_build_id"

    invoke-static {v4, v5, v11}, Lj5/f;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v5

    if-eqz v10, :cond_a

    if-eqz v12, :cond_a

    if-nez v5, :cond_b

    :cond_a
    move-object/from16 v32, v0

    move-object/from16 v23, v6

    move-object/from16 v31, v8

    goto/16 :goto_b

    :cond_b
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v11

    invoke-virtual {v11, v10}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v11

    invoke-virtual {v11, v12}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v12

    invoke-virtual {v12, v5}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v5

    array-length v12, v10

    move-object/from16 v23, v6

    array-length v6, v5

    if-ne v12, v6, :cond_c

    array-length v6, v11

    array-length v12, v5

    if-eq v6, v12, :cond_d

    :cond_c
    move-object/from16 v32, v0

    move-object/from16 v31, v8

    goto :goto_a

    :cond_d
    const/4 v6, 0x0

    :goto_8
    array-length v12, v5

    if-ge v6, v12, :cond_e

    new-instance v12, Lj5/c;

    move/from16 v22, v6

    aget-object v6, v10, v22

    move-object/from16 v31, v8

    aget-object v8, v11, v22

    move-object/from16 v32, v0

    aget-object v0, v5, v22

    invoke-direct {v12, v6, v8, v0}, Lj5/c;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v22, 0x1

    move-object/from16 v8, v31

    move-object/from16 v0, v32

    goto :goto_8

    :cond_e
    move-object/from16 v32, v0

    move-object/from16 v31, v8

    :cond_f
    :goto_9
    const/4 v5, 0x3

    :cond_10
    const/4 v6, 0x0

    goto :goto_c

    :goto_a
    const-string v0, "Lengths did not match: %d %d %d"

    array-length v6, v10

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    array-length v8, v11

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    array-length v5, v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    filled-new-array {v6, v8, v5}, [Ljava/lang/Object;

    move-result-object v5

    invoke-static {v0, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    invoke-static {v1, v5}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v6

    if-eqz v6, :cond_f

    const/4 v6, 0x0

    invoke-static {v1, v0, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_9

    :goto_b
    const-string v0, "Could not find resources: %d %d %d"

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    filled-new-array {v6, v8, v5}, [Ljava/lang/Object;

    move-result-object v5

    invoke-static {v0, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    invoke-static {v1, v5}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v6

    if-eqz v6, :cond_10

    const/4 v6, 0x0

    invoke-static {v1, v0, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_c
    const-string v0, "Mapping file ID is: "

    invoke-static {v0, v7}, Lq3/h;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v5}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v8

    if-eqz v8, :cond_11

    invoke-static {v1, v0, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_11
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v5, 0x0

    :goto_d
    if-ge v5, v0, :cond_13

    invoke-virtual {v9, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    add-int/lit8 v5, v5, 0x1

    check-cast v6, Lj5/c;

    iget-object v8, v6, Lj5/c;->a:Ljava/lang/String;

    iget-object v10, v6, Lj5/c;->b:Ljava/lang/String;

    iget-object v6, v6, Lj5/c;->c:Ljava/lang/String;

    const-string v11, "Build id for "

    const-string v12, " on "

    move/from16 v22, v0

    const-string v0, ": "

    invoke-static {v11, v8, v12, v10, v0}, Lcom/google/android/gms/internal/measurement/q1;->r(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    invoke-static {v1, v6}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v8

    if-eqz v8, :cond_12

    const/4 v8, 0x0

    invoke-static {v1, v0, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_e

    :cond_12
    const/4 v8, 0x0

    :goto_e
    move/from16 v0, v22

    goto :goto_d

    :cond_13
    const/4 v6, 0x3

    const/4 v8, 0x0

    new-instance v0, LP2/w;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v4, v0, LP2/w;->t:Ljava/lang/Object;

    iput-object v8, v0, LP2/w;->u:Ljava/lang/Object;

    :try_start_2
    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual/range {v31 .. v31}, Lj5/v;->d()Ljava/lang/String;

    move-result-object v26

    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v8

    const/4 v10, 0x0

    invoke-virtual {v8, v5, v10}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v8

    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v11, 0x1c

    if-lt v10, v11, :cond_14

    invoke-static {v8}, LT/Q;->d(Landroid/content/pm/PackageInfo;)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v10

    :goto_f
    move-object/from16 v28, v10

    goto :goto_10

    :cond_14
    iget v10, v8, Landroid/content/pm/PackageInfo;->versionCode:I

    invoke-static {v10}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v10

    goto :goto_f

    :goto_10
    iget-object v8, v8, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    if-nez v8, :cond_15

    const-string v8, "0.0"

    :cond_15
    move-object v11, v8

    new-instance v36, LH2/x;

    move-object/from16 v30, v0

    move-object/from16 v27, v5

    move-object/from16 v24, v7

    move-object/from16 v25, v9

    move-object/from16 v29, v11

    move-object/from16 v22, v36

    invoke-direct/range {v22 .. v30}, LH2/x;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LP2/w;)V
    :try_end_2
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_2 .. :try_end_2} :catch_3

    move-object/from16 v36, v22

    move-object/from16 v5, v23

    move-object/from16 v0, v26

    move-object/from16 v12, v28

    move-object/from16 v11, v29

    const-string v7, "Installer package name is: "

    invoke-static {v7, v0}, Lq3/h;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    invoke-static {v1, v7}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v8

    if-eqz v8, :cond_16

    const/4 v8, 0x0

    invoke-static {v1, v0, v8}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_16
    new-instance v0, LS1/e;

    const/16 v8, 0x10

    invoke-direct {v0, v8}, LS1/e;-><init>(I)V

    invoke-virtual/range {v31 .. v31}, Lj5/v;->d()Ljava/lang/String;

    move-result-object v8

    new-instance v9, LS1/e;

    const/16 v10, 0xc

    invoke-direct {v9, v10}, LS1/e;-><init>(I)V

    new-instance v10, Lr5/a;

    const/4 v6, 0x1

    invoke-direct {v10, v6, v9}, Lr5/a;-><init>(ILjava/lang/Object;)V

    new-instance v6, Lr5/a;

    invoke-direct {v6, v13}, Lr5/a;-><init>(Lp5/c;)V

    sget-object v13, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v13, "https://firebase-settings.crashlytics.com/spi/v2/platforms/android/gmp/"

    const-string v7, "/settings"

    invoke-static {v13, v5, v7}, Lq3/h;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-instance v13, LO1/r;

    invoke-direct {v13, v7, v0}, LO1/r;-><init>(Ljava/lang/String;LS1/e;)V

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    sget-object v7, Lj5/v;->h:Ljava/lang/String;

    move-object/from16 v23, v6

    const-string v6, ""

    invoke-virtual {v0, v7, v6}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v6, Landroid/os/Build;->MODEL:Ljava/lang/String;

    move-object/from16 v24, v8

    const-string v8, ""

    invoke-virtual {v6, v7, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v8, "/"

    invoke-static {v0, v8, v6}, Lcom/google/android/gms/internal/measurement/q1;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    sget-object v0, Landroid/os/Build$VERSION;->INCREMENTAL:Ljava/lang/String;

    const-string v8, ""

    invoke-virtual {v0, v7, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v8, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    move-object/from16 v25, v0

    const-string v0, ""

    invoke-virtual {v8, v7, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v0, "com.google.firebase.crashlytics.mapping_file_id"

    const-string v7, "string"

    invoke-static {v4, v0, v7}, Lj5/f;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_17

    const-string v0, "com.crashlytics.android.build_id"

    invoke-static {v4, v0, v7}, Lj5/f;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    :cond_17
    if-eqz v0, :cond_18

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_11

    :cond_18
    const/4 v0, 0x0

    :goto_11
    filled-new-array {v0, v5, v11, v12}, [Ljava/lang/String;

    move-result-object v0

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v26, v0

    move-object/from16 v27, v4

    const/4 v0, 0x0

    :goto_12
    const/4 v4, 0x4

    if-ge v0, v4, :cond_1a

    aget-object v4, v26, v0

    move/from16 v28, v0

    if-eqz v4, :cond_19

    const-string v0, "-"

    invoke-virtual {v4, v0, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v0, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_19
    add-int/lit8 v0, v28, 0x1

    goto :goto_12

    :cond_1a
    invoke-static {v7}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v4

    move-object/from16 v28, v5

    const/4 v5, 0x0

    :goto_13
    if-ge v5, v4, :cond_1b

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v29

    add-int/lit8 v5, v5, 0x1

    move/from16 v30, v4

    move-object/from16 v4, v29

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move/from16 v4, v30

    goto :goto_13

    :cond_1b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_1c

    invoke-static {v0}, Lj5/f;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v48, v10

    move-object v10, v0

    move-object/from16 v0, v48

    goto :goto_14

    :cond_1c
    move-object v0, v10

    const/4 v10, 0x0

    :goto_14
    if-eqz v24, :cond_1d

    const/16 v26, 0x4

    goto :goto_15

    :cond_1d
    const/16 v26, 0x1

    :goto_15
    invoke-static/range {v26 .. v26}, Lcom/google/android/gms/internal/measurement/q1;->c(I)I

    move-result v4

    move-object v5, v13

    move v13, v4

    new-instance v4, Lr5/d;

    move-object/from16 v24, v1

    move-object/from16 v19, v14

    move-object/from16 v47, v16

    move-object/from16 v14, v23

    move-object/from16 v7, v25

    move-object/from16 v1, v27

    move-object/from16 v22, v36

    move-object/from16 v16, v2

    move-object/from16 v23, v3

    move-object v3, v5

    move-object/from16 v5, v28

    move-object v2, v0

    move-object v0, v9

    move-object/from16 v9, v31

    invoke-direct/range {v4 .. v13}, Lr5/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lj5/v;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    new-instance v5, Lcom/google/android/gms/internal/consent_sdk/b;

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    new-instance v6, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v6}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    iput-object v6, v5, Lcom/google/android/gms/internal/consent_sdk/b;->h:Ljava/lang/Object;

    new-instance v7, Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v8, LO4/h;

    invoke-direct {v8}, LO4/h;-><init>()V

    invoke-direct {v7, v8}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object v7, v5, Lcom/google/android/gms/internal/consent_sdk/b;->i:Ljava/lang/Object;

    iput-object v1, v5, Lcom/google/android/gms/internal/consent_sdk/b;->a:Ljava/lang/Object;

    iput-object v4, v5, Lcom/google/android/gms/internal/consent_sdk/b;->b:Ljava/lang/Object;

    iput-object v0, v5, Lcom/google/android/gms/internal/consent_sdk/b;->d:Ljava/lang/Object;

    iput-object v2, v5, Lcom/google/android/gms/internal/consent_sdk/b;->c:Ljava/lang/Object;

    iput-object v14, v5, Lcom/google/android/gms/internal/consent_sdk/b;->e:Ljava/lang/Object;

    iput-object v3, v5, Lcom/google/android/gms/internal/consent_sdk/b;->f:Ljava/lang/Object;

    iput-object v15, v5, Lcom/google/android/gms/internal/consent_sdk/b;->g:Ljava/lang/Object;

    invoke-static {v0}, LS6/b;->p(LS1/e;)Lr5/b;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    iget-object v0, v5, Lcom/google/android/gms/internal/consent_sdk/b;->i:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v1, v5, Lcom/google/android/gms/internal/consent_sdk/b;->h:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v2, v5, Lcom/google/android/gms/internal/consent_sdk/b;->a:Ljava/lang/Object;

    check-cast v2, Landroid/content/Context;

    const-string v3, "com.google.firebase.crashlytics"

    const/4 v10, 0x0

    invoke-virtual {v2, v3, v10}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v3, "existing_instance_identifier"

    move-object/from16 v4, v23

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-object v3, v5, Lcom/google/android/gms/internal/consent_sdk/b;->b:Ljava/lang/Object;

    check-cast v3, Lr5/d;

    iget-object v3, v3, Lr5/d;->f:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lcom/google/android/gms/internal/consent_sdk/b;->a(I)Lr5/b;

    move-result-object v2

    if-eqz v2, :cond_1e

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LO4/h;

    invoke-virtual {v0, v2}, LO4/h;->d(Ljava/lang/Object;)V

    const/4 v6, 0x0

    invoke-static {v6}, LE4/j4;->e(Ljava/lang/Object;)LO4/o;

    move-result-object v0

    const/4 v6, 0x3

    goto :goto_16

    :cond_1e
    const/4 v6, 0x3

    invoke-virtual {v5, v6}, Lcom/google/android/gms/internal/consent_sdk/b;->a(I)Lr5/b;

    move-result-object v2

    if-eqz v2, :cond_1f

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LO4/h;

    invoke-virtual {v0, v2}, LO4/h;->d(Ljava/lang/Object;)V

    :cond_1f
    iget-object v0, v5, Lcom/google/android/gms/internal/consent_sdk/b;->g:Ljava/lang/Object;

    check-cast v0, LV3/q;

    iget-object v1, v0, LV3/q;->y:Ljava/lang/Object;

    check-cast v1, LO4/h;

    iget-object v1, v1, LO4/h;->a:LO4/o;

    iget-object v2, v0, LV3/q;->v:Ljava/lang/Object;

    monitor-enter v2

    :try_start_3
    iget-object v0, v0, LV3/q;->w:Ljava/lang/Object;

    check-cast v0, LO4/h;

    iget-object v0, v0, LO4/h;->a:LO4/o;

    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    invoke-static {v1, v0}, Lk5/a;->a(LO4/o;LO4/o;)LO4/o;

    move-result-object v0

    move-object/from16 v14, v19

    iget-object v1, v14, Lk5/c;->a:Lk5/b;

    new-instance v2, LR/p;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    iput-object v5, v2, LR/p;->u:Ljava/lang/Object;

    iput-object v14, v2, LR/p;->t:Ljava/lang/Object;

    invoke-virtual {v0, v1, v2}, LO4/o;->k(Ljava/util/concurrent/Executor;LO4/g;)LO4/o;

    move-result-object v0

    :goto_16
    new-instance v1, Le5/h;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, Le5/h;-><init>(I)V

    move-object/from16 v2, v16

    invoke-virtual {v0, v2, v1}, LO4/o;->c(Ljava/util/concurrent/Executor;LO4/d;)V

    move-object/from16 v1, v47

    iget-object v0, v1, Lj5/p;->i:Lp5/c;

    const-string v2, "The Crashlytics build ID is missing. This occurs when the Crashlytics Gradle plugin is missing from your app\'s build configuration. Please review the Firebase Crashlytics onboarding instructions at https://firebase.google.com/docs/crashlytics/get-started?platform=android#add-plugin"

    iget-object v3, v1, Lj5/p;->a:Landroid/content/Context;

    const-string v4, "com.crashlytics.RequireBuildId"

    if-eqz v3, :cond_21

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    if-eqz v7, :cond_21

    const-string v8, "bool"

    invoke-static {v3, v4, v8}, Lj5/f;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v8

    if-lez v8, :cond_20

    invoke-virtual {v7, v8}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v4

    :goto_17
    move-object/from16 v7, v22

    goto :goto_18

    :cond_20
    const-string v7, "string"

    invoke-static {v3, v4, v7}, Lj5/f;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    if-lez v4, :cond_21

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v4

    goto :goto_17

    :cond_21
    move-object/from16 v7, v22

    const/4 v4, 0x1

    :goto_18
    iget-object v8, v7, LH2/x;->v:Ljava/lang/Object;

    check-cast v8, Ljava/lang/String;

    const-string v9, "."

    const-string v10, ".     |  |"

    if-nez v4, :cond_22

    const-string v2, "Configured not to require a build ID."

    move-object/from16 v4, v24

    const/4 v11, 0x2

    invoke-static {v4, v11}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v8

    if-eqz v8, :cond_23

    const/4 v8, 0x0

    invoke-static {v4, v2, v8}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_19

    :cond_22
    move-object/from16 v4, v24

    const/4 v11, 0x2

    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_28

    :cond_23
    :goto_19
    new-instance v2, Lj5/d;

    invoke-direct {v2}, Lj5/d;-><init>()V

    iget-object v2, v2, Lj5/d;->a:Ljava/lang/String;

    :try_start_4
    new-instance v8, LP2/c;

    const-string v9, "crash_marker"

    const/16 v10, 0x9

    invoke-direct {v8, v10, v9, v0}, LP2/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    iput-object v8, v1, Lj5/p;->f:LP2/c;

    new-instance v8, LP2/c;

    const-string v9, "initialization_marker"

    invoke-direct {v8, v10, v9, v0}, LP2/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    iput-object v8, v1, Lj5/p;->e:LP2/c;

    new-instance v8, Lp5/c;

    move-object/from16 v9, v32

    invoke-direct {v8, v2, v0, v9}, Lp5/c;-><init>(Ljava/lang/String;Lp5/c;Lk5/c;)V

    new-instance v10, Ll5/f;

    invoke-direct {v10, v0}, Ll5/f;-><init>(Lp5/c;)V

    new-instance v0, LP2/e;

    new-instance v12, LS1/j;

    const/16 v13, 0x11

    invoke-direct {v12, v13}, LS1/j;-><init>(I)V

    const/4 v14, 0x1

    new-array v14, v14, [Ls5/a;

    const/16 v21, 0x0

    aput-object v12, v14, v21

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v14, v0, LP2/e;->t:Ljava/lang/Object;

    new-instance v12, LS1/e;

    invoke-direct {v12, v13}, LS1/e;-><init>(I)V

    iput-object v12, v0, LP2/e;->u:Ljava/lang/Object;

    iget-object v12, v1, Lj5/p;->n:LW2/g;

    iget-object v12, v12, LW2/g;->u:Ljava/lang/Object;

    check-cast v12, Ld5/o;

    new-instance v13, Le5/h;

    invoke-direct {v13, v11}, Le5/h;-><init>(I)V

    invoke-virtual {v12, v13}, Ld5/o;->a(LC5/a;)V

    iget-object v12, v1, Lj5/p;->a:Landroid/content/Context;

    iget-object v13, v1, Lj5/p;->h:Lj5/v;

    iget-object v14, v1, Lj5/p;->i:Lp5/c;

    iget-object v15, v1, Lj5/p;->c:LP2/e;

    iget-object v6, v1, Lj5/p;->l:Lj5/i;

    iget-object v11, v1, Lj5/p;->o:Lk5/c;

    move-object/from16 v39, v0

    move-object/from16 v40, v5

    move-object/from16 v42, v6

    move-object/from16 v36, v7

    move-object/from16 v38, v8

    move-object/from16 v37, v10

    move-object/from16 v43, v11

    move-object/from16 v33, v12

    move-object/from16 v34, v13

    move-object/from16 v35, v14

    move-object/from16 v41, v15

    invoke-static/range {v33 .. v43}, Lp5/c;->f(Landroid/content/Context;Lj5/v;Lp5/c;LH2/x;Ll5/f;Lp5/c;LP2/e;Lcom/google/android/gms/internal/consent_sdk/b;LP2/e;Lj5/i;Lk5/c;)Lp5/c;

    move-result-object v42

    move-object/from16 v0, v40

    new-instance v33, Lj5/l;

    iget-object v5, v1, Lj5/p;->a:Landroid/content/Context;

    iget-object v6, v1, Lj5/p;->h:Lj5/v;

    iget-object v7, v1, Lj5/p;->b:LV3/q;

    iget-object v8, v1, Lj5/p;->i:Lp5/c;

    iget-object v10, v1, Lj5/p;->f:LP2/c;

    iget-object v11, v1, Lj5/p;->m:Lg5/a;

    iget-object v12, v1, Lj5/p;->k:Lf5/a;

    iget-object v13, v1, Lj5/p;->l:Lj5/i;

    iget-object v14, v1, Lj5/p;->o:Lk5/c;

    move-object/from16 v34, v5

    move-object/from16 v35, v6

    move-object/from16 v43, v11

    move-object/from16 v44, v12

    move-object/from16 v45, v13

    move-object/from16 v46, v14

    move-object/from16 v39, v36

    move-object/from16 v41, v37

    move-object/from16 v40, v38

    move-object/from16 v36, v7

    move-object/from16 v37, v8

    move-object/from16 v38, v10

    invoke-direct/range {v33 .. v46}, Lj5/l;-><init>(Landroid/content/Context;Lj5/v;LV3/q;Lp5/c;LP2/c;LH2/x;Lp5/c;Ll5/f;Lp5/c;Lg5/a;Lh5/a;Lj5/i;Lk5/c;)V

    move-object/from16 v5, v33

    iput-object v5, v1, Lj5/p;->g:Lj5/l;

    iget-object v5, v1, Lj5/p;->e:LP2/c;

    iget-object v6, v5, LP2/c;->v:Ljava/lang/Object;

    check-cast v6, Lp5/c;

    iget-object v5, v5, LP2/c;->u:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v7, Ljava/io/File;

    iget-object v6, v6, Lp5/c;->v:Ljava/lang/Object;

    check-cast v6, Ljava/io/File;

    invoke-direct {v7, v6, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v7}, Ljava/io/File;->exists()Z

    move-result v5

    iget-object v6, v9, Lk5/c;->a:Lk5/b;

    iget-object v6, v6, Lk5/b;->t:Ljava/util/concurrent/ExecutorService;

    new-instance v7, LF2/f;

    const/4 v11, 0x2

    invoke-direct {v7, v11, v1}, LF2/f;-><init>(ILjava/lang/Object;)V

    invoke-interface {v6, v7}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v6
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    :try_start_5
    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v10, 0x3

    invoke-interface {v6, v10, v11, v7}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Boolean;
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1

    :try_start_6
    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v7, v6}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    :catch_1
    iget-object v6, v1, Lj5/p;->g:Lj5/l;

    invoke-static {}, Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v7

    iget-object v8, v6, Lj5/l;->e:Lk5/c;

    iget-object v8, v8, Lk5/c;->a:Lk5/b;

    new-instance v10, LE2/d;

    const/16 v11, 0xd

    invoke-direct {v10, v11, v6, v2}, LE2/d;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v8, v10}, Lk5/b;->a(Ljava/lang/Runnable;)LO4/o;

    new-instance v2, LW2/g;

    invoke-direct {v2, v11, v6}, LW2/g;-><init>(ILjava/lang/Object;)V

    new-instance v8, Lj5/r;

    iget-object v10, v6, Lj5/l;->j:Lg5/a;

    invoke-direct {v8, v2, v0, v7, v10}, Lj5/r;-><init>(LW2/g;Lcom/google/android/gms/internal/consent_sdk/b;Ljava/lang/Thread$UncaughtExceptionHandler;Lg5/a;)V

    iput-object v8, v6, Lj5/l;->n:Lj5/r;

    invoke-static {v8}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    if-eqz v5, :cond_26

    const-string v2, "android.permission.ACCESS_NETWORK_STATE"

    invoke-virtual {v3, v2}, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-nez v2, :cond_24

    const-string v2, "connectivity"

    invoke-virtual {v3, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/net/ConnectivityManager;

    invoke-virtual {v2}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v2

    if-eqz v2, :cond_26

    invoke-virtual {v2}, Landroid/net/NetworkInfo;->isConnectedOrConnecting()Z

    move-result v2

    if-eqz v2, :cond_26

    :cond_24
    const-string v2, "Crashlytics did not finish previous background initialization. Initializing synchronously."

    const/4 v5, 0x3

    invoke-static {v4, v5}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v3

    if-eqz v3, :cond_25

    const/4 v6, 0x0

    invoke-static {v4, v2, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_25
    invoke-virtual {v1, v0}, Lj5/p;->b(Lcom/google/android/gms/internal/consent_sdk/b;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2

    goto :goto_1b

    :catch_2
    move-exception v0

    goto :goto_1a

    :cond_26
    const-string v2, "Successfully configured exception handler."

    const/4 v5, 0x3

    invoke-static {v4, v5}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v3

    if-eqz v3, :cond_27

    const/4 v6, 0x0

    invoke-static {v4, v2, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_27
    iget-object v2, v9, Lk5/c;->a:Lk5/b;

    new-instance v3, Lj5/m;

    const/4 v10, 0x0

    invoke-direct {v3, v1, v0, v10}, Lj5/m;-><init>(Lj5/p;Lcom/google/android/gms/internal/consent_sdk/b;I)V

    invoke-virtual {v2, v3}, Lk5/b;->a(Ljava/lang/Runnable;)LO4/o;

    goto :goto_1b

    :goto_1a
    const-string v2, "Crashlytics was not started due to an exception during initialization"

    invoke-static {v4, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v6, 0x0

    iput-object v6, v1, Lj5/p;->g:Lj5/l;

    :goto_1b
    new-instance v0, Lf5/b;

    invoke-direct {v0, v1}, Lf5/b;-><init>(Lj5/p;)V

    goto :goto_1c

    :cond_28
    invoke-static {v4, v9}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ".     |  | "

    invoke-static {v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v4, v10}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v4, v10}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ".   \\ |  | /"

    invoke-static {v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ".    \\    /"

    invoke-static {v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ".     \\  /"

    invoke-static {v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ".      \\/"

    invoke-static {v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v4, v9}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v4, v9}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ".      /\\"

    invoke-static {v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ".     /  \\"

    invoke-static {v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ".    /    \\"

    invoke-static {v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ".   / |  | \\"

    invoke-static {v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v4, v10}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v4, v10}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v4, v10}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v4, v9}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :catchall_1
    move-exception v0

    :try_start_7
    monitor-exit v2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    throw v0

    :catch_3
    move-exception v0

    move-object v4, v1

    const-string v1, "Error retrieving app package info."

    invoke-static {v4, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v0, 0x0

    :goto_1c
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    sub-long v1, v1, v17

    const-wide/16 v5, 0x10

    cmp-long v3, v1, v5

    if-lez v3, :cond_29

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v5, "Initializing Crashlytics blocked main for "

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, " ms"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    invoke-static {v4, v5}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v2

    if-eqz v2, :cond_29

    const/4 v6, 0x0

    invoke-static {v4, v1, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_29
    return-object v0

    :goto_1d
    :try_start_8
    monitor-exit v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    throw v0

    :sswitch_0
    move-object v2, v1

    iget-object v0, v2, LA3/b;->u:Ljava/lang/Object;

    return-object v0

    :sswitch_1
    move-object v2, v1

    iget-object v1, v2, LA3/b;->u:Ljava/lang/Object;

    check-cast v1, Ld5/q;

    new-instance v3, LB5/d;

    const-class v4, Landroid/content/Context;

    invoke-virtual {v0, v4}, LT3/o;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/content/Context;

    const-class v5, LY4/f;

    invoke-virtual {v0, v5}, LT3/o;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LY4/f;

    invoke-virtual {v5}, LY4/f;->c()Ljava/lang/String;

    move-result-object v5

    const-class v6, LB5/e;

    invoke-static {v6}, Ld5/q;->a(Ljava/lang/Class;)Ld5/q;

    move-result-object v6

    invoke-virtual {v0, v6}, LT3/o;->c(Ld5/q;)Ljava/util/Set;

    move-result-object v6

    const-class v7, LI5/b;

    invoke-virtual {v0, v7}, LT3/o;->e(Ljava/lang/Class;)LC5/b;

    move-result-object v7

    invoke-virtual {v0, v1}, LT3/o;->f(Ld5/q;)Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Ljava/util/concurrent/Executor;

    invoke-direct/range {v3 .. v8}, LB5/d;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;LC5/b;Ljava/util/concurrent/Executor;)V

    return-object v3

    nop

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x9 -> :sswitch_0
    .end sparse-switch
.end method

.method public g(LO4/o;)Ljava/lang/Object;
    .locals 0

    iget p1, p0, LA3/b;->t:I

    packed-switch p1, :pswitch_data_0

    :pswitch_0
    iget-object p1, p0, LA3/b;->u:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Runnable;

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    const/4 p1, 0x0

    invoke-static {p1}, LE4/j4;->e(Ljava/lang/Object;)LO4/o;

    move-result-object p1

    return-object p1

    :pswitch_1
    iget-object p1, p0, LA3/b;->u:Ljava/lang/Object;

    check-cast p1, Lj5/j;

    invoke-virtual {p1}, Lj5/j;->call()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LO4/o;

    return-object p1

    :pswitch_2
    iget-object p1, p0, LA3/b;->u:Ljava/lang/Object;

    check-cast p1, Ljava/util/concurrent/CountDownLatch;

    invoke-virtual {p1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 p1, 0x0

    return-object p1

    :pswitch_data_0
    .packed-switch 0xd
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public h(LS7/h;)Lw2/c;
    .locals 7

    iget-object v0, p0, LA3/b;->u:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Landroid/content/Context;

    iget-object v0, p1, LS7/h;->w:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Ljava/lang/String;

    iget-object p1, p1, LS7/h;->y:Ljava/lang/Object;

    move-object v4, p1

    check-cast v4, Lcom/google/android/gms/internal/ads/cr;

    const-string p1, "callback"

    invoke-static {v4, p1}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result p1

    if-eqz p1, :cond_0

    new-instance v1, Lx2/g;

    const/4 v5, 0x1

    move v6, v5

    invoke-direct/range {v1 .. v6}, Lx2/g;-><init>(Landroid/content/Context;Ljava/lang/String;Lcom/google/android/gms/internal/ads/cr;ZZ)V

    return-object v1

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Must set a non-null database name to a configuration that uses the no backup directory."

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public i()V
    .locals 9

    iget-object v0, p0, LA3/b;->u:Ljava/lang/Object;

    check-cast v0, Lr7/e;

    sget-object v1, Lk0/l;->c:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    sget-object v2, Lk0/l;->h:Ljava/lang/Object;

    const-string v3, "<this>"

    invoke-static {v2, v3}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v3, Ljava/util/ArrayList;

    const/16 v4, 0xa

    invoke-static {v2, v4}, Le7/n;->l(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v4, 0x0

    move v5, v4

    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v7, 0x1

    if-nez v5, :cond_1

    invoke-static {v6, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    move v5, v7

    move v7, v4

    :cond_1
    if-eqz v7, :cond_0

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    sput-object v3, Lk0/l;->h:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-void

    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public j(Lo1/h;)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, LA3/b;->u:Ljava/lang/Object;

    check-cast v0, LD7/B;

    new-instance v1, LF0/A;

    const/16 v2, 0x15

    invoke-direct {v1, v2, p1, v0}, LF0/A;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, LD7/k0;->a0(Lr7/c;)LD7/K;

    const-string p1, "Deferred.asListenableFuture"

    return-object p1
.end method
