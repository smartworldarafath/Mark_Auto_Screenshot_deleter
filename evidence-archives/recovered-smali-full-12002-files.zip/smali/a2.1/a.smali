.class public final La2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/AutoCloseable;
.implements LD7/v;


# instance fields
.field public final t:Lh7/h;


# direct methods
.method public constructor <init>(Lh7/h;)V
    .locals 1

    const-string v0, "coroutineContext"

    invoke-static {p1, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La2/a;->t:Lh7/h;

    return-void
.end method


# virtual methods
.method public final N()Lh7/h;
    .locals 1

    iget-object v0, p0, La2/a;->t:Lh7/h;

    return-object v0
.end method

.method public final close()V
    .locals 2

    iget-object v0, p0, La2/a;->t:Lh7/h;

    const/4 v1, 0x0

    invoke-static {v0, v1}, LD7/y;->h(Lh7/h;Ljava/util/concurrent/CancellationException;)V

    return-void
.end method
