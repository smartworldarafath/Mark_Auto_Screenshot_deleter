.class public final La2/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/c0;


# static fields
.field public static final a:La2/b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La2/b;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La2/b;->a:La2/b;

    return-void
.end method


# virtual methods
.method public final c(Ls7/e;LY1/d;)Landroidx/lifecycle/a0;
    .locals 0

    invoke-static {p1}, LH4/L4;->a(Ly7/b;)Ljava/lang/Class;

    move-result-object p1

    invoke-static {p1}, LF4/j5;->a(Ljava/lang/Class;)Landroidx/lifecycle/a0;

    move-result-object p1

    return-object p1
.end method
