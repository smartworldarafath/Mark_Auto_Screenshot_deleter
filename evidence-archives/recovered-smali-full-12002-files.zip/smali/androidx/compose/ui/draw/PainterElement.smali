.class final Landroidx/compose/ui/draw/PainterElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Ly0/b;

.field public final b:Lm0/e;

.field public final c:LJ0/S;

.field public final d:F

.field public final e:Lt0/k;


# direct methods
.method public constructor <init>(Ly0/b;Lm0/e;LJ0/S;FLt0/k;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/ui/draw/PainterElement;->a:Ly0/b;

    iput-object p2, p0, Landroidx/compose/ui/draw/PainterElement;->b:Lm0/e;

    iput-object p3, p0, Landroidx/compose/ui/draw/PainterElement;->c:LJ0/S;

    iput p4, p0, Landroidx/compose/ui/draw/PainterElement;->d:F

    iput-object p5, p0, Landroidx/compose/ui/draw/PainterElement;->e:Lt0/k;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    if-ne p0, p1, :cond_0

    goto :goto_1

    :cond_0
    instance-of v0, p1, Landroidx/compose/ui/draw/PainterElement;

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    check-cast p1, Landroidx/compose/ui/draw/PainterElement;

    iget-object v0, p0, Landroidx/compose/ui/draw/PainterElement;->a:Ly0/b;

    iget-object v1, p1, Landroidx/compose/ui/draw/PainterElement;->a:Ly0/b;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    iget-object v0, p0, Landroidx/compose/ui/draw/PainterElement;->b:Lm0/e;

    iget-object v1, p1, Landroidx/compose/ui/draw/PainterElement;->b:Lm0/e;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    :cond_3
    iget-object v0, p0, Landroidx/compose/ui/draw/PainterElement;->c:LJ0/S;

    iget-object v1, p1, Landroidx/compose/ui/draw/PainterElement;->c:LJ0/S;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_0

    :cond_4
    iget v0, p0, Landroidx/compose/ui/draw/PainterElement;->d:F

    iget v1, p1, Landroidx/compose/ui/draw/PainterElement;->d:F

    invoke-static {v0, v1}, Ljava/lang/Float;->compare(FF)I

    move-result v0

    if-eqz v0, :cond_5

    goto :goto_0

    :cond_5
    iget-object v0, p0, Landroidx/compose/ui/draw/PainterElement;->e:Lt0/k;

    iget-object p1, p1, Landroidx/compose/ui/draw/PainterElement;->e:Lt0/k;

    invoke-static {v0, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6

    :goto_0
    const/4 p1, 0x0

    return p1

    :cond_6
    :goto_1
    const/4 p1, 0x1

    return p1
.end method

.method public final g()Lm0/q;
    .locals 2

    new-instance v0, Lq0/g;

    invoke-direct {v0}, Lm0/q;-><init>()V

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->a:Ly0/b;

    iput-object v1, v0, Lq0/g;->H:Ly0/b;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lq0/g;->I:Z

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->b:Lm0/e;

    iput-object v1, v0, Lq0/g;->J:Lm0/e;

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->c:LJ0/S;

    iput-object v1, v0, Lq0/g;->K:LJ0/S;

    iget v1, p0, Landroidx/compose/ui/draw/PainterElement;->d:F

    iput v1, v0, Lq0/g;->L:F

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->e:Lt0/k;

    iput-object v1, v0, Lq0/g;->M:Lt0/k;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 7

    check-cast p1, Lq0/g;

    iget-boolean v0, p1, Lq0/g;->I:Z

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->a:Ly0/b;

    const/4 v2, 0x1

    if-ne v0, v2, :cond_1

    iget-object v0, p1, Lq0/g;->H:Ly0/b;

    invoke-virtual {v0}, Ly0/b;->h()J

    move-result-wide v3

    invoke-virtual {v1}, Ly0/b;->h()J

    move-result-wide v5

    invoke-static {v3, v4, v5, v6}, Ls0/e;->a(JJ)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    move v0, v2

    :goto_1
    iput-object v1, p1, Lq0/g;->H:Ly0/b;

    iput-boolean v2, p1, Lq0/g;->I:Z

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->b:Lm0/e;

    iput-object v1, p1, Lq0/g;->J:Lm0/e;

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->c:LJ0/S;

    iput-object v1, p1, Lq0/g;->K:LJ0/S;

    iget v1, p0, Landroidx/compose/ui/draw/PainterElement;->d:F

    iput v1, p1, Lq0/g;->L:F

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->e:Lt0/k;

    iput-object v1, p1, Lq0/g;->M:Lt0/k;

    if-eqz v0, :cond_2

    invoke-static {p1}, LL0/f;->m(LL0/z;)V

    :cond_2
    invoke-static {p1}, LL0/f;->l(LL0/o;)V

    return-void
.end method

.method public final hashCode()I
    .locals 3

    iget-object v0, p0, Landroidx/compose/ui/draw/PainterElement;->a:Ly0/b;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Lq3/h;->e(IIZ)I

    move-result v0

    iget-object v2, p0, Landroidx/compose/ui/draw/PainterElement;->b:Lm0/e;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v2, v0

    mul-int/2addr v2, v1

    iget-object v0, p0, Landroidx/compose/ui/draw/PainterElement;->c:LJ0/S;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget v2, p0, Landroidx/compose/ui/draw/PainterElement;->d:F

    invoke-static {v2, v0, v1}, Lq3/h;->b(FII)I

    move-result v0

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->e:Lt0/k;

    if-nez v1, :cond_0

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_0
    add-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "PainterElement(painter="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->a:Ly0/b;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", sizeToIntrinsics=true, alignment="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->b:Lm0/e;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", contentScale="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->c:LJ0/S;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", alpha="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/compose/ui/draw/PainterElement;->d:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, ", colorFilter="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/ui/draw/PainterElement;->e:Lt0/k;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
