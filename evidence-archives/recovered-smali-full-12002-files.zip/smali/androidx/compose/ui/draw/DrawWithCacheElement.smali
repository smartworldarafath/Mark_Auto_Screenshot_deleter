.class final Landroidx/compose/ui/draw/DrawWithCacheElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Lr7/c;


# direct methods
.method public constructor <init>(Lr7/c;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/ui/draw/DrawWithCacheElement;->a:Lr7/c;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Landroidx/compose/ui/draw/DrawWithCacheElement;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Landroidx/compose/ui/draw/DrawWithCacheElement;

    iget-object p1, p1, Landroidx/compose/ui/draw/DrawWithCacheElement;->a:Lr7/c;

    iget-object v1, p0, Landroidx/compose/ui/draw/DrawWithCacheElement;->a:Lr7/c;

    if-eq v1, p1, :cond_2

    return v2

    :cond_2
    return v0
.end method

.method public final g()Lm0/q;
    .locals 3

    new-instance v0, Lq0/b;

    new-instance v1, Lq0/c;

    invoke-direct {v1}, Lq0/c;-><init>()V

    iget-object v2, p0, Landroidx/compose/ui/draw/DrawWithCacheElement;->a:Lr7/c;

    invoke-direct {v0, v1, v2}, Lq0/b;-><init>(Lq0/c;Lr7/c;)V

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 1

    check-cast p1, Lq0/b;

    iget-object v0, p0, Landroidx/compose/ui/draw/DrawWithCacheElement;->a:Lr7/c;

    iput-object v0, p1, Lq0/b;->J:Lr7/c;

    invoke-virtual {p1}, Lq0/b;->K0()V

    return-void
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, Landroidx/compose/ui/draw/DrawWithCacheElement;->a:Lr7/c;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method
