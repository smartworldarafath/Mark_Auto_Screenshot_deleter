.class final Landroidx/compose/ui/input/rotary/RotaryInputElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Landroidx/compose/ui/input/rotary/RotaryInputElement;

    if-nez v1, :cond_1

    const/4 p1, 0x0

    return p1

    :cond_1
    check-cast p1, Landroidx/compose/ui/input/rotary/RotaryInputElement;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return v0
.end method

.method public final g()Lm0/q;
    .locals 2

    new-instance v0, LH0/a;

    sget-object v1, LM0/p;->x:LM0/p;

    invoke-direct {v0}, Lm0/q;-><init>()V

    iput-object v1, v0, LH0/a;->H:LM0/p;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 1

    check-cast p1, LH0/a;

    sget-object v0, LM0/p;->x:LM0/p;

    iput-object v0, p1, LH0/a;->H:LM0/p;

    return-void
.end method

.method public final hashCode()I
    .locals 1

    sget-object v0, LM0/p;->x:LM0/p;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    return v0
.end method
