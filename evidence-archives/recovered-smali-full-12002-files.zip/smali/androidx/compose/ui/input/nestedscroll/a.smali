.class public abstract Landroidx/compose/ui/input/nestedscroll/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Lm0/r;LE0/a;LE0/e;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;

    invoke-direct {v0, p1, p2}, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;-><init>(LE0/a;LE0/e;)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method
