.class final Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:LE0/a;

.field public final b:LE0/e;


# direct methods
.method public constructor <init>(LE0/a;LE0/e;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->a:LE0/a;

    iput-object p2, p0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->b:LE0/e;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    instance-of v0, p1, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;

    iget-object v0, p1, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->a:LE0/a;

    iget-object v2, p0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->a:LE0/a;

    invoke-static {v0, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    return v1

    :cond_1
    iget-object p1, p1, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->b:LE0/e;

    iget-object v0, p0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->b:LE0/e;

    invoke-static {p1, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_2

    return v1

    :cond_2
    const/4 p1, 0x1

    return p1
.end method

.method public final g()Lm0/q;
    .locals 3

    new-instance v0, LE0/h;

    iget-object v1, p0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->a:LE0/a;

    iget-object v2, p0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->b:LE0/e;

    invoke-direct {v0, v1, v2}, LE0/h;-><init>(LE0/a;LE0/e;)V

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 3

    check-cast p1, LE0/h;

    iget-object v0, p0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->a:LE0/a;

    iput-object v0, p1, LE0/h;->H:LE0/a;

    iget-object v0, p1, LE0/h;->I:LE0/e;

    iget-object v1, v0, LE0/e;->a:LE0/h;

    const/4 v2, 0x0

    if-ne v1, p1, :cond_0

    iput-object v2, v0, LE0/e;->a:LE0/h;

    :cond_0
    iget-object v1, p0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->b:LE0/e;

    if-nez v1, :cond_1

    new-instance v0, LE0/e;

    invoke-direct {v0}, LE0/e;-><init>()V

    iput-object v0, p1, LE0/h;->I:LE0/e;

    goto :goto_0

    :cond_1
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    iput-object v1, p1, LE0/h;->I:LE0/e;

    :cond_2
    :goto_0
    iget-boolean v0, p1, Lm0/q;->G:Z

    if-eqz v0, :cond_3

    iget-object v0, p1, LE0/h;->I:LE0/e;

    iput-object p1, v0, LE0/e;->a:LE0/h;

    iput-object v2, v0, LE0/e;->b:LE0/h;

    iput-object v2, p1, LE0/h;->J:LE0/h;

    new-instance v1, LE0/b;

    const/4 v2, 0x1

    invoke-direct {v1, v2, p1}, LE0/b;-><init>(ILjava/lang/Object;)V

    iput-object v1, v0, LE0/e;->c:Ls7/k;

    invoke-virtual {p1}, Lm0/q;->y0()LD7/v;

    move-result-object p1

    iput-object p1, v0, LE0/e;->d:LD7/v;

    :cond_3
    return-void
.end method

.method public final hashCode()I
    .locals 2

    iget-object v0, p0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->a:LE0/a;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;->b:LE0/e;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    add-int/2addr v0, v1

    return v0
.end method
