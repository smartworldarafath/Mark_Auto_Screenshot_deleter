.class public interface abstract Landroidx/compose/ui/input/pointer/PointerInputEventHandler;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract invoke(LF0/y;Lh7/c;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LF0/y;",
            "Lh7/c;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method
