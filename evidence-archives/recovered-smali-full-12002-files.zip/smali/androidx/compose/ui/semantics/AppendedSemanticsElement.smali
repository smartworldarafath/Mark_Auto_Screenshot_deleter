.class public final Landroidx/compose/ui/semantics/AppendedSemanticsElement;
.super LL0/c0;
.source "SourceFile"

# interfaces
.implements Lm0/p;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;",
        "Lm0/p;"
    }
.end annotation


# instance fields
.field public final a:Z

.field public final b:Lr7/c;


# direct methods
.method public constructor <init>(Lr7/c;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p2, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->a:Z

    iput-object p1, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->b:Lr7/c;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    if-ne p0, p1, :cond_0

    goto :goto_1

    :cond_0
    instance-of v0, p1, Landroidx/compose/ui/semantics/AppendedSemanticsElement;

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    check-cast p1, Landroidx/compose/ui/semantics/AppendedSemanticsElement;

    iget-boolean v0, p1, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->a:Z

    iget-boolean v1, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->a:Z

    if-eq v1, v0, :cond_2

    goto :goto_0

    :cond_2
    iget-object v0, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->b:Lr7/c;

    iget-object p1, p1, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->b:Lr7/c;

    if-eq v0, p1, :cond_3

    :goto_0
    const/4 p1, 0x0

    return p1

    :cond_3
    :goto_1
    const/4 p1, 0x1

    return p1
.end method

.method public final g()Lm0/q;
    .locals 2

    new-instance v0, LT0/c;

    invoke-direct {v0}, Lm0/q;-><init>()V

    iget-boolean v1, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->a:Z

    iput-boolean v1, v0, LT0/c;->H:Z

    iget-object v1, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->b:Lr7/c;

    iput-object v1, v0, LT0/c;->I:Lr7/c;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 1

    check-cast p1, LT0/c;

    iget-boolean v0, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->a:Z

    iput-boolean v0, p1, LT0/c;->H:Z

    iget-object v0, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->b:Lr7/c;

    iput-object v0, p1, LT0/c;->I:Lr7/c;

    return-void
.end method

.method public final hashCode()I
    .locals 2

    iget-boolean v0, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->a:Z

    invoke-static {v0}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;->b:Lr7/c;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method
