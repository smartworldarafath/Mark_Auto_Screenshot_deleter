.class public final Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:La0/B;

.field public static final b:La0/X0;

.field public static final c:La0/B;

.field public static final d:La0/X0;

.field public static final e:La0/X0;

.field public static final f:La0/X0;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    sget-object v0, LM0/N;->v:LM0/N;

    new-instance v1, La0/B;

    invoke-direct {v1, v0}, La0/B;-><init>(Lr7/a;)V

    sput-object v1, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->a:La0/B;

    sget-object v0, LM0/N;->w:LM0/N;

    new-instance v1, La0/X0;

    invoke-direct {v1, v0}, La0/q0;-><init>(Lr7/a;)V

    sput-object v1, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->b:La0/X0;

    sget-object v0, LM0/p;->y:LM0/p;

    new-instance v1, La0/B;

    invoke-direct {v1, v0}, La0/B;-><init>(Lr7/c;)V

    sput-object v1, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->c:La0/B;

    sget-object v0, LM0/N;->x:LM0/N;

    new-instance v1, La0/X0;

    invoke-direct {v1, v0}, La0/q0;-><init>(Lr7/a;)V

    sput-object v1, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->d:La0/X0;

    sget-object v0, LM0/N;->y:LM0/N;

    new-instance v1, La0/X0;

    invoke-direct {v1, v0}, La0/q0;-><init>(Lr7/a;)V

    sput-object v1, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->e:La0/X0;

    sget-object v0, LM0/N;->z:LM0/N;

    new-instance v1, La0/X0;

    invoke-direct {v1, v0}, La0/q0;-><init>(Lr7/a;)V

    sput-object v1, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->f:La0/X0;

    return-void
.end method

.method public static final a(LM0/x;Lr7/e;La0/r;I)V
    .locals 28

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    const v4, -0x1f032317

    invoke-virtual {v2, v4}, La0/r;->X(I)La0/r;

    invoke-virtual {v2, v0}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    :goto_0
    or-int/2addr v4, v3

    invoke-virtual {v2, v1}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    const/16 v6, 0x20

    goto :goto_1

    :cond_1
    const/16 v6, 0x10

    :goto_1
    or-int/2addr v4, v6

    and-int/lit8 v6, v4, 0x13

    const/16 v7, 0x12

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eq v6, v7, :cond_2

    move v6, v9

    goto :goto_2

    :cond_2
    move v6, v8

    :goto_2
    and-int/2addr v4, v9

    invoke-virtual {v2, v4, v6}, La0/r;->N(IZ)Z

    move-result v4

    if-eqz v4, :cond_1a

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v6

    sget-object v7, La0/m;->a:La0/U;

    if-ne v6, v7, :cond_3

    new-instance v6, Landroid/content/res/Configuration;

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    invoke-virtual {v10}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v10

    invoke-direct {v6, v10}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    invoke-static {v6}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v6

    invoke-virtual {v2, v6}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_3
    check-cast v6, La0/Z;

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v10

    if-ne v10, v7, :cond_4

    new-instance v10, LM0/O;

    invoke-direct {v10, v6, v8}, LM0/O;-><init>(La0/Z;I)V

    invoke-virtual {v2, v10}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_4
    check-cast v10, Lr7/c;

    invoke-virtual {v0, v10}, LM0/x;->setConfigurationChangeObserver(Lr7/c;)V

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v10

    if-ne v10, v7, :cond_5

    new-instance v10, LM0/d0;

    invoke-direct {v10, v4}, LM0/d0;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v10}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_5
    check-cast v10, LM0/d0;

    invoke-virtual {v0}, LM0/x;->getViewTreeOwners()LM0/n;

    move-result-object v11

    if-eqz v11, :cond_19

    iget-object v12, v11, LM0/n;->b:Ls2/e;

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v13

    if-ne v13, v7, :cond_a

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v13

    const-string v14, "null cannot be cast to non-null type android.view.View"

    invoke-static {v13, v14}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v13, Landroid/view/View;

    const v14, 0x7f09007b

    invoke-virtual {v13, v14}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v14

    instance-of v15, v14, Ljava/lang/String;

    const/16 v16, 0x0

    if-eqz v15, :cond_6

    check-cast v14, Ljava/lang/String;

    goto :goto_3

    :cond_6
    move-object/from16 v14, v16

    :goto_3
    if-nez v14, :cond_7

    invoke-virtual {v13}, Landroid/view/View;->getId()I

    move-result v13

    invoke-static {v13}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v14

    :cond_7
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-class v15, Lj0/g;

    invoke-virtual {v15}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v15, 0x3a

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-interface {v12}, Ls2/e;->f()Lj6/d;

    move-result-object v14

    invoke-virtual {v14, v13}, Lj6/d;->e(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v15

    if-eqz v15, :cond_9

    new-instance v5, Ljava/util/LinkedHashMap;

    invoke-direct {v5}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual {v15}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v16

    check-cast v16, Ljava/lang/Iterable;

    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_4
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_8

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v9, v17

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v15, v9}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v8

    move-object/from16 v19, v6

    const-string v6, "null cannot be cast to non-null type java.util.ArrayList<kotlin.Any?>"

    invoke-static {v8, v6}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v5, v9, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v6, v19

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto :goto_4

    :cond_8
    :goto_5
    move-object/from16 v19, v6

    goto :goto_6

    :cond_9
    move-object/from16 v5, v16

    goto :goto_5

    :goto_6
    sget-object v6, LM0/p;->z:LM0/p;

    sget-object v8, Lj0/i;->a:La0/X0;

    new-instance v8, Lj0/h;

    invoke-direct {v8, v5, v6}, Lj0/h;-><init>(Ljava/util/Map;Lr7/c;)V

    :try_start_0
    new-instance v5, LM0/u0;

    const/4 v6, 0x0

    invoke-direct {v5, v6, v8}, LM0/u0;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v14, v13, v5}, Lj6/d;->n(Ljava/lang/String;Ls2/d;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x1

    goto :goto_7

    :catch_0
    const/4 v6, 0x0

    :goto_7
    new-instance v5, LM0/t0;

    new-instance v9, LM0/v0;

    invoke-direct {v9, v6, v14, v13}, LM0/v0;-><init>(ZLj6/d;Ljava/lang/String;)V

    invoke-direct {v5, v8, v9}, LM0/t0;-><init>(Lj0/h;LM0/v0;)V

    invoke-virtual {v2, v5}, La0/r;->g0(Ljava/lang/Object;)V

    move-object v13, v5

    goto :goto_8

    :cond_a
    move-object/from16 v19, v6

    :goto_8
    check-cast v13, LM0/t0;

    invoke-virtual {v2, v13}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v5

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v6

    if-nez v5, :cond_b

    if-ne v6, v7, :cond_c

    :cond_b
    new-instance v6, LF0/B;

    const/16 v5, 0x8

    invoke-direct {v6, v5, v13}, LF0/B;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v2, v6}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_c
    check-cast v6, Lr7/c;

    sget-object v5, Ld7/z;->a:Ld7/z;

    invoke-static {v5, v6, v2}, La0/b;->e(Ljava/lang/Object;Lr7/c;La0/r;)V

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v5

    const/4 v6, 0x7

    if-ne v5, v7, :cond_e

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x1f

    if-lt v5, v8, :cond_d

    const-class v5, Landroid/os/Vibrator;

    invoke-virtual {v4, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/os/Vibrator;

    const/4 v8, 0x2

    const/4 v9, 0x1

    filled-new-array {v9, v6, v8}, [I

    move-result-object v8

    invoke-static {v5, v8}, LA1/m0;->v(Landroid/os/Vibrator;[I)Z

    move-result v5

    if-eqz v5, :cond_d

    new-instance v5, LB0/b;

    invoke-virtual {v0}, LM0/x;->getView()Landroid/view/View;

    move-result-object v8

    invoke-direct {v5, v8, v9}, LB0/b;-><init>(Landroid/view/View;I)V

    goto :goto_9

    :cond_d
    new-instance v5, LM0/H0;

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    :goto_9
    invoke-virtual {v2, v5}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_e
    check-cast v5, LB0/a;

    invoke-interface/range {v19 .. v19}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/content/res/Configuration;

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v9

    if-ne v9, v7, :cond_f

    new-instance v9, LR0/c;

    invoke-direct {v9}, LR0/c;-><init>()V

    invoke-virtual {v2, v9}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_f
    check-cast v9, LR0/c;

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v14

    if-ne v14, v7, :cond_11

    new-instance v14, Landroid/content/res/Configuration;

    invoke-direct {v14}, Landroid/content/res/Configuration;-><init>()V

    if-eqz v8, :cond_10

    invoke-virtual {v14, v8}, Landroid/content/res/Configuration;->setTo(Landroid/content/res/Configuration;)V

    :cond_10
    invoke-virtual {v2, v14}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_11
    check-cast v14, Landroid/content/res/Configuration;

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v8

    if-ne v8, v7, :cond_12

    new-instance v8, LM0/Q;

    invoke-direct {v8, v14, v9}, LM0/Q;-><init>(Landroid/content/res/Configuration;LR0/c;)V

    invoke-virtual {v2, v8}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_12
    check-cast v8, LM0/Q;

    invoke-virtual {v2, v4}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v14

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v15

    if-nez v14, :cond_13

    if-ne v15, v7, :cond_14

    :cond_13
    new-instance v15, LF0/A;

    const/4 v14, 0x6

    invoke-direct {v15, v14, v4, v8}, LF0/A;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, v15}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_14
    check-cast v15, Lr7/c;

    invoke-static {v9, v15, v2}, La0/b;->e(Ljava/lang/Object;Lr7/c;La0/r;)V

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v8

    if-ne v8, v7, :cond_15

    new-instance v8, LR0/d;

    invoke-direct {v8}, LR0/d;-><init>()V

    invoke-virtual {v2, v8}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_15
    check-cast v8, LR0/d;

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v14

    if-ne v14, v7, :cond_16

    new-instance v14, LM0/S;

    invoke-direct {v14, v8}, LM0/S;-><init>(LR0/d;)V

    invoke-virtual {v2, v14}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_16
    check-cast v14, LM0/S;

    invoke-virtual {v2, v4}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v15

    invoke-virtual {v2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v6

    if-nez v15, :cond_17

    if-ne v6, v7, :cond_18

    :cond_17
    new-instance v6, LF0/A;

    const/4 v7, 0x7

    invoke-direct {v6, v7, v4, v14}, LF0/A;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v2, v6}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_18
    check-cast v6, Lr7/c;

    invoke-static {v8, v6, v2}, La0/b;->e(Ljava/lang/Object;Lr7/c;La0/r;)V

    sget-object v6, LM0/r0;->v:La0/B;

    invoke-virtual {v2, v6}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Boolean;

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    invoke-virtual {v0}, LM0/x;->getScrollCaptureInProgress$ui_release()Z

    move-result v14

    or-int/2addr v7, v14

    invoke-interface/range {v19 .. v19}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroid/content/res/Configuration;

    sget-object v15, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->a:La0/B;

    invoke-virtual {v15, v14}, La0/B;->a(Ljava/lang/Object;)LW3/E;

    move-result-object v18

    sget-object v14, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->b:La0/X0;

    invoke-virtual {v14, v4}, La0/X0;->a(Ljava/lang/Object;)LW3/E;

    move-result-object v19

    sget-object v4, LW1/i;->a:La0/q0;

    iget-object v11, v11, LM0/n;->a:Landroidx/lifecycle/w;

    invoke-virtual {v4, v11}, La0/q0;->a(Ljava/lang/Object;)LW3/E;

    move-result-object v20

    sget-object v4, Lt2/a;->a:La0/q0;

    invoke-virtual {v4, v12}, La0/q0;->a(Ljava/lang/Object;)LW3/E;

    move-result-object v21

    sget-object v4, Lj0/i;->a:La0/X0;

    invoke-virtual {v4, v13}, La0/X0;->a(Ljava/lang/Object;)LW3/E;

    move-result-object v22

    sget-object v4, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->f:La0/X0;

    invoke-virtual {v0}, LM0/x;->getView()Landroid/view/View;

    move-result-object v11

    invoke-virtual {v4, v11}, La0/X0;->a(Ljava/lang/Object;)LW3/E;

    move-result-object v23

    sget-object v4, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->d:La0/X0;

    invoke-virtual {v4, v9}, La0/X0;->a(Ljava/lang/Object;)LW3/E;

    move-result-object v24

    sget-object v4, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->e:La0/X0;

    invoke-virtual {v4, v8}, La0/X0;->a(Ljava/lang/Object;)LW3/E;

    move-result-object v25

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v6, v4}, La0/B;->a(Ljava/lang/Object;)LW3/E;

    move-result-object v26

    sget-object v4, LM0/r0;->l:La0/X0;

    invoke-virtual {v4, v5}, La0/X0;->a(Ljava/lang/Object;)LW3/E;

    move-result-object v27

    filled-new-array/range {v18 .. v27}, [LW3/E;

    move-result-object v4

    new-instance v5, LM0/P;

    const/4 v6, 0x0

    invoke-direct {v5, v0, v10, v1, v6}, LM0/P;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lr7/e;I)V

    const v6, 0x3f2ad1a9

    invoke-static {v6, v5, v2}, Li0/i;->d(ILd7/e;La0/r;)Li0/d;

    move-result-object v5

    const/16 v6, 0x38

    invoke-static {v4, v5, v2, v6}, La0/b;->b([LW3/E;Lr7/e;La0/r;I)V

    goto :goto_a

    :cond_19
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Called when the ViewTreeOwnersAvailability is not yet in Available state"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1a
    invoke-virtual {v2}, La0/r;->Q()V

    :goto_a
    invoke-virtual {v2}, La0/r;->r()La0/r0;

    move-result-object v2

    if-eqz v2, :cond_1b

    new-instance v4, LJ0/H;

    const/4 v5, 0x3

    invoke-direct {v4, v0, v1, v3, v5}, LJ0/H;-><init>(Ljava/lang/Object;Lr7/e;II)V

    iput-object v4, v2, La0/r0;->d:Lr7/e;

    :cond_1b
    return-void
.end method

.method public static final b(Ljava/lang/String;)V
    .locals 3

    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "CompositionLocal "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " not present"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static final getLocalLifecycleOwner()La0/q0;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "La0/q0;"
        }
    .end annotation

    sget-object v0, LW1/i;->a:La0/q0;

    return-object v0
.end method
