.class public abstract Landroidx/compose/ui/layout/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lp/w;

.field public static final b:[LJ0/r0;

.field public static final c:Lp/w;


# direct methods
.method static constructor <clinit>()V
    .locals 17

    new-instance v0, Lp/w;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, Lp/w;-><init>(I)V

    sget-object v2, LJ0/r0;->a:LJ0/q0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, LJ0/q0;->g:LJ0/s0;

    const/4 v3, 0x1

    invoke-virtual {v0, v3, v2}, Lp/w;->h(ILjava/lang/Object;)V

    sget-object v4, LJ0/q0;->f:LJ0/s0;

    const/4 v5, 0x2

    invoke-virtual {v0, v5, v4}, Lp/w;->h(ILjava/lang/Object;)V

    sget-object v6, LJ0/q0;->b:LJ0/s0;

    const/4 v7, 0x4

    invoke-virtual {v0, v7, v6}, Lp/w;->h(ILjava/lang/Object;)V

    sget-object v8, LJ0/q0;->d:LJ0/s0;

    invoke-virtual {v0, v1, v8}, Lp/w;->h(ILjava/lang/Object;)V

    sget-object v9, LJ0/q0;->h:LJ0/s0;

    const/16 v10, 0x10

    invoke-virtual {v0, v10, v9}, Lp/w;->h(ILjava/lang/Object;)V

    sget-object v11, LJ0/q0;->e:LJ0/s0;

    const/16 v12, 0x20

    invoke-virtual {v0, v12, v11}, Lp/w;->h(ILjava/lang/Object;)V

    sget-object v13, LJ0/q0;->i:LJ0/s0;

    const/16 v14, 0x40

    invoke-virtual {v0, v14, v13}, Lp/w;->h(ILjava/lang/Object;)V

    sput-object v0, Landroidx/compose/ui/layout/b;->a:Lp/w;

    const/16 v0, 0x9

    new-array v0, v0, [LJ0/r0;

    const/4 v15, 0x0

    aput-object v2, v0, v15

    aput-object v4, v0, v3

    aput-object v6, v0, v5

    const/4 v15, 0x3

    aput-object v13, v0, v15

    aput-object v9, v0, v7

    const/4 v15, 0x5

    aput-object v11, v0, v15

    const/4 v15, 0x6

    aput-object v8, v0, v15

    sget-object v15, LJ0/q0;->j:LJ0/s0;

    move/from16 v16, v1

    const/4 v1, 0x7

    aput-object v15, v0, v1

    sget-object v15, LJ0/q0;->c:LJ0/s0;

    aput-object v15, v0, v16

    sput-object v0, Landroidx/compose/ui/layout/b;->b:[LJ0/r0;

    new-instance v0, Lp/w;

    invoke-direct {v0, v1}, Lp/w;-><init>(I)V

    invoke-virtual {v0, v3, v2}, Lp/w;->h(ILjava/lang/Object;)V

    invoke-virtual {v0, v5, v4}, Lp/w;->h(ILjava/lang/Object;)V

    invoke-virtual {v0, v7, v6}, Lp/w;->h(ILjava/lang/Object;)V

    invoke-virtual {v0, v10, v9}, Lp/w;->h(ILjava/lang/Object;)V

    invoke-virtual {v0, v14, v13}, Lp/w;->h(ILjava/lang/Object;)V

    invoke-virtual {v0, v12, v11}, Lp/w;->h(ILjava/lang/Object;)V

    move/from16 v1, v16

    invoke-virtual {v0, v1, v8}, Lp/w;->h(ILjava/lang/Object;)V

    sput-object v0, Landroidx/compose/ui/layout/b;->c:Lp/w;

    return-void
.end method

.method public static final a(LL0/O;LJ0/o;JII)V
    .locals 6

    const-wide/16 v0, -0x1

    invoke-static {p2, p3, v0, v1}, LJ0/h0;->g(JJ)Z

    move-result v0

    if-nez v0, :cond_0

    const/16 v0, 0x30

    ushr-long v0, p2, v0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    long-to-int v0, v0

    int-to-float v0, v0

    const/16 v1, 0x20

    ushr-long v4, p2, v1

    and-long/2addr v4, v2

    long-to-int v1, v4

    int-to-float v1, v1

    const/16 v4, 0x10

    ushr-long v4, p2, v4

    and-long/2addr v4, v2

    long-to-int v4, v4

    sub-int/2addr p4, v4

    int-to-float p4, p4

    and-long/2addr p2, v2

    long-to-int p2, p2

    sub-int/2addr p5, p2

    int-to-float p2, p5

    invoke-virtual {p1}, LJ0/o;->b()LJ0/n;

    move-result-object p3

    invoke-virtual {p0, p3, v0}, LL0/O;->b(LJ0/n;F)V

    invoke-virtual {p1}, LJ0/o;->d()LJ0/n;

    move-result-object p3

    invoke-virtual {p0, p3, v1}, LL0/O;->b(LJ0/n;F)V

    invoke-virtual {p1}, LJ0/o;->c()LJ0/n;

    move-result-object p3

    invoke-virtual {p0, p3, p4}, LL0/O;->b(LJ0/n;F)V

    invoke-virtual {p1}, LJ0/o;->a()LJ0/n;

    move-result-object p1

    invoke-virtual {p0, p1, p2}, LL0/O;->b(LJ0/n;F)V

    :cond_0
    return-void
.end method

.method public static final b(LJ0/p;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/ui/layout/RulerProviderModifierElement;

    invoke-direct {v0, p0}, Landroidx/compose/ui/layout/RulerProviderModifierElement;-><init>(LJ0/p;)V

    return-object v0
.end method
