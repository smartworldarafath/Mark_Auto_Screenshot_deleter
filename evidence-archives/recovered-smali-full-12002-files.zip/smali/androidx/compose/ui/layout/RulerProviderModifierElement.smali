.class final Landroidx/compose/ui/layout/RulerProviderModifierElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:LJ0/p;


# direct methods
.method public constructor <init>(LJ0/p;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/ui/layout/RulerProviderModifierElement;->a:LJ0/p;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x1

    if-ne p1, p0, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Landroidx/compose/ui/layout/RulerProviderModifierElement;

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    check-cast p1, Landroidx/compose/ui/layout/RulerProviderModifierElement;

    goto :goto_0

    :cond_1
    move-object p1, v2

    :goto_0
    if-eqz p1, :cond_2

    iget-object v2, p1, Landroidx/compose/ui/layout/RulerProviderModifierElement;->a:LJ0/p;

    :cond_2
    iget-object p1, p0, Landroidx/compose/ui/layout/RulerProviderModifierElement;->a:LJ0/p;

    if-ne v2, p1, :cond_3

    return v0

    :cond_3
    const/4 p1, 0x0

    return p1
.end method

.method public final g()Lm0/q;
    .locals 2

    new-instance v0, LJ0/e0;

    iget-object v1, p0, Landroidx/compose/ui/layout/RulerProviderModifierElement;->a:LJ0/p;

    invoke-direct {v0, v1}, LJ0/e0;-><init>(LJ0/p;)V

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 2

    check-cast p1, LJ0/e0;

    iget-object v0, p1, LJ0/e0;->H:LJ0/p;

    iget-object v1, p0, Landroidx/compose/ui/layout/RulerProviderModifierElement;->a:LJ0/p;

    if-eq v0, v1, :cond_0

    iput-object v1, p1, LJ0/e0;->H:LJ0/p;

    invoke-static {p1}, LL0/f;->v(LL0/l;)LL0/J;

    move-result-object p1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p1, v0, v1}, LL0/J;->V(LL0/J;ZI)V

    :cond_0
    return-void
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, Landroidx/compose/ui/layout/RulerProviderModifierElement;->a:LJ0/p;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method
