.class public abstract Landroidx/compose/ui/viewinterop/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Lr7/c;Lm0/r;Lr7/c;La0/r;I)V
    .locals 22

    move-object/from16 v1, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    move-object/from16 v9, p3

    move/from16 v10, p4

    sget-object v11, Lm1/b;->y:Lm1/b;

    const v0, -0xabaf393

    invoke-virtual {v9, v0}, La0/r;->X(I)La0/r;

    and-int/lit8 v0, v10, 0x6

    if-nez v0, :cond_1

    invoke-virtual {v9, v1}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x4

    goto :goto_0

    :cond_0
    const/4 v0, 0x2

    :goto_0
    or-int/2addr v0, v10

    goto :goto_1

    :cond_1
    move v0, v10

    :goto_1
    and-int/lit8 v2, v10, 0x30

    if-nez v2, :cond_3

    invoke-virtual {v9, v7}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/16 v2, 0x20

    goto :goto_2

    :cond_2
    const/16 v2, 0x10

    :goto_2
    or-int/2addr v0, v2

    :cond_3
    or-int/lit16 v0, v0, 0x180

    and-int/lit16 v2, v10, 0xc00

    if-nez v2, :cond_5

    invoke-virtual {v9, v11}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    const/16 v2, 0x800

    goto :goto_3

    :cond_4
    const/16 v2, 0x400

    :goto_3
    or-int/2addr v0, v2

    :cond_5
    and-int/lit16 v2, v10, 0x6000

    if-nez v2, :cond_7

    invoke-virtual {v9, v8}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    const/16 v2, 0x4000

    goto :goto_4

    :cond_6
    const/16 v2, 0x2000

    :goto_4
    or-int/2addr v0, v2

    :cond_7
    and-int/lit16 v2, v0, 0x2493

    const/16 v3, 0x2492

    if-eq v2, v3, :cond_8

    const/4 v2, 0x1

    goto :goto_5

    :cond_8
    const/4 v2, 0x0

    :goto_5
    and-int/lit8 v3, v0, 0x1

    invoke-virtual {v9, v3, v2}, La0/r;->N(IZ)Z

    move-result v2

    if-eqz v2, :cond_11

    iget-wide v2, v9, La0/r;->T:J

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v14

    sget-object v2, Landroidx/compose/ui/viewinterop/FocusGroupPropertiesElement;->a:Landroidx/compose/ui/viewinterop/FocusGroupPropertiesElement;

    invoke-interface {v7, v2}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v2

    sget-object v3, Landroidx/compose/ui/focus/FocusTargetNode$FocusTargetElement;->a:Landroidx/compose/ui/focus/FocusTargetNode$FocusTargetElement;

    invoke-interface {v2, v3}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v2

    sget-object v4, Landroidx/compose/ui/viewinterop/FocusTargetPropertiesElement;->a:Landroidx/compose/ui/viewinterop/FocusTargetPropertiesElement;

    invoke-interface {v2, v4}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v2

    invoke-interface {v2, v3}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v2

    invoke-static {v9, v2}, Lm0/a;->c(La0/r;Lm0/r;)Lm0/r;

    move-result-object v15

    sget-object v2, LM0/r0;->h:La0/X0;

    invoke-virtual {v9, v2}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lj1/c;

    sget-object v3, LM0/r0;->n:La0/X0;

    invoke-virtual {v9, v3}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lj1/m;

    invoke-virtual {v9}, La0/r;->l()La0/n0;

    move-result-object v4

    sget-object v5, LW1/i;->a:La0/q0;

    invoke-virtual {v9, v5}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/lifecycle/w;

    sget-object v6, Lt2/a;->a:La0/q0;

    invoke-virtual {v9, v6}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ls2/e;

    const v12, 0x4e5e438f    # 9.3224237E8f

    invoke-virtual {v9, v12}, La0/r;->V(I)V

    and-int/lit8 v0, v0, 0xe

    move/from16 v16, v14

    iget-wide v13, v9, La0/r;->T:J

    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v13

    sget-object v14, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->b:La0/X0;

    invoke-virtual {v9, v14}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroid/content/Context;

    move-object/from16 v17, v3

    invoke-static {v9}, La0/b;->w(La0/r;)La0/p;

    move-result-object v3

    sget-object v12, Lj0/i;->a:La0/X0;

    invoke-virtual {v9, v12}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lj0/g;

    move/from16 v18, v0

    sget-object v0, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->f:La0/X0;

    invoke-virtual {v9, v0}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {v9, v14}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v19

    and-int/lit8 v20, v18, 0xe

    move-object/from16 v21, v2

    xor-int/lit8 v2, v20, 0x6

    move-object/from16 v20, v4

    const/4 v4, 0x4

    if-le v2, v4, :cond_9

    invoke-virtual {v9, v1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_a

    :cond_9
    and-int/lit8 v2, v18, 0x6

    if-ne v2, v4, :cond_b

    :cond_a
    const/4 v2, 0x1

    goto :goto_6

    :cond_b
    const/4 v2, 0x0

    :goto_6
    or-int v2, v19, v2

    invoke-virtual {v9, v3}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v2, v4

    invoke-virtual {v9, v12}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v2, v4

    invoke-virtual {v9, v13}, La0/r;->d(I)Z

    move-result v4

    or-int/2addr v2, v4

    invoke-virtual {v9, v0}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v2, v4

    invoke-virtual {v9}, La0/r;->K()Ljava/lang/Object;

    move-result-object v4

    if-nez v2, :cond_c

    sget-object v2, La0/m;->a:La0/U;

    if-ne v4, v2, :cond_d

    :cond_c
    move-object v2, v6

    move-object v6, v0

    goto :goto_7

    :cond_d
    move-object v12, v5

    move-object v7, v6

    move-object/from16 v14, v17

    move-object/from16 v13, v21

    goto :goto_8

    :goto_7
    new-instance v0, Lm1/m;

    move-object v7, v2

    move-object v4, v12

    move-object v2, v1

    move-object v12, v5

    move v5, v13

    move-object v1, v14

    move-object/from16 v14, v17

    move-object/from16 v13, v21

    invoke-direct/range {v0 .. v6}, Lm1/m;-><init>(Landroid/content/Context;Lr7/c;La0/p;Lj0/g;ILandroid/view/View;)V

    invoke-virtual {v9, v0}, La0/r;->g0(Ljava/lang/Object;)V

    move-object v4, v0

    :goto_8
    check-cast v4, Lr7/a;

    const/16 v0, 0x7d

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v9, v0, v2, v1, v1}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    iput-boolean v2, v9, La0/r;->r:Z

    move-object v5, v12

    move-object/from16 v0, v20

    iget-boolean v1, v9, La0/r;->S:Z

    if-eqz v1, :cond_e

    invoke-virtual {v9, v4}, La0/r;->k(Lr7/a;)V

    goto :goto_9

    :cond_e
    invoke-virtual {v9}, La0/r;->j0()V

    :goto_9
    sget-object v1, LL0/j;->b:LL0/i;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, LL0/i;->d:LL0/h;

    invoke-static {v9, v0, v1}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v0, Lm1/l;->x:Lm1/l;

    invoke-static {v9, v15, v0}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v0, Lm1/l;->y:Lm1/l;

    invoke-static {v9, v13, v0}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v0, Lm1/l;->z:Lm1/l;

    invoke-static {v9, v5, v0}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v0, Lm1/l;->A:Lm1/l;

    invoke-static {v9, v7, v0}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v0, Lm1/l;->B:Lm1/l;

    invoke-static {v9, v14, v0}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v0, LL0/i;->f:LL0/h;

    iget-boolean v1, v9, La0/r;->S:Z

    if-nez v1, :cond_f

    invoke-virtual {v9}, La0/r;->K()Ljava/lang/Object;

    move-result-object v1

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10

    :cond_f
    move/from16 v1, v16

    invoke-static {v1, v9, v1, v0}, Lq3/h;->n(ILa0/r;ILL0/h;)V

    :cond_10
    sget-object v0, Lm1/l;->v:Lm1/l;

    invoke-static {v9, v8, v0}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v0, Lm1/l;->w:Lm1/l;

    invoke-static {v9, v11, v0}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    const/4 v12, 0x1

    invoke-virtual {v9, v12}, La0/r;->p(Z)V

    const/4 v0, 0x0

    invoke-virtual {v9, v0}, La0/r;->p(Z)V

    goto :goto_a

    :cond_11
    invoke-virtual {v9}, La0/r;->Q()V

    :goto_a
    invoke-virtual {v9}, La0/r;->r()La0/r0;

    move-result-object v6

    if-eqz v6, :cond_12

    new-instance v0, LJ0/g0;

    const/4 v5, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object v3, v8

    move v4, v10

    invoke-direct/range {v0 .. v5}, LJ0/g0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ld7/e;II)V

    iput-object v0, v6, La0/r0;->d:Lr7/e;

    :cond_12
    return-void
.end method

.method public static final b(Lr7/c;Lr7/c;La0/r;I)V
    .locals 4

    const v0, -0x6a521d79

    invoke-virtual {p2, v0}, La0/r;->X(I)La0/r;

    and-int/lit8 v0, p3, 0x6

    if-nez v0, :cond_1

    invoke-virtual {p2, p0}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x4

    goto :goto_0

    :cond_0
    const/4 v0, 0x2

    :goto_0
    or-int/2addr v0, p3

    goto :goto_1

    :cond_1
    move v0, p3

    :goto_1
    and-int/lit8 v1, p3, 0x30

    sget-object v2, Lm0/o;->a:Lm0/o;

    if-nez v1, :cond_3

    invoke-virtual {p2, v2}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    const/16 v1, 0x20

    goto :goto_2

    :cond_2
    const/16 v1, 0x10

    :goto_2
    or-int/2addr v0, v1

    :cond_3
    and-int/lit16 v1, p3, 0x180

    if-nez v1, :cond_5

    invoke-virtual {p2, p1}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    const/16 v1, 0x100

    goto :goto_3

    :cond_4
    const/16 v1, 0x80

    :goto_3
    or-int/2addr v0, v1

    :cond_5
    and-int/lit16 v1, v0, 0x93

    const/16 v3, 0x92

    if-eq v1, v3, :cond_6

    const/4 v1, 0x1

    goto :goto_4

    :cond_6
    const/4 v1, 0x0

    :goto_4
    and-int/lit8 v3, v0, 0x1

    invoke-virtual {p2, v3, v1}, La0/r;->N(IZ)Z

    move-result v1

    if-eqz v1, :cond_7

    and-int/lit8 v1, v0, 0xe

    or-int/lit16 v1, v1, 0xc00

    and-int/lit8 v3, v0, 0x70

    or-int/2addr v1, v3

    const v3, 0xe000

    shl-int/lit8 v0, v0, 0x6

    and-int/2addr v0, v3

    or-int/2addr v0, v1

    invoke-static {p0, v2, p1, p2, v0}, Landroidx/compose/ui/viewinterop/a;->a(Lr7/c;Lm0/r;Lr7/c;La0/r;I)V

    goto :goto_5

    :cond_7
    invoke-virtual {p2}, La0/r;->Q()V

    :goto_5
    invoke-virtual {p2}, La0/r;->r()La0/r0;

    move-result-object p2

    if-eqz p2, :cond_8

    new-instance v0, LX/Z1;

    invoke-direct {v0, p0, p1, p3}, LX/Z1;-><init>(Lr7/c;Lr7/c;I)V

    iput-object v0, p2, La0/r0;->d:Lr7/e;

    :cond_8
    return-void
.end method

.method public static final c(LL0/J;)Lm1/q;
    .locals 0

    iget-object p0, p0, LL0/J;->G:Lm1/q;

    if-eqz p0, :cond_0

    return-object p0

    :cond_0
    const-string p0, "Required value was null."

    invoke-static {p0}, Lcom/google/android/gms/internal/measurement/q1;->h(Ljava/lang/String;)LA2/c;

    move-result-object p0

    throw p0
.end method
