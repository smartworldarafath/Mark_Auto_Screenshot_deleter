.class public abstract Landroidx/compose/foundation/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Lm0/r;Lt0/x;)Lm0/r;
    .locals 6

    new-instance v0, Landroidx/compose/foundation/BackgroundElement;

    const-wide/16 v1, 0x0

    const/4 v5, 0x1

    sget-object v4, Lt0/D;->a:Lt0/C;

    move-object v3, p1

    invoke-direct/range {v0 .. v5}, Landroidx/compose/foundation/BackgroundElement;-><init>(JLt0/x;Lt0/H;I)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final b(Lm0/r;JLt0/H;)Lm0/r;
    .locals 6

    new-instance v0, Landroidx/compose/foundation/BackgroundElement;

    const/4 v3, 0x0

    const/4 v5, 0x2

    move-wide v1, p1

    move-object v4, p3

    invoke-direct/range {v0 .. v5}, Landroidx/compose/foundation/BackgroundElement;-><init>(JLt0/x;Lt0/H;I)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final c(Lm0/r;Ly/j;Lu/c0;ZLT0/g;Lr7/a;)Lm0/r;
    .locals 9

    instance-of v0, p2, Lu/g0;

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    move-object v3, p2

    check-cast v3, Lu/g0;

    new-instance v1, Landroidx/compose/foundation/ClickableElement;

    const/4 v4, 0x0

    move-object v2, p1

    move v5, p3

    move-object v7, p4

    move-object v8, p5

    invoke-direct/range {v1 .. v8}, Landroidx/compose/foundation/ClickableElement;-><init>(Ly/j;Lu/g0;ZZLjava/lang/String;LT0/g;Lr7/a;)V

    goto :goto_0

    :cond_0
    move-object v2, p1

    move v5, p3

    move-object v7, p4

    move-object v8, p5

    if-nez p2, :cond_1

    new-instance v1, Landroidx/compose/foundation/ClickableElement;

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-direct/range {v1 .. v8}, Landroidx/compose/foundation/ClickableElement;-><init>(Ly/j;Lu/g0;ZZLjava/lang/String;LT0/g;Lr7/a;)V

    goto :goto_0

    :cond_1
    sget-object p1, Lm0/o;->a:Lm0/o;

    if-eqz v2, :cond_2

    invoke-static {p1, v2, p2}, Landroidx/compose/foundation/c;->a(Lm0/r;Ly/j;Lu/c0;)Lm0/r;

    move-result-object p1

    new-instance v1, Landroidx/compose/foundation/ClickableElement;

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-direct/range {v1 .. v8}, Landroidx/compose/foundation/ClickableElement;-><init>(Ly/j;Lu/g0;ZZLjava/lang/String;LT0/g;Lr7/a;)V

    invoke-interface {p1, v1}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v1

    goto :goto_0

    :cond_2
    new-instance p3, Landroidx/compose/foundation/b;

    invoke-direct {p3, p2, v5, v7, v8}, Landroidx/compose/foundation/b;-><init>(Lu/c0;ZLT0/g;Lr7/a;)V

    invoke-static {p1, p3}, Lm0/a;->a(Lm0/r;Lr7/f;)Lm0/r;

    move-result-object v1

    :goto_0
    invoke-interface {p0, v1}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic d(Lm0/r;Ly/j;Lu/c0;ZLT0/g;Lr7/a;I)Lm0/r;
    .locals 6

    and-int/lit8 p6, p6, 0x10

    if-eqz p6, :cond_0

    const/4 p4, 0x0

    :cond_0
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p5

    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/a;->c(Lm0/r;Ly/j;Lu/c0;ZLT0/g;Lr7/a;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static e(Lm0/r;ZLjava/lang/String;Lr7/a;I)Lm0/r;
    .locals 8

    and-int/lit8 v0, p4, 0x1

    if-eqz v0, :cond_0

    const/4 p1, 0x1

    :cond_0
    move v4, p1

    and-int/lit8 p1, p4, 0x2

    if-eqz p1, :cond_1

    const/4 p2, 0x0

    :cond_1
    move-object v5, p2

    new-instance v0, Landroidx/compose/foundation/ClickableElement;

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x0

    move-object v7, p3

    invoke-direct/range {v0 .. v7}, Landroidx/compose/foundation/ClickableElement;-><init>(Ly/j;Lu/g0;ZZLjava/lang/String;LT0/g;Lr7/a;)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final f(Lm0/r;Ly/j;Lr7/a;)Lm0/r;
    .locals 3

    new-instance v0, Landroidx/compose/foundation/CombinedClickableElement;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0, p2, v2, p1, v1}, Landroidx/compose/foundation/CombinedClickableElement;-><init>(Lr7/a;Lr7/a;Ly/j;Z)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static g(Lm0/r;Lr7/a;Lr7/a;)Lm0/r;
    .locals 3

    new-instance v0, Landroidx/compose/foundation/CombinedClickableElement;

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0, p2, p1, v2, v1}, Landroidx/compose/foundation/CombinedClickableElement;-><init>(Lr7/a;Lr7/a;Ly/j;Z)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final h(Lm0/r;ZLy/j;)Lm0/r;
    .locals 0

    if-eqz p1, :cond_0

    new-instance p1, Landroidx/compose/foundation/FocusableElement;

    invoke-direct {p1, p2}, Landroidx/compose/foundation/FocusableElement;-><init>(Ly/j;)V

    goto :goto_0

    :cond_0
    sget-object p1, Lm0/o;->a:Lm0/o;

    :goto_0
    invoke-interface {p0, p1}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static i(Lm0/r;Ly/j;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/HoverableElement;

    invoke-direct {v0, p1}, Landroidx/compose/foundation/HoverableElement;-><init>(Ly/j;)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final j(Landroid/view/KeyEvent;)Z
    .locals 4

    invoke-static {p0}, LD0/c;->b(Landroid/view/KeyEvent;)J

    move-result-wide v0

    sget p0, LD0/a;->p:I

    sget-wide v2, LD0/a;->h:J

    invoke-static {v0, v1, v2, v3}, LD0/a;->a(JJ)Z

    move-result p0

    if-nez p0, :cond_1

    sget-wide v2, LD0/a;->k:J

    invoke-static {v0, v1, v2, v3}, LD0/a;->a(JJ)Z

    move-result p0

    if-nez p0, :cond_1

    sget-wide v2, LD0/a;->o:J

    invoke-static {v0, v1, v2, v3}, LD0/a;->a(JJ)Z

    move-result p0

    if-nez p0, :cond_1

    sget-wide v2, LD0/a;->j:J

    invoke-static {v0, v1, v2, v3}, LD0/a;->a(JJ)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 p0, 0x1

    return p0
.end method

.method public static k(Lm0/r;Lw/C0;Lw/h0;ZLw/l;Ly/j;ZLu/s;)Lm0/r;
    .locals 8

    sget v0, Lu/C;->a:F

    sget-object v0, Lw/h0;->t:Lw/h0;

    sget-object v1, Lm0/o;->a:Lm0/o;

    if-ne p2, v0, :cond_0

    sget-object v0, Lu/U;->c:Lu/U;

    invoke-static {v1, v0}, LH4/G4;->a(Lm0/r;Lt0/H;)Lm0/r;

    move-result-object v0

    goto :goto_0

    :cond_0
    sget-object v0, Lu/U;->b:Lu/U;

    invoke-static {v1, v0}, LH4/G4;->a(Lm0/r;Lt0/H;)Lm0/r;

    move-result-object v0

    :goto_0
    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    new-instance v0, Landroidx/compose/foundation/ScrollingContainerElement;

    move-object v4, p1

    move-object v3, p2

    move v6, p3

    move-object v2, p4

    move-object v5, p5

    move v7, p6

    move-object v1, p7

    invoke-direct/range {v0 .. v7}, Landroidx/compose/foundation/ScrollingContainerElement;-><init>(Lu/s;Lw/l;Lw/h0;Lw/C0;Ly/j;ZZ)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method
