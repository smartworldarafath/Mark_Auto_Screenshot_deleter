.class public abstract Landroidx/compose/foundation/text/handwriting/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LL0/n;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/16 v0, 0x28

    int-to-float v0, v0

    const/16 v1, 0xa

    int-to-float v1, v1

    new-instance v2, LL0/n;

    invoke-direct {v2, v1, v0, v1, v0}, LL0/n;-><init>(FFFF)V

    sput-object v2, Landroidx/compose/foundation/text/handwriting/a;->a:LL0/n;

    return-void
.end method

.method public static final a(ZZLr7/a;)Lm0/r;
    .locals 1

    sget-object v0, Lm0/o;->a:Lm0/o;

    if-eqz p0, :cond_1

    sget-boolean p0, LQ/c;->a:Z

    if-eqz p0, :cond_1

    if-eqz p1, :cond_0

    new-instance v0, Landroidx/compose/ui/input/pointer/StylusHoverIconModifierElement;

    sget-object p0, Landroidx/compose/foundation/text/handwriting/a;->a:LL0/n;

    invoke-direct {v0, p0}, Landroidx/compose/ui/input/pointer/StylusHoverIconModifierElement;-><init>(LL0/n;)V

    :cond_0
    new-instance p0, Landroidx/compose/foundation/text/handwriting/StylusHandwritingElement;

    invoke-direct {p0, p2}, Landroidx/compose/foundation/text/handwriting/StylusHandwritingElement;-><init>(Lr7/a;)V

    invoke-interface {v0, p0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0

    :cond_1
    return-object v0
.end method
