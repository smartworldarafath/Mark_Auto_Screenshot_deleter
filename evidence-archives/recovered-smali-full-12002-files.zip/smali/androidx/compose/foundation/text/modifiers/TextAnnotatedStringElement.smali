.class public final Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:LW0/g;

.field public final b:LW0/L;

.field public final c:La1/l;

.field public final d:Lr7/c;

.field public final e:I

.field public final f:Z

.field public final g:I

.field public final h:I

.field public final i:Ljava/util/List;

.field public final j:Lr7/c;

.field public final k:Lt0/q;

.field public final l:Lr7/c;


# direct methods
.method public constructor <init>(LW0/g;LW0/L;La1/l;Lr7/c;IZIILjava/util/List;Lr7/c;Lt0/q;Lr7/c;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->a:LW0/g;

    iput-object p2, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->b:LW0/L;

    iput-object p3, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->c:La1/l;

    iput-object p4, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->d:Lr7/c;

    iput p5, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->e:I

    iput-boolean p6, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->f:Z

    iput p7, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->g:I

    iput p8, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->h:I

    iput-object p9, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->i:Ljava/util/List;

    iput-object p10, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->j:Lr7/c;

    iput-object p11, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->k:Lt0/q;

    iput-object p12, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->l:Lr7/c;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    if-ne p0, p1, :cond_0

    goto/16 :goto_0

    :cond_0
    instance-of v0, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;

    if-nez v0, :cond_1

    goto/16 :goto_1

    :cond_1
    check-cast p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;

    iget-object v0, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->k:Lt0/q;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->k:Lt0/q;

    invoke-static {v1, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto/16 :goto_1

    :cond_2
    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->a:LW0/g;

    iget-object v1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->a:LW0/g;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_1

    :cond_3
    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->b:LW0/L;

    iget-object v1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->b:LW0/L;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_1

    :cond_4
    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->i:Ljava/util/List;

    iget-object v1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->i:Ljava/util/List;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_1

    :cond_5
    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->c:La1/l;

    iget-object v1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->c:La1/l;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    goto :goto_1

    :cond_6
    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->d:Lr7/c;

    iget-object v1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->d:Lr7/c;

    if-eq v0, v1, :cond_7

    goto :goto_1

    :cond_7
    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->l:Lr7/c;

    iget-object v1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->l:Lr7/c;

    if-eq v0, v1, :cond_8

    goto :goto_1

    :cond_8
    iget v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->e:I

    iget v1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->e:I

    if-ne v0, v1, :cond_d

    iget-boolean v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->f:Z

    iget-boolean v1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->f:Z

    if-eq v0, v1, :cond_9

    goto :goto_1

    :cond_9
    iget v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->g:I

    iget v1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->g:I

    if-eq v0, v1, :cond_a

    goto :goto_1

    :cond_a
    iget v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->h:I

    iget v1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->h:I

    if-eq v0, v1, :cond_b

    goto :goto_1

    :cond_b
    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->j:Lr7/c;

    iget-object p1, p1, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->j:Lr7/c;

    if-eq v0, p1, :cond_c

    goto :goto_1

    :cond_c
    :goto_0
    const/4 p1, 0x1

    return p1

    :cond_d
    :goto_1
    const/4 p1, 0x0

    return p1
.end method

.method public final g()Lm0/q;
    .locals 2

    new-instance v0, LS/h;

    invoke-direct {v0}, Lm0/q;-><init>()V

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->a:LW0/g;

    iput-object v1, v0, LS/h;->H:LW0/g;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->b:LW0/L;

    iput-object v1, v0, LS/h;->I:LW0/L;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->c:La1/l;

    iput-object v1, v0, LS/h;->J:La1/l;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->d:Lr7/c;

    iput-object v1, v0, LS/h;->K:Lr7/c;

    iget v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->e:I

    iput v1, v0, LS/h;->L:I

    iget-boolean v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->f:Z

    iput-boolean v1, v0, LS/h;->M:Z

    iget v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->g:I

    iput v1, v0, LS/h;->N:I

    iget v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->h:I

    iput v1, v0, LS/h;->O:I

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->i:Ljava/util/List;

    iput-object v1, v0, LS/h;->P:Ljava/util/List;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->j:Lr7/c;

    iput-object v1, v0, LS/h;->Q:Lr7/c;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->k:Lt0/q;

    iput-object v1, v0, LS/h;->R:Lt0/q;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->l:Lr7/c;

    iput-object v1, v0, LS/h;->S:Lr7/c;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    check-cast v1, LS/h;

    iget-object v2, v1, LS/h;->R:Lt0/q;

    iget-object v3, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->k:Lt0/q;

    invoke-static {v3, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    iput-object v3, v1, LS/h;->R:Lt0/q;

    if-eqz v2, :cond_1

    iget-object v2, v1, LS/h;->I:LW0/L;

    iget-object v3, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->b:LW0/L;

    if-eq v3, v2, :cond_0

    iget-object v3, v3, LW0/L;->a:LW0/D;

    iget-object v2, v2, LW0/L;->a:LW0/D;

    invoke-virtual {v3, v2}, LW0/D;->c(LW0/D;)Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_0

    :cond_0
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_0
    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    const/4 v2, 0x1

    :goto_1
    iget-object v3, v1, LS/h;->H:LW0/g;

    iget-object v3, v3, LW0/g;->u:Ljava/lang/String;

    iget-object v4, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->a:LW0/g;

    iget-object v5, v4, LW0/g;->u:Ljava/lang/String;

    invoke-static {v3, v5}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    iget-object v5, v1, LS/h;->H:LW0/g;

    iget-object v5, v5, LW0/g;->t:Ljava/util/List;

    iget-object v6, v4, LW0/g;->t:Ljava/util/List;

    invoke-static {v5, v6}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v3, :cond_3

    if-nez v5, :cond_2

    goto :goto_2

    :cond_2
    const/4 v5, 0x0

    goto :goto_3

    :cond_3
    :goto_2
    const/4 v5, 0x1

    :goto_3
    if-eqz v5, :cond_4

    iput-object v4, v1, LS/h;->H:LW0/g;

    :cond_4
    if-nez v3, :cond_5

    const/4 v3, 0x0

    iput-object v3, v1, LS/h;->W:LS/g;

    :cond_5
    iget-object v3, v1, LS/h;->I:LW0/L;

    iget-object v4, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->b:LW0/L;

    invoke-virtual {v3, v4}, LW0/L;->c(LW0/L;)Z

    move-result v3

    const/4 v6, 0x1

    xor-int/2addr v3, v6

    iput-object v4, v1, LS/h;->I:LW0/L;

    iget-object v4, v1, LS/h;->P:Ljava/util/List;

    iget-object v7, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->i:Ljava/util/List;

    invoke-static {v4, v7}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_6

    iput-object v7, v1, LS/h;->P:Ljava/util/List;

    move v3, v6

    :cond_6
    iget v4, v1, LS/h;->O:I

    iget v7, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->h:I

    if-eq v4, v7, :cond_7

    iput v7, v1, LS/h;->O:I

    move v3, v6

    :cond_7
    iget v4, v1, LS/h;->N:I

    iget v7, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->g:I

    if-eq v4, v7, :cond_8

    iput v7, v1, LS/h;->N:I

    move v3, v6

    :cond_8
    iget-boolean v4, v1, LS/h;->M:Z

    iget-boolean v7, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->f:Z

    if-eq v4, v7, :cond_9

    iput-boolean v7, v1, LS/h;->M:Z

    move v3, v6

    :cond_9
    iget-object v4, v1, LS/h;->J:La1/l;

    iget-object v7, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->c:La1/l;

    invoke-static {v4, v7}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_a

    iput-object v7, v1, LS/h;->J:La1/l;

    move v3, v6

    :cond_a
    iget v4, v1, LS/h;->L:I

    iget v7, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->e:I

    if-ne v4, v7, :cond_b

    move v6, v3

    goto :goto_4

    :cond_b
    iput v7, v1, LS/h;->L:I

    :goto_4
    iget-object v3, v1, LS/h;->K:Lr7/c;

    iget-object v4, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->d:Lr7/c;

    const/4 v7, 0x1

    if-eq v3, v4, :cond_c

    iput-object v4, v1, LS/h;->K:Lr7/c;

    move v3, v7

    goto :goto_5

    :cond_c
    const/4 v3, 0x0

    :goto_5
    iget-object v4, v1, LS/h;->Q:Lr7/c;

    iget-object v8, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->j:Lr7/c;

    if-eq v4, v8, :cond_d

    iput-object v8, v1, LS/h;->Q:Lr7/c;

    move v3, v7

    :cond_d
    iget-object v4, v1, LS/h;->S:Lr7/c;

    iget-object v8, v0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->l:Lr7/c;

    if-eq v4, v8, :cond_e

    iput-object v8, v1, LS/h;->S:Lr7/c;

    goto :goto_6

    :cond_e
    move v7, v3

    :goto_6
    if-nez v5, :cond_f

    if-nez v6, :cond_f

    if-eqz v7, :cond_11

    :cond_f
    invoke-virtual {v1}, LS/h;->K0()LS/d;

    move-result-object v3

    iget-object v4, v1, LS/h;->H:LW0/g;

    iget-object v8, v1, LS/h;->I:LW0/L;

    iget-object v9, v1, LS/h;->J:La1/l;

    iget v10, v1, LS/h;->L:I

    iget-boolean v11, v1, LS/h;->M:Z

    iget v12, v1, LS/h;->N:I

    iget v13, v1, LS/h;->O:I

    iget-object v14, v1, LS/h;->P:Ljava/util/List;

    iput-object v4, v3, LS/d;->a:LW0/g;

    iget-object v4, v3, LS/d;->k:LW0/L;

    invoke-virtual {v8, v4}, LW0/L;->c(LW0/L;)Z

    move-result v4

    iput-object v8, v3, LS/d;->k:LW0/L;

    const/4 v15, 0x0

    const/16 v16, 0x2

    if-nez v4, :cond_10

    move-object v4, v9

    iget-wide v8, v3, LS/d;->q:J

    shl-long v8, v8, v16

    iput-wide v8, v3, LS/d;->q:J

    iput-object v15, v3, LS/d;->l:LH4/l5;

    iput-object v15, v3, LS/d;->n:LW0/I;

    const/4 v8, -0x1

    iput v8, v3, LS/d;->p:I

    iput v8, v3, LS/d;->o:I

    goto :goto_7

    :cond_10
    move-object v4, v9

    :goto_7
    iput-object v4, v3, LS/d;->b:La1/l;

    iput v10, v3, LS/d;->c:I

    iput-boolean v11, v3, LS/d;->d:Z

    iput v12, v3, LS/d;->e:I

    iput v13, v3, LS/d;->f:I

    iput-object v14, v3, LS/d;->g:Ljava/util/List;

    iget-wide v8, v3, LS/d;->q:J

    shl-long v8, v8, v16

    const-wide/16 v10, 0x2

    or-long/2addr v8, v10

    iput-wide v8, v3, LS/d;->q:J

    iput-object v15, v3, LS/d;->l:LH4/l5;

    iput-object v15, v3, LS/d;->n:LW0/I;

    const/4 v8, -0x1

    iput v8, v3, LS/d;->p:I

    iput v8, v3, LS/d;->o:I

    :cond_11
    iget-boolean v3, v1, Lm0/q;->G:Z

    if-nez v3, :cond_12

    goto :goto_8

    :cond_12
    if-nez v5, :cond_13

    if-eqz v2, :cond_14

    iget-object v3, v1, LS/h;->V:LS/f;

    if-eqz v3, :cond_14

    :cond_13
    invoke-static {v1}, LL0/f;->n(LL0/z0;)V

    :cond_14
    if-nez v5, :cond_15

    if-nez v6, :cond_15

    if-eqz v7, :cond_16

    :cond_15
    invoke-static {v1}, LL0/f;->m(LL0/z;)V

    invoke-static {v1}, LL0/f;->l(LL0/o;)V

    :cond_16
    if-eqz v2, :cond_17

    invoke-static {v1}, LL0/f;->l(LL0/o;)V

    :cond_17
    :goto_8
    return-void
.end method

.method public final hashCode()I
    .locals 4

    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->a:LW0/g;

    invoke-virtual {v0}, LW0/g;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget-object v2, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->b:LW0/L;

    invoke-virtual {v2}, LW0/L;->hashCode()I

    move-result v2

    add-int/2addr v2, v0

    mul-int/2addr v2, v1

    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->c:La1/l;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    const/4 v2, 0x0

    iget-object v3, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->d:Lr7/c;

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    goto :goto_0

    :cond_0
    move v3, v2

    :goto_0
    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    iget v3, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->e:I

    invoke-static {v3, v0, v1}, Lq3/h;->c(III)I

    move-result v0

    iget-boolean v3, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->f:Z

    invoke-static {v0, v1, v3}, Lq3/h;->e(IIZ)I

    move-result v0

    iget v3, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->g:I

    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    iget v3, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->h:I

    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    iget-object v3, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->i:Ljava/util/List;

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    goto :goto_1

    :cond_1
    move v3, v2

    :goto_1
    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    iget-object v3, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->j:Lr7/c;

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    goto :goto_2

    :cond_2
    move v3, v2

    :goto_2
    add-int/2addr v0, v3

    mul-int/lit16 v0, v0, 0x3c1

    iget-object v3, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->k:Lt0/q;

    if-eqz v3, :cond_3

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    goto :goto_3

    :cond_3
    move v3, v2

    :goto_3
    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextAnnotatedStringElement;->l:Lr7/c;

    if-eqz v1, :cond_4

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :cond_4
    add-int/2addr v0, v2

    return v0
.end method
