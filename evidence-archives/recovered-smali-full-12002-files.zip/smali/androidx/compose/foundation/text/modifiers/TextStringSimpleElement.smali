.class public final Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:LW0/L;

.field public final c:La1/l;

.field public final d:I

.field public final e:Z

.field public final f:I

.field public final g:I

.field public final h:Lt0/q;


# direct methods
.method public constructor <init>(Ljava/lang/String;LW0/L;La1/l;IZIILt0/q;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->a:Ljava/lang/String;

    iput-object p2, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->b:LW0/L;

    iput-object p3, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->c:La1/l;

    iput p4, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->d:I

    iput-boolean p5, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->e:Z

    iput p6, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->f:I

    iput p7, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->g:I

    iput-object p8, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->h:Lt0/q;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    if-ne p0, p1, :cond_0

    goto :goto_0

    :cond_0
    instance-of v0, p1, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;

    if-nez v0, :cond_1

    goto :goto_1

    :cond_1
    check-cast p1, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;

    iget-object v0, p1, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->h:Lt0/q;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->h:Lt0/q;

    invoke-static {v1, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_1

    :cond_2
    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->a:Ljava/lang/String;

    iget-object v1, p1, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->a:Ljava/lang/String;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_1

    :cond_3
    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->b:LW0/L;

    iget-object v1, p1, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->b:LW0/L;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_1

    :cond_4
    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->c:La1/l;

    iget-object v1, p1, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->c:La1/l;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_1

    :cond_5
    iget v0, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->d:I

    iget v1, p1, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->d:I

    if-ne v0, v1, :cond_9

    iget-boolean v0, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->e:Z

    iget-boolean v1, p1, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->e:Z

    if-eq v0, v1, :cond_6

    goto :goto_1

    :cond_6
    iget v0, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->f:I

    iget v1, p1, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->f:I

    if-eq v0, v1, :cond_7

    goto :goto_1

    :cond_7
    iget v0, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->g:I

    iget p1, p1, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->g:I

    if-eq v0, p1, :cond_8

    goto :goto_1

    :cond_8
    :goto_0
    const/4 p1, 0x1

    return p1

    :cond_9
    :goto_1
    const/4 p1, 0x0

    return p1
.end method

.method public final g()Lm0/q;
    .locals 2

    new-instance v0, LS/k;

    invoke-direct {v0}, Lm0/q;-><init>()V

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->a:Ljava/lang/String;

    iput-object v1, v0, LS/k;->H:Ljava/lang/String;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->b:LW0/L;

    iput-object v1, v0, LS/k;->I:LW0/L;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->c:La1/l;

    iput-object v1, v0, LS/k;->J:La1/l;

    iget v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->d:I

    iput v1, v0, LS/k;->K:I

    iget-boolean v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->e:Z

    iput-boolean v1, v0, LS/k;->L:Z

    iget v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->f:I

    iput v1, v0, LS/k;->M:I

    iget v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->g:I

    iput v1, v0, LS/k;->N:I

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->h:Lt0/q;

    iput-object v1, v0, LS/k;->O:Lt0/q;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 11

    check-cast p1, LS/k;

    iget-object v0, p1, LS/k;->O:Lt0/q;

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->h:Lt0/q;

    invoke-static {v1, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    iput-object v1, p1, LS/k;->O:Lt0/q;

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v3, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->b:LW0/L;

    if-eqz v0, :cond_1

    iget-object v0, p1, LS/k;->I:LW0/L;

    if-eq v3, v0, :cond_0

    iget-object v4, v3, LW0/L;->a:LW0/D;

    iget-object v0, v0, LW0/L;->a:LW0/D;

    invoke-virtual {v4, v0}, LW0/D;->c(LW0/D;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_0
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_0
    move v0, v1

    goto :goto_1

    :cond_1
    move v0, v2

    :goto_1
    iget-object v4, p1, LS/k;->H:Ljava/lang/String;

    iget-object v5, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->a:Ljava/lang/String;

    invoke-static {v4, v5}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    goto :goto_2

    :cond_2
    iput-object v5, p1, LS/k;->H:Ljava/lang/String;

    const/4 v1, 0x0

    iput-object v1, p1, LS/k;->S:LS/j;

    move v1, v2

    :goto_2
    iget-object v4, p1, LS/k;->I:LW0/L;

    invoke-virtual {v4, v3}, LW0/L;->c(LW0/L;)Z

    move-result v4

    xor-int/2addr v4, v2

    iput-object v3, p1, LS/k;->I:LW0/L;

    iget v3, p1, LS/k;->N:I

    iget v5, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->g:I

    if-eq v3, v5, :cond_3

    iput v5, p1, LS/k;->N:I

    move v4, v2

    :cond_3
    iget v3, p1, LS/k;->M:I

    iget v5, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->f:I

    if-eq v3, v5, :cond_4

    iput v5, p1, LS/k;->M:I

    move v4, v2

    :cond_4
    iget-boolean v3, p1, LS/k;->L:Z

    iget-boolean v5, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->e:Z

    if-eq v3, v5, :cond_5

    iput-boolean v5, p1, LS/k;->L:Z

    move v4, v2

    :cond_5
    iget-object v3, p1, LS/k;->J:La1/l;

    iget-object v5, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->c:La1/l;

    invoke-static {v3, v5}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_6

    iput-object v5, p1, LS/k;->J:La1/l;

    move v4, v2

    :cond_6
    iget v3, p1, LS/k;->K:I

    iget v5, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->d:I

    if-ne v3, v5, :cond_7

    move v2, v4

    goto :goto_3

    :cond_7
    iput v5, p1, LS/k;->K:I

    :goto_3
    if-nez v1, :cond_8

    if-eqz v2, :cond_9

    :cond_8
    invoke-virtual {p1}, LS/k;->K0()LS/e;

    move-result-object v3

    iget-object v4, p1, LS/k;->H:Ljava/lang/String;

    iget-object v5, p1, LS/k;->I:LW0/L;

    iget-object v6, p1, LS/k;->J:La1/l;

    iget v7, p1, LS/k;->K:I

    iget-boolean v8, p1, LS/k;->L:Z

    iget v9, p1, LS/k;->M:I

    iget v10, p1, LS/k;->N:I

    iput-object v4, v3, LS/e;->a:Ljava/lang/String;

    iput-object v5, v3, LS/e;->b:LW0/L;

    iput-object v6, v3, LS/e;->c:La1/l;

    iput v7, v3, LS/e;->d:I

    iput-boolean v8, v3, LS/e;->e:Z

    iput v9, v3, LS/e;->f:I

    iput v10, v3, LS/e;->g:I

    iget-wide v4, v3, LS/e;->s:J

    const/4 v6, 0x2

    shl-long/2addr v4, v6

    const-wide/16 v6, 0x2

    or-long/2addr v4, v6

    iput-wide v4, v3, LS/e;->s:J

    invoke-virtual {v3}, LS/e;->c()V

    :cond_9
    iget-boolean v3, p1, Lm0/q;->G:Z

    if-nez v3, :cond_a

    goto :goto_4

    :cond_a
    if-nez v1, :cond_b

    if-eqz v0, :cond_c

    iget-object v3, p1, LS/k;->R:LS/i;

    if-eqz v3, :cond_c

    :cond_b
    invoke-static {p1}, LL0/f;->n(LL0/z0;)V

    :cond_c
    if-nez v1, :cond_d

    if-eqz v2, :cond_e

    :cond_d
    invoke-static {p1}, LL0/f;->m(LL0/z;)V

    invoke-static {p1}, LL0/f;->l(LL0/o;)V

    :cond_e
    if-eqz v0, :cond_f

    invoke-static {p1}, LL0/f;->l(LL0/o;)V

    :cond_f
    :goto_4
    return-void
.end method

.method public final hashCode()I
    .locals 3

    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget-object v2, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->b:LW0/L;

    invoke-virtual {v2}, LW0/L;->hashCode()I

    move-result v2

    add-int/2addr v2, v0

    mul-int/2addr v2, v1

    iget-object v0, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->c:La1/l;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget v2, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->d:I

    invoke-static {v2, v0, v1}, Lq3/h;->c(III)I

    move-result v0

    iget-boolean v2, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->e:Z

    invoke-static {v0, v1, v2}, Lq3/h;->e(IIZ)I

    move-result v0

    iget v2, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->f:I

    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget v2, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->g:I

    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object v1, p0, Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;->h:Lt0/q;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    add-int/2addr v0, v1

    return v0
.end method
