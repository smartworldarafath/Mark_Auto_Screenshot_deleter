.class public abstract Landroidx/compose/foundation/text/contextmenu/modifier/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Lm0/r;LE/S;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/text/contextmenu/modifier/AddTextContextMenuDataComponentsWithContextElement;

    invoke-direct {v0, p1}, Landroidx/compose/foundation/text/contextmenu/modifier/AddTextContextMenuDataComponentsWithContextElement;-><init>(LE/S;)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final b(LT/T;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureElement;

    invoke-direct {v0, p0}, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureElement;-><init>(LT/T;)V

    return-object v0
.end method

.method public static final c(Lm0/r;LA1/i;LT/T;LT/U;LI/z;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuToolbarHandlerElement;

    invoke-direct {v0, p1, p2, p3, p4}, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuToolbarHandlerElement;-><init>(LA1/i;LT/T;LT/U;LI/z;)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method
