.class public abstract Landroidx/compose/foundation/relocation/a;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lm0/r;LF/b;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;

    invoke-direct {v0, p1}, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;-><init>(LF/b;)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method
