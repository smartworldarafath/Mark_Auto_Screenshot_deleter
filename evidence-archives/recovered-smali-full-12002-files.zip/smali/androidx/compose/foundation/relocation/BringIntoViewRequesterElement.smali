.class final Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:LF/b;


# direct methods
.method public constructor <init>(LF/b;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;->a:LF/b;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    if-eq p0, p1, :cond_1

    instance-of v0, p1, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;

    if-eqz v0, :cond_0

    check-cast p1, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;

    iget-object p1, p1, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;->a:LF/b;

    iget-object v0, p0, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;->a:LF/b;

    invoke-static {v0, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    return p1
.end method

.method public final g()Lm0/q;
    .locals 2

    new-instance v0, LF/c;

    invoke-direct {v0}, Lm0/q;-><init>()V

    iget-object v1, p0, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;->a:LF/b;

    iput-object v1, v0, LF/c;->H:LF/b;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 2

    check-cast p1, LF/c;

    iget-object v0, p1, LF/c;->H:LF/b;

    if-eqz v0, :cond_0

    iget-object v0, v0, LF/b;->a:Lc0/e;

    invoke-virtual {v0, p1}, Lc0/e;->l(Ljava/lang/Object;)Z

    :cond_0
    iget-object v0, p0, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;->a:LF/b;

    if-eqz v0, :cond_1

    iget-object v1, v0, LF/b;->a:Lc0/e;

    invoke-virtual {v1, p1}, Lc0/e;->b(Ljava/lang/Object;)V

    :cond_1
    iput-object v0, p1, LF/c;->H:LF/b;

    return-void
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;->a:LF/b;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method
