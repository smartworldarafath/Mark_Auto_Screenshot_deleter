.class final Landroidx/compose/foundation/IndicationModifierElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Ly/j;

.field public final b:Lu/g0;


# direct methods
.method public constructor <init>(Ly/j;Lu/g0;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/IndicationModifierElement;->a:Ly/j;

    iput-object p2, p0, Landroidx/compose/foundation/IndicationModifierElement;->b:Lu/g0;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Landroidx/compose/foundation/IndicationModifierElement;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Landroidx/compose/foundation/IndicationModifierElement;

    iget-object v1, p1, Landroidx/compose/foundation/IndicationModifierElement;->a:Ly/j;

    iget-object v3, p0, Landroidx/compose/foundation/IndicationModifierElement;->a:Ly/j;

    invoke-static {v3, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget-object v1, p0, Landroidx/compose/foundation/IndicationModifierElement;->b:Lu/g0;

    iget-object p1, p1, Landroidx/compose/foundation/IndicationModifierElement;->b:Lu/g0;

    invoke-static {v1, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_3

    return v2

    :cond_3
    return v0
.end method

.method public final g()Lm0/q;
    .locals 3

    new-instance v0, Lu/f0;

    iget-object v1, p0, Landroidx/compose/foundation/IndicationModifierElement;->b:Lu/g0;

    iget-object v2, p0, Landroidx/compose/foundation/IndicationModifierElement;->a:Ly/j;

    invoke-interface {v1, v2}, Lu/g0;->a(Ly/j;)LL0/l;

    move-result-object v1

    invoke-direct {v0}, LL0/m;-><init>()V

    iput-object v1, v0, Lu/f0;->J:LL0/l;

    invoke-virtual {v0, v1}, LL0/m;->K0(LL0/l;)LL0/l;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 2

    check-cast p1, Lu/f0;

    iget-object v0, p0, Landroidx/compose/foundation/IndicationModifierElement;->b:Lu/g0;

    iget-object v1, p0, Landroidx/compose/foundation/IndicationModifierElement;->a:Ly/j;

    invoke-interface {v0, v1}, Lu/g0;->a(Ly/j;)LL0/l;

    move-result-object v0

    iget-object v1, p1, Lu/f0;->J:LL0/l;

    invoke-virtual {p1, v1}, LL0/m;->L0(LL0/l;)V

    iput-object v0, p1, Lu/f0;->J:LL0/l;

    invoke-virtual {p1, v0}, LL0/m;->K0(LL0/l;)LL0/l;

    return-void
.end method

.method public final hashCode()I
    .locals 2

    iget-object v0, p0, Landroidx/compose/foundation/IndicationModifierElement;->a:Ly/j;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Landroidx/compose/foundation/IndicationModifierElement;->b:Lu/g0;

    invoke-interface {v1}, Lu/g0;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method
