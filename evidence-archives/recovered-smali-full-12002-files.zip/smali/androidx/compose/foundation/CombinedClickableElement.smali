.class final Landroidx/compose/foundation/CombinedClickableElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Ly/j;

.field public final b:Z

.field public final c:Lr7/a;

.field public final d:Lr7/a;


# direct methods
.method public constructor <init>(Lr7/a;Lr7/a;Ly/j;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Landroidx/compose/foundation/CombinedClickableElement;->a:Ly/j;

    iput-boolean p4, p0, Landroidx/compose/foundation/CombinedClickableElement;->b:Z

    iput-object p1, p0, Landroidx/compose/foundation/CombinedClickableElement;->c:Lr7/a;

    iput-object p2, p0, Landroidx/compose/foundation/CombinedClickableElement;->d:Lr7/a;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    const-class v1, Landroidx/compose/foundation/CombinedClickableElement;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    if-eq v1, v2, :cond_2

    goto :goto_0

    :cond_2
    check-cast p1, Landroidx/compose/foundation/CombinedClickableElement;

    iget-object v1, p0, Landroidx/compose/foundation/CombinedClickableElement;->a:Ly/j;

    iget-object v2, p1, Landroidx/compose/foundation/CombinedClickableElement;->a:Ly/j;

    invoke-static {v1, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    goto :goto_0

    :cond_3
    iget-boolean v1, p0, Landroidx/compose/foundation/CombinedClickableElement;->b:Z

    iget-boolean v2, p1, Landroidx/compose/foundation/CombinedClickableElement;->b:Z

    if-eq v1, v2, :cond_4

    goto :goto_0

    :cond_4
    iget-object v1, p0, Landroidx/compose/foundation/CombinedClickableElement;->c:Lr7/a;

    iget-object v2, p1, Landroidx/compose/foundation/CombinedClickableElement;->c:Lr7/a;

    if-eq v1, v2, :cond_5

    goto :goto_0

    :cond_5
    iget-object v1, p0, Landroidx/compose/foundation/CombinedClickableElement;->d:Lr7/a;

    iget-object p1, p1, Landroidx/compose/foundation/CombinedClickableElement;->d:Lr7/a;

    if-eq v1, p1, :cond_6

    :goto_0
    const/4 p1, 0x0

    return p1

    :cond_6
    return v0
.end method

.method public final g()Lm0/q;
    .locals 5

    new-instance v0, Lu/H;

    iget-object v1, p0, Landroidx/compose/foundation/CombinedClickableElement;->a:Ly/j;

    iget-boolean v2, p0, Landroidx/compose/foundation/CombinedClickableElement;->b:Z

    iget-object v3, p0, Landroidx/compose/foundation/CombinedClickableElement;->c:Lr7/a;

    iget-object v4, p0, Landroidx/compose/foundation/CombinedClickableElement;->d:Lr7/a;

    invoke-direct {v0, v3, v4, v1, v2}, Lu/H;-><init>(Lr7/a;Lr7/a;Ly/j;Z)V

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 8

    move-object v0, p1

    check-cast v0, Lu/H;

    const/4 p1, 0x1

    iput-boolean p1, v0, Lu/H;->e0:Z

    iget-object v1, v0, Lu/H;->d0:Lr7/a;

    const/4 v2, 0x0

    if-nez v1, :cond_0

    move v1, p1

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    iget-object v3, p0, Landroidx/compose/foundation/CombinedClickableElement;->d:Lr7/a;

    if-nez v3, :cond_1

    move v4, p1

    goto :goto_1

    :cond_1
    move v4, v2

    :goto_1
    if-eq v1, v4, :cond_2

    invoke-virtual {v0}, Lu/p;->Q0()V

    invoke-static {v0}, LL0/f;->n(LL0/z0;)V

    move v2, p1

    :cond_2
    iput-object v3, v0, Lu/H;->d0:Lr7/a;

    iget-boolean v1, v0, Lu/p;->O:Z

    const/4 v4, 0x1

    if-eq v1, v4, :cond_3

    goto :goto_2

    :cond_3
    move p1, v2

    :goto_2
    iget-object v1, p0, Landroidx/compose/foundation/CombinedClickableElement;->a:Ly/j;

    const/4 v2, 0x0

    iget-boolean v3, p0, Landroidx/compose/foundation/CombinedClickableElement;->b:Z

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v7, p0, Landroidx/compose/foundation/CombinedClickableElement;->c:Lr7/a;

    invoke-virtual/range {v0 .. v7}, Lu/p;->W0(Ly/j;Lu/g0;ZZLjava/lang/String;LT0/g;Lr7/a;)V

    if-eqz p1, :cond_4

    iget-object p1, v0, Lu/p;->S:LF0/O;

    if-eqz p1, :cond_4

    invoke-virtual {p1}, LF0/O;->M0()V

    :cond_4
    return-void
.end method

.method public final hashCode()I
    .locals 4

    const/4 v0, 0x0

    iget-object v1, p0, Landroidx/compose/foundation/CombinedClickableElement;->a:Ly/j;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_0

    :cond_0
    move v1, v0

    :goto_0
    mul-int/lit16 v1, v1, 0x3c1

    iget-boolean v2, p0, Landroidx/compose/foundation/CombinedClickableElement;->b:Z

    const/16 v3, 0x1f

    invoke-static {v1, v3, v2}, Lq3/h;->e(IIZ)I

    move-result v1

    const/16 v2, 0x745f

    const/4 v3, 0x1

    invoke-static {v1, v2, v3}, Lq3/h;->e(IIZ)I

    move-result v1

    iget-object v2, p0, Landroidx/compose/foundation/CombinedClickableElement;->c:Lr7/a;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v2, v1

    mul-int/lit16 v2, v2, 0x3c1

    iget-object v1, p0, Landroidx/compose/foundation/CombinedClickableElement;->d:Lr7/a;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v0

    :cond_1
    add-int/2addr v2, v0

    mul-int/lit16 v2, v2, 0x3c1

    invoke-static {v3}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v0

    add-int/2addr v0, v2

    return v0
.end method
