.class public final Landroidx/compose/foundation/lazy/layout/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lp/H;

.field public b:LD4/f;

.field public c:I

.field public final d:Lp/I;

.field public final e:Ljava/util/ArrayList;

.field public final f:Ljava/util/ArrayList;

.field public final g:Ljava/util/ArrayList;

.field public final h:Ljava/util/ArrayList;

.field public final i:Ljava/util/ArrayList;

.field public j:LE/E;

.field public final k:Lm0/r;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Lp/P;->a:[J

    new-instance v0, Lp/H;

    invoke-direct {v0}, Lp/H;-><init>()V

    iput-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->a:Lp/H;

    sget-object v0, Lp/Q;->a:Lp/I;

    new-instance v0, Lp/I;

    invoke-direct {v0}, Lp/I;-><init>()V

    iput-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->d:Lp/I;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->e:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->f:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->g:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->h:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->i:Ljava/util/ArrayList;

    new-instance v0, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemAnimator$DisplayingDisappearingItemsElement;

    invoke-direct {v0, p0}, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemAnimator$DisplayingDisappearingItemsElement;-><init>(Landroidx/compose/foundation/lazy/layout/b;)V

    iput-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->k:Lm0/r;

    return-void
.end method

.method public static c(LE/U;ILE/G;)V
    .locals 10

    const/4 v0, 0x0

    invoke-interface {p0, v0}, LE/U;->i(I)J

    move-result-wide v1

    invoke-interface {p0}, LE/U;->g()Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x1

    invoke-static {v0, p1, v3, v1, v2}, Lj1/j;->a(IIIJ)J

    move-result-wide v3

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    invoke-static {p1, v0, v3, v1, v2}, Lj1/j;->a(IIIJ)J

    move-result-wide v3

    :goto_0
    iget-object p1, p2, LE/G;->a:[LE/C;

    array-length p2, p1

    move v5, v0

    :goto_1
    if-ge v0, p2, :cond_2

    aget-object v6, p1, v0

    add-int/lit8 v7, v5, 0x1

    if-eqz v6, :cond_1

    invoke-interface {p0, v5}, LE/U;->i(I)J

    move-result-wide v8

    invoke-static {v8, v9, v1, v2}, Lj1/j;->c(JJ)J

    move-result-wide v8

    invoke-static {v3, v4, v8, v9}, Lj1/j;->d(JJ)J

    move-result-wide v8

    iput-wide v8, v6, LE/C;->l:J

    :cond_1
    add-int/lit8 v0, v0, 0x1

    move v5, v7

    goto :goto_1

    :cond_2
    return-void
.end method

.method public static h([ILE/U;)I
    .locals 5

    invoke-interface {p1}, LE/U;->j()I

    move-result v0

    invoke-interface {p1}, LE/U;->d()I

    move-result v1

    add-int/2addr v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v0, v1, :cond_0

    aget v3, p0, v0

    invoke-interface {p1}, LE/U;->c()I

    move-result v4

    add-int/2addr v4, v3

    aput v4, p0, v0

    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    move-result v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return v2
.end method


# virtual methods
.method public final a(ILjava/lang/Object;)LE/C;
    .locals 1

    iget-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->a:Lp/H;

    invoke-virtual {v0, p2}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, LE/G;

    if-eqz p2, :cond_0

    iget-object p2, p2, LE/G;->a:[LE/C;

    aget-object p1, p2, p1

    return-object p1

    :cond_0
    const/4 p1, 0x0

    return-object p1
.end method

.method public final b()J
    .locals 13

    iget-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->i:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v1, :cond_1

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LE/C;

    iget-object v6, v5, LE/C;->n:Lw0/b;

    if-eqz v6, :cond_0

    const/16 v7, 0x20

    shr-long v8, v2, v7

    long-to-int v8, v8

    iget-wide v9, v5, LE/C;->l:J

    shr-long/2addr v9, v7

    long-to-int v9, v9

    iget-wide v10, v6, Lw0/b;->u:J

    shr-long/2addr v10, v7

    long-to-int v10, v10

    add-int/2addr v9, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I

    move-result v8

    const-wide v9, 0xffffffffL

    and-long/2addr v2, v9

    long-to-int v2, v2

    iget-wide v11, v5, LE/C;->l:J

    and-long/2addr v11, v9

    long-to-int v3, v11

    iget-wide v5, v6, Lw0/b;->u:J

    and-long/2addr v5, v9

    long-to-int v5, v5

    add-int/2addr v3, v5

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    int-to-long v5, v8

    shl-long/2addr v5, v7

    int-to-long v2, v2

    and-long/2addr v2, v9

    or-long/2addr v2, v5

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    return-wide v2
.end method

.method public final d(IIILjava/util/ArrayList;LD4/f;LE/V;ZIZIILD7/v;Lt0/t;)V
    .locals 48

    move-object/from16 v0, p0

    move-object/from16 v3, p4

    move-object/from16 v4, p5

    move/from16 v5, p8

    iget-object v6, v0, Landroidx/compose/foundation/lazy/layout/b;->b:LD4/f;

    iput-object v4, v0, Landroidx/compose/foundation/lazy/layout/b;->b:LD4/f;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v7

    const/4 v8, 0x0

    move v9, v8

    :goto_0
    iget-object v11, v0, Landroidx/compose/foundation/lazy/layout/b;->a:Lp/H;

    if-ge v9, v7, :cond_3

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, LE/U;

    invoke-interface {v12}, LE/U;->b()I

    move-result v13

    move v14, v8

    :goto_1
    if-ge v14, v13, :cond_2

    invoke-interface {v12, v14}, LE/U;->e(I)Ljava/lang/Object;

    move-result-object v15

    const/16 v16, 0x0

    instance-of v10, v15, LE/l;

    if-eqz v10, :cond_0

    move-object v10, v15

    check-cast v10, LE/l;

    goto :goto_2

    :cond_0
    move-object/from16 v10, v16

    :goto_2
    if-eqz v10, :cond_1

    goto :goto_3

    :cond_1
    add-int/lit8 v14, v14, 0x1

    goto :goto_1

    :cond_2
    add-int/lit8 v9, v9, 0x1

    goto :goto_0

    :cond_3
    const/16 v16, 0x0

    invoke-virtual {v11}, Lp/H;->i()Z

    move-result v7

    if-eqz v7, :cond_4

    invoke-virtual {v0}, Landroidx/compose/foundation/lazy/layout/b;->e()V

    return-void

    :cond_4
    :goto_3
    iget v7, v0, Landroidx/compose/foundation/lazy/layout/b;->c:I

    invoke-static {v3}, Le7/l;->w(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, LE/U;

    if-eqz v9, :cond_5

    invoke-interface {v9}, LE/U;->getIndex()I

    move-result v9

    goto :goto_4

    :cond_5
    move v9, v8

    :goto_4
    iput v9, v0, Landroidx/compose/foundation/lazy/layout/b;->c:I

    int-to-long v9, v8

    const/16 v12, 0x20

    shl-long/2addr v9, v12

    move/from16 v13, p1

    int-to-long v13, v13

    const-wide v17, 0xffffffffL

    and-long v13, v13, v17

    or-long/2addr v9, v13

    if-nez p7, :cond_7

    if-nez p9, :cond_6

    goto :goto_5

    :cond_6
    move v14, v8

    goto :goto_6

    :cond_7
    :goto_5
    const/4 v14, 0x1

    :goto_6
    iget-object v15, v11, Lp/H;->b:[Ljava/lang/Object;

    move/from16 v19, v12

    iget-object v12, v11, Lp/H;->a:[J

    array-length v13, v12

    add-int/lit8 v13, v13, -0x2

    const-wide/16 v20, 0x80

    const-wide/16 v22, 0xff

    const/16 v24, 0x7

    iget-object v8, v0, Landroidx/compose/foundation/lazy/layout/b;->d:Lp/I;

    const-wide v25, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    move-object/from16 p9, v12

    move/from16 v28, v14

    if-ltz v13, :cond_b

    move-object/from16 v29, v15

    const/4 v12, 0x0

    :goto_7
    const/16 v27, 0x8

    aget-wide v14, p9, v12

    not-long v1, v14

    shl-long v1, v1, v24

    and-long/2addr v1, v14

    and-long v1, v1, v25

    cmp-long v1, v1, v25

    if-eqz v1, :cond_a

    sub-int v1, v12, v13

    not-int v1, v1

    ushr-int/lit8 v1, v1, 0x1f

    rsub-int/lit8 v1, v1, 0x8

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v1, :cond_9

    and-long v30, v14, v22

    cmp-long v30, v30, v20

    if-gez v30, :cond_8

    shl-int/lit8 v30, v12, 0x3

    add-int v30, v30, v2

    move/from16 v31, v2

    aget-object v2, v29, v30

    invoke-virtual {v8, v2}, Lp/I;->a(Ljava/lang/Object;)Z

    goto :goto_9

    :cond_8
    move/from16 v31, v2

    :goto_9
    shr-long v14, v14, v27

    add-int/lit8 v2, v31, 0x1

    goto :goto_8

    :cond_9
    move/from16 v2, v27

    if-ne v1, v2, :cond_b

    :cond_a
    if-eq v12, v13, :cond_b

    add-int/lit8 v12, v12, 0x1

    goto :goto_7

    :cond_b
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_a
    iget-object v12, v0, Landroidx/compose/foundation/lazy/layout/b;->i:Ljava/util/ArrayList;

    iget-object v14, v0, Landroidx/compose/foundation/lazy/layout/b;->f:Ljava/util/ArrayList;

    iget-object v15, v0, Landroidx/compose/foundation/lazy/layout/b;->e:Ljava/util/ArrayList;

    if-ge v2, v1, :cond_1c

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v29

    move-object/from16 v13, v29

    check-cast v13, LE/U;

    move/from16 v29, v1

    invoke-interface {v13}, LE/U;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v8, v1}, Lp/I;->l(Ljava/lang/Object;)Z

    invoke-interface {v13}, LE/U;->b()I

    move-result v1

    move/from16 v36, v2

    const/4 v2, 0x0

    :goto_b
    if-ge v2, v1, :cond_1a

    move/from16 v30, v1

    invoke-interface {v13, v2}, LE/U;->e(I)Ljava/lang/Object;

    move-result-object v1

    move/from16 v31, v2

    instance-of v2, v1, LE/l;

    if-eqz v2, :cond_c

    check-cast v1, LE/l;

    goto :goto_c

    :cond_c
    move-object/from16 v1, v16

    :goto_c
    if-eqz v1, :cond_19

    invoke-interface {v13}, LE/U;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v11, v1}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v30, v1

    check-cast v30, LE/G;

    if-eqz v6, :cond_d

    invoke-interface {v13}, LE/U;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v6, v1}, LD4/f;->f(Ljava/lang/Object;)I

    move-result v1

    :goto_d
    const/4 v2, -0x1

    goto :goto_e

    :cond_d
    const/4 v1, -0x1

    goto :goto_d

    :goto_e
    if-ne v1, v2, :cond_e

    if-eqz v6, :cond_e

    const/4 v2, 0x1

    goto :goto_f

    :cond_e
    const/4 v2, 0x0

    :goto_f
    if-nez v30, :cond_13

    new-instance v12, LE/G;

    invoke-direct {v12, v0}, LE/G;-><init>(Landroidx/compose/foundation/lazy/layout/b;)V

    move/from16 v34, p10

    move/from16 v35, p11

    move-object/from16 v32, p12

    move-object/from16 v33, p13

    move-object/from16 v30, v12

    move-object/from16 v31, v13

    invoke-static/range {v30 .. v35}, LE/G;->b(LE/G;LE/U;LD7/v;Lt0/t;II)V

    move/from16 v37, v2

    invoke-interface {v13}, LE/U;->getKey()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v11, v2, v12}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v13}, LE/U;->getIndex()I

    move-result v2

    if-eq v2, v1, :cond_10

    const/4 v2, -0x1

    if-eq v1, v2, :cond_10

    if-ge v1, v7, :cond_f

    invoke-virtual {v15, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_15

    :cond_f
    invoke-virtual {v14, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_15

    :cond_10
    const/4 v1, 0x0

    invoke-interface {v13, v1}, LE/U;->i(I)J

    move-result-wide v14

    invoke-interface {v13}, LE/U;->g()Z

    move-result v1

    if-eqz v1, :cond_11

    and-long v1, v14, v17

    :goto_10
    long-to-int v1, v1

    goto :goto_11

    :cond_11
    shr-long v1, v14, v19

    goto :goto_10

    :goto_11
    invoke-static {v13, v1, v12}, Landroidx/compose/foundation/lazy/layout/b;->c(LE/U;ILE/G;)V

    if-eqz v37, :cond_1b

    iget-object v1, v12, LE/G;->a:[LE/C;

    array-length v2, v1

    const/4 v12, 0x0

    :goto_12
    if-ge v12, v2, :cond_1b

    aget-object v13, v1, v12

    if-eqz v13, :cond_12

    invoke-virtual {v13}, LE/C;->a()V

    :cond_12
    add-int/lit8 v12, v12, 0x1

    goto :goto_12

    :cond_13
    move/from16 v37, v2

    if-eqz v28, :cond_1b

    move/from16 v34, p10

    move/from16 v35, p11

    move-object/from16 v32, p12

    move-object/from16 v33, p13

    move-object/from16 v31, v13

    invoke-static/range {v30 .. v35}, LE/G;->b(LE/G;LE/U;LD7/v;Lt0/t;II)V

    move-object/from16 v1, v30

    iget-object v2, v1, LE/G;->a:[LE/C;

    array-length v14, v2

    const/4 v15, 0x0

    :goto_13
    if-ge v15, v14, :cond_15

    move-object/from16 v30, v2

    aget-object v2, v30, v15

    move/from16 v31, v14

    move/from16 v32, v15

    if-eqz v2, :cond_14

    iget-wide v14, v2, LE/C;->l:J

    sget-wide v3, LE/C;->s:J

    invoke-static {v14, v15, v3, v4}, Lj1/j;->b(JJ)Z

    move-result v3

    if-nez v3, :cond_14

    iget-wide v3, v2, LE/C;->l:J

    invoke-static {v3, v4, v9, v10}, Lj1/j;->d(JJ)J

    move-result-wide v3

    iput-wide v3, v2, LE/C;->l:J

    :cond_14
    add-int/lit8 v15, v32, 0x1

    move-object/from16 v3, p4

    move-object/from16 v4, p5

    move-object/from16 v2, v30

    move/from16 v14, v31

    goto :goto_13

    :cond_15
    if-eqz v37, :cond_18

    iget-object v1, v1, LE/G;->a:[LE/C;

    array-length v2, v1

    const/4 v3, 0x0

    :goto_14
    if-ge v3, v2, :cond_18

    aget-object v4, v1, v3

    if-eqz v4, :cond_17

    invoke-virtual {v4}, LE/C;->b()Z

    move-result v14

    if-eqz v14, :cond_16

    invoke-virtual {v12, v4}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v14, v0, Landroidx/compose/foundation/lazy/layout/b;->j:LE/E;

    if-eqz v14, :cond_16

    invoke-static {v14}, LL0/f;->l(LL0/o;)V

    :cond_16
    invoke-virtual {v4}, LE/C;->a()V

    :cond_17
    add-int/lit8 v3, v3, 0x1

    goto :goto_14

    :cond_18
    const/4 v1, 0x0

    invoke-virtual {v0, v13, v1}, Landroidx/compose/foundation/lazy/layout/b;->g(LE/U;Z)V

    goto :goto_15

    :cond_19
    add-int/lit8 v2, v31, 0x1

    move-object/from16 v3, p4

    move-object/from16 v4, p5

    move/from16 v1, v30

    goto/16 :goto_b

    :cond_1a
    invoke-interface {v13}, LE/U;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/compose/foundation/lazy/layout/b;->f(Ljava/lang/Object;)V

    :cond_1b
    :goto_15
    add-int/lit8 v2, v36, 0x1

    move-object/from16 v3, p4

    move-object/from16 v4, p5

    move/from16 v1, v29

    goto/16 :goto_a

    :cond_1c
    new-array v1, v5, [I

    if-eqz v28, :cond_22

    if-eqz v6, :cond_22

    invoke-virtual {v15}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_1f

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-le v2, v3, :cond_1d

    new-instance v2, LE/H;

    const/4 v3, 0x2

    invoke-direct {v2, v6, v3}, LE/H;-><init>(LD4/f;I)V

    invoke-static {v15, v2}, Le7/q;->n(Ljava/util/List;Ljava/util/Comparator;)V

    :cond_1d
    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x0

    :goto_16
    if-ge v3, v2, :cond_1e

    invoke-virtual {v15, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LE/U;

    invoke-static {v1, v4}, Landroidx/compose/foundation/lazy/layout/b;->h([ILE/U;)I

    move-result v7

    sub-int v7, p10, v7

    invoke-interface {v4}, LE/U;->getKey()Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v11, v9}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    invoke-static {v9}, Ls7/j;->b(Ljava/lang/Object;)V

    check-cast v9, LE/G;

    invoke-static {v4, v7, v9}, Landroidx/compose/foundation/lazy/layout/b;->c(LE/U;ILE/G;)V

    const/4 v7, 0x0

    invoke-virtual {v0, v4, v7}, Landroidx/compose/foundation/lazy/layout/b;->g(LE/U;Z)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_16

    :cond_1e
    const/4 v7, 0x0

    invoke-static {v1, v7, v5, v7}, Ljava/util/Arrays;->fill([IIII)V

    :cond_1f
    invoke-virtual {v14}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_22

    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-le v2, v3, :cond_20

    new-instance v2, LE/H;

    const/4 v3, 0x0

    invoke-direct {v2, v6, v3}, LE/H;-><init>(LD4/f;I)V

    invoke-static {v14, v2}, Le7/q;->n(Ljava/util/List;Ljava/util/Comparator;)V

    :cond_20
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x0

    :goto_17
    if-ge v3, v2, :cond_21

    invoke-virtual {v14, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LE/U;

    invoke-static {v1, v4}, Landroidx/compose/foundation/lazy/layout/b;->h([ILE/U;)I

    move-result v7

    add-int v7, v7, p11

    invoke-interface {v4}, LE/U;->c()I

    move-result v9

    sub-int/2addr v7, v9

    invoke-interface {v4}, LE/U;->getKey()Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v11, v9}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    invoke-static {v9}, Ls7/j;->b(Ljava/lang/Object;)V

    check-cast v9, LE/G;

    invoke-static {v4, v7, v9}, Landroidx/compose/foundation/lazy/layout/b;->c(LE/U;ILE/G;)V

    const/4 v7, 0x0

    invoke-virtual {v0, v4, v7}, Landroidx/compose/foundation/lazy/layout/b;->g(LE/U;Z)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_17

    :cond_21
    const/4 v7, 0x0

    invoke-static {v1, v7, v5, v7}, Ljava/util/Arrays;->fill([IIII)V

    :cond_22
    iget-object v2, v8, Lp/I;->b:[Ljava/lang/Object;

    iget-object v3, v8, Lp/I;->a:[J

    array-length v4, v3

    add-int/lit8 v4, v4, -0x2

    iget-object v7, v0, Landroidx/compose/foundation/lazy/layout/b;->h:Ljava/util/ArrayList;

    iget-object v9, v0, Landroidx/compose/foundation/lazy/layout/b;->g:Ljava/util/ArrayList;

    if-ltz v4, :cond_37

    move-object v13, v2

    move-object/from16 v29, v3

    const/4 v10, 0x0

    :goto_18
    aget-wide v2, v29, v10

    move-object/from16 v31, v13

    move-object/from16 v30, v14

    not-long v13, v2

    shl-long v13, v13, v24

    and-long/2addr v13, v2

    and-long v13, v13, v25

    cmp-long v13, v13, v25

    if-eqz v13, :cond_36

    sub-int v13, v10, v4

    not-int v13, v13

    ushr-int/lit8 v13, v13, 0x1f

    const/16 v27, 0x8

    rsub-int/lit8 v13, v13, 0x8

    const/4 v14, 0x0

    :goto_19
    if-ge v14, v13, :cond_35

    and-long v32, v2, v22

    cmp-long v32, v32, v20

    if-gez v32, :cond_34

    shl-int/lit8 v32, v10, 0x3

    add-int v32, v32, v14

    move-wide/from16 v33, v2

    aget-object v2, v31, v32

    invoke-virtual {v11, v2}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LE/G;

    if-nez v3, :cond_23

    move-object/from16 v46, v1

    goto/16 :goto_22

    :cond_23
    move-object/from16 v32, v8

    move/from16 v44, v14

    move-object/from16 v8, p5

    invoke-virtual {v8, v2}, LD4/f;->f(Ljava/lang/Object;)I

    move-result v14

    move-object/from16 v45, v15

    iget v15, v3, LE/G;->e:I

    invoke-static {v5, v15}, Ljava/lang/Math;->min(II)I

    move-result v15

    iput v15, v3, LE/G;->e:I

    sub-int v15, v5, v15

    iget v5, v3, LE/G;->d:I

    invoke-static {v15, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    iput v5, v3, LE/G;->d:I

    const/4 v5, -0x1

    if-ne v14, v5, :cond_2f

    iget-object v14, v3, LE/G;->a:[LE/C;

    array-length v15, v14

    const/4 v5, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    :goto_1a
    if-ge v5, v15, :cond_2d

    move/from16 v37, v5

    aget-object v5, v14, v37

    add-int/lit8 v38, v36, 0x1

    if-eqz v5, :cond_2c

    invoke-virtual {v5}, LE/C;->b()Z

    move-result v39

    if-eqz v39, :cond_24

    move-object/from16 v46, v1

    move-object/from16 v47, v11

    move-object/from16 v39, v14

    move/from16 v40, v15

    goto/16 :goto_1c

    :cond_24
    move-object/from16 v39, v14

    iget-object v14, v5, LE/C;->k:La0/h0;

    invoke-virtual {v14}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/Boolean;

    invoke-virtual {v14}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v14

    if-eqz v14, :cond_26

    invoke-virtual {v5}, LE/C;->c()V

    iget-object v14, v3, LE/G;->a:[LE/C;

    aput-object v16, v14, v36

    invoke-virtual {v12, v5}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v5, v0, Landroidx/compose/foundation/lazy/layout/b;->j:LE/E;

    if-eqz v5, :cond_25

    invoke-static {v5}, LL0/f;->l(LL0/o;)V

    :cond_25
    move-object/from16 v46, v1

    move-object/from16 v47, v11

    goto :goto_1d

    :cond_26
    iget-object v14, v5, LE/C;->n:Lw0/b;

    if-eqz v14, :cond_29

    move/from16 v40, v15

    iget-object v15, v5, LE/C;->f:Ls/z;

    invoke-virtual {v5}, LE/C;->b()Z

    move-result v41

    if-nez v41, :cond_27

    if-nez v15, :cond_28

    :cond_27
    move-object/from16 v46, v1

    move-object/from16 v47, v11

    goto :goto_1b

    :cond_28
    move-object/from16 v46, v1

    const/4 v1, 0x1

    invoke-virtual {v5, v1}, LE/C;->e(Z)V

    iget-object v1, v5, LE/C;->a:LD7/v;

    move-object/from16 v47, v11

    new-instance v11, LE/v;

    move-object/from16 v8, v16

    invoke-direct {v11, v5, v15, v14, v8}, LE/v;-><init>(LE/C;Ls/z;Lw0/b;Lh7/c;)V

    const/4 v14, 0x3

    invoke-static {v1, v8, v8, v11, v14}, LD7/y;->x(LD7/v;Lh7/h;LD7/w;Lr7/e;I)LD7/B;

    goto :goto_1b

    :cond_29
    move-object/from16 v46, v1

    move-object/from16 v47, v11

    move/from16 v40, v15

    :goto_1b
    invoke-virtual {v5}, LE/C;->b()Z

    move-result v1

    if-eqz v1, :cond_2b

    invoke-virtual {v12, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, v0, Landroidx/compose/foundation/lazy/layout/b;->j:LE/E;

    if-eqz v1, :cond_2a

    invoke-static {v1}, LL0/f;->l(LL0/o;)V

    :cond_2a
    const/16 v16, 0x0

    :goto_1c
    const/16 v35, 0x1

    goto :goto_1e

    :cond_2b
    invoke-virtual {v5}, LE/C;->c()V

    iget-object v1, v3, LE/G;->a:[LE/C;

    const/16 v16, 0x0

    aput-object v16, v1, v36

    goto :goto_1e

    :cond_2c
    move-object/from16 v46, v1

    move-object/from16 v47, v11

    move-object/from16 v39, v14

    :goto_1d
    move/from16 v40, v15

    :goto_1e
    add-int/lit8 v5, v37, 0x1

    move-object/from16 v8, p5

    move/from16 v36, v38

    move-object/from16 v14, v39

    move/from16 v15, v40

    move-object/from16 v1, v46

    move-object/from16 v11, v47

    goto/16 :goto_1a

    :cond_2d
    move-object/from16 v46, v1

    move-object/from16 v47, v11

    if-nez v35, :cond_2e

    invoke-virtual {v0, v2}, Landroidx/compose/foundation/lazy/layout/b;->f(Ljava/lang/Object;)V

    :cond_2e
    move-object v5, v12

    goto/16 :goto_21

    :cond_2f
    move-object/from16 v46, v1

    move-object/from16 v47, v11

    iget-object v1, v3, LE/G;->b:Lj1/a;

    invoke-static {v1}, Ls7/j;->b(Ljava/lang/Object;)V

    move-object v5, v12

    iget-wide v11, v1, Lj1/a;->a:J

    iget v1, v3, LE/G;->d:I

    iget v8, v3, LE/G;->e:I

    move-object/from16 v35, p6

    move/from16 v37, v1

    move/from16 v38, v8

    move-wide/from16 v39, v11

    move/from16 v36, v14

    invoke-virtual/range {v35 .. v40}, LE/V;->q(IIIJ)LE/U;

    move-result-object v38

    move/from16 v1, v36

    invoke-interface/range {v38 .. v38}, LE/U;->h()V

    iget-object v8, v3, LE/G;->a:[LE/C;

    array-length v11, v8

    const/4 v12, 0x0

    :goto_1f
    if-ge v12, v11, :cond_31

    aget-object v14, v8, v12

    if-eqz v14, :cond_30

    iget-object v14, v14, LE/C;->h:La0/h0;

    invoke-virtual {v14}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/Boolean;

    invoke-virtual {v14}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v14

    const/4 v15, 0x1

    if-ne v14, v15, :cond_30

    goto :goto_20

    :cond_30
    add-int/lit8 v12, v12, 0x1

    goto :goto_1f

    :cond_31
    if-eqz v6, :cond_32

    invoke-virtual {v6, v2}, LD4/f;->f(Ljava/lang/Object;)I

    move-result v8

    if-ne v1, v8, :cond_32

    invoke-virtual {v0, v2}, Landroidx/compose/foundation/lazy/layout/b;->f(Ljava/lang/Object;)V

    goto :goto_21

    :cond_32
    :goto_20
    iget v2, v3, LE/G;->c:I

    move/from16 v41, p10

    move/from16 v42, p11

    move-object/from16 v39, p12

    move-object/from16 v40, p13

    move/from16 v43, v2

    move-object/from16 v37, v3

    invoke-virtual/range {v37 .. v43}, LE/G;->a(LE/U;LD7/v;Lt0/t;III)V

    move-object/from16 v2, v38

    iget v3, v0, Landroidx/compose/foundation/lazy/layout/b;->c:I

    if-ge v1, v3, :cond_33

    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_21

    :cond_33
    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_21
    const/16 v2, 0x8

    goto :goto_23

    :cond_34
    move-object/from16 v46, v1

    move-wide/from16 v33, v2

    :goto_22
    move-object/from16 v32, v8

    move-object/from16 v47, v11

    move-object v5, v12

    move/from16 v44, v14

    move-object/from16 v45, v15

    goto :goto_21

    :goto_23
    shr-long v11, v33, v2

    add-int/lit8 v14, v44, 0x1

    move-wide v2, v11

    move-object/from16 v8, v32

    move-object/from16 v15, v45

    move-object/from16 v1, v46

    move-object/from16 v11, v47

    move-object v12, v5

    move/from16 v5, p8

    goto/16 :goto_19

    :cond_35
    move-object/from16 v46, v1

    move-object/from16 v32, v8

    move-object/from16 v47, v11

    move-object v5, v12

    move-object/from16 v45, v15

    const/16 v2, 0x8

    if-ne v13, v2, :cond_38

    goto :goto_24

    :cond_36
    move-object/from16 v46, v1

    move-object/from16 v32, v8

    move-object/from16 v47, v11

    move-object v5, v12

    move-object/from16 v45, v15

    const/16 v2, 0x8

    :goto_24
    if-eq v10, v4, :cond_38

    add-int/lit8 v10, v10, 0x1

    move-object v12, v5

    move-object/from16 v14, v30

    move-object/from16 v13, v31

    move-object/from16 v8, v32

    move-object/from16 v15, v45

    move-object/from16 v1, v46

    move-object/from16 v11, v47

    move/from16 v5, p8

    goto/16 :goto_18

    :cond_37
    move-object/from16 v46, v1

    move-object/from16 v32, v8

    move-object/from16 v47, v11

    move-object/from16 v30, v14

    move-object/from16 v45, v15

    :cond_38
    invoke-virtual {v9}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_3e

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x1

    if-le v1, v3, :cond_39

    new-instance v1, LE/H;

    const/4 v2, 0x3

    move-object/from16 v4, p5

    invoke-direct {v1, v4, v2}, LE/H;-><init>(LD4/f;I)V

    invoke-static {v9, v1}, Le7/q;->n(Ljava/util/List;Ljava/util/Comparator;)V

    goto :goto_25

    :cond_39
    move-object/from16 v4, p5

    :goto_25
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_26
    if-ge v2, v1, :cond_3d

    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LE/U;

    invoke-interface {v3}, LE/U;->getKey()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v6, v47

    invoke-virtual {v6, v5}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v5}, Ls7/j;->b(Ljava/lang/Object;)V

    check-cast v5, LE/G;

    move-object/from16 v8, v46

    invoke-static {v8, v3}, Landroidx/compose/foundation/lazy/layout/b;->h([ILE/U;)I

    move-result v10

    if-eqz p7, :cond_3b

    invoke-static/range {p4 .. p4}, Le7/l;->v(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, LE/U;

    const/4 v12, 0x0

    invoke-interface {v11, v12}, LE/U;->i(I)J

    move-result-wide v13

    invoke-interface {v11}, LE/U;->g()Z

    move-result v11

    if-eqz v11, :cond_3a

    and-long v11, v13, v17

    :goto_27
    long-to-int v11, v11

    goto :goto_28

    :cond_3a
    shr-long v11, v13, v19

    goto :goto_27

    :cond_3b
    iget v11, v5, LE/G;->f:I

    :goto_28
    sub-int/2addr v11, v10

    iget v5, v5, LE/G;->c:I

    move/from16 v10, p2

    move/from16 v12, p3

    invoke-interface {v3, v11, v5, v10, v12}, LE/U;->k(IIII)V

    if-eqz v28, :cond_3c

    const/4 v15, 0x1

    invoke-virtual {v0, v3, v15}, Landroidx/compose/foundation/lazy/layout/b;->g(LE/U;Z)V

    :cond_3c
    add-int/lit8 v2, v2, 0x1

    move-object/from16 v47, v6

    move-object/from16 v46, v8

    goto :goto_26

    :cond_3d
    move/from16 v10, p2

    move/from16 v12, p3

    move/from16 v5, p8

    move-object/from16 v8, v46

    move-object/from16 v6, v47

    const/4 v2, 0x0

    invoke-static {v8, v2, v5, v2}, Ljava/util/Arrays;->fill([IIII)V

    goto :goto_29

    :cond_3e
    move/from16 v10, p2

    move/from16 v12, p3

    move-object/from16 v4, p5

    move-object/from16 v8, v46

    move-object/from16 v6, v47

    :goto_29
    invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_43

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x1

    if-le v1, v3, :cond_3f

    new-instance v1, LE/H;

    const/4 v2, 0x1

    invoke-direct {v1, v4, v2}, LE/H;-><init>(LD4/f;I)V

    invoke-static {v7, v1}, Le7/q;->n(Ljava/util/List;Ljava/util/Comparator;)V

    :cond_3f
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_2a
    if-ge v2, v1, :cond_43

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LE/U;

    invoke-interface {v3}, LE/U;->getKey()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v6, v4}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Ls7/j;->b(Ljava/lang/Object;)V

    check-cast v4, LE/G;

    invoke-static {v8, v3}, Landroidx/compose/foundation/lazy/layout/b;->h([ILE/U;)I

    move-result v5

    if-eqz p7, :cond_41

    invoke-static/range {p4 .. p4}, Le7/l;->B(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, LE/U;

    const/4 v13, 0x0

    invoke-interface {v11, v13}, LE/U;->i(I)J

    move-result-wide v14

    invoke-interface {v11}, LE/U;->g()Z

    move-result v13

    if-eqz v13, :cond_40

    and-long v13, v14, v17

    :goto_2b
    long-to-int v13, v13

    goto :goto_2c

    :cond_40
    shr-long v13, v14, v19

    goto :goto_2b

    :goto_2c
    invoke-interface {v11}, LE/U;->c()I

    move-result v11

    add-int/2addr v11, v13

    goto :goto_2d

    :cond_41
    iget v11, v4, LE/G;->g:I

    :goto_2d
    invoke-interface {v3}, LE/U;->c()I

    move-result v13

    sub-int/2addr v11, v13

    add-int/2addr v11, v5

    iget v4, v4, LE/G;->c:I

    invoke-interface {v3, v11, v4, v10, v12}, LE/U;->k(IIII)V

    const/4 v15, 0x1

    if-eqz v28, :cond_42

    invoke-virtual {v0, v3, v15}, Landroidx/compose/foundation/lazy/layout/b;->g(LE/U;Z)V

    :cond_42
    add-int/lit8 v2, v2, 0x1

    goto :goto_2a

    :cond_43
    invoke-static {v9}, Ljava/util/Collections;->reverse(Ljava/util/List;)V

    move-object/from16 v3, p4

    const/4 v1, 0x0

    invoke-virtual {v3, v1, v9}, Ljava/util/ArrayList;->addAll(ILjava/util/Collection;)Z

    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual/range {v45 .. v45}, Ljava/util/ArrayList;->clear()V

    invoke-virtual/range {v30 .. v30}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v9}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v7}, Ljava/util/ArrayList;->clear()V

    invoke-virtual/range {v32 .. v32}, Lp/I;->b()V

    return-void
.end method

.method public final e()V
    .locals 15

    iget-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->a:Lp/H;

    invoke-virtual {v0}, Lp/H;->j()Z

    move-result v1

    if-eqz v1, :cond_5

    iget-object v1, v0, Lp/H;->c:[Ljava/lang/Object;

    iget-object v2, v0, Lp/H;->a:[J

    array-length v3, v2

    add-int/lit8 v3, v3, -0x2

    if-ltz v3, :cond_4

    const/4 v4, 0x0

    move v5, v4

    :goto_0
    aget-wide v6, v2, v5

    not-long v8, v6

    const/4 v10, 0x7

    shl-long/2addr v8, v10

    and-long/2addr v8, v6

    const-wide v10, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    and-long/2addr v8, v10

    cmp-long v8, v8, v10

    if-eqz v8, :cond_3

    sub-int v8, v5, v3

    not-int v8, v8

    ushr-int/lit8 v8, v8, 0x1f

    const/16 v9, 0x8

    rsub-int/lit8 v8, v8, 0x8

    move v10, v4

    :goto_1
    if-ge v10, v8, :cond_2

    const-wide/16 v11, 0xff

    and-long/2addr v11, v6

    const-wide/16 v13, 0x80

    cmp-long v11, v11, v13

    if-gez v11, :cond_1

    shl-int/lit8 v11, v5, 0x3

    add-int/2addr v11, v10

    aget-object v11, v1, v11

    check-cast v11, LE/G;

    iget-object v11, v11, LE/G;->a:[LE/C;

    array-length v12, v11

    move v13, v4

    :goto_2
    if-ge v13, v12, :cond_1

    aget-object v14, v11, v13

    if-eqz v14, :cond_0

    invoke-virtual {v14}, LE/C;->c()V

    :cond_0
    add-int/lit8 v13, v13, 0x1

    goto :goto_2

    :cond_1
    shr-long/2addr v6, v9

    add-int/lit8 v10, v10, 0x1

    goto :goto_1

    :cond_2
    if-ne v8, v9, :cond_4

    :cond_3
    if-eq v5, v3, :cond_4

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_4
    invoke-virtual {v0}, Lp/H;->a()V

    :cond_5
    return-void
.end method

.method public final f(Ljava/lang/Object;)V
    .locals 3

    iget-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->a:Lp/H;

    invoke-virtual {v0, p1}, Lp/H;->k(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LE/G;

    if-eqz p1, :cond_1

    iget-object p1, p1, LE/G;->a:[LE/C;

    if-eqz p1, :cond_1

    array-length v0, p1

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    aget-object v2, p1, v1

    if-eqz v2, :cond_0

    invoke-virtual {v2}, LE/C;->c()V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final g(LE/U;Z)V
    .locals 13

    iget-object v0, p0, Landroidx/compose/foundation/lazy/layout/b;->a:Lp/H;

    invoke-interface {p1}, LE/U;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Ls7/j;->b(Ljava/lang/Object;)V

    check-cast v0, LE/G;

    iget-object v0, v0, LE/G;->a:[LE/C;

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v2, v1, :cond_3

    aget-object v5, v0, v2

    add-int/lit8 v10, v3, 0x1

    if-eqz v5, :cond_2

    invoke-interface {p1, v3}, LE/U;->i(I)J

    move-result-wide v11

    iget-wide v3, v5, LE/C;->l:J

    sget-wide v6, LE/C;->s:J

    invoke-static {v3, v4, v6, v7}, Lj1/j;->b(JJ)Z

    move-result v6

    if-nez v6, :cond_1

    invoke-static {v3, v4, v11, v12}, Lj1/j;->b(JJ)Z

    move-result v6

    if-nez v6, :cond_1

    invoke-static {v11, v12, v3, v4}, Lj1/j;->c(JJ)J

    move-result-wide v3

    iget-object v6, v5, LE/C;->e:Ls/z;

    if-nez v6, :cond_0

    goto :goto_1

    :cond_0
    iget-object v7, v5, LE/C;->q:La0/h0;

    invoke-virtual {v7}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lj1/j;

    iget-wide v7, v7, Lj1/j;->a:J

    invoke-static {v7, v8, v3, v4}, Lj1/j;->c(JJ)J

    move-result-wide v7

    invoke-virtual {v5, v7, v8}, LE/C;->g(J)V

    const/4 v3, 0x1

    invoke-virtual {v5, v3}, LE/C;->f(Z)V

    iput-boolean p2, v5, LE/C;->g:Z

    iget-object v3, v5, LE/C;->a:LD7/v;

    new-instance v4, LE/x;

    const/4 v9, 0x0

    invoke-direct/range {v4 .. v9}, LE/x;-><init>(LE/C;Ls/z;JLh7/c;)V

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v3, v7, v7, v4, v6}, LD7/y;->x(LD7/v;Lh7/h;LD7/w;Lr7/e;I)LD7/B;

    :cond_1
    :goto_1
    iput-wide v11, v5, LE/C;->l:J

    :cond_2
    add-int/lit8 v2, v2, 0x1

    move v3, v10

    goto :goto_0

    :cond_3
    return-void
.end method
