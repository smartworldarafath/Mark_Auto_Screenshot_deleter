.class public final Landroidx/compose/foundation/lazy/layout/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/f;


# instance fields
.field public final synthetic t:LE/d0;

.field public final synthetic u:Lm0/r;

.field public final synthetic v:LC/p;

.field public final synthetic w:La0/Z;


# direct methods
.method public constructor <init>(LE/d0;Lm0/r;LC/p;La0/Z;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/lazy/layout/c;->t:LE/d0;

    iput-object p2, p0, Landroidx/compose/foundation/lazy/layout/c;->u:Lm0/r;

    iput-object p3, p0, Landroidx/compose/foundation/lazy/layout/c;->v:LC/p;

    iput-object p4, p0, Landroidx/compose/foundation/lazy/layout/c;->w:La0/Z;

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    check-cast p1, Lj0/d;

    check-cast p2, La0/r;

    check-cast p3, Ljava/lang/Number;

    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object p3

    sget-object v0, La0/m;->a:La0/U;

    if-ne p3, v0, :cond_0

    new-instance p3, LE/M;

    new-instance v1, LC/k;

    const/4 v2, 0x2

    iget-object v3, p0, Landroidx/compose/foundation/lazy/layout/c;->w:La0/Z;

    invoke-direct {v1, v3, v2}, LC/k;-><init>(La0/Z;I)V

    invoke-direct {p3, p1, v1}, LE/M;-><init>(Lj0/d;LC/k;)V

    invoke-virtual {p2, p3}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_0
    move-object v3, p3

    check-cast v3, LE/M;

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_1

    new-instance p1, LJ0/l0;

    new-instance p3, LR/p;

    invoke-direct {p3}, Ljava/lang/Object;-><init>()V

    iput-object v3, p3, LR/p;->t:Ljava/lang/Object;

    sget-object v1, Lp/M;->a:Lp/C;

    new-instance v1, Lp/C;

    invoke-direct {v1}, Lp/C;-><init>()V

    iput-object v1, p3, LR/p;->u:Ljava/lang/Object;

    invoke-direct {p1, p3}, LJ0/l0;-><init>(LJ0/o0;)V

    invoke-virtual {p2, p1}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_1
    move-object v4, p1

    check-cast v4, LJ0/l0;

    iget-object v2, p0, Landroidx/compose/foundation/lazy/layout/c;->t:LE/d0;

    const/4 p1, 0x0

    if-eqz v2, :cond_9

    const p3, 0x67eb8deb

    invoke-virtual {p2, p3}, La0/r;->V(I)V

    const p3, 0x34e696b7

    invoke-virtual {p2, p3}, La0/r;->V(I)V

    sget-object p3, LE/x0;->a:LE/w0;

    if-eqz p3, :cond_2

    const v1, 0x5034f7f0

    invoke-virtual {p2, v1}, La0/r;->V(I)V

    invoke-virtual {p2, p1}, La0/r;->p(Z)V

    :goto_0
    move-object v5, p3

    goto :goto_2

    :cond_2
    const p3, 0x5035b7a1

    invoke-virtual {p2, p3}, La0/r;->V(I)V

    sget-object p3, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->f:La0/X0;

    invoke-virtual {p2, p3}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroid/view/View;

    invoke-virtual {p2, p3}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v1

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v5

    if-nez v1, :cond_3

    if-ne v5, v0, :cond_6

    :cond_3
    const v1, 0x7f09007a

    invoke-virtual {p3, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v5

    instance-of v6, v5, LE/v0;

    if-eqz v6, :cond_4

    check-cast v5, LE/v0;

    goto :goto_1

    :cond_4
    const/4 v5, 0x0

    :goto_1
    if-nez v5, :cond_5

    new-instance v5, LE/c;

    invoke-direct {v5, p3}, LE/c;-><init>(Landroid/view/View;)V

    invoke-virtual {p3, v1, v5}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    :cond_5
    invoke-virtual {p2, v5}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_6
    move-object p3, v5

    check-cast p3, LE/v0;

    invoke-virtual {p2, p1}, La0/r;->p(Z)V

    goto :goto_0

    :goto_2
    invoke-virtual {p2, p1}, La0/r;->p(Z)V

    filled-new-array {v2, v3, v4, v5}, [Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2, v2}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v1

    invoke-virtual {p2, v3}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v1, v6

    invoke-virtual {p2, v4}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v1, v6

    invoke-virtual {p2, v5}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v1, v6

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v6

    if-nez v1, :cond_7

    if-ne v6, v0, :cond_8

    :cond_7
    new-instance v1, LB5/h;

    const/4 v6, 0x2

    invoke-direct/range {v1 .. v6}, LB5/h;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p2, v1}, La0/r;->g0(Ljava/lang/Object;)V

    move-object v6, v1

    :cond_8
    check-cast v6, Lr7/c;

    invoke-static {p3, v6, p2}, La0/b;->f([Ljava/lang/Object;Lr7/c;La0/r;)V

    invoke-virtual {p2, p1}, La0/r;->p(Z)V

    goto :goto_3

    :cond_9
    const p3, 0x67f47fcd

    invoke-virtual {p2, p3}, La0/r;->V(I)V

    invoke-virtual {p2, p1}, La0/r;->p(Z)V

    :goto_3
    sget p3, LE/e0;->a:I

    iget-object p3, p0, Landroidx/compose/foundation/lazy/layout/c;->u:Lm0/r;

    if-eqz v2, :cond_b

    new-instance v1, Landroidx/compose/foundation/lazy/layout/TraversablePrefetchStateModifierElement;

    invoke-direct {v1, v2}, Landroidx/compose/foundation/lazy/layout/TraversablePrefetchStateModifierElement;-><init>(LE/d0;)V

    invoke-interface {p3, v1}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v1

    if-nez v1, :cond_a

    goto :goto_4

    :cond_a
    move-object p3, v1

    :cond_b
    :goto_4
    invoke-virtual {p2, v3}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v1

    iget-object v2, p0, Landroidx/compose/foundation/lazy/layout/c;->v:LC/p;

    invoke-virtual {p2, v2}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v1, v5

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v5

    if-nez v1, :cond_c

    if-ne v5, v0, :cond_d

    :cond_c
    new-instance v5, LE/S;

    invoke-direct {v5, p1, v3, v2}, LE/S;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p2, v5}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_d
    check-cast v5, Lr7/e;

    const/16 p1, 0x8

    invoke-static {v4, p3, v5, p2, p1}, LJ0/h0;->a(LJ0/l0;Lm0/r;Lr7/e;La0/r;I)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1
.end method
