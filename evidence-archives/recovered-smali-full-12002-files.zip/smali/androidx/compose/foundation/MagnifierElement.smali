.class public final Landroidx/compose/foundation/MagnifierElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:LT/j0;

.field public final b:LT/i0;

.field public final c:Lu/w0;


# direct methods
.method public constructor <init>(LT/j0;LT/i0;Lu/w0;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/MagnifierElement;->a:LT/j0;

    iput-object p2, p0, Landroidx/compose/foundation/MagnifierElement;->b:LT/i0;

    iput-object p3, p0, Landroidx/compose/foundation/MagnifierElement;->c:Lu/w0;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    if-ne p0, p1, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    instance-of v0, p1, Landroidx/compose/foundation/MagnifierElement;

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    check-cast p1, Landroidx/compose/foundation/MagnifierElement;

    iget-object p1, p1, Landroidx/compose/foundation/MagnifierElement;->a:LT/j0;

    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final g()Lm0/q;
    .locals 4

    new-instance v0, Lu/j0;

    iget-object v1, p0, Landroidx/compose/foundation/MagnifierElement;->a:LT/j0;

    iget-object v2, p0, Landroidx/compose/foundation/MagnifierElement;->b:LT/i0;

    iget-object v3, p0, Landroidx/compose/foundation/MagnifierElement;->c:Lu/w0;

    invoke-direct {v0, v1, v2, v3}, Lu/j0;-><init>(LT/j0;LT/i0;Lu/w0;)V

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 8

    check-cast p1, Lu/j0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p1, Lu/j0;->J:Lu/w0;

    iget-object v1, p1, Lu/j0;->K:Landroid/view/View;

    iget-object v2, p1, Lu/j0;->L:Lj1/c;

    iget-object v3, p0, Landroidx/compose/foundation/MagnifierElement;->a:LT/j0;

    iput-object v3, p1, Lu/j0;->H:LT/j0;

    iget-object v3, p0, Landroidx/compose/foundation/MagnifierElement;->b:LT/i0;

    iput-object v3, p1, Lu/j0;->I:LT/i0;

    iget-object v3, p0, Landroidx/compose/foundation/MagnifierElement;->c:Lu/w0;

    iput-object v3, p1, Lu/j0;->J:Lu/w0;

    invoke-static {p1}, LL0/f;->x(LL0/l;)Landroid/view/View;

    move-result-object v4

    invoke-static {p1}, LL0/f;->v(LL0/l;)LL0/J;

    move-result-object v5

    iget-object v5, v5, LL0/J;->Q:Lj1/c;

    iget-object v6, p1, Lu/j0;->M:Lu/v0;

    if-eqz v6, :cond_2

    sget-object v6, Lu/k0;->a:LT0/v;

    const/high16 v6, 0x7fc00000    # Float.NaN

    invoke-static {v6}, Ljava/lang/Float;->isNaN(F)Z

    move-result v7

    if-eqz v7, :cond_0

    invoke-static {v6}, Ljava/lang/Float;->isNaN(F)Z

    move-result v7

    if-eqz v7, :cond_0

    goto :goto_0

    :cond_0
    invoke-interface {v3}, Lu/w0;->a()Z

    move-result v7

    if-eqz v7, :cond_1

    :goto_0
    invoke-static {v6, v6}, Lj1/f;->a(FF)Z

    move-result v7

    if-eqz v7, :cond_1

    invoke-static {v6, v6}, Lj1/f;->a(FF)Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {v4, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {v5, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    :cond_1
    invoke-virtual {p1}, Lu/j0;->L0()V

    :cond_2
    invoke-virtual {p1}, Lu/j0;->M0()V

    return-void
.end method

.method public final hashCode()I
    .locals 6

    iget-object v0, p0, Landroidx/compose/foundation/MagnifierElement;->a:LT/j0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit16 v0, v0, 0x3c1

    const/high16 v1, 0x7fc00000    # Float.NaN

    const/16 v2, 0x1f

    invoke-static {v1, v0, v2}, Lq3/h;->b(FII)I

    move-result v0

    const/4 v3, 0x1

    invoke-static {v0, v2, v3}, Lq3/h;->e(IIZ)I

    move-result v0

    const-wide v4, 0x7fc000007fc00000L    # 2.247117487993712E307

    invoke-static {v0, v2, v4, v5}, Lq3/h;->d(IIJ)I

    move-result v0

    invoke-static {v1, v0, v2}, Lq3/h;->b(FII)I

    move-result v0

    invoke-static {v1, v0, v2}, Lq3/h;->b(FII)I

    move-result v0

    invoke-static {v0, v2, v3}, Lq3/h;->e(IIZ)I

    move-result v0

    iget-object v1, p0, Landroidx/compose/foundation/MagnifierElement;->b:LT/i0;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/2addr v1, v2

    iget-object v0, p0, Landroidx/compose/foundation/MagnifierElement;->c:Lu/w0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    return v0
.end method
