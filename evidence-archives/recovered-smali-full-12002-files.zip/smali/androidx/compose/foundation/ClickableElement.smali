.class final Landroidx/compose/foundation/ClickableElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Ly/j;

.field public final b:Lu/g0;

.field public final c:Z

.field public final d:Z

.field public final e:Ljava/lang/String;

.field public final f:LT0/g;

.field public final g:Lr7/a;


# direct methods
.method public constructor <init>(Ly/j;Lu/g0;ZZLjava/lang/String;LT0/g;Lr7/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/ClickableElement;->a:Ly/j;

    iput-object p2, p0, Landroidx/compose/foundation/ClickableElement;->b:Lu/g0;

    iput-boolean p3, p0, Landroidx/compose/foundation/ClickableElement;->c:Z

    iput-boolean p4, p0, Landroidx/compose/foundation/ClickableElement;->d:Z

    iput-object p5, p0, Landroidx/compose/foundation/ClickableElement;->e:Ljava/lang/String;

    iput-object p6, p0, Landroidx/compose/foundation/ClickableElement;->f:LT0/g;

    iput-object p7, p0, Landroidx/compose/foundation/ClickableElement;->g:Lr7/a;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    if-ne p0, p1, :cond_0

    goto :goto_1

    :cond_0
    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    const-class v0, Landroidx/compose/foundation/ClickableElement;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-eq v0, v1, :cond_2

    goto :goto_0

    :cond_2
    check-cast p1, Landroidx/compose/foundation/ClickableElement;

    iget-object v0, p0, Landroidx/compose/foundation/ClickableElement;->a:Ly/j;

    iget-object v1, p1, Landroidx/compose/foundation/ClickableElement;->a:Ly/j;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    :cond_3
    iget-object v0, p0, Landroidx/compose/foundation/ClickableElement;->b:Lu/g0;

    iget-object v1, p1, Landroidx/compose/foundation/ClickableElement;->b:Lu/g0;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_0

    :cond_4
    iget-boolean v0, p0, Landroidx/compose/foundation/ClickableElement;->c:Z

    iget-boolean v1, p1, Landroidx/compose/foundation/ClickableElement;->c:Z

    if-eq v0, v1, :cond_5

    goto :goto_0

    :cond_5
    iget-boolean v0, p0, Landroidx/compose/foundation/ClickableElement;->d:Z

    iget-boolean v1, p1, Landroidx/compose/foundation/ClickableElement;->d:Z

    if-eq v0, v1, :cond_6

    goto :goto_0

    :cond_6
    iget-object v0, p0, Landroidx/compose/foundation/ClickableElement;->e:Ljava/lang/String;

    iget-object v1, p1, Landroidx/compose/foundation/ClickableElement;->e:Ljava/lang/String;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    goto :goto_0

    :cond_7
    iget-object v0, p0, Landroidx/compose/foundation/ClickableElement;->f:LT0/g;

    iget-object v1, p1, Landroidx/compose/foundation/ClickableElement;->f:LT0/g;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto :goto_0

    :cond_8
    iget-object v0, p0, Landroidx/compose/foundation/ClickableElement;->g:Lr7/a;

    iget-object p1, p1, Landroidx/compose/foundation/ClickableElement;->g:Lr7/a;

    if-eq v0, p1, :cond_9

    :goto_0
    const/4 p1, 0x0

    return p1

    :cond_9
    :goto_1
    const/4 p1, 0x1

    return p1
.end method

.method public final g()Lm0/q;
    .locals 8

    new-instance v0, Lu/A;

    iget-object v6, p0, Landroidx/compose/foundation/ClickableElement;->f:LT0/g;

    iget-object v7, p0, Landroidx/compose/foundation/ClickableElement;->g:Lr7/a;

    iget-object v1, p0, Landroidx/compose/foundation/ClickableElement;->a:Ly/j;

    iget-object v2, p0, Landroidx/compose/foundation/ClickableElement;->b:Lu/g0;

    iget-boolean v3, p0, Landroidx/compose/foundation/ClickableElement;->c:Z

    iget-boolean v4, p0, Landroidx/compose/foundation/ClickableElement;->d:Z

    iget-object v5, p0, Landroidx/compose/foundation/ClickableElement;->e:Ljava/lang/String;

    invoke-direct/range {v0 .. v7}, Lu/p;-><init>(Ly/j;Lu/g0;ZZLjava/lang/String;LT0/g;Lr7/a;)V

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 8

    move-object v0, p1

    check-cast v0, Lu/A;

    iget-object v6, p0, Landroidx/compose/foundation/ClickableElement;->f:LT0/g;

    iget-object v7, p0, Landroidx/compose/foundation/ClickableElement;->g:Lr7/a;

    iget-object v1, p0, Landroidx/compose/foundation/ClickableElement;->a:Ly/j;

    iget-object v2, p0, Landroidx/compose/foundation/ClickableElement;->b:Lu/g0;

    iget-boolean v3, p0, Landroidx/compose/foundation/ClickableElement;->c:Z

    iget-boolean v4, p0, Landroidx/compose/foundation/ClickableElement;->d:Z

    iget-object v5, p0, Landroidx/compose/foundation/ClickableElement;->e:Ljava/lang/String;

    invoke-virtual/range {v0 .. v7}, Lu/p;->W0(Ly/j;Lu/g0;ZZLjava/lang/String;LT0/g;Lr7/a;)V

    return-void
.end method

.method public final hashCode()I
    .locals 4

    const/4 v0, 0x0

    iget-object v1, p0, Landroidx/compose/foundation/ClickableElement;->a:Ly/j;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_0

    :cond_0
    move v1, v0

    :goto_0
    const/16 v2, 0x1f

    mul-int/2addr v1, v2

    iget-object v3, p0, Landroidx/compose/foundation/ClickableElement;->b:Lu/g0;

    if-eqz v3, :cond_1

    invoke-interface {v3}, Lu/g0;->hashCode()I

    move-result v3

    goto :goto_1

    :cond_1
    move v3, v0

    :goto_1
    add-int/2addr v1, v3

    mul-int/2addr v1, v2

    iget-boolean v3, p0, Landroidx/compose/foundation/ClickableElement;->c:Z

    invoke-static {v1, v2, v3}, Lq3/h;->e(IIZ)I

    move-result v1

    iget-boolean v3, p0, Landroidx/compose/foundation/ClickableElement;->d:Z

    invoke-static {v1, v2, v3}, Lq3/h;->e(IIZ)I

    move-result v1

    iget-object v3, p0, Landroidx/compose/foundation/ClickableElement;->e:Ljava/lang/String;

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v3

    goto :goto_2

    :cond_2
    move v3, v0

    :goto_2
    add-int/2addr v1, v3

    mul-int/2addr v1, v2

    iget-object v3, p0, Landroidx/compose/foundation/ClickableElement;->f:LT0/g;

    if-eqz v3, :cond_3

    iget v0, v3, LT0/g;->a:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    :cond_3
    add-int/2addr v1, v0

    mul-int/2addr v1, v2

    iget-object v0, p0, Landroidx/compose/foundation/ClickableElement;->g:Lr7/a;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    return v0
.end method
