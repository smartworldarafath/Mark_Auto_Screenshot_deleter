.class public abstract Landroidx/compose/foundation/layout/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(IF)LA/V;
    .locals 1

    and-int/lit8 p0, p0, 0x1

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    int-to-float p1, v0

    :cond_0
    int-to-float p0, v0

    new-instance v0, LA/V;

    invoke-direct {v0, p1, p0, p1, p0}, LA/V;-><init>(FFFF)V

    return-object v0
.end method

.method public static final b(FFFF)LA/V;
    .locals 1

    new-instance v0, LA/V;

    invoke-direct {v0, p0, p1, p2, p3}, LA/V;-><init>(FFFF)V

    return-object v0
.end method

.method public static c(Lm0/r;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/layout/AspectRatioElement;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final d(LA/U;Lj1/m;)F
    .locals 1

    sget-object v0, Lj1/m;->t:Lj1/m;

    if-ne p1, v0, :cond_0

    invoke-interface {p0, p1}, LA/U;->b(Lj1/m;)F

    move-result p0

    return p0

    :cond_0
    invoke-interface {p0, p1}, LA/U;->c(Lj1/m;)F

    move-result p0

    return p0
.end method

.method public static final e(LA/U;Lj1/m;)F
    .locals 1

    sget-object v0, Lj1/m;->t:Lj1/m;

    if-ne p1, v0, :cond_0

    invoke-interface {p0, p1}, LA/U;->c(Lj1/m;)F

    move-result p0

    return p0

    :cond_0
    invoke-interface {p0, p1}, LA/U;->b(Lj1/m;)F

    move-result p0

    return p0
.end method

.method public static final f(Lm0/r;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/layout/IntrinsicHeightElement;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final g(IIJ)Z
    .locals 2

    invoke-static {p2, p3}, Lj1/a;->j(J)I

    move-result v0

    invoke-static {p2, p3}, Lj1/a;->h(J)I

    move-result v1

    if-gt p0, v1, :cond_0

    if-gt v0, p0, :cond_0

    invoke-static {p2, p3}, Lj1/a;->i(J)I

    move-result p0

    invoke-static {p2, p3}, Lj1/a;->g(J)I

    move-result p2

    if-gt p1, p2, :cond_0

    if-gt p0, p1, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public static h(Lm0/r;F)Lm0/r;
    .locals 2

    const/4 v0, 0x0

    int-to-float v0, v0

    new-instance v1, Landroidx/compose/foundation/layout/OffsetElement;

    invoke-direct {v1, v0, p1}, Landroidx/compose/foundation/layout/OffsetElement;-><init>(FF)V

    invoke-interface {p0, v1}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final i(Lm0/r;LA/U;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/layout/PaddingValuesElement;

    invoke-direct {v0, p1}, Landroidx/compose/foundation/layout/PaddingValuesElement;-><init>(LA/U;)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final j(Lm0/r;F)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/layout/PaddingElement;

    invoke-direct {v0, p1, p1, p1, p1}, Landroidx/compose/foundation/layout/PaddingElement;-><init>(FFFF)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final k(Lm0/r;FF)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/layout/PaddingElement;

    invoke-direct {v0, p1, p2, p1, p2}, Landroidx/compose/foundation/layout/PaddingElement;-><init>(FFFF)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static l(Lm0/r;FFI)Lm0/r;
    .locals 2

    and-int/lit8 v0, p3, 0x1

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    int-to-float p1, v1

    :cond_0
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_1

    int-to-float p2, v1

    :cond_1
    invoke-static {p0, p1, p2}, Landroidx/compose/foundation/layout/a;->k(Lm0/r;FF)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final m(Lm0/r;FFFF)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/layout/PaddingElement;

    invoke-direct {v0, p1, p2, p3, p4}, Landroidx/compose/foundation/layout/PaddingElement;-><init>(FFFF)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static n(Lm0/r;FFFFI)Lm0/r;
    .locals 2

    and-int/lit8 v0, p5, 0x1

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    int-to-float p1, v1

    :cond_0
    and-int/lit8 v0, p5, 0x2

    if-eqz v0, :cond_1

    int-to-float p2, v1

    :cond_1
    and-int/lit8 v0, p5, 0x4

    if-eqz v0, :cond_2

    int-to-float p3, v1

    :cond_2
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_3

    int-to-float p4, v1

    :cond_3
    invoke-static {p0, p1, p2, p3, p4}, Landroidx/compose/foundation/layout/a;->m(Lm0/r;FFFF)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final o(Lm0/r;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/foundation/layout/IntrinsicWidthElement;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method
