.class public final Landroidx/compose/foundation/layout/VerticalAlignElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Lm0/i;


# direct methods
.method public constructor <init>(Lm0/i;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/layout/VerticalAlignElement;->a:Lm0/i;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    if-ne p0, p1, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    instance-of v0, p1, Landroidx/compose/foundation/layout/VerticalAlignElement;

    if-eqz v0, :cond_1

    check-cast p1, Landroidx/compose/foundation/layout/VerticalAlignElement;

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    if-nez p1, :cond_2

    const/4 p1, 0x0

    return p1

    :cond_2
    iget-object v0, p0, Landroidx/compose/foundation/layout/VerticalAlignElement;->a:Lm0/i;

    iget-object p1, p1, Landroidx/compose/foundation/layout/VerticalAlignElement;->a:Lm0/i;

    invoke-virtual {v0, p1}, Lm0/i;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final g()Lm0/q;
    .locals 2

    new-instance v0, LA/h0;

    invoke-direct {v0}, Lm0/q;-><init>()V

    iget-object v1, p0, Landroidx/compose/foundation/layout/VerticalAlignElement;->a:Lm0/i;

    iput-object v1, v0, LA/h0;->H:Lm0/i;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 1

    check-cast p1, LA/h0;

    iget-object v0, p0, Landroidx/compose/foundation/layout/VerticalAlignElement;->a:Lm0/i;

    iput-object v0, p1, LA/h0;->H:Lm0/i;

    return-void
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, Landroidx/compose/foundation/layout/VerticalAlignElement;->a:Lm0/i;

    iget v0, v0, Lm0/i;->a:F

    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    move-result v0

    return v0
.end method
