.class public final Landroidx/compose/foundation/gestures/DraggableElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# static fields
.field public static final f:Ls/E0;


# instance fields
.field public final a:Lj6/b;

.field public final b:Z

.field public final c:Z

.field public final d:Lr7/f;

.field public final e:Lr7/f;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Ls/E0;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, Ls/E0;-><init>(I)V

    sput-object v0, Landroidx/compose/foundation/gestures/DraggableElement;->f:Ls/E0;

    return-void
.end method

.method public constructor <init>(Lj6/b;ZZLr7/f;Lr7/f;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->a:Lj6/b;

    iput-boolean p2, p0, Landroidx/compose/foundation/gestures/DraggableElement;->b:Z

    iput-boolean p3, p0, Landroidx/compose/foundation/gestures/DraggableElement;->c:Z

    iput-object p4, p0, Landroidx/compose/foundation/gestures/DraggableElement;->d:Lr7/f;

    iput-object p5, p0, Landroidx/compose/foundation/gestures/DraggableElement;->e:Lr7/f;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    const-class v1, Landroidx/compose/foundation/gestures/DraggableElement;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    if-eq v1, v2, :cond_2

    goto :goto_0

    :cond_2
    check-cast p1, Landroidx/compose/foundation/gestures/DraggableElement;

    iget-object v1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->a:Lj6/b;

    iget-object v2, p1, Landroidx/compose/foundation/gestures/DraggableElement;->a:Lj6/b;

    invoke-static {v1, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    goto :goto_0

    :cond_3
    iget-boolean v1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->b:Z

    iget-boolean v2, p1, Landroidx/compose/foundation/gestures/DraggableElement;->b:Z

    if-eq v1, v2, :cond_4

    goto :goto_0

    :cond_4
    iget-boolean v1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->c:Z

    iget-boolean v2, p1, Landroidx/compose/foundation/gestures/DraggableElement;->c:Z

    if-eq v1, v2, :cond_5

    goto :goto_0

    :cond_5
    iget-object v1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->d:Lr7/f;

    iget-object v2, p1, Landroidx/compose/foundation/gestures/DraggableElement;->d:Lr7/f;

    invoke-static {v1, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    goto :goto_0

    :cond_6
    iget-object v1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->e:Lr7/f;

    iget-object p1, p1, Landroidx/compose/foundation/gestures/DraggableElement;->e:Lr7/f;

    invoke-static {v1, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_7

    :goto_0
    const/4 p1, 0x0

    return p1

    :cond_7
    return v0
.end method

.method public final g()Lm0/q;
    .locals 5

    new-instance v0, Lw/N;

    sget-object v1, Landroidx/compose/foundation/gestures/DraggableElement;->f:Ls/E0;

    iget-boolean v2, p0, Landroidx/compose/foundation/gestures/DraggableElement;->b:Z

    const/4 v3, 0x0

    sget-object v4, Lw/h0;->t:Lw/h0;

    invoke-direct {v0, v1, v2, v3, v4}, Lw/I;-><init>(Lr7/c;ZLy/j;Lw/h0;)V

    iget-object v1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->a:Lj6/b;

    iput-object v1, v0, Lw/N;->S:Lj6/b;

    iput-object v4, v0, Lw/N;->T:Lw/h0;

    iget-boolean v1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->c:Z

    iput-boolean v1, v0, Lw/N;->U:Z

    iget-object v1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->d:Lr7/f;

    iput-object v1, v0, Lw/N;->V:Lr7/f;

    iget-object v1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->e:Lr7/f;

    iput-object v1, v0, Lw/N;->W:Lr7/f;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 6

    move-object v0, p1

    check-cast v0, Lw/N;

    iget-object p1, v0, Lw/N;->S:Lj6/b;

    iget-object v1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->a:Lj6/b;

    invoke-static {p1, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    if-nez p1, :cond_0

    iput-object v1, v0, Lw/N;->S:Lj6/b;

    move p1, v2

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iget-object v1, v0, Lw/N;->T:Lw/h0;

    sget-object v4, Lw/h0;->t:Lw/h0;

    if-eq v1, v4, :cond_1

    iput-object v4, v0, Lw/N;->T:Lw/h0;

    move v5, v2

    goto :goto_1

    :cond_1
    move v5, p1

    :goto_1
    iget-object p1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->d:Lr7/f;

    iput-object p1, v0, Lw/N;->V:Lr7/f;

    iget-object p1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->e:Lr7/f;

    iput-object p1, v0, Lw/N;->W:Lr7/f;

    iget-boolean p1, p0, Landroidx/compose/foundation/gestures/DraggableElement;->c:Z

    iput-boolean p1, v0, Lw/N;->U:Z

    sget-object v1, Landroidx/compose/foundation/gestures/DraggableElement;->f:Ls/E0;

    iget-boolean v2, p0, Landroidx/compose/foundation/gestures/DraggableElement;->b:Z

    const/4 v3, 0x0

    invoke-virtual/range {v0 .. v5}, Lw/I;->V0(Lr7/c;ZLy/j;Lw/h0;Z)V

    return-void
.end method

.method public final hashCode()I
    .locals 4

    iget-object v0, p0, Landroidx/compose/foundation/gestures/DraggableElement;->a:Lj6/b;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    sget-object v2, Lw/h0;->t:Lw/h0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v2, v0

    mul-int/2addr v2, v1

    iget-boolean v0, p0, Landroidx/compose/foundation/gestures/DraggableElement;->b:Z

    const/16 v3, 0x3c1

    invoke-static {v2, v3, v0}, Lq3/h;->e(IIZ)I

    move-result v0

    iget-boolean v2, p0, Landroidx/compose/foundation/gestures/DraggableElement;->c:Z

    invoke-static {v0, v1, v2}, Lq3/h;->e(IIZ)I

    move-result v0

    iget-object v2, p0, Landroidx/compose/foundation/gestures/DraggableElement;->d:Lr7/f;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v2, v0

    mul-int/2addr v2, v1

    iget-object v0, p0, Landroidx/compose/foundation/gestures/DraggableElement;->e:Lr7/f;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method
