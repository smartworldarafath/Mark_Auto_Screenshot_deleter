.class public abstract Landroidx/compose/foundation/gestures/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ls/E0;

.field public static final b:Lw/o0;

.field public static final c:Lw/n0;

.field public static final d:Lw/p0;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Ls/E0;

    const/16 v1, 0x15

    invoke-direct {v0, v1}, Ls/E0;-><init>(I)V

    sput-object v0, Landroidx/compose/foundation/gestures/a;->a:Ls/E0;

    new-instance v0, Lw/o0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/compose/foundation/gestures/a;->b:Lw/o0;

    new-instance v0, Lw/n0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/compose/foundation/gestures/a;->c:Lw/n0;

    new-instance v0, Lw/p0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/compose/foundation/gestures/a;->d:Lw/p0;

    return-void
.end method

.method public static final a(Lw/I0;JLj7/c;)Ljava/lang/Object;
    .locals 9

    instance-of v0, p3, Lw/q0;

    if-eqz v0, :cond_0

    move-object v0, p3

    check-cast v0, Lw/q0;

    iget v1, v0, Lw/q0;->z:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    iput v1, v0, Lw/q0;->z:I

    goto :goto_0

    :cond_0
    new-instance v0, Lw/q0;

    invoke-direct {v0, p3}, Lj7/c;-><init>(Lh7/c;)V

    :goto_0
    iget-object p3, v0, Lw/q0;->y:Ljava/lang/Object;

    iget v1, v0, Lw/q0;->z:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2

    if-ne v1, v2, :cond_1

    iget-object p0, v0, Lw/q0;->x:Ls7/r;

    iget-object p1, v0, Lw/q0;->w:Lw/I0;

    invoke-static {p3}, Ld7/a;->e(Ljava/lang/Object;)V

    move-object v7, p0

    move-object p0, p1

    goto :goto_1

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    invoke-static {p3}, Ld7/a;->e(Ljava/lang/Object;)V

    new-instance v7, Ls7/r;

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    new-instance v3, Lw/r0;

    const/4 v8, 0x0

    move-object v4, p0

    move-wide v5, p1

    invoke-direct/range {v3 .. v8}, Lw/r0;-><init>(Lw/I0;JLs7/r;Lh7/c;)V

    iput-object v4, v0, Lw/q0;->w:Lw/I0;

    iput-object v7, v0, Lw/q0;->x:Ls7/r;

    iput v2, v0, Lw/q0;->z:I

    sget-object p0, Lu/l0;->t:Lu/l0;

    invoke-virtual {v4, p0, v3, v0}, Lw/I0;->f(Lu/l0;Lr7/e;Lj7/c;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Li7/a;->t:Li7/a;

    if-ne p0, p1, :cond_3

    return-object p1

    :cond_3
    move-object p0, v4

    :goto_1
    iget p1, v7, Ls7/r;->t:F

    invoke-virtual {p0, p1}, Lw/I0;->h(F)J

    move-result-wide p0

    new-instance p2, Ls0/b;

    invoke-direct {p2, p0, p1}, Ls0/b;-><init>(J)V

    return-object p2
.end method

.method public static b(LI/B0;Lw/h0;ZZLy/j;)Lm0/r;
    .locals 6

    new-instance v0, Landroidx/compose/foundation/gestures/ScrollableElement;

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move v4, p3

    move-object v5, p4

    invoke-direct/range {v0 .. v5}, Landroidx/compose/foundation/gestures/ScrollableElement;-><init>(Lw/C0;Lw/h0;ZZLy/j;)V

    return-object v0
.end method
