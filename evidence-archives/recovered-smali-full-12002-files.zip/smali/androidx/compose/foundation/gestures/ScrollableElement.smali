.class final Landroidx/compose/foundation/gestures/ScrollableElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Lw/C0;

.field public final b:Lw/h0;

.field public final c:Z

.field public final d:Z

.field public final e:Ly/j;


# direct methods
.method public constructor <init>(Lw/C0;Lw/h0;ZZLy/j;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->a:Lw/C0;

    iput-object p2, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->b:Lw/h0;

    iput-boolean p3, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->c:Z

    iput-boolean p4, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->d:Z

    iput-object p5, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->e:Ly/j;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    if-ne p0, p1, :cond_0

    goto :goto_1

    :cond_0
    instance-of v0, p1, Landroidx/compose/foundation/gestures/ScrollableElement;

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    check-cast p1, Landroidx/compose/foundation/gestures/ScrollableElement;

    iget-object v0, p1, Landroidx/compose/foundation/gestures/ScrollableElement;->a:Lw/C0;

    iget-object v1, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->a:Lw/C0;

    invoke-static {v1, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    iget-object v0, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->b:Lw/h0;

    iget-object v1, p1, Landroidx/compose/foundation/gestures/ScrollableElement;->b:Lw/h0;

    if-eq v0, v1, :cond_3

    goto :goto_0

    :cond_3
    iget-boolean v0, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->c:Z

    iget-boolean v1, p1, Landroidx/compose/foundation/gestures/ScrollableElement;->c:Z

    if-eq v0, v1, :cond_4

    goto :goto_0

    :cond_4
    iget-boolean v0, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->d:Z

    iget-boolean v1, p1, Landroidx/compose/foundation/gestures/ScrollableElement;->d:Z

    if-eq v0, v1, :cond_5

    goto :goto_0

    :cond_5
    iget-object v0, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->e:Ly/j;

    iget-object p1, p1, Landroidx/compose/foundation/gestures/ScrollableElement;->e:Ly/j;

    invoke-static {v0, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6

    :goto_0
    const/4 p1, 0x0

    return p1

    :cond_6
    :goto_1
    const/4 p1, 0x1

    return p1
.end method

.method public final g()Lm0/q;
    .locals 8

    new-instance v0, Lw/B0;

    iget-boolean v7, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->d:Z

    iget-object v5, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->e:Ly/j;

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v3, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->b:Lw/h0;

    iget-object v4, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->a:Lw/C0;

    iget-boolean v6, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->c:Z

    invoke-direct/range {v0 .. v7}, Lw/B0;-><init>(Lu/s;Lw/l;Lw/h0;Lw/C0;Ly/j;ZZ)V

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 8

    move-object v0, p1

    check-cast v0, Lw/B0;

    const/4 v2, 0x0

    iget-object v5, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->e:Ly/j;

    const/4 v1, 0x0

    iget-object v3, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->b:Lw/h0;

    iget-object v4, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->a:Lw/C0;

    iget-boolean v6, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->c:Z

    iget-boolean v7, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->d:Z

    invoke-virtual/range {v0 .. v7}, Lw/B0;->W0(Lu/s;Lw/l;Lw/h0;Lw/C0;Ly/j;ZZ)V

    return-void
.end method

.method public final hashCode()I
    .locals 4

    iget-object v0, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->a:Lw/C0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget-object v2, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->b:Lw/h0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v2, v0

    const/16 v0, 0x3c1

    mul-int/2addr v2, v0

    iget-boolean v3, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->c:Z

    invoke-static {v2, v1, v3}, Lq3/h;->e(IIZ)I

    move-result v2

    iget-boolean v3, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->d:Z

    invoke-static {v2, v0, v3}, Lq3/h;->e(IIZ)I

    move-result v0

    iget-object v2, p0, Landroidx/compose/foundation/gestures/ScrollableElement;->e:Ly/j;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    return v0
.end method
