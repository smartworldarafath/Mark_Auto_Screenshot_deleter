.class public final Landroidx/compose/foundation/selection/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/f;


# instance fields
.field public final synthetic t:Lu/c0;

.field public final synthetic u:Z

.field public final synthetic v:Z

.field public final synthetic w:LT0/g;

.field public final synthetic x:Lr7/a;


# direct methods
.method public constructor <init>(Lu/c0;ZZLT0/g;Lr7/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/selection/a;->t:Lu/c0;

    iput-boolean p2, p0, Landroidx/compose/foundation/selection/a;->u:Z

    iput-boolean p3, p0, Landroidx/compose/foundation/selection/a;->v:Z

    iput-object p4, p0, Landroidx/compose/foundation/selection/a;->w:LT0/g;

    iput-object p5, p0, Landroidx/compose/foundation/selection/a;->x:Lr7/a;

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    check-cast p1, Lm0/r;

    check-cast p2, La0/r;

    check-cast p3, Ljava/lang/Number;

    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    const p1, -0x5af0b3b9

    invoke-virtual {p2, p1}, La0/r;->V(I)V

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object p1

    sget-object p3, La0/m;->a:La0/U;

    if-ne p1, p3, :cond_0

    new-instance p1, Ly/j;

    invoke-direct {p1}, Ly/j;-><init>()V

    invoke-virtual {p2, p1}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_0
    move-object v2, p1

    check-cast v2, Ly/j;

    sget-object p1, Lm0/o;->a:Lm0/o;

    iget-object p3, p0, Landroidx/compose/foundation/selection/a;->t:Lu/c0;

    invoke-static {p1, v2, p3}, Landroidx/compose/foundation/c;->a(Lm0/r;Ly/j;Lu/c0;)Lm0/r;

    move-result-object p1

    new-instance v0, Landroidx/compose/foundation/selection/SelectableElement;

    iget-object v5, p0, Landroidx/compose/foundation/selection/a;->w:LT0/g;

    iget-object v6, p0, Landroidx/compose/foundation/selection/a;->x:Lr7/a;

    iget-boolean v1, p0, Landroidx/compose/foundation/selection/a;->u:Z

    const/4 v3, 0x0

    iget-boolean v4, p0, Landroidx/compose/foundation/selection/a;->v:Z

    invoke-direct/range {v0 .. v6}, Landroidx/compose/foundation/selection/SelectableElement;-><init>(ZLy/j;Lu/g0;ZLT0/g;Lr7/a;)V

    invoke-interface {p1, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p1

    const/4 p3, 0x0

    invoke-virtual {p2, p3}, La0/r;->p(Z)V

    return-object p1
.end method
