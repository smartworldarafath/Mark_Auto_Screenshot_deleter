.class public abstract Landroidx/compose/foundation/selection/b;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Lm0/r;ZLy/j;Lu/c0;ZLT0/g;Lr7/a;)Lm0/r;
    .locals 9

    instance-of v0, p3, Lu/g0;

    if-eqz v0, :cond_0

    move-object v4, p3

    check-cast v4, Lu/g0;

    new-instance v1, Landroidx/compose/foundation/selection/SelectableElement;

    move v2, p1

    move-object v3, p2

    move v5, p4

    move-object v6, p5

    move-object v7, p6

    invoke-direct/range {v1 .. v7}, Landroidx/compose/foundation/selection/SelectableElement;-><init>(ZLy/j;Lu/g0;ZLT0/g;Lr7/a;)V

    goto :goto_0

    :cond_0
    move v3, p1

    move-object v4, p2

    move v6, p4

    move-object v7, p5

    move-object v8, p6

    if-nez p3, :cond_1

    new-instance v2, Landroidx/compose/foundation/selection/SelectableElement;

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v8}, Landroidx/compose/foundation/selection/SelectableElement;-><init>(ZLy/j;Lu/g0;ZLT0/g;Lr7/a;)V

    move-object v1, v2

    goto :goto_0

    :cond_1
    sget-object v0, Lm0/o;->a:Lm0/o;

    if-eqz v4, :cond_2

    invoke-static {v0, v4, p3}, Landroidx/compose/foundation/c;->a(Lm0/r;Ly/j;Lu/c0;)Lm0/r;

    move-result-object p1

    new-instance v2, Landroidx/compose/foundation/selection/SelectableElement;

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v8}, Landroidx/compose/foundation/selection/SelectableElement;-><init>(ZLy/j;Lu/g0;ZLT0/g;Lr7/a;)V

    invoke-interface {p1, v2}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v1

    goto :goto_0

    :cond_2
    new-instance p1, Landroidx/compose/foundation/selection/a;

    move-object p2, p3

    move p3, v3

    move p4, v6

    move-object p5, v7

    move-object p6, v8

    invoke-direct/range {p1 .. p6}, Landroidx/compose/foundation/selection/a;-><init>(Lu/c0;ZZLT0/g;Lr7/a;)V

    invoke-static {v0, p1}, Lm0/a;->a(Lm0/r;Lr7/f;)Lm0/r;

    move-result-object v1

    :goto_0
    invoke-interface {p0, v1}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method

.method public static final b(Lm0/r;ZLy/j;ZLT0/g;Lr7/c;)Lm0/r;
    .locals 6

    new-instance v0, Landroidx/compose/foundation/selection/ToggleableElement;

    move v1, p1

    move-object v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p5

    invoke-direct/range {v0 .. v5}, Landroidx/compose/foundation/selection/ToggleableElement;-><init>(ZLy/j;ZLT0/g;Lr7/c;)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method
