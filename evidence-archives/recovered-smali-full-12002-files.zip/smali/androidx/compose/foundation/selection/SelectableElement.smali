.class final Landroidx/compose/foundation/selection/SelectableElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Z

.field public final b:Ly/j;

.field public final c:Lu/g0;

.field public final d:Z

.field public final e:LT0/g;

.field public final f:Lr7/a;


# direct methods
.method public constructor <init>(ZLy/j;Lu/g0;ZLT0/g;Lr7/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Landroidx/compose/foundation/selection/SelectableElement;->a:Z

    iput-object p2, p0, Landroidx/compose/foundation/selection/SelectableElement;->b:Ly/j;

    iput-object p3, p0, Landroidx/compose/foundation/selection/SelectableElement;->c:Lu/g0;

    iput-boolean p4, p0, Landroidx/compose/foundation/selection/SelectableElement;->d:Z

    iput-object p5, p0, Landroidx/compose/foundation/selection/SelectableElement;->e:LT0/g;

    iput-object p6, p0, Landroidx/compose/foundation/selection/SelectableElement;->f:Lr7/a;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    if-ne p0, p1, :cond_0

    goto :goto_1

    :cond_0
    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    const-class v0, Landroidx/compose/foundation/selection/SelectableElement;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-eq v0, v1, :cond_2

    goto :goto_0

    :cond_2
    check-cast p1, Landroidx/compose/foundation/selection/SelectableElement;

    iget-boolean v0, p0, Landroidx/compose/foundation/selection/SelectableElement;->a:Z

    iget-boolean v1, p1, Landroidx/compose/foundation/selection/SelectableElement;->a:Z

    if-eq v0, v1, :cond_3

    goto :goto_0

    :cond_3
    iget-object v0, p0, Landroidx/compose/foundation/selection/SelectableElement;->b:Ly/j;

    iget-object v1, p1, Landroidx/compose/foundation/selection/SelectableElement;->b:Ly/j;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_0

    :cond_4
    iget-object v0, p0, Landroidx/compose/foundation/selection/SelectableElement;->c:Lu/g0;

    iget-object v1, p1, Landroidx/compose/foundation/selection/SelectableElement;->c:Lu/g0;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_0

    :cond_5
    iget-boolean v0, p0, Landroidx/compose/foundation/selection/SelectableElement;->d:Z

    iget-boolean v1, p1, Landroidx/compose/foundation/selection/SelectableElement;->d:Z

    if-eq v0, v1, :cond_6

    goto :goto_0

    :cond_6
    iget-object v0, p0, Landroidx/compose/foundation/selection/SelectableElement;->e:LT0/g;

    iget-object v1, p1, Landroidx/compose/foundation/selection/SelectableElement;->e:LT0/g;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    goto :goto_0

    :cond_7
    iget-object v0, p0, Landroidx/compose/foundation/selection/SelectableElement;->f:Lr7/a;

    iget-object p1, p1, Landroidx/compose/foundation/selection/SelectableElement;->f:Lr7/a;

    if-eq v0, p1, :cond_8

    :goto_0
    const/4 p1, 0x0

    return p1

    :cond_8
    :goto_1
    const/4 p1, 0x1

    return p1
.end method

.method public final g()Lm0/q;
    .locals 8

    new-instance v0, LG/a;

    iget-object v7, p0, Landroidx/compose/foundation/selection/SelectableElement;->f:Lr7/a;

    const/4 v5, 0x0

    iget-object v1, p0, Landroidx/compose/foundation/selection/SelectableElement;->b:Ly/j;

    iget-object v2, p0, Landroidx/compose/foundation/selection/SelectableElement;->c:Lu/g0;

    const/4 v3, 0x0

    iget-boolean v4, p0, Landroidx/compose/foundation/selection/SelectableElement;->d:Z

    iget-object v6, p0, Landroidx/compose/foundation/selection/SelectableElement;->e:LT0/g;

    invoke-direct/range {v0 .. v7}, Lu/p;-><init>(Ly/j;Lu/g0;ZZLjava/lang/String;LT0/g;Lr7/a;)V

    iget-boolean v1, p0, Landroidx/compose/foundation/selection/SelectableElement;->a:Z

    iput-boolean v1, v0, LG/a;->e0:Z

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 8

    move-object v0, p1

    check-cast v0, LG/a;

    iget-boolean p1, v0, LG/a;->e0:Z

    iget-boolean v1, p0, Landroidx/compose/foundation/selection/SelectableElement;->a:Z

    if-eq p1, v1, :cond_0

    iput-boolean v1, v0, LG/a;->e0:Z

    invoke-static {v0}, LL0/f;->n(LL0/z0;)V

    :cond_0
    const/4 v5, 0x0

    iget-object v1, p0, Landroidx/compose/foundation/selection/SelectableElement;->b:Ly/j;

    iget-object v2, p0, Landroidx/compose/foundation/selection/SelectableElement;->c:Lu/g0;

    const/4 v3, 0x0

    iget-boolean v4, p0, Landroidx/compose/foundation/selection/SelectableElement;->d:Z

    iget-object v6, p0, Landroidx/compose/foundation/selection/SelectableElement;->e:LT0/g;

    iget-object v7, p0, Landroidx/compose/foundation/selection/SelectableElement;->f:Lr7/a;

    invoke-virtual/range {v0 .. v7}, Lu/p;->W0(Ly/j;Lu/g0;ZZLjava/lang/String;LT0/g;Lr7/a;)V

    return-void
.end method

.method public final hashCode()I
    .locals 4

    iget-boolean v0, p0, Landroidx/compose/foundation/selection/SelectableElement;->a:Z

    invoke-static {v0}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    const/4 v2, 0x0

    iget-object v3, p0, Landroidx/compose/foundation/selection/SelectableElement;->b:Ly/j;

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    goto :goto_0

    :cond_0
    move v3, v2

    :goto_0
    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    iget-object v3, p0, Landroidx/compose/foundation/selection/SelectableElement;->c:Lu/g0;

    if-eqz v3, :cond_1

    invoke-interface {v3}, Lu/g0;->hashCode()I

    move-result v3

    goto :goto_1

    :cond_1
    move v3, v2

    :goto_1
    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    invoke-static {v0, v1, v2}, Lq3/h;->e(IIZ)I

    move-result v0

    iget-boolean v3, p0, Landroidx/compose/foundation/selection/SelectableElement;->d:Z

    invoke-static {v0, v1, v3}, Lq3/h;->e(IIZ)I

    move-result v0

    iget-object v3, p0, Landroidx/compose/foundation/selection/SelectableElement;->e:LT0/g;

    if-eqz v3, :cond_2

    iget v2, v3, LT0/g;->a:I

    invoke-static {v2}, Ljava/lang/Integer;->hashCode(I)I

    move-result v2

    :cond_2
    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object v1, p0, Landroidx/compose/foundation/selection/SelectableElement;->f:Lr7/a;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    return v1
.end method
