.class final Landroidx/compose/foundation/ScrollingContainerElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Lw/C0;

.field public final b:Lw/h0;

.field public final c:Z

.field public final d:Lw/l;

.field public final e:Ly/j;

.field public final f:Z

.field public final g:Lu/s;


# direct methods
.method public constructor <init>(Lu/s;Lw/l;Lw/h0;Lw/C0;Ly/j;ZZ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p4, p0, Landroidx/compose/foundation/ScrollingContainerElement;->a:Lw/C0;

    iput-object p3, p0, Landroidx/compose/foundation/ScrollingContainerElement;->b:Lw/h0;

    iput-boolean p6, p0, Landroidx/compose/foundation/ScrollingContainerElement;->c:Z

    iput-object p2, p0, Landroidx/compose/foundation/ScrollingContainerElement;->d:Lw/l;

    iput-object p5, p0, Landroidx/compose/foundation/ScrollingContainerElement;->e:Ly/j;

    iput-boolean p7, p0, Landroidx/compose/foundation/ScrollingContainerElement;->f:Z

    iput-object p1, p0, Landroidx/compose/foundation/ScrollingContainerElement;->g:Lu/s;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    if-ne p0, p1, :cond_0

    goto :goto_0

    :cond_0
    if-eqz p1, :cond_9

    const-class v0, Landroidx/compose/foundation/ScrollingContainerElement;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-eq v0, v1, :cond_1

    goto :goto_1

    :cond_1
    check-cast p1, Landroidx/compose/foundation/ScrollingContainerElement;

    iget-object v0, p0, Landroidx/compose/foundation/ScrollingContainerElement;->a:Lw/C0;

    iget-object v1, p1, Landroidx/compose/foundation/ScrollingContainerElement;->a:Lw/C0;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_1

    :cond_2
    iget-object v0, p0, Landroidx/compose/foundation/ScrollingContainerElement;->b:Lw/h0;

    iget-object v1, p1, Landroidx/compose/foundation/ScrollingContainerElement;->b:Lw/h0;

    if-eq v0, v1, :cond_3

    goto :goto_1

    :cond_3
    iget-boolean v0, p0, Landroidx/compose/foundation/ScrollingContainerElement;->c:Z

    iget-boolean v1, p1, Landroidx/compose/foundation/ScrollingContainerElement;->c:Z

    if-eq v0, v1, :cond_4

    goto :goto_1

    :cond_4
    iget-object v0, p0, Landroidx/compose/foundation/ScrollingContainerElement;->d:Lw/l;

    iget-object v1, p1, Landroidx/compose/foundation/ScrollingContainerElement;->d:Lw/l;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_1

    :cond_5
    iget-object v0, p0, Landroidx/compose/foundation/ScrollingContainerElement;->e:Ly/j;

    iget-object v1, p1, Landroidx/compose/foundation/ScrollingContainerElement;->e:Ly/j;

    invoke-static {v0, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    goto :goto_1

    :cond_6
    iget-boolean v0, p0, Landroidx/compose/foundation/ScrollingContainerElement;->f:Z

    iget-boolean v1, p1, Landroidx/compose/foundation/ScrollingContainerElement;->f:Z

    if-eq v0, v1, :cond_7

    goto :goto_1

    :cond_7
    iget-object v0, p0, Landroidx/compose/foundation/ScrollingContainerElement;->g:Lu/s;

    iget-object p1, p1, Landroidx/compose/foundation/ScrollingContainerElement;->g:Lu/s;

    invoke-static {v0, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_8

    goto :goto_1

    :cond_8
    :goto_0
    const/4 p1, 0x1

    return p1

    :cond_9
    :goto_1
    const/4 p1, 0x0

    return p1
.end method

.method public final g()Lm0/q;
    .locals 2

    new-instance v0, Lu/E0;

    invoke-direct {v0}, LL0/m;-><init>()V

    iget-object v1, p0, Landroidx/compose/foundation/ScrollingContainerElement;->a:Lw/C0;

    iput-object v1, v0, Lu/E0;->J:Lw/C0;

    iget-object v1, p0, Landroidx/compose/foundation/ScrollingContainerElement;->b:Lw/h0;

    iput-object v1, v0, Lu/E0;->K:Lw/h0;

    iget-boolean v1, p0, Landroidx/compose/foundation/ScrollingContainerElement;->c:Z

    iput-boolean v1, v0, Lu/E0;->L:Z

    iget-object v1, p0, Landroidx/compose/foundation/ScrollingContainerElement;->d:Lw/l;

    iput-object v1, v0, Lu/E0;->M:Lw/l;

    iget-object v1, p0, Landroidx/compose/foundation/ScrollingContainerElement;->e:Ly/j;

    iput-object v1, v0, Lu/E0;->N:Ly/j;

    iget-boolean v1, p0, Landroidx/compose/foundation/ScrollingContainerElement;->f:Z

    iput-boolean v1, v0, Lu/E0;->O:Z

    iget-object v1, p0, Landroidx/compose/foundation/ScrollingContainerElement;->g:Lu/s;

    iput-object v1, v0, Lu/E0;->P:Lu/s;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 8

    move-object v0, p1

    check-cast v0, Lu/E0;

    iget-object v2, p0, Landroidx/compose/foundation/ScrollingContainerElement;->d:Lw/l;

    iget-object v5, p0, Landroidx/compose/foundation/ScrollingContainerElement;->e:Ly/j;

    iget-object v1, p0, Landroidx/compose/foundation/ScrollingContainerElement;->g:Lu/s;

    iget-object v3, p0, Landroidx/compose/foundation/ScrollingContainerElement;->b:Lw/h0;

    iget-object v4, p0, Landroidx/compose/foundation/ScrollingContainerElement;->a:Lw/C0;

    iget-boolean v6, p0, Landroidx/compose/foundation/ScrollingContainerElement;->f:Z

    iget-boolean v7, p0, Landroidx/compose/foundation/ScrollingContainerElement;->c:Z

    invoke-virtual/range {v0 .. v7}, Lu/E0;->P0(Lu/s;Lw/l;Lw/h0;Lw/C0;Ly/j;ZZ)V

    return-void
.end method

.method public final hashCode()I
    .locals 4

    iget-object v0, p0, Landroidx/compose/foundation/ScrollingContainerElement;->a:Lw/C0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget-object v2, p0, Landroidx/compose/foundation/ScrollingContainerElement;->b:Lw/h0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v2, v0

    mul-int/2addr v2, v1

    iget-boolean v0, p0, Landroidx/compose/foundation/ScrollingContainerElement;->c:Z

    invoke-static {v2, v1, v0}, Lq3/h;->e(IIZ)I

    move-result v0

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Lq3/h;->e(IIZ)I

    move-result v0

    iget-object v3, p0, Landroidx/compose/foundation/ScrollingContainerElement;->d:Lw/l;

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    goto :goto_0

    :cond_0
    move v3, v2

    :goto_0
    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    iget-object v3, p0, Landroidx/compose/foundation/ScrollingContainerElement;->e:Ly/j;

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    goto :goto_1

    :cond_1
    move v3, v2

    :goto_1
    add-int/2addr v0, v3

    mul-int/lit16 v0, v0, 0x3c1

    iget-boolean v3, p0, Landroidx/compose/foundation/ScrollingContainerElement;->f:Z

    invoke-static {v0, v1, v3}, Lq3/h;->e(IIZ)I

    move-result v0

    iget-object v1, p0, Landroidx/compose/foundation/ScrollingContainerElement;->g:Lu/s;

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :cond_2
    add-int/2addr v0, v2

    return v0
.end method
