.class public abstract Landroidx/compose/foundation/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:La0/B;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lm2/F;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lm2/F;-><init>(I)V

    new-instance v1, La0/B;

    invoke-direct {v1, v0}, La0/B;-><init>(Lr7/a;)V

    sput-object v1, Landroidx/compose/foundation/c;->a:La0/B;

    return-void
.end method

.method public static final a(Lm0/r;Ly/j;Lu/c0;)Lm0/r;
    .locals 2

    if-nez p2, :cond_0

    return-object p0

    :cond_0
    instance-of v0, p2, Lu/g0;

    if-eqz v0, :cond_1

    new-instance v0, Landroidx/compose/foundation/IndicationModifierElement;

    check-cast p2, Lu/g0;

    invoke-direct {v0, p1, p2}, Landroidx/compose/foundation/IndicationModifierElement;-><init>(Ly/j;Lu/g0;)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0

    :cond_1
    new-instance v0, LI/z0;

    const/4 v1, 0x4

    invoke-direct {v0, v1, p2, p1}, LI/z0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {p0, v0}, Lm0/a;->a(Lm0/r;Lr7/f;)Lm0/r;

    move-result-object p0

    return-object p0
.end method
