.class public abstract Landroidx/compose/animation/b;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Ls/w0;Lr7/c;Lm0/r;Lr/K;Lr/L;Lr7/e;Li0/d;La0/r;I)V
    .locals 29

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v11, p7

    move/from16 v0, p8

    const v8, 0x72039c2f

    invoke-virtual {v11, v8}, La0/r;->X(I)La0/r;

    and-int/lit8 v8, v0, 0x6

    const/4 v9, 0x4

    if-nez v8, :cond_1

    invoke-virtual {v11, v1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_0

    move v8, v9

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    :goto_0
    or-int/2addr v8, v0

    goto :goto_1

    :cond_1
    move v8, v0

    :goto_1
    and-int/lit8 v10, v0, 0x30

    if-nez v10, :cond_3

    invoke-virtual {v11, v2}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_2

    const/16 v10, 0x20

    goto :goto_2

    :cond_2
    const/16 v10, 0x10

    :goto_2
    or-int/2addr v8, v10

    :cond_3
    and-int/lit16 v10, v0, 0x180

    if-nez v10, :cond_5

    invoke-virtual {v11, v3}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_4

    const/16 v10, 0x100

    goto :goto_3

    :cond_4
    const/16 v10, 0x80

    :goto_3
    or-int/2addr v8, v10

    :cond_5
    and-int/lit16 v10, v0, 0xc00

    if-nez v10, :cond_7

    invoke-virtual {v11, v4}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_6

    const/16 v10, 0x800

    goto :goto_4

    :cond_6
    const/16 v10, 0x400

    :goto_4
    or-int/2addr v8, v10

    :cond_7
    and-int/lit16 v10, v0, 0x6000

    if-nez v10, :cond_9

    invoke-virtual {v11, v5}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_8

    const/16 v10, 0x4000

    goto :goto_5

    :cond_8
    const/16 v10, 0x2000

    :goto_5
    or-int/2addr v8, v10

    :cond_9
    const/high16 v10, 0x30000

    and-int/2addr v10, v0

    if-nez v10, :cond_b

    invoke-virtual {v11, v6}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_a

    const/high16 v10, 0x20000

    goto :goto_6

    :cond_a
    const/high16 v10, 0x10000

    :goto_6
    or-int/2addr v8, v10

    :cond_b
    const/high16 v10, 0x180000

    or-int/2addr v8, v10

    const/high16 v10, 0xc00000

    and-int/2addr v10, v0

    if-nez v10, :cond_d

    invoke-virtual {v11, v7}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_c

    const/high16 v10, 0x800000

    goto :goto_7

    :cond_c
    const/high16 v10, 0x400000

    :goto_7
    or-int/2addr v8, v10

    :cond_d
    move v14, v8

    const v8, 0x492493

    and-int/2addr v8, v14

    const v10, 0x492492

    const/4 v15, 0x0

    if-eq v8, v10, :cond_e

    const/4 v8, 0x1

    goto :goto_8

    :cond_e
    move v8, v15

    :goto_8
    and-int/lit8 v10, v14, 0x1

    invoke-virtual {v11, v10, v8}, La0/r;->N(IZ)Z

    move-result v8

    if-eqz v8, :cond_4d

    iget-object v8, v1, Ls/w0;->d:La0/h0;

    iget-object v10, v1, Ls/w0;->a:LE/V;

    invoke-virtual {v8}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v2, v8}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Boolean;

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    if-nez v8, :cond_10

    invoke-virtual {v10}, LE/V;->t()Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v2, v8}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Boolean;

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    if-nez v8, :cond_10

    invoke-virtual {v1}, Ls/w0;->g()Z

    move-result v8

    if-nez v8, :cond_10

    invoke-virtual {v1}, Ls/w0;->d()Z

    move-result v8

    if-eqz v8, :cond_f

    goto :goto_9

    :cond_f
    const v8, -0xdb7cd6d

    invoke-virtual {v11, v8}, La0/r;->V(I)V

    invoke-virtual {v11, v15}, La0/r;->p(Z)V

    move-object v1, v7

    goto/16 :goto_22

    :cond_10
    :goto_9
    const v8, -0xdd8f8c3

    invoke-virtual {v11, v8}, La0/r;->V(I)V

    and-int/lit8 v8, v14, 0xe

    or-int/lit8 v13, v8, 0x30

    and-int/lit8 v12, v13, 0xe

    xor-int/lit8 v15, v12, 0x6

    if-le v15, v9, :cond_11

    invoke-virtual {v11, v1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_12

    :cond_11
    and-int/lit8 v13, v13, 0x6

    if-ne v13, v9, :cond_13

    :cond_12
    const/4 v13, 0x1

    goto :goto_a

    :cond_13
    const/4 v13, 0x0

    :goto_a
    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v15

    move/from16 v17, v13

    sget-object v13, La0/m;->a:La0/U;

    if-nez v17, :cond_14

    if-ne v15, v13, :cond_15

    :cond_14
    invoke-virtual {v10}, LE/V;->t()Ljava/lang/Object;

    move-result-object v15

    invoke-virtual {v11, v15}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_15
    invoke-virtual {v1}, Ls/w0;->g()Z

    move-result v17

    if-eqz v17, :cond_16

    invoke-virtual {v10}, LE/V;->t()Ljava/lang/Object;

    move-result-object v15

    :cond_16
    const v10, 0x6defb3b0

    invoke-virtual {v11, v10}, La0/r;->V(I)V

    invoke-static {v1, v2, v15, v11}, Landroidx/compose/animation/b;->d(Ls/w0;Lr7/c;Ljava/lang/Object;La0/r;)Lr/z;

    move-result-object v15

    const/4 v9, 0x0

    invoke-virtual {v11, v9}, La0/r;->p(Z)V

    iget-object v9, v1, Ls/w0;->d:La0/h0;

    invoke-virtual {v9}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v11, v10}, La0/r;->V(I)V

    invoke-static {v1, v2, v9, v11}, Landroidx/compose/animation/b;->d(Ls/w0;Lr7/c;Ljava/lang/Object;La0/r;)Lr/z;

    move-result-object v9

    const/4 v10, 0x0

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    or-int/lit16 v10, v12, 0xc00

    sget-object v12, Ls/B0;->a:Lb2/a;

    and-int/lit8 v12, v10, 0xe

    xor-int/lit8 v12, v12, 0x6

    const/4 v0, 0x4

    if-le v12, v0, :cond_17

    invoke-virtual {v11, v1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v17

    if-nez v17, :cond_18

    :cond_17
    and-int/lit8 v2, v10, 0x6

    if-ne v2, v0, :cond_19

    :cond_18
    const/4 v0, 0x1

    goto :goto_b

    :cond_19
    const/4 v0, 0x0

    :goto_b
    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v2

    if-nez v0, :cond_1b

    if-ne v2, v13, :cond_1a

    goto :goto_c

    :cond_1a
    move/from16 v18, v10

    move/from16 v19, v14

    goto :goto_d

    :cond_1b
    :goto_c
    new-instance v2, Ls/w0;

    new-instance v0, Ls/K;

    invoke-direct {v0, v15}, Ls/K;-><init>(Ljava/lang/Object;)V

    move/from16 v18, v10

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v19, v14

    iget-object v14, v1, Ls/w0;->c:Ljava/lang/String;

    const-string v7, " > EnterExitTransition"

    invoke-static {v10, v14, v7}, LX3/b;->m(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v2, v0, v1, v7}, Ls/w0;-><init>(LE/V;Ls/w0;Ljava/lang/String;)V

    invoke-virtual {v11, v2}, La0/r;->g0(Ljava/lang/Object;)V

    :goto_d
    check-cast v2, Ls/w0;

    const/4 v0, 0x4

    if-le v12, v0, :cond_1c

    invoke-virtual {v11, v1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_1d

    :cond_1c
    and-int/lit8 v7, v18, 0x6

    if-ne v7, v0, :cond_1e

    :cond_1d
    const/4 v0, 0x1

    goto :goto_e

    :cond_1e
    const/4 v0, 0x0

    :goto_e
    invoke-virtual {v11, v2}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v7

    or-int/2addr v0, v7

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v7

    if-nez v0, :cond_1f

    if-ne v7, v13, :cond_20

    :cond_1f
    new-instance v7, Lj6/c;

    const/4 v0, 0x5

    invoke-direct {v7, v0, v1, v2}, Lj6/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v11, v7}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_20
    check-cast v7, Lr7/c;

    invoke-static {v2, v7, v11}, La0/b;->e(Ljava/lang/Object;Lr7/c;La0/r;)V

    invoke-virtual {v1}, Ls/w0;->g()Z

    move-result v0

    if-eqz v0, :cond_21

    invoke-virtual {v2, v15, v9}, Ls/w0;->k(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_f

    :cond_21
    invoke-virtual {v2, v9}, Ls/w0;->p(Ljava/lang/Object;)V

    iget-object v0, v2, Ls/w0;->k:La0/h0;

    sget-object v7, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v0, v7}, La0/h0;->setValue(Ljava/lang/Object;)V

    :goto_f
    invoke-static {v6, v11}, La0/b;->x(Ljava/lang/Object;La0/r;)La0/Z;

    move-result-object v0

    iget-object v7, v2, Ls/w0;->a:LE/V;

    iget-object v9, v2, Ls/w0;->a:LE/V;

    iget-object v10, v2, Ls/w0;->d:La0/h0;

    invoke-virtual {v7}, LE/V;->t()Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v10}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v12

    invoke-interface {v6, v7, v12}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v11, v2}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v12

    invoke-virtual {v11, v0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v14

    or-int/2addr v12, v14

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v14

    const/4 v15, 0x0

    if-nez v12, :cond_22

    if-ne v14, v13, :cond_23

    :cond_22
    new-instance v14, Lr/r;

    invoke-direct {v14, v2, v0, v15}, Lr/r;-><init>(Ls/w0;La0/Z;Lh7/c;)V

    invoke-virtual {v11, v14}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_23
    check-cast v14, Lr7/e;

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v13, :cond_24

    invoke-static {v7}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v0

    invoke-virtual {v11, v0}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_24
    check-cast v0, La0/Z;

    invoke-virtual {v11, v14}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v7

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v12

    if-nez v7, :cond_25

    if-ne v12, v13, :cond_26

    :cond_25
    new-instance v12, La0/P0;

    invoke-direct {v12, v14, v0, v15}, La0/P0;-><init>(Lr7/e;La0/Z;Lh7/c;)V

    invoke-virtual {v11, v12}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_26
    check-cast v12, Lr7/e;

    sget-object v7, Ld7/z;->a:Ld7/z;

    invoke-static {v11, v7, v12}, La0/b;->g(La0/r;Ljava/lang/Object;Lr7/e;)V

    invoke-virtual {v9}, LE/V;->t()Ljava/lang/Object;

    move-result-object v7

    sget-object v12, Lr/z;->v:Lr/z;

    if-ne v7, v12, :cond_28

    invoke-virtual {v10}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v7

    if-ne v7, v12, :cond_28

    invoke-interface {v0}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_27

    goto :goto_10

    :cond_27
    const v0, -0xdb7e4ad

    invoke-virtual {v11, v0}, La0/r;->V(I)V

    const/4 v9, 0x0

    invoke-virtual {v11, v9}, La0/r;->p(Z)V

    move-object/from16 v1, p6

    move v10, v9

    goto/16 :goto_21

    :cond_28
    :goto_10
    const v0, -0xdc9414d

    invoke-virtual {v11, v0}, La0/r;->V(I)V

    const/4 v0, 0x4

    if-ne v8, v0, :cond_29

    const/4 v0, 0x1

    goto :goto_11

    :cond_29
    const/4 v0, 0x0

    :goto_11
    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v7

    if-nez v0, :cond_2a

    if-ne v7, v13, :cond_2b

    :cond_2a
    new-instance v7, Lr/w;

    invoke-direct {v7}, Lr/w;-><init>()V

    invoke-virtual {v11, v7}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_2b
    check-cast v7, Lr/w;

    sget-object v0, Lr/F;->a:Ls/D0;

    move-object v0, v9

    sget-object v9, Ls/d;->p:Ls/D0;

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v8

    if-ne v8, v13, :cond_2c

    sget-object v8, Lr/C;->u:Lr/C;

    invoke-virtual {v11, v8}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_2c
    move-object v14, v8

    check-cast v14, Lr7/a;

    invoke-virtual {v11, v2}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v8

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v12

    if-nez v8, :cond_2d

    if-ne v12, v13, :cond_2e

    :cond_2d
    invoke-static {v4}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v12

    invoke-virtual {v11, v12}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_2e
    check-cast v12, La0/Z;

    invoke-virtual {v0}, LE/V;->t()Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v10}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v15

    move-object/from16 v17, v0

    sget-object v0, Lr/z;->u:Lr/z;

    if-ne v8, v15, :cond_30

    invoke-virtual/range {v17 .. v17}, LE/V;->t()Ljava/lang/Object;

    move-result-object v8

    if-ne v8, v0, :cond_30

    invoke-virtual {v2}, Ls/w0;->g()Z

    move-result v8

    if-eqz v8, :cond_2f

    invoke-interface {v12, v4}, La0/Z;->setValue(Ljava/lang/Object;)V

    goto :goto_12

    :cond_2f
    sget-object v8, Lr/K;->b:Lr/K;

    invoke-interface {v12, v8}, La0/Z;->setValue(Ljava/lang/Object;)V

    goto :goto_12

    :cond_30
    invoke-virtual {v10}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v8

    if-ne v8, v0, :cond_31

    invoke-interface {v12}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lr/K;

    invoke-virtual {v8, v4}, Lr/K;->a(Lr/K;)Lr/K;

    move-result-object v8

    invoke-interface {v12, v8}, La0/Z;->setValue(Ljava/lang/Object;)V

    :cond_31
    :goto_12
    invoke-interface {v12}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v8

    move-object v15, v8

    check-cast v15, Lr/K;

    invoke-virtual {v11, v2}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v8

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v12

    if-nez v8, :cond_32

    if-ne v12, v13, :cond_33

    :cond_32
    invoke-static {v5}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v12

    invoke-virtual {v11, v12}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_33
    check-cast v12, La0/Z;

    invoke-virtual/range {v17 .. v17}, LE/V;->t()Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v10}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v1

    if-ne v8, v1, :cond_35

    invoke-virtual/range {v17 .. v17}, LE/V;->t()Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_35

    invoke-virtual {v2}, Ls/w0;->g()Z

    move-result v0

    if-eqz v0, :cond_34

    invoke-interface {v12, v5}, La0/Z;->setValue(Ljava/lang/Object;)V

    goto :goto_13

    :cond_34
    sget-object v0, Lr/L;->b:Lr/L;

    invoke-interface {v12, v0}, La0/Z;->setValue(Ljava/lang/Object;)V

    goto :goto_13

    :cond_35
    invoke-virtual {v10}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v1

    if-eq v1, v0, :cond_36

    invoke-interface {v12}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lr/L;

    invoke-virtual {v0, v5}, Lr/L;->a(Lr/L;)Lr/L;

    move-result-object v0

    invoke-interface {v12, v0}, La0/Z;->setValue(Ljava/lang/Object;)V

    :cond_36
    :goto_13
    invoke-interface {v12}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lr/L;

    iget-object v1, v15, Lr/K;->a:Lr/Z;

    iget-object v8, v1, Lr/Z;->b:Lr/X;

    if-nez v8, :cond_38

    iget-object v8, v0, Lr/L;->a:Lr/Z;

    iget-object v8, v8, Lr/Z;->b:Lr/X;

    if-eqz v8, :cond_37

    goto :goto_14

    :cond_37
    const/4 v8, 0x0

    goto :goto_15

    :cond_38
    :goto_14
    const/4 v8, 0x1

    :goto_15
    iget-object v1, v1, Lr/Z;->c:Lr/x;

    if-nez v1, :cond_3a

    iget-object v1, v0, Lr/L;->a:Lr/Z;

    iget-object v1, v1, Lr/Z;->c:Lr/x;

    if-eqz v1, :cond_39

    goto :goto_16

    :cond_39
    const/4 v1, 0x0

    goto :goto_17

    :cond_3a
    :goto_16
    const/4 v1, 0x1

    :goto_17
    if-eqz v8, :cond_3c

    const v8, 0x7fa35c5

    invoke-virtual {v11, v8}, La0/r;->V(I)V

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v8

    if-ne v8, v13, :cond_3b

    const-string v8, "Built-in slide"

    invoke-virtual {v11, v8}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_3b
    move-object v10, v8

    check-cast v10, Ljava/lang/String;

    const/16 v12, 0x180

    move-object v8, v13

    const/4 v13, 0x0

    move-object/from16 v16, v8

    move-object v8, v2

    move-object/from16 v2, v16

    const/16 v16, 0x1

    invoke-static/range {v8 .. v13}, Ls/B0;->b(Ls/w0;Ls/D0;Ljava/lang/String;La0/r;II)Ls/q0;

    move-result-object v10

    move-object/from16 v17, v9

    const/4 v9, 0x0

    invoke-virtual {v11, v9}, La0/r;->p(Z)V

    move-object/from16 v18, v10

    goto :goto_18

    :cond_3c
    move-object v8, v2

    move-object/from16 v17, v9

    move-object v2, v13

    const/4 v9, 0x0

    const/16 v16, 0x1

    const v10, 0x7fbd310

    invoke-virtual {v11, v10}, La0/r;->V(I)V

    invoke-virtual {v11, v9}, La0/r;->p(Z)V

    const/16 v18, 0x0

    :goto_18
    if-eqz v1, :cond_3e

    const v9, 0x7fd399f

    invoke-virtual {v11, v9}, La0/r;->V(I)V

    sget-object v9, Ls/d;->q:Ls/D0;

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v10

    if-ne v10, v2, :cond_3d

    const-string v10, "Built-in shrink/expand"

    invoke-virtual {v11, v10}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_3d
    check-cast v10, Ljava/lang/String;

    const/16 v12, 0x180

    const/4 v13, 0x0

    invoke-static/range {v8 .. v13}, Ls/B0;->b(Ls/w0;Ls/D0;Ljava/lang/String;La0/r;II)Ls/q0;

    move-result-object v9

    const/4 v10, 0x0

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    move-object/from16 v27, v9

    goto :goto_19

    :cond_3e
    const/4 v10, 0x0

    const v9, 0x7feea87

    invoke-virtual {v11, v9}, La0/r;->V(I)V

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    const/16 v27, 0x0

    :goto_19
    if-eqz v1, :cond_40

    const v9, 0x8000a21

    invoke-virtual {v11, v9}, La0/r;->V(I)V

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v9

    if-ne v9, v2, :cond_3f

    const-string v9, "Built-in InterruptionHandlingOffset"

    invoke-virtual {v11, v9}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_3f
    move-object v10, v9

    check-cast v10, Ljava/lang/String;

    const/16 v12, 0x180

    const/4 v13, 0x0

    move-object/from16 v9, v17

    invoke-static/range {v8 .. v13}, Ls/B0;->b(Ls/w0;Ls/D0;Ljava/lang/String;La0/r;II)Ls/q0;

    move-result-object v9

    const/4 v10, 0x0

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    move-object/from16 v17, v9

    goto :goto_1a

    :cond_40
    const/4 v10, 0x0

    const v9, 0x802a3c7

    invoke-virtual {v11, v9}, La0/r;->V(I)V

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    const/16 v17, 0x0

    :goto_1a
    iget-object v9, v15, Lr/K;->a:Lr/Z;

    iget-object v10, v0, Lr/L;->a:Lr/Z;

    xor-int/lit8 v1, v1, 0x1

    sget-object v12, Ls/d;->j:Ls/D0;

    iget-object v9, v9, Lr/Z;->a:Lr/M;

    if-nez v9, :cond_42

    iget-object v9, v10, Lr/Z;->a:Lr/M;

    if-eqz v9, :cond_41

    goto :goto_1b

    :cond_41
    const/4 v9, 0x0

    goto :goto_1c

    :cond_42
    :goto_1b
    move/from16 v9, v16

    :goto_1c
    if-eqz v9, :cond_44

    const v9, -0x29f40b7d

    invoke-virtual {v11, v9}, La0/r;->V(I)V

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v9

    if-ne v9, v2, :cond_43

    const-string v9, "Built-in alpha"

    invoke-virtual {v11, v9}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_43
    move-object v10, v9

    check-cast v10, Ljava/lang/String;

    move-object v9, v12

    const/16 v12, 0x180

    const/4 v13, 0x0

    invoke-static/range {v8 .. v13}, Ls/B0;->b(Ls/w0;Ls/D0;Ljava/lang/String;La0/r;II)Ls/q0;

    move-result-object v9

    const/4 v10, 0x0

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    goto :goto_1d

    :cond_44
    const/4 v10, 0x0

    const v9, -0x29f17598

    invoke-virtual {v11, v9}, La0/r;->V(I)V

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    const/4 v9, 0x0

    :goto_1d
    const v12, -0x29edd778

    invoke-virtual {v11, v12}, La0/r;->V(I)V

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    const v12, -0x29ea06f8

    invoke-virtual {v11, v12}, La0/r;->V(I)V

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    invoke-virtual {v11, v9}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v10

    invoke-virtual {v11, v15}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v12

    or-int/2addr v10, v12

    invoke-virtual {v11, v0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v12

    or-int/2addr v10, v12

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v13

    or-int/2addr v10, v13

    invoke-virtual {v11, v8}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v13

    or-int/2addr v10, v13

    invoke-virtual {v11, v12}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v13

    or-int/2addr v10, v13

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v13

    if-nez v10, :cond_46

    if-ne v13, v2, :cond_45

    goto :goto_1e

    :cond_45
    move-object/from16 v25, v0

    move-object/from16 v24, v15

    goto :goto_1f

    :cond_46
    :goto_1e
    new-instance v20, Lr/A;

    move-object/from16 v26, v12

    move-object/from16 v25, v0

    move-object/from16 v23, v8

    move-object/from16 v21, v9

    move-object/from16 v22, v12

    move-object/from16 v24, v15

    invoke-direct/range {v20 .. v26}, Lr/A;-><init>(Ls/q0;Ls/q0;Ls/w0;Lr/K;Lr/L;Ls/q0;)V

    move-object/from16 v13, v20

    invoke-virtual {v11, v13}, La0/r;->g0(Ljava/lang/Object;)V

    :goto_1f
    move-object/from16 v28, v13

    check-cast v28, Lr/A;

    invoke-virtual {v11, v1}, La0/r;->g(Z)Z

    move-result v0

    invoke-virtual {v11, v14}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v9

    or-int/2addr v0, v9

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v9

    if-nez v0, :cond_47

    if-ne v9, v2, :cond_48

    :cond_47
    new-instance v9, Lr/D;

    invoke-direct {v9, v14, v1}, Lr/D;-><init>(Lr7/a;Z)V

    invoke-virtual {v11, v9}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_48
    check-cast v9, Lr7/c;

    sget-object v0, Lm0/o;->a:Lm0/o;

    invoke-static {v0, v9}, Landroidx/compose/ui/graphics/a;->a(Lm0/r;Lr7/c;)Lm0/r;

    move-result-object v1

    new-instance v20, Landroidx/compose/animation/EnterExitTransitionElement;

    move-object/from16 v21, v8

    move-object/from16 v23, v17

    move-object/from16 v26, v25

    move-object/from16 v22, v27

    move-object/from16 v27, v14

    move-object/from16 v25, v24

    move-object/from16 v24, v18

    invoke-direct/range {v20 .. v28}, Landroidx/compose/animation/EnterExitTransitionElement;-><init>(Ls/w0;Ls/q0;Ls/q0;Ls/q0;Lr/K;Lr/L;Lr7/a;Lr/A;)V

    move-object/from16 v8, v20

    invoke-interface {v1, v8}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v1

    const v8, -0x715e89

    invoke-virtual {v11, v8}, La0/r;->V(I)V

    const/4 v10, 0x0

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    invoke-interface {v1, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v0

    invoke-interface {v3, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v0

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v2, :cond_49

    new-instance v1, Lr/p;

    invoke-direct {v1, v7}, Lr/p;-><init>(Lr/w;)V

    invoke-virtual {v11, v1}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_49
    check-cast v1, Lr/p;

    iget-wide v8, v11, La0/r;->T:J

    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    invoke-virtual {v11}, La0/r;->l()La0/n0;

    move-result-object v8

    invoke-static {v11, v0}, Lm0/a;->c(La0/r;Lm0/r;)Lm0/r;

    move-result-object v0

    sget-object v9, LL0/j;->b:LL0/i;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v9, LL0/i;->b:LL0/C;

    invoke-virtual {v11}, La0/r;->Z()V

    iget-boolean v10, v11, La0/r;->S:Z

    if-eqz v10, :cond_4a

    invoke-virtual {v11, v9}, La0/r;->k(Lr7/a;)V

    goto :goto_20

    :cond_4a
    invoke-virtual {v11}, La0/r;->j0()V

    :goto_20
    sget-object v9, LL0/i;->e:LL0/h;

    invoke-static {v11, v1, v9}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v1, LL0/i;->d:LL0/h;

    invoke-static {v11, v8, v1}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v1, LL0/i;->f:LL0/h;

    iget-boolean v8, v11, La0/r;->S:Z

    if-nez v8, :cond_4b

    invoke-virtual {v11}, La0/r;->K()Ljava/lang/Object;

    move-result-object v8

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v8, v9}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_4c

    :cond_4b
    invoke-static {v2, v11, v2, v1}, Lq3/h;->n(ILa0/r;ILL0/h;)V

    :cond_4c
    sget-object v1, LL0/i;->c:LL0/h;

    invoke-static {v11, v0, v1}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    shr-int/lit8 v0, v19, 0x12

    and-int/lit8 v0, v0, 0x70

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v1, p6

    invoke-virtual {v1, v7, v11, v0}, Li0/d;->f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move/from16 v0, v16

    invoke-virtual {v11, v0}, La0/r;->p(Z)V

    const/4 v10, 0x0

    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    :goto_21
    invoke-virtual {v11, v10}, La0/r;->p(Z)V

    goto :goto_22

    :cond_4d
    move-object v1, v7

    invoke-virtual {v11}, La0/r;->Q()V

    :goto_22
    invoke-virtual {v11}, La0/r;->r()La0/r0;

    move-result-object v9

    if-eqz v9, :cond_4e

    new-instance v0, Lr/q;

    move-object/from16 v2, p1

    move/from16 v8, p8

    move-object v7, v1

    move-object/from16 v1, p0

    invoke-direct/range {v0 .. v8}, Lr/q;-><init>(Ls/w0;Lr7/c;Lm0/r;Lr/K;Lr/L;Lr7/e;Li0/d;I)V

    iput-object v0, v9, La0/r0;->d:Lr7/e;

    :cond_4e
    return-void
.end method

.method public static final b(ZLm0/r;Lr/K;Lr/L;Ljava/lang/String;Li0/d;La0/r;II)V
    .locals 10

    move-object/from16 v6, p6

    move/from16 v8, p7

    const v0, 0x6b47faab

    invoke-virtual {v6, v0}, La0/r;->X(I)La0/r;

    invoke-virtual {v6, p0}, La0/r;->g(Z)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x20

    goto :goto_0

    :cond_0
    const/16 v0, 0x10

    :goto_0
    or-int/2addr v0, v8

    and-int/lit8 v1, p8, 0x2

    if-eqz v1, :cond_1

    or-int/lit16 v0, v0, 0x180

    goto :goto_2

    :cond_1
    and-int/lit16 v2, v8, 0x180

    if-nez v2, :cond_3

    invoke-virtual {v6, p1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/16 v2, 0x100

    goto :goto_1

    :cond_2
    const/16 v2, 0x80

    :goto_1
    or-int/2addr v0, v2

    :cond_3
    :goto_2
    and-int/lit8 v2, p8, 0x4

    if-eqz v2, :cond_4

    or-int/lit16 v0, v0, 0xc00

    goto :goto_4

    :cond_4
    and-int/lit16 v3, v8, 0xc00

    if-nez v3, :cond_6

    invoke-virtual {v6, p2}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5

    const/16 v3, 0x800

    goto :goto_3

    :cond_5
    const/16 v3, 0x400

    :goto_3
    or-int/2addr v0, v3

    :cond_6
    :goto_4
    and-int/lit8 v3, p8, 0x8

    if-eqz v3, :cond_7

    or-int/lit16 v0, v0, 0x6000

    goto :goto_6

    :cond_7
    and-int/lit16 v4, v8, 0x6000

    if-nez v4, :cond_9

    invoke-virtual {v6, p3}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_8

    const/16 v4, 0x4000

    goto :goto_5

    :cond_8
    const/16 v4, 0x2000

    :goto_5
    or-int/2addr v0, v4

    :cond_9
    :goto_6
    const/high16 v4, 0x30000

    or-int/2addr v0, v4

    const v5, 0x92491

    and-int/2addr v5, v0

    const v7, 0x92490

    if-eq v5, v7, :cond_a

    const/4 v5, 0x1

    goto :goto_7

    :cond_a
    const/4 v5, 0x0

    :goto_7
    and-int/lit8 v7, v0, 0x1

    invoke-virtual {v6, v7, v5}, La0/r;->N(IZ)Z

    move-result v5

    if-eqz v5, :cond_f

    if-eqz v1, :cond_b

    sget-object p1, Lm0/o;->a:Lm0/o;

    :cond_b
    const/16 v1, 0xf

    const/4 v5, 0x3

    const/4 v7, 0x0

    if-eqz v2, :cond_c

    invoke-static {v7, v5}, Lr/F;->b(Ls/z;I)Lr/K;

    move-result-object p2

    invoke-static {v7, v1}, Lr/F;->a(Ls/C0;I)Lr/K;

    move-result-object v2

    invoke-virtual {p2, v2}, Lr/K;->a(Lr/K;)Lr/K;

    move-result-object p2

    :cond_c
    if-eqz v3, :cond_d

    invoke-static {v7, v5}, Lr/F;->c(Ls/z;I)Lr/L;

    move-result-object p3

    invoke-static {v7, v1}, Lr/F;->d(Ls/C0;I)Lr/L;

    move-result-object v1

    invoke-virtual {p3, v1}, Lr/L;->a(Lr/L;)Lr/L;

    move-result-object p3

    :cond_d
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    shr-int/lit8 v2, v0, 0x3

    and-int/lit8 v2, v2, 0xe

    or-int/lit8 v2, v2, 0x30

    const-string v9, "AnimatedVisibility"

    invoke-static {v1, v9, v6, v2}, Ls/B0;->e(Ljava/lang/Object;Ljava/lang/String;La0/r;I)Ls/w0;

    move-result-object v1

    invoke-virtual {v6}, La0/r;->K()Ljava/lang/Object;

    move-result-object v2

    sget-object v3, La0/m;->a:La0/U;

    if-ne v2, v3, :cond_e

    sget-object v2, Lr/s;->v:Lr/s;

    invoke-virtual {v6, v2}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_e
    check-cast v2, Lr7/c;

    and-int/lit16 v3, v0, 0x380

    or-int/lit8 v3, v3, 0x30

    and-int/lit16 v5, v0, 0x1c00

    or-int/2addr v3, v5

    const v5, 0xe000

    and-int/2addr v0, v5

    or-int/2addr v0, v3

    or-int v7, v0, v4

    move-object v3, p2

    move-object v4, p3

    move-object v5, p5

    move-object v0, v1

    move-object v1, v2

    move-object v2, p1

    invoke-static/range {v0 .. v7}, Landroidx/compose/animation/b;->c(Ls/w0;Lr7/c;Lm0/r;Lr/K;Lr/L;Li0/d;La0/r;I)V

    move-object v5, v9

    goto :goto_8

    :cond_f
    invoke-virtual/range {p6 .. p6}, La0/r;->Q()V

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    :goto_8
    invoke-virtual/range {p6 .. p6}, La0/r;->r()La0/r0;

    move-result-object p1

    if-eqz p1, :cond_10

    new-instance v0, Lr/t;

    move v1, p0

    move-object v6, p5

    move v7, v8

    move/from16 v8, p8

    invoke-direct/range {v0 .. v8}, Lr/t;-><init>(ZLm0/r;Lr/K;Lr/L;Ljava/lang/String;Li0/d;II)V

    iput-object v0, p1, La0/r0;->d:Lr7/e;

    :cond_10
    return-void
.end method

.method public static final c(Ls/w0;Lr7/c;Lm0/r;Lr/K;Lr/L;Li0/d;La0/r;I)V
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v9, p2

    move-object/from16 v7, p6

    move/from16 v10, p7

    const v2, 0x65b46798

    invoke-virtual {v7, v2}, La0/r;->X(I)La0/r;

    and-int/lit8 v2, v10, 0x6

    const/4 v3, 0x4

    if-nez v2, :cond_1

    invoke-virtual {v7, v0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    :goto_0
    or-int/2addr v2, v10

    goto :goto_1

    :cond_1
    move v2, v10

    :goto_1
    and-int/lit8 v4, v10, 0x30

    const/16 v5, 0x20

    if-nez v4, :cond_3

    invoke-virtual {v7, v1}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    move v4, v5

    goto :goto_2

    :cond_2
    const/16 v4, 0x10

    :goto_2
    or-int/2addr v2, v4

    :cond_3
    and-int/lit16 v4, v10, 0x180

    if-nez v4, :cond_5

    invoke-virtual {v7, v9}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    const/16 v4, 0x100

    goto :goto_3

    :cond_4
    const/16 v4, 0x80

    :goto_3
    or-int/2addr v2, v4

    :cond_5
    and-int/lit16 v4, v10, 0xc00

    if-nez v4, :cond_7

    move-object/from16 v4, p3

    invoke-virtual {v7, v4}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_6

    const/16 v6, 0x800

    goto :goto_4

    :cond_6
    const/16 v6, 0x400

    :goto_4
    or-int/2addr v2, v6

    goto :goto_5

    :cond_7
    move-object/from16 v4, p3

    :goto_5
    and-int/lit16 v6, v10, 0x6000

    if-nez v6, :cond_9

    move-object/from16 v6, p4

    invoke-virtual {v7, v6}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_8

    const/16 v8, 0x4000

    goto :goto_6

    :cond_8
    const/16 v8, 0x2000

    :goto_6
    or-int/2addr v2, v8

    goto :goto_7

    :cond_9
    move-object/from16 v6, p4

    :goto_7
    const/high16 v8, 0x30000

    and-int v11, v10, v8

    if-nez v11, :cond_b

    move-object/from16 v11, p5

    invoke-virtual {v7, v11}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_a

    const/high16 v12, 0x20000

    goto :goto_8

    :cond_a
    const/high16 v12, 0x10000

    :goto_8
    or-int/2addr v2, v12

    goto :goto_9

    :cond_b
    move-object/from16 v11, p5

    :goto_9
    const v12, 0x12493

    and-int/2addr v12, v2

    const v13, 0x12492

    const/4 v14, 0x0

    const/4 v15, 0x1

    if-eq v12, v13, :cond_c

    move v12, v15

    goto :goto_a

    :cond_c
    move v12, v14

    :goto_a
    and-int/lit8 v13, v2, 0x1

    invoke-virtual {v7, v13, v12}, La0/r;->N(IZ)Z

    move-result v12

    if-eqz v12, :cond_12

    and-int/lit8 v12, v2, 0x70

    if-ne v12, v5, :cond_d

    move v5, v15

    goto :goto_b

    :cond_d
    move v5, v14

    :goto_b
    and-int/lit8 v13, v2, 0xe

    if-ne v13, v3, :cond_e

    move v14, v15

    :cond_e
    or-int v3, v5, v14

    invoke-virtual {v7}, La0/r;->K()Ljava/lang/Object;

    move-result-object v5

    sget-object v14, La0/m;->a:La0/U;

    if-nez v3, :cond_f

    if-ne v5, v14, :cond_10

    :cond_f
    new-instance v5, Lr/u;

    invoke-direct {v5, v1, v0}, Lr/u;-><init>(Lr7/c;Ls/w0;)V

    invoke-virtual {v7, v5}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_10
    check-cast v5, Lr7/f;

    invoke-static {v9, v5}, Landroidx/compose/ui/layout/a;->b(Lm0/r;Lr7/f;)Lm0/r;

    move-result-object v3

    invoke-virtual {v7}, La0/r;->K()Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v14, :cond_11

    sget-object v5, Lr/f;->w:Lr/f;

    invoke-virtual {v7, v5}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_11
    check-cast v5, Lr7/e;

    or-int/2addr v8, v13

    or-int/2addr v8, v12

    and-int/lit16 v12, v2, 0x1c00

    or-int/2addr v8, v12

    const v12, 0xe000

    and-int/2addr v12, v2

    or-int/2addr v8, v12

    const/high16 v12, 0x1c00000

    shl-int/lit8 v2, v2, 0x6

    and-int/2addr v2, v12

    or-int/2addr v8, v2

    move-object v2, v3

    move-object v3, v4

    move-object v4, v6

    move-object v6, v11

    invoke-static/range {v0 .. v8}, Landroidx/compose/animation/b;->a(Ls/w0;Lr7/c;Lm0/r;Lr/K;Lr/L;Lr7/e;Li0/d;La0/r;I)V

    goto :goto_c

    :cond_12
    invoke-virtual/range {p6 .. p6}, La0/r;->Q()V

    :goto_c
    invoke-virtual/range {p6 .. p6}, La0/r;->r()La0/r0;

    move-result-object v11

    if-eqz v11, :cond_13

    new-instance v0, LX/l1;

    const/4 v8, 0x4

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object v3, v9

    move v7, v10

    invoke-direct/range {v0 .. v8}, LX/l1;-><init>(Ls/w0;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Li0/d;II)V

    iput-object v0, v11, La0/r0;->d:Lr7/e;

    :cond_13
    return-void
.end method

.method public static final d(Ls/w0;Lr7/c;Ljava/lang/Object;La0/r;)Lr/z;
    .locals 6

    const/4 v0, 0x0

    const v1, -0x192ea059

    const/4 v2, 0x0

    invoke-virtual {p3, v1, v2, p0, v0}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0}, Ls/w0;->g()Z

    move-result v0

    iget-object p0, p0, Ls/w0;->a:LE/V;

    sget-object v1, Lr/z;->t:Lr/z;

    sget-object v3, Lr/z;->v:Lr/z;

    sget-object v4, Lr/z;->u:Lr/z;

    if-eqz v0, :cond_1

    const v0, -0xca519e1

    invoke-virtual {p3, v0}, La0/r;->V(I)V

    invoke-virtual {p3, v2}, La0/r;->p(Z)V

    invoke-interface {p1, p2}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_0

    move-object v1, v4

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, LE/V;->t()Ljava/lang/Object;

    move-result-object p0

    invoke-interface {p1, p0}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_6

    move-object v1, v3

    goto :goto_1

    :cond_1
    const v0, -0xca0eb0c

    invoke-virtual {p3, v0}, La0/r;->V(I)V

    invoke-virtual {p3}, La0/r;->K()Ljava/lang/Object;

    move-result-object v0

    sget-object v5, La0/m;->a:La0/U;

    if-ne v0, v5, :cond_2

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v0}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v0

    invoke-virtual {p3, v0}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_2
    check-cast v0, La0/Z;

    invoke-virtual {p0}, LE/V;->t()Ljava/lang/Object;

    move-result-object p0

    invoke-interface {p1, p0}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_3

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-interface {v0, p0}, La0/Z;->setValue(Ljava/lang/Object;)V

    :cond_3
    invoke-interface {p1, p2}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_4

    move-object v1, v4

    goto :goto_0

    :cond_4
    invoke-interface {v0}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_5

    move-object v1, v3

    :cond_5
    :goto_0
    invoke-virtual {p3, v2}, La0/r;->p(Z)V

    :cond_6
    :goto_1
    invoke-virtual {p3, v2}, La0/r;->p(Z)V

    return-object v1
.end method
