.class public abstract Landroidx/compose/animation/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:J

.field public static final synthetic b:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/high16 v0, -0x80000000

    int-to-long v0, v0

    const/16 v2, 0x20

    shl-long v2, v0, v2

    const-wide v4, 0xffffffffL

    and-long/2addr v0, v4

    or-long/2addr v0, v2

    sput-wide v0, Landroidx/compose/animation/a;->a:J

    return-void
.end method

.method public static final a(Ls/w0;Lm0/r;Lr7/c;Lm0/e;Lr7/c;Li0/d;La0/r;I)V
    .locals 20

    move-object/from16 v1, p0

    move-object/from16 v7, p1

    move-object/from16 v3, p2

    move-object/from16 v8, p3

    move-object/from16 v9, p4

    move-object/from16 v10, p6

    move/from16 v11, p7

    const v0, 0x1e804e2f

    invoke-virtual {v10, v0}, La0/r;->X(I)La0/r;

    and-int/lit8 v0, v11, 0x6

    const/4 v2, 0x4

    if-nez v0, :cond_1

    invoke-virtual {v10, v1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    const/4 v0, 0x2

    :goto_0
    or-int/2addr v0, v11

    goto :goto_1

    :cond_1
    move v0, v11

    :goto_1
    and-int/lit8 v4, v11, 0x30

    if-nez v4, :cond_3

    invoke-virtual {v10, v7}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    const/16 v4, 0x20

    goto :goto_2

    :cond_2
    const/16 v4, 0x10

    :goto_2
    or-int/2addr v0, v4

    :cond_3
    and-int/lit16 v4, v11, 0x180

    if-nez v4, :cond_5

    invoke-virtual {v10, v3}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    const/16 v4, 0x100

    goto :goto_3

    :cond_4
    const/16 v4, 0x80

    :goto_3
    or-int/2addr v0, v4

    :cond_5
    and-int/lit16 v4, v11, 0xc00

    if-nez v4, :cond_7

    invoke-virtual {v10, v8}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_6

    const/16 v4, 0x800

    goto :goto_4

    :cond_6
    const/16 v4, 0x400

    :goto_4
    or-int/2addr v0, v4

    :cond_7
    and-int/lit16 v4, v11, 0x6000

    if-nez v4, :cond_9

    invoke-virtual {v10, v9}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_8

    const/16 v4, 0x4000

    goto :goto_5

    :cond_8
    const/16 v4, 0x2000

    :goto_5
    or-int/2addr v0, v4

    :cond_9
    const/high16 v4, 0x30000

    and-int/2addr v4, v11

    move-object/from16 v6, p5

    if-nez v4, :cond_b

    invoke-virtual {v10, v6}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a

    const/high16 v4, 0x20000

    goto :goto_6

    :cond_a
    const/high16 v4, 0x10000

    :goto_6
    or-int/2addr v0, v4

    :cond_b
    const v4, 0x12493

    and-int/2addr v4, v0

    const v5, 0x12492

    if-eq v4, v5, :cond_c

    const/4 v4, 0x1

    goto :goto_7

    :cond_c
    const/4 v4, 0x0

    :goto_7
    and-int/lit8 v5, v0, 0x1

    invoke-virtual {v10, v5, v4}, La0/r;->N(IZ)Z

    move-result v4

    if-eqz v4, :cond_32

    sget-object v4, LM0/r0;->n:La0/X0;

    invoke-virtual {v10, v4}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lj1/m;

    and-int/lit8 v0, v0, 0xe

    if-ne v0, v2, :cond_d

    const/4 v5, 0x1

    goto :goto_8

    :cond_d
    const/4 v5, 0x0

    :goto_8
    invoke-virtual {v10}, La0/r;->K()Ljava/lang/Object;

    move-result-object v14

    sget-object v15, La0/m;->a:La0/U;

    if-nez v5, :cond_e

    if-ne v14, v15, :cond_f

    :cond_e
    new-instance v14, Lr/o;

    invoke-direct {v14, v1, v8, v4}, Lr/o;-><init>(Ls/w0;Lm0/e;Lj1/m;)V

    invoke-virtual {v10, v14}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_f
    check-cast v14, Lr/o;

    if-ne v0, v2, :cond_10

    const/4 v5, 0x1

    goto :goto_9

    :cond_10
    const/4 v5, 0x0

    :goto_9
    invoke-virtual {v10}, La0/r;->K()Ljava/lang/Object;

    move-result-object v13

    if-nez v5, :cond_11

    if-ne v13, v15, :cond_12

    :cond_11
    iget-object v5, v1, Ls/w0;->a:LE/V;

    invoke-virtual {v5}, LE/V;->t()Ljava/lang/Object;

    move-result-object v5

    filled-new-array {v5}, [Ljava/lang/Object;

    move-result-object v5

    new-instance v13, Lk0/o;

    invoke-direct {v13}, Lk0/o;-><init>()V

    invoke-static {v5}, Le7/k;->y([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-virtual {v13, v5}, Lk0/o;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v10, v13}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_12
    move-object v5, v13

    check-cast v5, Lk0/o;

    if-ne v0, v2, :cond_13

    const/4 v0, 0x1

    goto :goto_a

    :cond_13
    const/4 v0, 0x0

    :goto_a
    invoke-virtual {v10}, La0/r;->K()Ljava/lang/Object;

    move-result-object v2

    if-nez v0, :cond_14

    if-ne v2, v15, :cond_15

    :cond_14
    sget-object v0, Lp/P;->a:[J

    new-instance v2, Lp/H;

    invoke-direct {v2}, Lp/H;-><init>()V

    invoke-virtual {v10, v2}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_15
    move-object v13, v2

    check-cast v13, Lp/H;

    iget-object v0, v1, Ls/w0;->a:LE/V;

    iget-object v2, v1, Ls/w0;->d:La0/h0;

    invoke-virtual {v0}, LE/V;->t()Ljava/lang/Object;

    move-result-object v12

    invoke-virtual {v5, v12}, Lk0/o;->contains(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_16

    invoke-virtual {v5}, Lk0/o;->clear()V

    invoke-virtual {v0}, LE/V;->t()Ljava/lang/Object;

    move-result-object v12

    invoke-virtual {v5, v12}, Lk0/o;->add(Ljava/lang/Object;)Z

    :cond_16
    invoke-virtual {v0}, LE/V;->t()Ljava/lang/Object;

    move-result-object v12

    move-object/from16 v16, v0

    invoke-virtual {v2}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v12, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1b

    invoke-virtual {v5}, Lk0/o;->size()I

    move-result v0

    const/4 v12, 0x1

    if-ne v0, v12, :cond_17

    const/4 v0, 0x0

    invoke-virtual {v5, v0}, Lk0/o;->get(I)Ljava/lang/Object;

    move-result-object v12

    invoke-virtual/range {v16 .. v16}, LE/V;->t()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v12, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_18

    :cond_17
    invoke-virtual {v5}, Lk0/o;->clear()V

    invoke-virtual/range {v16 .. v16}, LE/V;->t()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v5, v0}, Lk0/o;->add(Ljava/lang/Object;)Z

    :cond_18
    iget v0, v13, Lp/H;->e:I

    const/4 v12, 0x1

    if-ne v0, v12, :cond_19

    invoke-virtual/range {v16 .. v16}, LE/V;->t()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v13, v0}, Lp/H;->c(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1a

    :cond_19
    invoke-virtual {v13}, Lp/H;->a()V

    :cond_1a
    iput-object v8, v14, Lr/o;->b:Lm0/e;

    iput-object v4, v14, Lr/o;->c:Lj1/m;

    :cond_1b
    invoke-virtual/range {v16 .. v16}, LE/V;->t()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v4

    invoke-static {v0, v4}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1f

    invoke-virtual {v2}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v5, v0}, Lk0/o;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1f

    invoke-virtual {v5}, Lk0/o;->listIterator()Ljava/util/ListIterator;

    move-result-object v0

    const/4 v4, 0x0

    :goto_b
    move-object v12, v0

    check-cast v12, LL0/q;

    invoke-virtual {v12}, LL0/q;->hasNext()Z

    move-result v17

    move-object/from16 v18, v0

    if-eqz v17, :cond_1d

    invoke-virtual {v12}, LL0/q;->next()Ljava/lang/Object;

    move-result-object v12

    invoke-interface {v9, v12}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    invoke-virtual {v2}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-interface {v9, v0}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v12, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1c

    :goto_c
    const/4 v0, -0x1

    goto :goto_d

    :cond_1c
    add-int/lit8 v4, v4, 0x1

    move-object/from16 v0, v18

    goto :goto_b

    :cond_1d
    const/4 v4, -0x1

    goto :goto_c

    :goto_d
    if-ne v4, v0, :cond_1e

    invoke-virtual {v2}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v5, v0}, Lk0/o;->add(Ljava/lang/Object;)Z

    goto :goto_e

    :cond_1e
    invoke-virtual {v2}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v5, v4, v0}, Lk0/o;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_1f
    :goto_e
    invoke-virtual {v2}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v13, v0}, Lp/H;->c(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_21

    invoke-virtual/range {v16 .. v16}, LE/V;->t()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v13, v0}, Lp/H;->c(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_20

    goto :goto_f

    :cond_20
    const v0, 0x755d6173

    invoke-virtual {v10, v0}, La0/r;->V(I)V

    const/4 v0, 0x0

    invoke-virtual {v10, v0}, La0/r;->p(Z)V

    move-object v6, v3

    move-object v0, v14

    goto :goto_11

    :cond_21
    :goto_f
    const v0, 0x7535ef71

    invoke-virtual {v10, v0}, La0/r;->V(I)V

    invoke-virtual {v13}, Lp/H;->a()V

    invoke-virtual {v5}, Lk0/o;->size()I

    move-result v12

    const/4 v0, 0x0

    :goto_10
    if-ge v0, v12, :cond_22

    invoke-virtual {v5, v0}, Lk0/o;->get(I)Ljava/lang/Object;

    move-result-object v2

    move v4, v0

    new-instance v0, Lr/e;

    move-object/from16 v19, v14

    move v14, v4

    move-object/from16 v4, v19

    invoke-direct/range {v0 .. v6}, Lr/e;-><init>(Ls/w0;Ljava/lang/Object;Lr7/c;Lr/o;Lk0/o;Li0/d;)V

    move-object v1, v0

    move-object v6, v3

    move-object v0, v4

    const v3, -0x16ceaa7

    invoke-static {v3, v1, v10}, Li0/i;->d(ILd7/e;La0/r;)Li0/d;

    move-result-object v1

    invoke-virtual {v13, v2, v1}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    add-int/lit8 v1, v14, 0x1

    move-object v14, v0

    move v0, v1

    move-object v3, v6

    move-object/from16 v1, p0

    move-object/from16 v6, p5

    goto :goto_10

    :cond_22
    move-object v6, v3

    move-object v0, v14

    const/4 v1, 0x0

    invoke-virtual {v10, v1}, La0/r;->p(Z)V

    :goto_11
    invoke-virtual/range {p0 .. p0}, Ls/w0;->f()Ls/r0;

    move-result-object v1

    invoke-virtual {v10, v0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v2

    invoke-virtual {v10, v1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v1

    or-int/2addr v1, v2

    invoke-virtual {v10}, La0/r;->K()Ljava/lang/Object;

    move-result-object v2

    if-nez v1, :cond_23

    if-ne v2, v15, :cond_24

    :cond_23
    invoke-interface {v6, v0}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Lr/y;

    invoke-virtual {v10, v2}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_24
    check-cast v2, Lr/y;

    iget-object v1, v0, Lr/o;->a:Ls/w0;

    invoke-virtual {v10, v0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v3

    invoke-virtual {v10}, La0/r;->K()Ljava/lang/Object;

    move-result-object v4

    if-nez v3, :cond_25

    if-ne v4, v15, :cond_26

    :cond_25
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v3}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v4

    invoke-virtual {v10, v4}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_26
    check-cast v4, La0/Z;

    iget-object v2, v2, Lr/y;->d:Lr/W;

    invoke-static {v2, v10}, La0/b;->x(Ljava/lang/Object;La0/r;)La0/Z;

    move-result-object v12

    iget-object v2, v1, Ls/w0;->a:LE/V;

    invoke-virtual {v2}, LE/V;->t()Ljava/lang/Object;

    move-result-object v2

    iget-object v1, v1, Ls/w0;->d:La0/h0;

    invoke-virtual {v1}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v2, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_27

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {v4, v1}, La0/Z;->setValue(Ljava/lang/Object;)V

    goto :goto_12

    :cond_27
    invoke-interface {v12}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_28

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-interface {v4, v1}, La0/Z;->setValue(Ljava/lang/Object;)V

    :cond_28
    :goto_12
    invoke-interface {v4}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    sget-object v14, Lm0/o;->a:Lm0/o;

    const/4 v2, 0x0

    if-eqz v1, :cond_2b

    const v1, 0x50a7e5f9

    invoke-virtual {v10, v1}, La0/r;->V(I)V

    move-object v4, v0

    iget-object v0, v4, Lr/o;->a:Ls/w0;

    sget-object v1, Ls/d;->q:Ls/D0;

    move-object v3, v4

    const/4 v4, 0x0

    move-object/from16 v16, v5

    const/4 v5, 0x2

    move-object/from16 v17, v2

    const/4 v2, 0x0

    move-object v6, v3

    move-object v3, v10

    move-object/from16 v10, v17

    invoke-static/range {v0 .. v5}, Ls/B0;->b(Ls/w0;Ls/D0;Ljava/lang/String;La0/r;II)Ls/q0;

    move-result-object v2

    invoke-virtual {v3, v2}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v3}, La0/r;->K()Ljava/lang/Object;

    move-result-object v1

    if-nez v0, :cond_29

    if-ne v1, v15, :cond_2a

    :cond_29
    invoke-interface {v12}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lr/W;

    invoke-static {v14}, LH4/G4;->b(Lm0/r;)Lm0/r;

    move-result-object v1

    invoke-virtual {v3, v1}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_2a
    move-object v14, v1

    check-cast v14, Lm0/r;

    const/4 v0, 0x0

    invoke-virtual {v3, v0}, La0/r;->p(Z)V

    goto :goto_13

    :cond_2b
    move-object v6, v0

    move-object/from16 v16, v5

    move-object v3, v10

    const/4 v0, 0x0

    move-object v10, v2

    const v1, 0x50abf533

    invoke-virtual {v3, v1}, La0/r;->V(I)V

    invoke-virtual {v3, v0}, La0/r;->p(Z)V

    iput-object v10, v6, Lr/o;->f:Ls/p0;

    :goto_13
    new-instance v0, Landroidx/compose/animation/AnimatedContentTransitionScopeImpl$SizeModifierElement;

    invoke-direct {v0, v2, v12, v6}, Landroidx/compose/animation/AnimatedContentTransitionScopeImpl$SizeModifierElement;-><init>(Ls/q0;La0/Z;Lr/o;)V

    invoke-interface {v14, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v0

    invoke-interface {v7, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v0

    invoke-virtual {v3}, La0/r;->K()Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v15, :cond_2c

    new-instance v1, Lr/h;

    invoke-direct {v1, v6}, Lr/h;-><init>(Lr/o;)V

    invoke-virtual {v3, v1}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_2c
    check-cast v1, Lr/h;

    iget-wide v4, v3, La0/r;->T:J

    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    invoke-virtual {v3}, La0/r;->l()La0/n0;

    move-result-object v4

    invoke-static {v3, v0}, Lm0/a;->c(La0/r;Lm0/r;)Lm0/r;

    move-result-object v0

    sget-object v5, LL0/j;->b:LL0/i;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v5, LL0/i;->b:LL0/C;

    invoke-virtual {v3}, La0/r;->Z()V

    iget-boolean v6, v3, La0/r;->S:Z

    if-eqz v6, :cond_2d

    invoke-virtual {v3, v5}, La0/r;->k(Lr7/a;)V

    goto :goto_14

    :cond_2d
    invoke-virtual {v3}, La0/r;->j0()V

    :goto_14
    sget-object v5, LL0/i;->e:LL0/h;

    invoke-static {v3, v1, v5}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v1, LL0/i;->d:LL0/h;

    invoke-static {v3, v4, v1}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v1, LL0/i;->f:LL0/h;

    iget-boolean v4, v3, La0/r;->S:Z

    if-nez v4, :cond_2e

    invoke-virtual {v3}, La0/r;->K()Ljava/lang/Object;

    move-result-object v4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2f

    :cond_2e
    invoke-static {v2, v3, v2, v1}, Lq3/h;->n(ILa0/r;ILL0/h;)V

    :cond_2f
    sget-object v1, LL0/i;->c:LL0/h;

    invoke-static {v3, v0, v1}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    const v0, -0x334534ba    # -9.793387E7f

    invoke-virtual {v3, v0}, La0/r;->V(I)V

    invoke-virtual/range {v16 .. v16}, Lk0/o;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_15
    if-ge v1, v0, :cond_31

    move-object/from16 v5, v16

    invoke-virtual {v5, v1}, Lk0/o;->get(I)Ljava/lang/Object;

    move-result-object v2

    const v4, -0x78c25a0a

    invoke-interface {v9, v2}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v12, 0x0

    invoke-virtual {v3, v4, v12, v6, v10}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v13, v2}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lr7/e;

    if-nez v2, :cond_30

    const v2, 0x6077a733

    invoke-virtual {v3, v2}, La0/r;->V(I)V

    :goto_16
    invoke-virtual {v3, v12}, La0/r;->p(Z)V

    goto :goto_17

    :cond_30
    const v4, -0x78c25572

    invoke-virtual {v3, v4}, La0/r;->V(I)V

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v3, v4}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_16

    :goto_17
    invoke-virtual {v3, v12}, La0/r;->p(Z)V

    add-int/lit8 v1, v1, 0x1

    move-object/from16 v16, v5

    goto :goto_15

    :cond_31
    const/4 v12, 0x0

    invoke-virtual {v3, v12}, La0/r;->p(Z)V

    const/4 v12, 0x1

    invoke-virtual {v3, v12}, La0/r;->p(Z)V

    goto :goto_18

    :cond_32
    move-object v3, v10

    invoke-virtual {v3}, La0/r;->Q()V

    :goto_18
    invoke-virtual {v3}, La0/r;->r()La0/r0;

    move-result-object v10

    if-eqz v10, :cond_33

    new-instance v0, LX/l1;

    const/4 v8, 0x3

    move-object/from16 v1, p0

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v6, p5

    move-object v2, v7

    move-object v5, v9

    move v7, v11

    invoke-direct/range {v0 .. v8}, LX/l1;-><init>(Ls/w0;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Li0/d;II)V

    iput-object v0, v10, La0/r0;->d:Lr7/e;

    :cond_33
    return-void
.end method
