.class public abstract Landroidx/compose/animation/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:J


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/high16 v0, -0x80000000

    int-to-long v0, v0

    const/16 v2, 0x20

    shl-long v2, v0, v2

    const-wide v4, 0xffffffffL

    and-long/2addr v0, v4

    or-long/2addr v0, v2

    sput-wide v0, Landroidx/compose/animation/c;->a:J

    return-void
.end method

.method public static a(Lm0/r;Ls/g0;I)Lm0/r;
    .locals 5

    const/4 v0, 0x1

    and-int/2addr p2, v0

    if-eqz p2, :cond_0

    int-to-long p1, v0

    const/16 v1, 0x20

    shl-long v1, p1, v1

    const-wide v3, 0xffffffffL

    and-long/2addr p1, v3

    or-long/2addr p1, v1

    new-instance v1, Lj1/l;

    invoke-direct {v1, p1, p2}, Lj1/l;-><init>(J)V

    const/4 p1, 0x0

    const/high16 p2, 0x43c80000    # 400.0f

    invoke-static {p1, p2, v1, v0}, Ls/d;->n(FFLjava/lang/Object;I)Ls/g0;

    move-result-object p1

    :cond_0
    invoke-static {p0}, LH4/G4;->b(Lm0/r;)Lm0/r;

    move-result-object p0

    new-instance p2, Landroidx/compose/animation/SizeAnimationModifierElement;

    invoke-direct {p2, p1}, Landroidx/compose/animation/SizeAnimationModifierElement;-><init>(Ls/z;)V

    invoke-interface {p0, p2}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method
