.class final Landroidx/compose/animation/EnterExitTransitionElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:Ls/w0;

.field public final b:Ls/q0;

.field public final c:Ls/q0;

.field public final d:Ls/q0;

.field public final e:Lr/K;

.field public final f:Lr/L;

.field public final g:Lr7/a;

.field public final h:Lr/A;


# direct methods
.method public constructor <init>(Ls/w0;Ls/q0;Ls/q0;Ls/q0;Lr/K;Lr/L;Lr7/a;Lr/A;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->a:Ls/w0;

    iput-object p2, p0, Landroidx/compose/animation/EnterExitTransitionElement;->b:Ls/q0;

    iput-object p3, p0, Landroidx/compose/animation/EnterExitTransitionElement;->c:Ls/q0;

    iput-object p4, p0, Landroidx/compose/animation/EnterExitTransitionElement;->d:Ls/q0;

    iput-object p5, p0, Landroidx/compose/animation/EnterExitTransitionElement;->e:Lr/K;

    iput-object p6, p0, Landroidx/compose/animation/EnterExitTransitionElement;->f:Lr/L;

    iput-object p7, p0, Landroidx/compose/animation/EnterExitTransitionElement;->g:Lr7/a;

    iput-object p8, p0, Landroidx/compose/animation/EnterExitTransitionElement;->h:Lr/A;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Landroidx/compose/animation/EnterExitTransitionElement;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Landroidx/compose/animation/EnterExitTransitionElement;

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->a:Ls/w0;

    iget-object v3, p1, Landroidx/compose/animation/EnterExitTransitionElement;->a:Ls/w0;

    invoke-static {v1, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->b:Ls/q0;

    iget-object v3, p1, Landroidx/compose/animation/EnterExitTransitionElement;->b:Ls/q0;

    invoke-static {v1, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    return v2

    :cond_3
    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->c:Ls/q0;

    iget-object v3, p1, Landroidx/compose/animation/EnterExitTransitionElement;->c:Ls/q0;

    invoke-static {v1, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    return v2

    :cond_4
    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->d:Ls/q0;

    iget-object v3, p1, Landroidx/compose/animation/EnterExitTransitionElement;->d:Ls/q0;

    invoke-static {v1, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5

    return v2

    :cond_5
    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->e:Lr/K;

    iget-object v3, p1, Landroidx/compose/animation/EnterExitTransitionElement;->e:Lr/K;

    invoke-static {v1, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    return v2

    :cond_6
    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->f:Lr/L;

    iget-object v3, p1, Landroidx/compose/animation/EnterExitTransitionElement;->f:Lr/L;

    invoke-static {v1, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7

    return v2

    :cond_7
    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->g:Lr7/a;

    iget-object v3, p1, Landroidx/compose/animation/EnterExitTransitionElement;->g:Lr7/a;

    invoke-static {v1, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8

    return v2

    :cond_8
    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->h:Lr/A;

    iget-object p1, p1, Landroidx/compose/animation/EnterExitTransitionElement;->h:Lr/A;

    invoke-static {v1, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_9

    return v2

    :cond_9
    return v0
.end method

.method public final g()Lm0/q;
    .locals 9

    new-instance v0, Lr/J;

    iget-object v7, p0, Landroidx/compose/animation/EnterExitTransitionElement;->g:Lr7/a;

    iget-object v8, p0, Landroidx/compose/animation/EnterExitTransitionElement;->h:Lr/A;

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->a:Ls/w0;

    iget-object v2, p0, Landroidx/compose/animation/EnterExitTransitionElement;->b:Ls/q0;

    iget-object v3, p0, Landroidx/compose/animation/EnterExitTransitionElement;->c:Ls/q0;

    iget-object v4, p0, Landroidx/compose/animation/EnterExitTransitionElement;->d:Ls/q0;

    iget-object v5, p0, Landroidx/compose/animation/EnterExitTransitionElement;->e:Lr/K;

    iget-object v6, p0, Landroidx/compose/animation/EnterExitTransitionElement;->f:Lr/L;

    invoke-direct/range {v0 .. v8}, Lr/J;-><init>(Ls/w0;Ls/q0;Ls/q0;Ls/q0;Lr/K;Lr/L;Lr7/a;Lr/A;)V

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 1

    check-cast p1, Lr/J;

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->a:Ls/w0;

    iput-object v0, p1, Lr/J;->I:Ls/w0;

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->b:Ls/q0;

    iput-object v0, p1, Lr/J;->J:Ls/q0;

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->c:Ls/q0;

    iput-object v0, p1, Lr/J;->K:Ls/q0;

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->d:Ls/q0;

    iput-object v0, p1, Lr/J;->L:Ls/q0;

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->e:Lr/K;

    iput-object v0, p1, Lr/J;->M:Lr/K;

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->f:Lr/L;

    iput-object v0, p1, Lr/J;->N:Lr/L;

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->g:Lr7/a;

    iput-object v0, p1, Lr/J;->O:Lr7/a;

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->h:Lr/A;

    iput-object v0, p1, Lr/J;->P:Lr/A;

    return-void
.end method

.method public final hashCode()I
    .locals 3

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->a:Ls/w0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    const/4 v1, 0x0

    iget-object v2, p0, Landroidx/compose/animation/EnterExitTransitionElement;->b:Ls/q0;

    if-nez v2, :cond_0

    move v2, v1

    goto :goto_0

    :cond_0
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_0
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Landroidx/compose/animation/EnterExitTransitionElement;->c:Ls/q0;

    if-nez v2, :cond_1

    move v2, v1

    goto :goto_1

    :cond_1
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_1
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Landroidx/compose/animation/EnterExitTransitionElement;->d:Ls/q0;

    if-nez v2, :cond_2

    goto :goto_2

    :cond_2
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_2
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->e:Lr/K;

    iget-object v1, v1, Lr/K;->a:Lr/Z;

    invoke-virtual {v1}, Lr/Z;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->f:Lr/L;

    iget-object v0, v0, Lr/L;->a:Lr/Z;

    invoke-virtual {v0}, Lr/Z;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->g:Lr7/a;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object v0, p0, Landroidx/compose/animation/EnterExitTransitionElement;->h:Lr/A;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "EnterExitTransitionElement(transition="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->a:Ls/w0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", sizeAnimation="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->b:Ls/q0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", offsetAnimation="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->c:Ls/q0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", slideAnimation="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->d:Ls/q0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", enter="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->e:Lr/K;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", exit="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->f:Lr/L;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", isEnabled="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->g:Lr7/a;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", graphicsLayerBlock="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionElement;->h:Lr/A;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
