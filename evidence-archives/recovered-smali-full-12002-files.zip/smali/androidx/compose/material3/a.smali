.class public abstract Landroidx/compose/material3/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:F

.field public static final b:F

.field public static final c:F

.field public static final d:F

.field public static final e:F

.field public static final f:Ls/e0;

.field public static final g:Ls/C0;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    sget v0, LZ/s;->b:F

    sput v0, Landroidx/compose/material3/a;->a:F

    sget v1, LZ/s;->g:F

    sput v1, Landroidx/compose/material3/a;->b:F

    sget v1, LZ/s;->f:F

    sput v1, Landroidx/compose/material3/a;->c:F

    sget v1, LZ/s;->d:F

    sput v1, Landroidx/compose/material3/a;->d:F

    sub-float/2addr v1, v0

    const/4 v0, 0x2

    int-to-float v0, v0

    div-float/2addr v1, v0

    sput v1, Landroidx/compose/material3/a;->e:F

    new-instance v0, Ls/e0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/compose/material3/a;->f:Ls/e0;

    new-instance v0, Ls/C0;

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/16 v3, 0x64

    invoke-direct {v0, v3, v1, v2}, Ls/C0;-><init>(ILs/x;I)V

    sput-object v0, Landroidx/compose/material3/a;->g:Ls/C0;

    return-void
.end method

.method public static final a(ZLr7/c;Lm0/r;ZLX/I1;La0/r;II)V
    .locals 47

    move-object/from16 v2, p1

    move-object/from16 v6, p5

    move/from16 v8, p6

    const v0, 0x5e33f474

    invoke-virtual {v6, v0}, La0/r;->X(I)La0/r;

    and-int/lit8 v0, v8, 0x6

    if-nez v0, :cond_1

    move/from16 v0, p0

    invoke-virtual {v6, v0}, La0/r;->g(Z)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v3, v8

    goto :goto_1

    :cond_1
    move/from16 v0, p0

    move v3, v8

    :goto_1
    and-int/lit8 v4, v8, 0x30

    if-nez v4, :cond_3

    invoke-virtual {v6, v2}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    const/16 v4, 0x20

    goto :goto_2

    :cond_2
    const/16 v4, 0x10

    :goto_2
    or-int/2addr v3, v4

    :cond_3
    or-int/lit16 v4, v3, 0xd80

    and-int/lit8 v5, p7, 0x10

    if-eqz v5, :cond_5

    or-int/lit16 v4, v3, 0x6d80

    :cond_4
    move/from16 v3, p3

    goto :goto_4

    :cond_5
    and-int/lit16 v3, v8, 0x6000

    if-nez v3, :cond_4

    move/from16 v3, p3

    invoke-virtual {v6, v3}, La0/r;->g(Z)Z

    move-result v7

    if-eqz v7, :cond_6

    const/16 v7, 0x4000

    goto :goto_3

    :cond_6
    const/16 v7, 0x2000

    :goto_3
    or-int/2addr v4, v7

    :goto_4
    const/high16 v7, 0x30000

    and-int/2addr v7, v8

    if-nez v7, :cond_7

    const/high16 v7, 0x10000

    or-int/2addr v4, v7

    :cond_7
    const/high16 v7, 0x180000

    or-int/2addr v4, v7

    const v7, 0x92493

    and-int/2addr v7, v4

    const v9, 0x92492

    if-ne v7, v9, :cond_9

    invoke-virtual {v6}, La0/r;->z()Z

    move-result v7

    if-nez v7, :cond_8

    goto :goto_5

    :cond_8
    invoke-virtual {v6}, La0/r;->Q()V

    move-object/from16 v5, p4

    move v4, v3

    move-object/from16 v3, p2

    goto/16 :goto_b

    :cond_9
    :goto_5
    invoke-virtual {v6}, La0/r;->S()V

    and-int/lit8 v7, v8, 0x1

    sget-object v9, Lm0/o;->a:Lm0/o;

    const v10, -0x70001

    if-eqz v7, :cond_b

    invoke-virtual {v6}, La0/r;->x()Z

    move-result v7

    if-eqz v7, :cond_a

    goto :goto_7

    :cond_a
    invoke-virtual {v6}, La0/r;->Q()V

    and-int/2addr v4, v10

    move-object/from16 v8, p2

    move-object/from16 v13, p4

    move v2, v3

    :goto_6
    move v7, v4

    goto/16 :goto_9

    :cond_b
    :goto_7
    if-eqz v5, :cond_c

    const/4 v3, 0x1

    :cond_c
    sget-object v5, LX/L;->a:La0/X0;

    invoke-virtual {v6, v5}, La0/r;->j(La0/q0;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LX/J;

    iget-object v7, v5, LX/J;->S:LX/I1;

    iget-wide v11, v5, LX/J;->p:J

    if-nez v7, :cond_d

    new-instance v13, LX/I1;

    sget v7, LZ/s;->a:F

    const/16 v7, 0xa

    invoke-static {v5, v7}, LX/L;->d(LX/J;I)J

    move-result-wide v14

    const/16 v7, 0x1a

    invoke-static {v5, v7}, LX/L;->d(LX/J;I)J

    move-result-wide v16

    sget-wide v18, Lt0/p;->f:J

    const/16 v7, 0xb

    invoke-static {v5, v7}, LX/L;->d(LX/J;I)J

    move-result-wide v20

    const/16 v7, 0x18

    invoke-static {v5, v7}, LX/L;->d(LX/J;I)J

    move-result-wide v22

    move/from16 v46, v10

    const/16 v10, 0x27

    invoke-static {v5, v10}, LX/L;->d(LX/J;I)J

    move-result-wide v24

    invoke-static {v5, v7}, LX/L;->d(LX/J;I)J

    move-result-wide v26

    invoke-static {v5, v10}, LX/L;->d(LX/J;I)J

    move-result-wide v28

    const/16 v7, 0x23

    invoke-static {v5, v7}, LX/L;->d(LX/J;I)J

    move-result-wide v1

    const/high16 v7, 0x3f800000    # 1.0f

    const/16 v10, 0xe

    invoke-static {v1, v2, v7, v10}, Lt0/p;->b(JFI)J

    move-result-wide v1

    invoke-static {v1, v2, v11, v12}, Lt0/D;->k(JJ)J

    move-result-wide v30

    const/16 v1, 0x12

    move/from16 p3, v3

    invoke-static {v5, v1}, LX/L;->d(LX/J;I)J

    move-result-wide v2

    const v7, 0x3df5c28f    # 0.12f

    invoke-static {v2, v3, v7, v10}, Lt0/p;->b(JFI)J

    move-result-wide v2

    invoke-static {v2, v3, v11, v12}, Lt0/D;->k(JJ)J

    move-result-wide v32

    invoke-static {v5, v1}, LX/L;->d(LX/J;I)J

    move-result-wide v2

    const v7, 0x3ec28f5c    # 0.38f

    invoke-static {v2, v3, v7, v10}, Lt0/p;->b(JFI)J

    move-result-wide v2

    invoke-static {v2, v3, v11, v12}, Lt0/D;->k(JJ)J

    move-result-wide v36

    invoke-static {v5, v1}, LX/L;->d(LX/J;I)J

    move-result-wide v2

    invoke-static {v2, v3, v7, v10}, Lt0/p;->b(JFI)J

    move-result-wide v2

    invoke-static {v2, v3, v11, v12}, Lt0/D;->k(JJ)J

    move-result-wide v38

    const/16 v2, 0x27

    invoke-static {v5, v2}, LX/L;->d(LX/J;I)J

    move-result-wide v7

    const v3, 0x3df5c28f    # 0.12f

    invoke-static {v7, v8, v3, v10}, Lt0/p;->b(JFI)J

    move-result-wide v7

    invoke-static {v7, v8, v11, v12}, Lt0/D;->k(JJ)J

    move-result-wide v40

    invoke-static {v5, v1}, LX/L;->d(LX/J;I)J

    move-result-wide v7

    invoke-static {v7, v8, v3, v10}, Lt0/p;->b(JFI)J

    move-result-wide v7

    invoke-static {v7, v8, v11, v12}, Lt0/D;->k(JJ)J

    move-result-wide v42

    invoke-static {v5, v2}, LX/L;->d(LX/J;I)J

    move-result-wide v1

    const v3, 0x3ec28f5c    # 0.38f

    invoke-static {v1, v2, v3, v10}, Lt0/p;->b(JFI)J

    move-result-wide v1

    invoke-static {v1, v2, v11, v12}, Lt0/D;->k(JJ)J

    move-result-wide v44

    move-wide/from16 v34, v18

    invoke-direct/range {v13 .. v45}, LX/I1;-><init>(JJJJJJJJJJJJJJJJ)V

    iput-object v13, v5, LX/J;->S:LX/I1;

    goto :goto_8

    :cond_d
    move/from16 p3, v3

    move/from16 v46, v10

    move-object v13, v7

    :goto_8
    and-int v4, v4, v46

    move/from16 v2, p3

    move-object v8, v9

    goto/16 :goto_6

    :goto_9
    invoke-virtual {v6}, La0/r;->q()V

    const v1, 0x2eb3c1f3

    invoke-virtual {v6, v1}, La0/r;->V(I)V

    invoke-virtual {v6}, La0/r;->K()Ljava/lang/Object;

    move-result-object v1

    sget-object v3, La0/m;->a:La0/U;

    if-ne v1, v3, :cond_e

    new-instance v1, Ly/j;

    invoke-direct {v1}, Ly/j;-><init>()V

    invoke-virtual {v6, v1}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_e
    move-object v4, v1

    check-cast v4, Ly/j;

    const/4 v1, 0x0

    invoke-virtual {v6, v1}, La0/r;->p(Z)V

    if-eqz p1, :cond_f

    sget-object v1, LX/f0;->a:La0/X0;

    sget-object v0, Landroidx/compose/material3/MinimumInteractiveModifier;->a:Landroidx/compose/material3/MinimumInteractiveModifier;

    move-object v1, v4

    new-instance v4, LT0/g;

    const/4 v3, 0x2

    invoke-direct {v4, v3}, LT0/g;-><init>(I)V

    move-object/from16 v5, p1

    move v3, v2

    move-object v2, v1

    move/from16 v1, p0

    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/selection/b;->b(Lm0/r;ZLy/j;ZLT0/g;Lr7/c;)Lm0/r;

    move-result-object v9

    move-object v1, v2

    move v2, v3

    goto :goto_a

    :cond_f
    move-object v1, v4

    :goto_a
    invoke-interface {v8, v9}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v0

    invoke-static {v0}, Landroidx/compose/foundation/layout/c;->p(Lm0/r;)Lm0/r;

    move-result-object v0

    sget v3, Landroidx/compose/material3/a;->c:F

    sget v4, Landroidx/compose/material3/a;->d:F

    invoke-static {v0, v3, v4}, Landroidx/compose/foundation/layout/c;->h(Lm0/r;FF)Lm0/r;

    move-result-object v0

    sget v3, LZ/s;->a:F

    const/4 v3, 0x5

    invoke-static {v3, v6}, LX/y1;->a(ILa0/r;)Lt0/H;

    move-result-object v5

    shl-int/lit8 v3, v7, 0x3

    and-int/lit8 v4, v3, 0x70

    shr-int/lit8 v7, v7, 0x6

    and-int/lit16 v7, v7, 0x380

    or-int/2addr v4, v7

    const v7, 0xe000

    and-int/2addr v3, v7

    or-int v7, v4, v3

    move-object v4, v1

    move-object v3, v13

    move/from16 v1, p0

    invoke-static/range {v0 .. v7}, Landroidx/compose/material3/a;->b(Lm0/r;ZZLX/I1;Ly/j;Lt0/H;La0/r;I)V

    move v4, v2

    move-object v5, v3

    move-object v3, v8

    :goto_b
    invoke-virtual/range {p5 .. p5}, La0/r;->r()La0/r0;

    move-result-object v8

    if-eqz v8, :cond_10

    new-instance v0, LX/J1;

    move/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v6, p6

    move/from16 v7, p7

    invoke-direct/range {v0 .. v7}, LX/J1;-><init>(ZLr7/c;Lm0/r;ZLX/I1;II)V

    iput-object v0, v8, La0/r0;->d:Lr7/e;

    :cond_10
    return-void
.end method

.method public static final b(Lm0/r;ZZLX/I1;Ly/j;Lt0/H;La0/r;I)V
    .locals 16

    move-object/from16 v1, p0

    move/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v0, p6

    move/from16 v7, p7

    const v8, -0x5f0405ca

    invoke-virtual {v0, v8}, La0/r;->X(I)La0/r;

    and-int/lit8 v8, v7, 0x6

    if-nez v8, :cond_1

    invoke-virtual {v0, v1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_0

    const/4 v8, 0x4

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    :goto_0
    or-int/2addr v8, v7

    goto :goto_1

    :cond_1
    move v8, v7

    :goto_1
    and-int/lit8 v11, v7, 0x30

    if-nez v11, :cond_3

    invoke-virtual {v0, v2}, La0/r;->g(Z)Z

    move-result v11

    if-eqz v11, :cond_2

    const/16 v11, 0x20

    goto :goto_2

    :cond_2
    const/16 v11, 0x10

    :goto_2
    or-int/2addr v8, v11

    :cond_3
    and-int/lit16 v11, v7, 0x180

    if-nez v11, :cond_5

    invoke-virtual {v0, v3}, La0/r;->g(Z)Z

    move-result v11

    if-eqz v11, :cond_4

    const/16 v11, 0x100

    goto :goto_3

    :cond_4
    const/16 v11, 0x80

    :goto_3
    or-int/2addr v8, v11

    :cond_5
    and-int/lit16 v11, v7, 0xc00

    if-nez v11, :cond_7

    invoke-virtual {v0, v4}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_6

    const/16 v11, 0x800

    goto :goto_4

    :cond_6
    const/16 v11, 0x400

    :goto_4
    or-int/2addr v8, v11

    :cond_7
    and-int/lit16 v11, v7, 0x6000

    if-nez v11, :cond_9

    const/4 v11, 0x0

    invoke-virtual {v0, v11}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_8

    const/16 v11, 0x4000

    goto :goto_5

    :cond_8
    const/16 v11, 0x2000

    :goto_5
    or-int/2addr v8, v11

    :cond_9
    const/high16 v11, 0x30000

    and-int/2addr v11, v7

    if-nez v11, :cond_b

    invoke-virtual {v0, v5}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_a

    const/high16 v11, 0x20000

    goto :goto_6

    :cond_a
    const/high16 v11, 0x10000

    :goto_6
    or-int/2addr v8, v11

    :cond_b
    const/high16 v11, 0x180000

    and-int/2addr v11, v7

    if-nez v11, :cond_d

    invoke-virtual {v0, v6}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_c

    const/high16 v11, 0x100000

    goto :goto_7

    :cond_c
    const/high16 v11, 0x80000

    :goto_7
    or-int/2addr v8, v11

    :cond_d
    const v11, 0x92493

    and-int/2addr v8, v11

    const v11, 0x92492

    if-ne v8, v11, :cond_f

    invoke-virtual {v0}, La0/r;->z()Z

    move-result v8

    if-nez v8, :cond_e

    goto :goto_8

    :cond_e
    invoke-virtual {v0}, La0/r;->Q()V

    goto/16 :goto_e

    :cond_f
    :goto_8
    if-eqz v3, :cond_11

    if-eqz v2, :cond_10

    iget-wide v11, v4, LX/I1;->b:J

    goto :goto_9

    :cond_10
    iget-wide v11, v4, LX/I1;->f:J

    goto :goto_9

    :cond_11
    if-eqz v2, :cond_12

    iget-wide v11, v4, LX/I1;->j:J

    goto :goto_9

    :cond_12
    iget-wide v11, v4, LX/I1;->n:J

    :goto_9
    if-eqz v3, :cond_14

    if-eqz v2, :cond_13

    iget-wide v13, v4, LX/I1;->a:J

    goto :goto_a

    :cond_13
    iget-wide v13, v4, LX/I1;->e:J

    goto :goto_a

    :cond_14
    if-eqz v2, :cond_15

    iget-wide v13, v4, LX/I1;->i:J

    goto :goto_a

    :cond_15
    iget-wide v13, v4, LX/I1;->m:J

    :goto_a
    sget v8, LZ/s;->a:F

    const/4 v8, 0x5

    invoke-static {v8, v0}, LX/y1;->a(ILa0/r;)Lt0/H;

    move-result-object v8

    sget v15, LZ/s;->e:F

    if-eqz v3, :cond_17

    if-eqz v2, :cond_16

    iget-wide v9, v4, LX/I1;->c:J

    goto :goto_b

    :cond_16
    iget-wide v9, v4, LX/I1;->g:J

    goto :goto_b

    :cond_17
    if-eqz v2, :cond_18

    iget-wide v9, v4, LX/I1;->k:J

    goto :goto_b

    :cond_18
    iget-wide v9, v4, LX/I1;->o:J

    :goto_b
    new-instance v3, Lt0/J;

    invoke-direct {v3, v9, v10}, Lt0/J;-><init>(J)V

    new-instance v9, Landroidx/compose/foundation/BorderModifierNodeElement;

    invoke-direct {v9, v15, v3, v8}, Landroidx/compose/foundation/BorderModifierNodeElement;-><init>(FLt0/J;Lt0/H;)V

    invoke-interface {v1, v9}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v3

    invoke-static {v3, v11, v12, v8}, Landroidx/compose/foundation/a;->b(Lm0/r;JLt0/H;)Lm0/r;

    move-result-object v3

    sget-object v8, Lm0/c;->t:Lm0/j;

    const/4 v9, 0x0

    invoke-static {v8, v9}, LA/p;->d(Lm0/j;Z)LJ0/M;

    move-result-object v8

    iget-wide v10, v0, La0/r;->T:J

    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    move-result v10

    invoke-virtual {v0}, La0/r;->l()La0/n0;

    move-result-object v11

    invoke-static {v0, v3}, Lm0/a;->c(La0/r;Lm0/r;)Lm0/r;

    move-result-object v3

    sget-object v12, LL0/j;->b:LL0/i;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v12, LL0/i;->b:LL0/C;

    invoke-virtual {v0}, La0/r;->Z()V

    iget-boolean v15, v0, La0/r;->S:Z

    if-eqz v15, :cond_19

    invoke-virtual {v0, v12}, La0/r;->k(Lr7/a;)V

    goto :goto_c

    :cond_19
    invoke-virtual {v0}, La0/r;->j0()V

    :goto_c
    sget-object v15, LL0/i;->e:LL0/h;

    invoke-static {v0, v8, v15}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v8, LL0/i;->d:LL0/h;

    invoke-static {v0, v11, v8}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v11, LL0/i;->f:LL0/h;

    iget-boolean v9, v0, La0/r;->S:Z

    if-nez v9, :cond_1a

    invoke-virtual {v0}, La0/r;->K()Ljava/lang/Object;

    move-result-object v9

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v9, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b

    :cond_1a
    invoke-static {v10, v0, v10, v11}, Lq3/h;->n(ILa0/r;ILL0/h;)V

    :cond_1b
    sget-object v1, LL0/i;->c:LL0/h;

    invoke-static {v0, v3, v1}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    sget-object v3, Lm0/o;->a:Lm0/o;

    sget-object v9, Lm0/c;->w:Lm0/j;

    sget-object v10, Landroidx/compose/foundation/layout/b;->a:Landroidx/compose/foundation/layout/b;

    invoke-virtual {v10, v3, v9}, Landroidx/compose/foundation/layout/b;->a(Lm0/r;Lm0/j;)Lm0/r;

    move-result-object v3

    new-instance v9, Landroidx/compose/material3/ThumbElement;

    invoke-direct {v9, v5, v2}, Landroidx/compose/material3/ThumbElement;-><init>(Ly/j;Z)V

    invoke-interface {v3, v9}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object v3

    sget v9, LZ/s;->c:F

    const/4 v10, 0x2

    int-to-float v10, v10

    div-float/2addr v9, v10

    const/16 v10, 0x36

    const/4 v2, 0x4

    const/4 v4, 0x0

    invoke-static {v4, v9, v0, v10, v2}, LX/j1;->b(ZFLa0/r;II)Lu/c0;

    move-result-object v2

    invoke-static {v3, v5, v2}, Landroidx/compose/foundation/c;->a(Lm0/r;Ly/j;Lu/c0;)Lm0/r;

    move-result-object v2

    invoke-static {v2, v13, v14, v6}, Landroidx/compose/foundation/a;->b(Lm0/r;JLt0/H;)Lm0/r;

    move-result-object v2

    sget-object v3, Lm0/c;->x:Lm0/j;

    invoke-static {v3, v4}, LA/p;->d(Lm0/j;Z)LJ0/M;

    move-result-object v3

    iget-wide v9, v0, La0/r;->T:J

    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    invoke-virtual {v0}, La0/r;->l()La0/n0;

    move-result-object v9

    invoke-static {v0, v2}, Lm0/a;->c(La0/r;Lm0/r;)Lm0/r;

    move-result-object v2

    invoke-virtual {v0}, La0/r;->Z()V

    iget-boolean v10, v0, La0/r;->S:Z

    if-eqz v10, :cond_1c

    invoke-virtual {v0, v12}, La0/r;->k(Lr7/a;)V

    goto :goto_d

    :cond_1c
    invoke-virtual {v0}, La0/r;->j0()V

    :goto_d
    invoke-static {v0, v3, v15}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    invoke-static {v0, v9, v8}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    iget-boolean v3, v0, La0/r;->S:Z

    if-nez v3, :cond_1d

    invoke-virtual {v0}, La0/r;->K()Ljava/lang/Object;

    move-result-object v3

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v3, v8}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1e

    :cond_1d
    invoke-static {v4, v0, v4, v11}, Lq3/h;->n(ILa0/r;ILL0/h;)V

    :cond_1e
    invoke-static {v0, v2, v1}, La0/b;->y(La0/r;Ljava/lang/Object;Lr7/e;)V

    const v1, 0x4558f502

    invoke-virtual {v0, v1}, La0/r;->V(I)V

    const/4 v4, 0x0

    invoke-virtual {v0, v4}, La0/r;->p(Z)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, La0/r;->p(Z)V

    invoke-virtual {v0, v1}, La0/r;->p(Z)V

    :goto_e
    invoke-virtual {v0}, La0/r;->r()La0/r0;

    move-result-object v8

    if-eqz v8, :cond_1f

    new-instance v0, LX/K1;

    move-object/from16 v1, p0

    move/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v4, p3

    invoke-direct/range {v0 .. v7}, LX/K1;-><init>(Lm0/r;ZZLX/I1;Ly/j;Lt0/H;I)V

    iput-object v0, v8, La0/r0;->d:Lr7/e;

    :cond_1f
    return-void
.end method
