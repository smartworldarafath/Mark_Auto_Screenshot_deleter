.class public abstract Landroidx/compose/material3/internal/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Lr7/a;Lr7/e;Lj7/c;)Ljava/lang/Object;
    .locals 4

    instance-of v0, p2, LY/e;

    if-eqz v0, :cond_0

    move-object v0, p2

    check-cast v0, LY/e;

    iget v1, v0, LY/e;->x:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    iput v1, v0, LY/e;->x:I

    goto :goto_0

    :cond_0
    new-instance v0, LY/e;

    invoke-direct {v0, p2}, Lj7/c;-><init>(Lh7/c;)V

    :goto_0
    iget-object p2, v0, LY/e;->w:Ljava/lang/Object;

    iget v1, v0, LY/e;->x:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2

    if-ne v1, v2, :cond_1

    :try_start_0
    invoke-static {p2}, Ld7/a;->e(Ljava/lang/Object;)V
    :try_end_0
    .catch LY/c; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    invoke-static {p2}, Ld7/a;->e(Ljava/lang/Object;)V

    :try_start_1
    new-instance p2, LY/h;

    const/4 v1, 0x0

    invoke-direct {p2, p0, p1, v1}, LY/h;-><init>(Lr7/a;Lr7/e;Lh7/c;)V

    iput v2, v0, LY/e;->x:I

    invoke-static {p2, v0}, LD7/y;->j(Lr7/e;Lh7/c;)Ljava/lang/Object;

    move-result-object p0
    :try_end_1
    .catch LY/c; {:try_start_1 .. :try_end_1} :catch_0

    sget-object p1, Li7/a;->t:Li7/a;

    if-ne p0, p1, :cond_3

    return-object p1

    :catch_0
    :cond_3
    :goto_1
    sget-object p0, Ld7/z;->a:Ld7/z;

    return-object p0
.end method

.method public static final b(LP2/u;Ljava/lang/Object;FLj7/i;)Ljava/lang/Object;
    .locals 2

    new-instance v0, LY/d;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p2, v1}, LY/d;-><init>(LP2/u;FLh7/c;)V

    sget-object p2, Lu/l0;->t:Lu/l0;

    invoke-virtual {p0, p1, p2, v0, p3}, LP2/u;->c(Ljava/lang/Object;Lu/l0;LY/d;Lj7/c;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Li7/a;->t:Li7/a;

    if-ne p0, p1, :cond_0

    return-object p0

    :cond_0
    sget-object p0, Ld7/z;->a:Ld7/z;

    return-object p0
.end method

.method public static final c(Lm0/r;LP2/u;Lr7/e;)Lm0/r;
    .locals 1

    new-instance v0, Landroidx/compose/material3/internal/DraggableAnchorsElement;

    invoke-direct {v0, p1, p2}, Landroidx/compose/material3/internal/DraggableAnchorsElement;-><init>(LP2/u;Lr7/e;)V

    invoke-interface {p0, v0}, Lm0/r;->e(Lm0/r;)Lm0/r;

    move-result-object p0

    return-object p0
.end method
