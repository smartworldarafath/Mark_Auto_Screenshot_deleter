.class final Landroidx/compose/material3/internal/DraggableAnchorsElement;
.super LL0/c0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "LL0/c0;"
    }
.end annotation


# instance fields
.field public final a:LP2/u;

.field public final b:Lr7/e;


# direct methods
.method public constructor <init>(LP2/u;Lr7/e;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/material3/internal/DraggableAnchorsElement;->a:LP2/u;

    iput-object p2, p0, Landroidx/compose/material3/internal/DraggableAnchorsElement;->b:Lr7/e;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Landroidx/compose/material3/internal/DraggableAnchorsElement;

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    check-cast p1, Landroidx/compose/material3/internal/DraggableAnchorsElement;

    iget-object v1, p1, Landroidx/compose/material3/internal/DraggableAnchorsElement;->a:LP2/u;

    iget-object v2, p0, Landroidx/compose/material3/internal/DraggableAnchorsElement;->a:LP2/u;

    invoke-static {v2, v1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    iget-object v1, p0, Landroidx/compose/material3/internal/DraggableAnchorsElement;->b:Lr7/e;

    iget-object p1, p1, Landroidx/compose/material3/internal/DraggableAnchorsElement;->b:Lr7/e;

    if-eq v1, p1, :cond_3

    :goto_0
    const/4 p1, 0x0

    return p1

    :cond_3
    return v0
.end method

.method public final g()Lm0/q;
    .locals 2

    new-instance v0, LY/r;

    invoke-direct {v0}, Lm0/q;-><init>()V

    iget-object v1, p0, Landroidx/compose/material3/internal/DraggableAnchorsElement;->a:LP2/u;

    iput-object v1, v0, LY/r;->H:LP2/u;

    iget-object v1, p0, Landroidx/compose/material3/internal/DraggableAnchorsElement;->b:Lr7/e;

    iput-object v1, v0, LY/r;->I:Lr7/e;

    sget-object v1, Lw/h0;->t:Lw/h0;

    iput-object v1, v0, LY/r;->J:Lw/h0;

    return-object v0
.end method

.method public final h(Lm0/q;)V
    .locals 1

    check-cast p1, LY/r;

    iget-object v0, p0, Landroidx/compose/material3/internal/DraggableAnchorsElement;->a:LP2/u;

    iput-object v0, p1, LY/r;->H:LP2/u;

    iget-object v0, p0, Landroidx/compose/material3/internal/DraggableAnchorsElement;->b:Lr7/e;

    iput-object v0, p1, LY/r;->I:Lr7/e;

    sget-object v0, Lw/h0;->t:Lw/h0;

    iput-object v0, p1, LY/r;->J:Lw/h0;

    return-void
.end method

.method public final hashCode()I
    .locals 2

    iget-object v0, p0, Landroidx/compose/material3/internal/DraggableAnchorsElement;->a:LP2/u;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Landroidx/compose/material3/internal/DraggableAnchorsElement;->b:Lr7/e;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    sget-object v0, Lw/h0;->t:Lw/h0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    return v0
.end method
