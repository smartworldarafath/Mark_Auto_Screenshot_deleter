.class public final La1/r;
.super Lh7/a;
.source "SourceFile"

# interfaces
.implements LD7/t;


# virtual methods
.method public final l(Lh7/h;Ljava/lang/Throwable;)V
    .locals 0

    return-void
.end method
