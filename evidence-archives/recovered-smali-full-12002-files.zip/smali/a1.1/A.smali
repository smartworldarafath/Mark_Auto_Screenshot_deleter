.class public interface abstract La1/A;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget-object v0, La1/z;->a:La1/z;

    return-void
.end method
