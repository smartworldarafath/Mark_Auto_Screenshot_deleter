.class public final La1/z;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:La1/z;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La1/z;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La1/z;->a:La1/z;

    return-void
.end method
