.class public final La1/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La1/l;


# instance fields
.field public final a:LL4/K1;

.field public final b:La1/b;

.field public final c:LP2/e;

.field public final d:La1/s;

.field public final e:LU2/h;

.field public final f:LA7/j;


# direct methods
.method public constructor <init>(LL4/K1;La1/b;)V
    .locals 4

    sget-object v0, La1/o;->a:LP2/e;

    new-instance v1, La1/s;

    sget-object v2, La1/o;->b:LA4/f;

    invoke-direct {v1, v2}, La1/s;-><init>(LA4/f;)V

    new-instance v2, LU2/h;

    const/16 v3, 0x9

    invoke-direct {v2, v3}, LU2/h;-><init>(I)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La1/n;->a:LL4/K1;

    iput-object p2, p0, La1/n;->b:La1/b;

    iput-object v0, p0, La1/n;->c:LP2/e;

    iput-object v1, p0, La1/n;->d:La1/s;

    iput-object v2, p0, La1/n;->e:LU2/h;

    new-instance p1, LA7/j;

    const/16 p2, 0x1c

    invoke-direct {p1, p2, p0}, LA7/j;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, La1/n;->f:LA7/j;

    return-void
.end method


# virtual methods
.method public final a(La1/D;)La1/G;
    .locals 5

    iget-object v0, p0, La1/n;->c:LP2/e;

    new-instance v1, LA/Q;

    const/16 v2, 0x17

    invoke-direct {v1, v2, p0, p1}, LA/Q;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    iget-object v2, v0, LP2/e;->t:Ljava/lang/Object;

    check-cast v2, LT5/q;

    monitor-enter v2

    :try_start_0
    iget-object v3, v0, LP2/e;->u:Ljava/lang/Object;

    check-cast v3, Lcom/google/android/gms/internal/ads/bM;

    invoke-virtual {v3, p1}, Lcom/google/android/gms/internal/ads/bM;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La1/G;

    if-eqz v3, :cond_1

    invoke-interface {v3}, La1/G;->a()Z

    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v4, :cond_0

    monitor-exit v2

    return-object v3

    :cond_0
    :try_start_1
    iget-object v3, v0, LP2/e;->u:Ljava/lang/Object;

    check-cast v3, Lcom/google/android/gms/internal/ads/bM;

    invoke-virtual {v3, p1}, Lcom/google/android/gms/internal/ads/bM;->e(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La1/G;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_3

    :cond_1
    :goto_0
    monitor-exit v2

    :try_start_2
    new-instance v2, LA/Q;

    const/16 v3, 0x18

    invoke-direct {v2, v3, v0, p1}, LA/Q;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, LA/Q;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La1/G;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    iget-object v2, v0, LP2/e;->t:Ljava/lang/Object;

    check-cast v2, LT5/q;

    monitor-enter v2

    :try_start_3
    iget-object v3, v0, LP2/e;->u:Ljava/lang/Object;

    check-cast v3, Lcom/google/android/gms/internal/ads/bM;

    invoke-virtual {v3, p1}, Lcom/google/android/gms/internal/ads/bM;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    if-nez v3, :cond_2

    invoke-interface {v1}, La1/G;->a()Z

    move-result v3

    if-eqz v3, :cond_2

    iget-object v0, v0, LP2/e;->u:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/ads/bM;

    invoke-virtual {v0, p1, v1}, Lcom/google/android/gms/internal/ads/bM;->d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception p1

    goto :goto_2

    :cond_2
    :goto_1
    monitor-exit v2

    return-object v1

    :goto_2
    monitor-exit v2

    throw p1

    :catch_0
    move-exception p1

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Could not load font"

    invoke-direct {v0, v1, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :goto_3
    monitor-exit v2

    throw p1
.end method

.method public final b(La1/m;La1/w;II)La1/G;
    .locals 6

    new-instance v0, La1/D;

    iget-object v1, p0, La1/n;->b:La1/b;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v1, v1, La1/b;->t:I

    if-eqz v1, :cond_1

    const v2, 0x7fffffff

    if-ne v1, v2, :cond_0

    goto :goto_0

    :cond_0
    iget p2, p2, La1/w;->t:I

    add-int/2addr p2, v1

    const/4 v1, 0x1

    const/16 v2, 0x3e8

    invoke-static {p2, v1, v2}, LH4/Z5;->c(III)I

    move-result p2

    new-instance v1, La1/w;

    invoke-direct {v1, p2}, La1/w;-><init>(I)V

    move-object v2, v1

    goto :goto_1

    :cond_1
    :goto_0
    move-object v2, p2

    :goto_1
    iget-object p2, p0, La1/n;->a:LL4/K1;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x0

    move-object v1, p1

    move v3, p3

    move v4, p4

    invoke-direct/range {v0 .. v5}, La1/D;-><init>(La1/m;La1/w;IILjava/lang/Object;)V

    invoke-virtual {p0, v0}, La1/n;->a(La1/D;)La1/G;

    move-result-object p1

    return-object p1
.end method
