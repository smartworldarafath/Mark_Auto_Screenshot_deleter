.class public final La1/j;
.super La1/C;
.source "SourceFile"


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 1

    const-string v0, "FontFamily.Default"

    return-object v0
.end method
