.class public final La1/y;
.super La1/C;
.source "SourceFile"


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 1

    const-string v0, "FontFamily.SansSerif"

    return-object v0
.end method
