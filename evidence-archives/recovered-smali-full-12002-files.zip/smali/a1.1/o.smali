.class public abstract La1/o;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LP2/e;

.field public static final b:LA4/f;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LP2/e;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, LP2/e;-><init>(I)V

    sput-object v0, La1/o;->a:LP2/e;

    new-instance v0, LA4/f;

    const/16 v1, 0x16

    invoke-direct {v0, v1}, LA4/f;-><init>(I)V

    sput-object v0, La1/o;->b:LA4/f;

    return-void
.end method
