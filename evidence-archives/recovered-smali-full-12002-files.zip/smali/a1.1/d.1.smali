.class public final La1/d;
.super Lj7/c;
.source "SourceFile"


# instance fields
.field public w:Lb1/b;

.field public synthetic x:Ljava/lang/Object;

.field public final synthetic y:La1/f;

.field public z:I


# direct methods
.method public constructor <init>(La1/f;Lj7/c;)V
    .locals 0

    iput-object p1, p0, La1/d;->y:La1/f;

    invoke-direct {p0, p2}, Lj7/c;-><init>(Lh7/c;)V

    return-void
.end method


# virtual methods
.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iput-object p1, p0, La1/d;->x:Ljava/lang/Object;

    iget p1, p0, La1/d;->z:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, La1/d;->z:I

    iget-object p1, p0, La1/d;->y:La1/f;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, La1/f;->c(Lb1/b;Lj7/c;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
