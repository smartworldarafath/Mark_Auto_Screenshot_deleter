.class public abstract La1/C;
.super La1/m;
.source "SourceFile"
