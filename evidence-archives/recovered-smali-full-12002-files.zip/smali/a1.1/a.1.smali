.class public final La1/a;
.super Lj7/c;
.source "SourceFile"


# instance fields
.field public synthetic w:Ljava/lang/Object;

.field public final synthetic x:LL4/K1;

.field public y:I


# direct methods
.method public constructor <init>(LL4/K1;Lj7/c;)V
    .locals 0

    iput-object p1, p0, La1/a;->x:LL4/K1;

    invoke-direct {p0, p2}, Lj7/c;-><init>(Lh7/c;)V

    return-void
.end method


# virtual methods
.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iput-object p1, p0, La1/a;->w:Ljava/lang/Object;

    iget p1, p0, La1/a;->y:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, La1/a;->y:I

    iget-object p1, p0, La1/a;->x:LL4/K1;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, LL4/K1;->a(Lb1/b;Lj7/c;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
