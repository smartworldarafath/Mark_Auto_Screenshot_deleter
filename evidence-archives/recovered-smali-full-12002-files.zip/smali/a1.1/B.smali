.class public interface abstract La1/B;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(La1/w;I)Landroid/graphics/Typeface;
.end method

.method public abstract m(La1/y;La1/w;I)Landroid/graphics/Typeface;
.end method
