.class public final La1/E;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La1/G;
.implements La0/W0;


# instance fields
.field public final t:La1/f;


# direct methods
.method public constructor <init>(La1/f;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La1/E;->t:La1/f;

    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 1

    iget-object v0, p0, La1/E;->t:La1/f;

    iget-boolean v0, v0, La1/f;->z:Z

    return v0
.end method

.method public final getValue()Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, La1/E;->t:La1/f;

    invoke-virtual {v0}, La1/f;->getValue()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method
