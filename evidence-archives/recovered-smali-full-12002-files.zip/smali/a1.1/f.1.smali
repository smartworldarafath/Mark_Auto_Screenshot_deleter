.class public final La1/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/W0;


# instance fields
.field public final t:Ljava/util/List;

.field public final u:La1/D;

.field public final v:LA4/f;

.field public final w:Lr7/c;

.field public final x:LL4/K1;

.field public final y:La0/h0;

.field public z:Z


# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/lang/Object;La1/D;LA4/f;Lr7/c;LL4/K1;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La1/f;->t:Ljava/util/List;

    iput-object p3, p0, La1/f;->u:La1/D;

    iput-object p4, p0, La1/f;->v:LA4/f;

    iput-object p5, p0, La1/f;->w:Lr7/c;

    iput-object p6, p0, La1/f;->x:LL4/K1;

    invoke-static {p2}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object p1

    iput-object p1, p0, La1/f;->y:La0/h0;

    const/4 p1, 0x1

    iput-boolean p1, p0, La1/f;->z:Z

    return-void
.end method


# virtual methods
.method public final b(Lj7/c;)Ljava/lang/Object;
    .locals 17

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    instance-of v2, v0, La1/c;

    if-eqz v2, :cond_0

    move-object v2, v0

    check-cast v2, La1/c;

    iget v3, v2, La1/c;->C:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_0

    sub-int/2addr v3, v4

    iput v3, v2, La1/c;->C:I

    goto :goto_0

    :cond_0
    new-instance v2, La1/c;

    invoke-direct {v2, v1, v0}, La1/c;-><init>(La1/f;Lj7/c;)V

    :goto_0
    iget-object v0, v2, La1/c;->A:Ljava/lang/Object;

    iget v3, v2, La1/c;->C:I

    sget-object v4, Ld7/z;->a:Ld7/z;

    const/4 v5, 0x0

    iget-object v6, v1, La1/f;->w:Lr7/c;

    const/4 v7, 0x2

    iget-object v8, v1, La1/f;->y:La0/h0;

    const/4 v9, 0x1

    sget-object v11, Li7/a;->t:Li7/a;

    if-eqz v3, :cond_3

    if-eq v3, v9, :cond_2

    if-ne v3, v7, :cond_1

    iget v3, v2, La1/c;->z:I

    iget v12, v2, La1/c;->y:I

    iget-object v13, v2, La1/c;->w:Ljava/util/List;

    :try_start_0
    invoke-static {v0}, Ld7/a;->e(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move v0, v7

    goto/16 :goto_5

    :catchall_0
    move-exception v0

    goto/16 :goto_6

    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    iget v3, v2, La1/c;->z:I

    iget v12, v2, La1/c;->y:I

    iget-object v13, v2, La1/c;->x:Lb1/b;

    iget-object v14, v2, La1/c;->w:Ljava/util/List;

    :try_start_1
    invoke-static {v0}, Ld7/a;->e(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v7, v13

    move-object v13, v14

    goto :goto_2

    :cond_3
    invoke-static {v0}, Ld7/a;->e(Ljava/lang/Object;)V

    :try_start_2
    iget-object v0, v1, La1/f;->t:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v3

    const/4 v12, 0x0

    :goto_1
    if-ge v12, v3, :cond_7

    invoke-interface {v0, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lb1/b;

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v14, v1, La1/f;->v:LA4/f;

    iget-object v15, v1, La1/f;->x:LL4/K1;

    new-instance v7, LI1/C;

    const/4 v10, 0x4

    invoke-direct {v7, v1, v13, v5, v10}, LI1/C;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lh7/c;I)V

    iput-object v0, v2, La1/c;->w:Ljava/util/List;

    iput-object v13, v2, La1/c;->x:Lb1/b;

    iput v12, v2, La1/c;->y:I

    iput v3, v2, La1/c;->z:I

    iput v9, v2, La1/c;->C:I

    invoke-virtual {v14, v13, v15, v7, v2}, LA4/f;->t(Lb1/b;LL4/K1;LI1/C;Lj7/c;)Ljava/lang/Object;

    move-result-object v7

    if-ne v7, v11, :cond_4

    goto :goto_4

    :cond_4
    move-object/from16 v16, v13

    move-object v13, v0

    move-object v0, v7

    move-object/from16 v7, v16

    :goto_2
    if-eqz v0, :cond_5

    iget-object v3, v1, La1/f;->u:La1/D;

    iget v5, v3, La1/D;->d:I

    iget-object v9, v3, La1/D;->b:La1/w;

    iget v3, v3, La1/D;->c:I

    invoke-static {v5, v0, v7, v9, v3}, LF4/i5;->a(ILjava/lang/Object;Lb1/b;La1/w;I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v8, v0}, La0/h0;->setValue(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    iget-object v0, v2, Lj7/c;->u:Lh7/h;

    invoke-static {v0}, Ls7/j;->b(Ljava/lang/Object;)V

    invoke-static {v0}, LD7/y;->v(Lh7/h;)Z

    move-result v0

    const/4 v2, 0x0

    iput-boolean v2, v1, La1/f;->z:Z

    new-instance v2, La1/F;

    invoke-virtual {v8}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v3

    invoke-direct {v2, v3, v0}, La1/F;-><init>(Ljava/lang/Object;Z)V

    :goto_3
    invoke-interface {v6, v2}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v4

    :cond_5
    :try_start_3
    iput-object v13, v2, La1/c;->w:Ljava/util/List;

    iput-object v5, v2, La1/c;->x:Lb1/b;

    iput v12, v2, La1/c;->y:I

    iput v3, v2, La1/c;->z:I

    const/4 v0, 0x2

    iput v0, v2, La1/c;->C:I

    invoke-static {v2}, LD7/y;->J(Lj7/c;)Ljava/lang/Object;

    move-result-object v7
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    if-ne v7, v11, :cond_6

    :goto_4
    return-object v11

    :cond_6
    :goto_5
    add-int/2addr v12, v9

    move v7, v0

    move-object v0, v13

    goto :goto_1

    :cond_7
    iget-object v0, v2, Lj7/c;->u:Lh7/h;

    invoke-static {v0}, Ls7/j;->b(Ljava/lang/Object;)V

    invoke-static {v0}, LD7/y;->v(Lh7/h;)Z

    move-result v0

    const/4 v2, 0x0

    iput-boolean v2, v1, La1/f;->z:Z

    new-instance v2, La1/F;

    invoke-virtual {v8}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v3

    invoke-direct {v2, v3, v0}, La1/F;-><init>(Ljava/lang/Object;Z)V

    goto :goto_3

    :goto_6
    iget-object v2, v2, Lj7/c;->u:Lh7/h;

    invoke-static {v2}, Ls7/j;->b(Ljava/lang/Object;)V

    invoke-static {v2}, LD7/y;->v(Lh7/h;)Z

    move-result v2

    const/4 v3, 0x0

    iput-boolean v3, v1, La1/f;->z:Z

    new-instance v3, La1/F;

    invoke-virtual {v8}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v4

    invoke-direct {v3, v4, v2}, La1/F;-><init>(Ljava/lang/Object;Z)V

    invoke-interface {v6, v3}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    throw v0
.end method

.method public final c(Lb1/b;Lj7/c;)Ljava/lang/Object;
    .locals 6

    instance-of v0, p2, La1/d;

    if-eqz v0, :cond_0

    move-object v0, p2

    check-cast v0, La1/d;

    iget v1, v0, La1/d;->z:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    iput v1, v0, La1/d;->z:I

    goto :goto_0

    :cond_0
    new-instance v0, La1/d;

    invoke-direct {v0, p0, p2}, La1/d;-><init>(La1/f;Lj7/c;)V

    :goto_0
    iget-object p2, v0, Lj7/c;->u:Lh7/h;

    iget-object v1, v0, La1/d;->x:Ljava/lang/Object;

    iget v2, v0, La1/d;->z:I

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_2

    if-ne v2, v3, :cond_1

    iget-object p1, v0, La1/d;->w:Lb1/b;

    :try_start_0
    invoke-static {v1}, Ld7/a;->e(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :catch_0
    move-exception v0

    goto :goto_1

    :catch_1
    move-exception p1

    goto :goto_2

    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    invoke-static {v1}, Ld7/a;->e(Ljava/lang/Object;)V

    :try_start_1
    new-instance v1, La1/e;

    invoke-direct {v1, p0, p1, v4}, La1/e;-><init>(La1/f;Lb1/b;Lh7/c;)V

    iput-object p1, v0, La1/d;->w:Lb1/b;

    iput v3, v0, La1/d;->z:I

    const-wide/16 v2, 0x3a98

    invoke-static {v2, v3, v1, v0}, LD7/y;->I(JLr7/e;Lj7/c;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    sget-object p2, Li7/a;->t:Li7/a;

    if-ne p1, p2, :cond_3

    return-object p2

    :cond_3
    return-object p1

    :goto_1
    invoke-static {p2}, Ls7/j;->b(Ljava/lang/Object;)V

    sget-object v1, LD7/s;->t:LD7/s;

    invoke-interface {p2, v1}, Lh7/h;->W(Lh7/g;)Lh7/f;

    move-result-object v1

    check-cast v1, LD7/t;

    if-eqz v1, :cond_4

    new-instance v2, Ljava/lang/IllegalStateException;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v5, "Unable to load font "

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v2, p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-interface {v1, p2, v2}, LD7/t;->l(Lh7/h;Ljava/lang/Throwable;)V

    goto :goto_3

    :goto_2
    invoke-static {p2}, Ls7/j;->b(Ljava/lang/Object;)V

    invoke-static {p2}, LD7/y;->v(Lh7/h;)Z

    move-result p2

    if-eqz p2, :cond_5

    :cond_4
    :goto_3
    return-object v4

    :cond_5
    throw p1
.end method

.method public final getValue()Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, La1/f;->y:La0/h0;

    invoke-virtual {v0}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method
