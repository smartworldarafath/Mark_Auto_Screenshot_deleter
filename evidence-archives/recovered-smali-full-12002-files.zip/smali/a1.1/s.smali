.class public final La1/s;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final c:La1/r;


# instance fields
.field public final a:LA4/f;

.field public final b:LI7/d;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    sget-object v0, LD7/s;->t:LD7/s;

    new-instance v1, La1/r;

    invoke-direct {v1, v0}, Lh7/a;-><init>(Lh7/g;)V

    sput-object v1, La1/s;->c:La1/r;

    return-void
.end method

.method public constructor <init>(LA4/f;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La1/s;->a:LA4/f;

    sget-object p1, Lf1/j;->a:LE7/d;

    sget-object v0, La1/s;->c:La1/r;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, p1}, LF4/r7;->c(Lh7/f;Lh7/h;)Lh7/h;

    move-result-object p1

    sget-object v0, Lh7/i;->t:Lh7/i;

    invoke-interface {p1, v0}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object p1

    new-instance v0, LD7/s0;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LD7/e0;-><init>(LD7/c0;)V

    invoke-interface {p1, v0}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object p1

    invoke-static {p1}, LD7/y;->b(Lh7/h;)LI7/d;

    move-result-object p1

    iput-object p1, p0, La1/s;->b:LI7/d;

    return-void
.end method
