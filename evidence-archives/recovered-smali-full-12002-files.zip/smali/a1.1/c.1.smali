.class public final La1/c;
.super Lj7/c;
.source "SourceFile"


# instance fields
.field public synthetic A:Ljava/lang/Object;

.field public final synthetic B:La1/f;

.field public C:I

.field public w:Ljava/util/List;

.field public x:Lb1/b;

.field public y:I

.field public z:I


# direct methods
.method public constructor <init>(La1/f;Lj7/c;)V
    .locals 0

    iput-object p1, p0, La1/c;->B:La1/f;

    invoke-direct {p0, p2}, Lj7/c;-><init>(Lh7/c;)V

    return-void
.end method


# virtual methods
.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iput-object p1, p0, La1/c;->A:Ljava/lang/Object;

    iget p1, p0, La1/c;->C:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, La1/c;->C:I

    iget-object p1, p0, La1/c;->B:La1/f;

    invoke-virtual {p1, p0}, La1/f;->b(Lj7/c;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
