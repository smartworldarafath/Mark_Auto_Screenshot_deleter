.class public final La1/e;
.super Lj7/i;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public x:I

.field public final synthetic y:La1/f;

.field public final synthetic z:Lb1/b;


# direct methods
.method public constructor <init>(La1/f;Lb1/b;Lh7/c;)V
    .locals 0

    iput-object p1, p0, La1/e;->y:La1/f;

    iput-object p2, p0, La1/e;->z:Lb1/b;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lj7/i;-><init>(ILh7/c;)V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LD7/v;

    check-cast p2, Lh7/c;

    invoke-virtual {p0, p2, p1}, La1/e;->n(Lh7/c;Ljava/lang/Object;)Lh7/c;

    move-result-object p1

    check-cast p1, La1/e;

    sget-object p2, Ld7/z;->a:Ld7/z;

    invoke-virtual {p1, p2}, La1/e;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final n(Lh7/c;Ljava/lang/Object;)Lh7/c;
    .locals 2

    new-instance p2, La1/e;

    iget-object v0, p0, La1/e;->y:La1/f;

    iget-object v1, p0, La1/e;->z:Lb1/b;

    invoke-direct {p2, v0, v1, p1}, La1/e;-><init>(La1/f;Lb1/b;Lh7/c;)V

    return-object p2
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    iget v0, p0, La1/e;->x:I

    const/4 v1, 0x1

    if-eqz v0, :cond_1

    if-ne v0, v1, :cond_0

    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    iget-object p1, p0, La1/e;->y:La1/f;

    iget-object p1, p1, La1/f;->x:LL4/K1;

    iput v1, p0, La1/e;->x:I

    iget-object v0, p0, La1/e;->z:Lb1/b;

    invoke-virtual {p1, v0, p0}, LL4/K1;->a(Lb1/b;Lj7/c;)Ljava/lang/Object;

    move-result-object p1

    sget-object v0, Li7/a;->t:Li7/a;

    if-ne p1, v0, :cond_2

    return-object v0

    :cond_2
    return-object p1
.end method
