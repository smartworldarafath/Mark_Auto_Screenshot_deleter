.class public interface abstract La1/G;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/W0;


# virtual methods
.method public abstract a()Z
.end method
