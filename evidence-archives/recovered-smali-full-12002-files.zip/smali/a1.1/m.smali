.class public abstract La1/m;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final t:La1/j;

.field public static final u:La1/y;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La1/j;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La1/m;->t:La1/j;

    new-instance v0, La1/y;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La1/m;->u:La1/y;

    return-void
.end method
