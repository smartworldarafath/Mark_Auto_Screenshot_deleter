.class public final synthetic LA6/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/a;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Lm3/h;


# direct methods
.method public synthetic constructor <init>(Lm3/h;I)V
    .locals 0

    iput p2, p0, LA6/a;->t:I

    iput-object p1, p0, LA6/a;->u:Lm3/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 1

    iget v0, p0, LA6/a;->t:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LA6/a;->u:Lm3/h;

    invoke-virtual {v0}, Lm3/h;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    :goto_0
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LA6/a;->u:Lm3/h;

    invoke-virtual {v0}, Lm3/h;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto :goto_0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
