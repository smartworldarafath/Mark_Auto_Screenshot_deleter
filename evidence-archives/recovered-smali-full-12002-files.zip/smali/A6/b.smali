.class public final synthetic LA6/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Lm0/r;

.field public final synthetic v:I

.field public final synthetic w:J

.field public final synthetic x:I


# direct methods
.method public synthetic constructor <init>(ILm0/r;IJI)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, LA6/b;->t:I

    iput-object p2, p0, LA6/b;->u:Lm0/r;

    iput p3, p0, LA6/b;->v:I

    iput-wide p4, p0, LA6/b;->w:J

    iput p6, p0, LA6/b;->x:I

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    move-object v5, p1

    check-cast v5, La0/r;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget p1, p0, LA6/b;->x:I

    or-int/lit8 p1, p1, 0x1

    invoke-static {p1}, La0/b;->B(I)I

    move-result v6

    iget v0, p0, LA6/b;->t:I

    iget-object v1, p0, LA6/b;->u:Lm0/r;

    iget v2, p0, LA6/b;->v:I

    iget-wide v3, p0, LA6/b;->w:J

    invoke-static/range {v0 .. v6}, LE4/l;->b(ILm0/r;IJLa0/r;I)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1
.end method
