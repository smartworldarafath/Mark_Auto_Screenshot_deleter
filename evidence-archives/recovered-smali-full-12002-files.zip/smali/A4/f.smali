.class public LA4/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lj4/a;
.implements Lx5/a;
.implements LL4/S0;
.implements LL4/T;
.implements Lc3/e;
.implements Lcom/google/android/gms/internal/consent_sdk/a3;


# static fields
.field public static x:LA4/f;

.field public static y:LA4/f;


# instance fields
.field public final synthetic t:I

.field public u:Ljava/lang/Object;

.field public v:Ljava/lang/Object;

.field public w:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 4

    iput p1, p0, LA4/f;->t:I

    sparse-switch p1, :sswitch_data_0

    .line 55
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 56
    sget-object p1, Lp/P;->a:[J

    .line 57
    new-instance p1, Lp/H;

    invoke-direct {p1}, Lp/H;-><init>()V

    .line 58
    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    return-void

    .line 59
    :sswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Lcom/google/android/gms/internal/measurement/b;

    const-string v0, ""

    const-wide/16 v1, 0x0

    const/4 v3, 0x0

    invoke-direct {p1, v0, v1, v2, v3}, Lcom/google/android/gms/internal/measurement/b;-><init>(Ljava/lang/String;JLjava/util/HashMap;)V

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    new-instance p1, Lcom/google/android/gms/internal/measurement/b;

    .line 60
    invoke-direct {p1, v0, v1, v2, v3}, Lcom/google/android/gms/internal/measurement/b;-><init>(Ljava/lang/String;JLjava/util/HashMap;)V

    iput-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    .line 61
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    return-void

    .line 62
    :sswitch_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 63
    new-instance p1, Lcom/google/android/gms/internal/ads/bM;

    const/16 v0, 0x10

    invoke-direct {p1, v0}, Lcom/google/android/gms/internal/ads/bM;-><init>(I)V

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    .line 64
    sget-object p1, Lp/P;->a:[J

    .line 65
    new-instance p1, Lp/H;

    invoke-direct {p1}, Lp/H;-><init>()V

    .line 66
    iput-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    .line 67
    new-instance p1, LT5/q;

    const/16 v0, 0x9

    .line 68
    invoke-direct {p1, v0}, LT5/q;-><init>(I)V

    .line 69
    iput-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    return-void

    .line 70
    :sswitch_2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    .line 71
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    .line 72
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    return-void

    .line 73
    :sswitch_3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 74
    new-instance p1, LA1/i;

    const/16 v0, 0xd

    invoke-direct {p1, v0}, LA1/i;-><init>(I)V

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    .line 75
    new-instance p1, LA1/i;

    invoke-direct {p1, v0}, LA1/i;-><init>(I)V

    iput-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    .line 76
    new-instance p1, LA1/i;

    invoke-direct {p1, v0}, LA1/i;-><init>(I)V

    iput-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    return-void

    .line 77
    :sswitch_4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 78
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    .line 79
    iput-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    return-void

    .line 80
    :sswitch_5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    new-instance p1, Ljava/util/HashMap;

    .line 81
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    sget-object p1, LE4/f;->c:LE4/f;

    iput-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0x5 -> :sswitch_5
        0x7 -> :sswitch_4
        0xb -> :sswitch_3
        0x14 -> :sswitch_2
        0x16 -> :sswitch_1
        0x1d -> :sswitch_0
    .end sparse-switch
.end method

.method public synthetic constructor <init>(IZ)V
    .locals 0

    .line 1
    iput p1, p0, LA4/f;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LL4/J1;Ljava/lang/String;Ljava/lang/Object;I)V
    .locals 0

    .line 2
    iput p4, p0, LA4/f;->t:I

    iput-object p2, p0, LA4/f;->u:Ljava/lang/Object;

    iput-object p3, p0, LA4/f;->v:Ljava/lang/Object;

    iput-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LM0/O0;)V
    .locals 1

    const/16 v0, 0xa

    iput v0, p0, LA4/f;->t:I

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LP2/i;LB5/e;LO1/d;Ljava/util/Set;)V
    .locals 7

    const/16 v0, 0x11

    iput v0, p0, LA4/f;->t:I

    .line 46
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 47
    iput-object p2, p0, LA4/f;->u:Ljava/lang/Object;

    .line 48
    iput-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    .line 49
    iput-object p3, p0, LA4/f;->w:Ljava/lang/Object;

    .line 50
    invoke-interface {p4}, Ljava/util/Set;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_1

    .line 51
    :cond_0
    invoke-interface {p4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, [I

    .line 52
    new-instance v1, Ljava/lang/String;

    const/4 p3, 0x0

    array-length p4, p2

    invoke-direct {v1, p2, p3, p4}, Ljava/lang/String;-><init>([III)V

    .line 53
    new-instance v6, LO1/r;

    const/4 p2, 0x0

    invoke-direct {v6, v1, p2}, LO1/r;-><init>(Ljava/lang/String;I)V

    .line 54
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v2, 0x0

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, LA4/f;->r(Ljava/lang/CharSequence;IIIZLO1/p;)Ljava/lang/Object;

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method

.method public constructor <init>(LW3/L;Lcom/google/android/gms/internal/ads/q8;Landroid/content/Context;Landroid/net/Uri;)V
    .locals 0

    const/16 p1, 0x15

    iput p1, p0, LA4/f;->t:I

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LA4/f;->v:Ljava/lang/Object;

    iput-object p3, p0, LA4/f;->u:Ljava/lang/Object;

    iput-object p4, p0, LA4/f;->w:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .locals 7

    iput p2, p0, LA4/f;->t:I

    packed-switch p2, :pswitch_data_0

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, LA4/f;->v:Ljava/lang/Object;

    .line 6
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object p2

    iput-object p2, p0, LA4/f;->w:Ljava/lang/Object;

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    new-instance v1, LA4/d;

    const/4 p1, 0x0

    invoke-direct {v1, p1, p0}, LA4/d;-><init>(ILjava/lang/Object;)V

    const-wide/32 v4, 0x15180

    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x0

    .line 7
    invoke-interface/range {v0 .. v6}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleAtFixedRate(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    return-void

    .line 8
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    .line 10
    sget-object p1, Lh3/d;->a:Ld3/c;

    .line 11
    iput-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    .line 12
    new-instance p1, Lh3/h;

    invoke-direct {p1}, Lh3/h;-><init>()V

    iput-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    return-void

    :pswitch_data_0
    .packed-switch 0x12
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Landroid/content/Context;LL4/m0;)V
    .locals 4

    const/16 v0, 0xd

    iput v0, p0, LA4/f;->t:I

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const-wide/16 v1, -0x1

    invoke-direct {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    iput-object v0, p0, LA4/f;->w:Ljava/lang/Object;

    .line 14
    new-instance v0, Lp4/o;

    const-string v1, "measurement:api"

    invoke-direct {v0, v1}, Lp4/o;-><init>(Ljava/lang/String;)V

    .line 15
    new-instance v1, Lr4/b;

    .line 16
    sget-object v2, Lr4/b;->B:Lj6/b;

    sget-object v3, Ln4/e;->b:Ln4/e;

    invoke-direct {v1, p1, v2, v0, v3}, Ln4/f;-><init>(Landroid/content/Context;Lj6/b;Ln4/b;Ln4/e;)V

    .line 17
    iput-object v1, p0, LA4/f;->v:Ljava/lang/Object;

    iput-object p2, p0, LA4/f;->u:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/net/ConnectivityManager;Lh3/k;)V
    .locals 2

    const/16 v0, 0x1a

    iput v0, p0, LA4/f;->t:I

    .line 38
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 39
    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    .line 40
    iput-object p2, p0, LA4/f;->v:Ljava/lang/Object;

    .line 41
    new-instance p2, LL2/e;

    const/4 v0, 0x2

    invoke-direct {p2, v0, p0}, LL2/e;-><init>(ILjava/lang/Object;)V

    iput-object p2, p0, LA4/f;->w:Ljava/lang/Object;

    .line 42
    new-instance v0, Landroid/net/NetworkRequest$Builder;

    invoke-direct {v0}, Landroid/net/NetworkRequest$Builder;-><init>()V

    const/16 v1, 0xc

    .line 43
    invoke-virtual {v0, v1}, Landroid/net/NetworkRequest$Builder;->addCapability(I)Landroid/net/NetworkRequest$Builder;

    move-result-object v0

    .line 44
    invoke-virtual {v0}, Landroid/net/NetworkRequest$Builder;->build()Landroid/net/NetworkRequest;

    move-result-object v0

    .line 45
    invoke-virtual {p1, v0, p2}, Landroid/net/ConnectivityManager;->registerNetworkCallback(Landroid/net/NetworkRequest;Landroid/net/ConnectivityManager$NetworkCallback;)V

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .locals 2

    const/16 v0, 0x19

    iput v0, p0, LA4/f;->t:I

    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    .line 36
    new-instance v0, LE0/b;

    const/16 v1, 0x11

    invoke-direct {v0, v1, p0}, LE0/b;-><init>(ILjava/lang/Object;)V

    sget-object v1, Ld7/i;->u:Ld7/i;

    invoke-static {v1, v0}, Ld7/a;->c(Ld7/i;Lr7/a;)Ld7/h;

    move-result-object v0

    iput-object v0, p0, LA4/f;->v:Ljava/lang/Object;

    .line 37
    new-instance v0, LA1/i;

    invoke-direct {v0, p1}, LA1/i;-><init>(Landroid/view/View;)V

    iput-object v0, p0, LA4/f;->w:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroidx/lifecycle/z;)V
    .locals 2

    const/16 v0, 0x17

    iput v0, p0, LA4/f;->t:I

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 30
    new-instance v0, Landroidx/lifecycle/y;

    const/4 v1, 0x1

    .line 31
    invoke-direct {v0, p1, v1}, Landroidx/lifecycle/y;-><init>(Landroidx/lifecycle/w;Z)V

    .line 32
    iput-object v0, p0, LA4/f;->u:Ljava/lang/Object;

    .line 33
    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    iput-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lcom/google/android/gms/internal/measurement/b;)V
    .locals 1

    const/16 v0, 0x1d

    iput v0, p0, LA4/f;->t:I

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    invoke-virtual {p1}, Lcom/google/android/gms/internal/measurement/b;->a()Lcom/google/android/gms/internal/measurement/b;

    move-result-object p1

    iput-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    .line 28
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 3
    iput p4, p0, LA4/f;->t:I

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    iput-object p2, p0, LA4/f;->v:Ljava/lang/Object;

    iput-object p3, p0, LA4/f;->w:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 2

    iput p2, p0, LA4/f;->t:I

    packed-switch p2, :pswitch_data_0

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p2, LA4/f;

    const/16 v0, 0x8

    const/4 v1, 0x0

    .line 19
    invoke-direct {p2, v0, v1}, LA4/f;-><init>(IZ)V

    .line 20
    iput-object p2, p0, LA4/f;->v:Ljava/lang/Object;

    iput-object p2, p0, LA4/f;->w:Ljava/lang/Object;

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    return-void

    .line 21
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    new-instance p2, Lj6/b;

    .line 23
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 24
    iput-object p2, p0, LA4/f;->v:Ljava/lang/Object;

    .line 25
    iput-object p2, p0, LA4/f;->w:Ljava/lang/Object;

    .line 26
    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    return-void

    :pswitch_data_0
    .packed-switch 0x13
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Ljava/util/regex/Matcher;Ljava/lang/CharSequence;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LA4/f;->t:I

    const-string v0, "input"

    invoke-static {p2, v0}, Ls7/j;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    iput-object p2, p0, LA4/f;->v:Ljava/lang/Object;

    .line 83
    new-instance p1, LA7/k;

    const/4 p2, 0x0

    invoke-direct {p1, p2, p0}, LA7/k;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    return-void
.end method

.method public static final f(LA4/f;Landroid/net/Network;Z)V
    .locals 7

    iget-object v0, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, Landroid/net/ConnectivityManager;

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getAllNetworks()[Landroid/net/Network;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_3

    aget-object v4, v0, v3

    invoke-static {v4, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    const/4 v6, 0x1

    if-eqz v5, :cond_0

    move v4, p2

    goto :goto_1

    :cond_0
    iget-object v5, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v5, Landroid/net/ConnectivityManager;

    invoke-virtual {v5, v4}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v4

    if-eqz v4, :cond_1

    const/16 v5, 0xc

    invoke-virtual {v4, v5}, Landroid/net/NetworkCapabilities;->hasCapability(I)Z

    move-result v4

    if-eqz v4, :cond_1

    move v4, v6

    goto :goto_1

    :cond_1
    move v4, v2

    :goto_1
    if-eqz v4, :cond_2

    move v2, v6

    goto :goto_2

    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_3
    :goto_2
    iget-object p0, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast p0, Lh3/k;

    monitor-enter p0

    :try_start_0
    iget-object p1, p0, Lh3/k;->t:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LT2/i;

    if-eqz p1, :cond_4

    iput-boolean v2, p0, Lh3/k;->x:Z

    goto :goto_3

    :catchall_0
    move-exception p1

    goto :goto_4

    :cond_4
    invoke-virtual {p0}, Lh3/k;->b()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_3
    monitor-exit p0

    return-void

    :goto_4
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public static k(Landroid/text/Editable;Landroid/view/KeyEvent;Z)Z
    .locals 6

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getMetaState()I

    move-result p1

    invoke-static {p1}, Landroid/view/KeyEvent;->metaStateHasNoModifiers(I)Z

    move-result p1

    const/4 v0, 0x0

    if-nez p1, :cond_0

    goto :goto_1

    :cond_0
    invoke-static {p0}, Landroid/text/Selection;->getSelectionStart(Ljava/lang/CharSequence;)I

    move-result p1

    invoke-static {p0}, Landroid/text/Selection;->getSelectionEnd(Ljava/lang/CharSequence;)I

    move-result v1

    const/4 v2, -0x1

    if-eq p1, v2, :cond_6

    if-eq v1, v2, :cond_6

    if-eq p1, v1, :cond_1

    goto :goto_1

    :cond_1
    const-class v2, LO1/z;

    invoke-interface {p0, p1, v1, v2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [LO1/z;

    if-eqz v1, :cond_6

    array-length v2, v1

    if-lez v2, :cond_6

    array-length v2, v1

    move v3, v0

    :goto_0
    if-ge v3, v2, :cond_6

    aget-object v4, v1, v3

    invoke-interface {p0, v4}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    move-result v5

    invoke-interface {p0, v4}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    move-result v4

    if-eqz p2, :cond_2

    if-eq v5, p1, :cond_4

    :cond_2
    if-nez p2, :cond_3

    if-eq v4, p1, :cond_4

    :cond_3
    if-le p1, v5, :cond_5

    if-ge p1, v4, :cond_5

    :cond_4
    invoke-interface {p0, v5, v4}, Landroid/text/Editable;->delete(II)Landroid/text/Editable;

    const/4 p0, 0x1

    return p0

    :cond_5
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_6
    :goto_1
    return v0
.end method

.method public static final x(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .locals 2

    const-string v0, "app_set_id_storage"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    return-object p0
.end method

.method public static final y(Landroid/content/Context;)V
    .locals 4

    invoke-static {p0}, LA4/f;->x(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v3, "app_set_id_last_used_time"

    invoke-interface {v0, v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const-string v1, "Failed to store app set ID last used time for App "

    if-eqz v0, :cond_0

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/String;

    invoke-direct {p0, v1}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    :goto_0
    const-string v0, "AppSet"

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p0, LA4/e;

    const-string v0, "Failed to store the app set ID last used time."

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    return-void
.end method


# virtual methods
.method public a()LO4/o;
    .locals 4

    new-instance v0, LO4/h;

    invoke-direct {v0}, LO4/h;-><init>()V

    iget-object v1, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/ExecutorService;

    new-instance v2, LX4/a;

    const/4 v3, 0x1

    invoke-direct {v2, v3, p0, v0}, LX4/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    iget-object v0, v0, LO4/h;->a:LO4/o;

    return-object v0
.end method

.method public b()Z
    .locals 7

    iget-object v0, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, Landroid/net/ConnectivityManager;

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getAllNetworks()[Landroid/net/Network;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_1

    aget-object v5, v1, v4

    invoke-virtual {v0, v5}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v5

    if-eqz v5, :cond_0

    const/16 v6, 0xc

    invoke-virtual {v5, v6}, Landroid/net/NetworkCapabilities;->hasCapability(I)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    return v3
.end method

.method public bridge synthetic c(Ljava/lang/Class;Lw5/d;)Lx5/a;
    .locals 1

    iget-object v0, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast p2, Ljava/util/HashMap;

    invoke-virtual {p2, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-object p0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 6

    iget v0, p0, LA4/f;->t:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :pswitch_0
    new-instance v0, LA4/f;

    iget-object v1, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/internal/measurement/b;

    invoke-virtual {v1}, Lcom/google/android/gms/internal/measurement/b;->a()Lcom/google/android/gms/internal/measurement/b;

    move-result-object v1

    invoke-direct {v0, v1}, LA4/f;-><init>(Lcom/google/android/gms/internal/measurement/b;)V

    iget-object v1, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_0

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    add-int/lit8 v3, v3, 0x1

    check-cast v4, Lcom/google/android/gms/internal/measurement/b;

    iget-object v5, v0, LA4/f;->w:Ljava/lang/Object;

    check-cast v5, Ljava/util/ArrayList;

    invoke-virtual {v4}, Lcom/google/android/gms/internal/measurement/b;->a()Lcom/google/android/gms/internal/measurement/b;

    move-result-object v4

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x1d
        :pswitch_0
    .end packed-switch
.end method

.method public d()Ljava/lang/Object;
    .locals 5

    iget-object v0, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/consent_sdk/b3;

    invoke-interface {v0}, Lcom/google/android/gms/internal/consent_sdk/b3;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/consent_sdk/a;

    iget-object v0, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/consent_sdk/w2;

    iget-object v0, v0, Lcom/google/android/gms/internal/consent_sdk/w2;->u:Ljava/lang/Object;

    check-cast v0, Landroid/app/Application;

    sget-object v1, Lcom/google/android/gms/internal/consent_sdk/E;->b:Lcom/google/android/gms/internal/consent_sdk/D;

    invoke-static {v1}, Lcom/google/android/gms/internal/consent_sdk/G;->c(Ljava/lang/Object;)V

    iget-object v2, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/internal/consent_sdk/b3;

    invoke-interface {v2}, Lcom/google/android/gms/internal/consent_sdk/b3;->d()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/google/android/gms/internal/consent_sdk/y;

    new-instance v3, Lcom/google/android/gms/internal/consent_sdk/z;

    const/4 v4, 0x0

    invoke-direct {v3, v0, v1, v2, v4}, Lcom/google/android/gms/internal/consent_sdk/z;-><init>(Landroid/app/Application;Ljava/util/concurrent/Executor;Lcom/google/android/gms/internal/consent_sdk/y;Z)V

    return-object v3
.end method

.method public e(ILjava/lang/Throwable;[B)V
    .locals 8

    iget-object p3, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast p3, LL4/Q0;

    invoke-virtual {p3}, LL4/x;->I()V

    iget-object v0, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v0, LL4/B1;

    const/16 v1, 0xc8

    if-eq p1, v1, :cond_0

    const/16 v1, 0xcc

    if-eq p1, v1, :cond_0

    const/16 v1, 0x130

    if-ne p1, v1, :cond_1

    move p1, v1

    :cond_0
    if-nez p2, :cond_1

    iget-object p1, p3, LE/V;->u:Ljava/lang/Object;

    check-cast p1, LL4/m0;

    iget-object p1, p1, LL4/m0;->y:LL4/Q;

    invoke-static {p1}, LL4/m0;->l(LL4/u0;)V

    iget-object p1, p1, LL4/Q;->H:LL4/O;

    iget-wide v1, v0, LL4/B1;->t:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const-string v1, "[sgtm] Upload succeeded for row_id"

    invoke-virtual {p1, p2, v1}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object p1, LL4/W0;->v:LL4/W0;

    goto :goto_0

    :cond_1
    iget-object v1, p3, LE/V;->u:Ljava/lang/Object;

    check-cast v1, LL4/m0;

    iget-object v1, v1, LL4/m0;->y:LL4/Q;

    invoke-static {v1}, LL4/m0;->l(LL4/u0;)V

    iget-object v1, v1, LL4/Q;->C:LL4/O;

    iget-wide v2, v0, LL4/B1;->t:J

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v4, "[sgtm] Upload failed for row_id. response, exception"

    invoke-virtual {v1, v4, v2, v3, p2}, LL4/O;->i(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    sget-object p2, LL4/A;->u:LL4/z;

    const/4 v1, 0x0

    invoke-virtual {p2, v1}, LL4/z;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    const-string v1, ","

    invoke-virtual {p2, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p2

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    invoke-interface {p2, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    sget-object p1, LL4/W0;->x:LL4/W0;

    goto :goto_0

    :cond_2
    sget-object p1, LL4/W0;->w:LL4/W0;

    :goto_0
    iget-object p2, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast p2, Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v1, p3, LE/V;->u:Ljava/lang/Object;

    check-cast v1, LL4/m0;

    invoke-virtual {v1}, LL4/m0;->o()LL4/m1;

    move-result-object v1

    new-instance v2, LL4/d;

    iget-wide v4, v0, LL4/B1;->t:J

    iget v3, p1, LL4/W0;->t:I

    iget-wide v6, v0, LL4/B1;->y:J

    invoke-direct/range {v2 .. v7}, LL4/d;-><init>(IJJ)V

    invoke-virtual {v1}, LL4/x;->I()V

    invoke-virtual {v1}, LL4/C;->J()V

    const/4 v0, 0x1

    invoke-virtual {v1, v0}, LL4/m1;->Y(Z)LL4/R1;

    move-result-object v0

    new-instance v3, LE4/P4;

    const/16 v6, 0x9

    invoke-direct {v3, v1, v0, v2, v6}, LE4/P4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v1, v3}, LL4/m1;->W(Ljava/lang/Runnable;)V

    iget-object p3, p3, LE/V;->u:Ljava/lang/Object;

    check-cast p3, LL4/m0;

    iget-object p3, p3, LL4/m0;->y:LL4/Q;

    invoke-static {p3}, LL4/m0;->l(LL4/u0;)V

    iget-object p3, p3, LL4/Q;->H:LL4/O;

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const-string v1, "[sgtm] Updated status for row_id"

    invoke-virtual {p3, v1, v0, p1}, LL4/O;->h(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    monitor-enter p2

    :try_start_0
    invoke-virtual {p2, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    invoke-virtual {p2}, Ljava/lang/Object;->notifyAll()V

    monitor-exit p2

    return-void

    :catchall_0
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public g(LL0/J;LL0/w;)V
    .locals 4

    iget-object v0, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, LA1/i;

    iget-object v1, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v1, LA1/i;

    iget-object v2, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v2, LA1/i;

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result p2

    if-eqz p2, :cond_5

    const/4 v3, 0x1

    if-eq p2, v3, :cond_4

    const/4 v3, 0x2

    if-eq p2, v3, :cond_2

    const/4 v0, 0x3

    if-ne p2, v0, :cond_1

    iget-object p2, p1, LL0/J;->z:LL0/J;

    if-eqz p2, :cond_0

    invoke-virtual {v2, p1}, LA1/i;->c(LL0/J;)V

    return-void

    :cond_0
    invoke-virtual {v1, p1}, LA1/i;->c(LL0/J;)V

    return-void

    :cond_1
    new-instance p1, LA2/c;

    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    throw p1

    :cond_2
    iget-object p2, p1, LL0/J;->z:LL0/J;

    if-eqz p2, :cond_3

    invoke-virtual {v2, p1}, LA1/i;->c(LL0/J;)V

    return-void

    :cond_3
    invoke-virtual {v0, p1}, LA1/i;->c(LL0/J;)V

    return-void

    :cond_4
    invoke-virtual {v1, p1}, LA1/i;->c(LL0/J;)V

    invoke-virtual {v2, p1}, LA1/i;->c(LL0/J;)V

    return-void

    :cond_5
    invoke-virtual {v0, p1}, LA1/i;->c(LL0/J;)V

    invoke-virtual {v2, p1}, LA1/i;->c(LL0/J;)V

    return-void
.end method

.method public h()LC3/k;
    .locals 4

    iget-object v0, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_0

    const-string v0, " backendName"

    goto :goto_0

    :cond_0
    const-string v0, ""

    :goto_0
    iget-object v1, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v1, Lz3/c;

    if-nez v1, :cond_1

    const-string v1, " priority"

    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_1
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_2

    new-instance v0, LC3/k;

    iget-object v1, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    iget-object v2, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v2, [B

    iget-object v3, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v3, Lz3/c;

    invoke-direct {v0, v1, v2, v3}, LC3/k;-><init>(Ljava/lang/String;[BLz3/c;)V

    return-object v0

    :cond_2
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Missing required properties:"

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public i(Ljava/lang/String;ILjava/lang/Throwable;[BLjava/util/Map;)V
    .locals 7

    iget p1, p0, LA4/f;->t:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast p1, LL4/L1;

    iget-wide v0, p1, LL4/L1;->a:J

    iget-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast p1, LL4/J1;

    iget-object p5, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast p5, Ljava/lang/String;

    invoke-virtual {p1}, LL4/J1;->b()LL4/j0;

    move-result-object v2

    invoke-virtual {v2}, LL4/j0;->I()V

    invoke-virtual {p1}, LL4/J1;->k0()V

    const/4 v2, 0x0

    if-nez p4, :cond_0

    :try_start_0
    new-array p4, v2, [B

    goto :goto_0

    :catchall_0
    move-exception v0

    move-object p2, v0

    goto/16 :goto_2

    :cond_0
    :goto_0
    const/16 v3, 0xc8

    if-eq p2, v3, :cond_1

    const/16 v3, 0xcc

    if-ne p2, v3, :cond_3

    move p2, v3

    :cond_1
    if-nez p3, :cond_3

    iget-object p3, p1, LL4/J1;->v:LL4/m;

    invoke-static {p3}, LL4/J1;->T(LL4/E1;)V

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p4

    invoke-virtual {p3, p4}, LL4/m;->P(Ljava/lang/Long;)V

    invoke-virtual {p1}, LL4/J1;->a()LL4/Q;

    move-result-object p3

    iget-object p3, p3, LL4/Q;->H:LL4/O;

    const-string p4, "Successfully uploaded batch from upload queue. appId, status"

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {p3, p4, p5, p2}, LL4/O;->h(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object p2, p1, LL4/J1;->u:LL4/V;

    invoke-static {p2}, LL4/J1;->T(LL4/E1;)V

    invoke-virtual {p2}, LL4/V;->c0()Z

    move-result p2

    if-eqz p2, :cond_2

    iget-object p2, p1, LL4/J1;->v:LL4/m;

    invoke-static {p2}, LL4/J1;->T(LL4/E1;)V

    invoke-virtual {p2, p5}, LL4/m;->O(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_2

    invoke-virtual {p1, p5}, LL4/J1;->t(Ljava/lang/String;)V

    goto :goto_1

    :cond_2
    invoke-virtual {p1}, LL4/J1;->N()V

    goto :goto_1

    :cond_3
    new-instance v3, Ljava/lang/String;

    sget-object v4, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v3, p4, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result p4

    const/16 v4, 0x20

    invoke-static {v4, p4}, Ljava/lang/Math;->min(II)I

    move-result p4

    invoke-virtual {v3, v2, p4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p1}, LL4/J1;->a()LL4/Q;

    move-result-object v3

    iget-object v3, v3, LL4/Q;->E:LL4/O;

    const-string v4, "Network upload failed. Will retry later. appId, status, error"

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    if-nez p3, :cond_4

    move-object p3, p4

    :cond_4
    invoke-virtual {v3, v4, p5, p2, p3}, LL4/O;->i(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object p2, p1, LL4/J1;->v:LL4/m;

    invoke-static {p2}, LL4/J1;->T(LL4/E1;)V

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    invoke-virtual {p2, p3}, LL4/m;->U(Ljava/lang/Long;)V

    invoke-virtual {p1}, LL4/J1;->N()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_1
    iput-boolean v2, p1, LL4/J1;->N:Z

    invoke-virtual {p1}, LL4/J1;->O()V

    return-void

    :goto_2
    iput-boolean v2, p1, LL4/J1;->N:Z

    invoke-virtual {p1}, LL4/J1;->O()V

    throw p2

    :pswitch_0
    iget-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    move-object v0, p1

    check-cast v0, LL4/J1;

    iget-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    move-object v5, p1

    check-cast v5, Ljava/lang/String;

    iget-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    move-object v6, p1

    check-cast v6, Ljava/util/ArrayList;

    const/4 v1, 0x1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    invoke-virtual/range {v0 .. v6}, LL4/J1;->y(ZILjava/lang/Throwable;[BLjava/lang/String;Ljava/util/List;)V

    return-void

    :pswitch_data_0
    .packed-switch 0xf
        :pswitch_0
    .end packed-switch
.end method

.method public j(LL0/J;)Z
    .locals 4

    iget-object v0, p1, LL0/J;->z:LL0/J;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    iget-object v3, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v3, LA1/i;

    iget-object v3, v3, LA1/i;->u:Ljava/lang/Object;

    check-cast v3, LL0/A0;

    invoke-virtual {v3, p1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    iget-object v3, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v3, LA1/i;

    iget-object v3, v3, LA1/i;->u:Ljava/lang/Object;

    check-cast v3, LL0/A0;

    invoke-virtual {v3, p1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_1

    :cond_1
    move p1, v1

    goto :goto_2

    :cond_2
    :goto_1
    move p1, v2

    :goto_2
    if-nez v0, :cond_3

    if-eqz p1, :cond_3

    return v2

    :cond_3
    return v1
.end method

.method public l()LI/X;
    .locals 1

    iget-object v0, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v0, LI/X;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const-string v0, "keyboardActions"

    invoke-static {v0}, Ls7/j;->k(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method

.method public m()Lx7/d;
    .locals 2

    iget-object v0, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, Ljava/util/regex/Matcher;

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->start()I

    move-result v1

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->end()I

    move-result v0

    invoke-static {v1, v0}, LH4/Z5;->f(II)Lx7/d;

    move-result-object v0

    return-object v0
.end method

.method public n(Ljava/lang/CharSequence;IILO1/y;)Z
    .locals 7

    iget v0, p4, LO1/y;->c:I

    and-int/lit8 v0, v0, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_4

    iget-object v0, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v0, LO1/h;

    invoke-virtual {p4}, LO1/y;->b()LP1/a;

    move-result-object v4

    const/16 v5, 0x8

    invoke-virtual {v4, v5}, LP1/c;->a(I)I

    move-result v5

    if-eqz v5, :cond_0

    iget-object v6, v4, LP1/c;->w:Ljava/lang/Object;

    check-cast v6, Ljava/nio/ByteBuffer;

    iget v4, v4, LP1/c;->t:I

    add-int/2addr v5, v4

    invoke-virtual {v6, v5}, Ljava/nio/ByteBuffer;->getShort(I)S

    :cond_0
    check-cast v0, LO1/d;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v4, LO1/d;->b:Ljava/lang/ThreadLocal;

    invoke-virtual {v4}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v5

    if-nez v5, :cond_1

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v5}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :cond_1
    invoke-virtual {v4}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->setLength(I)V

    :goto_0
    if-ge p2, p3, :cond_2

    invoke-interface {p1, p2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_2
    iget-object p1, v0, LO1/d;->a:Landroid/text/TextPaint;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    sget p3, Lt1/c;->a:I

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->hasGlyph(Ljava/lang/String;)Z

    move-result p1

    iget p2, p4, LO1/y;->c:I

    and-int/lit8 p2, p2, 0x4

    if-eqz p1, :cond_3

    or-int/lit8 p1, p2, 0x2

    goto :goto_1

    :cond_3
    or-int/lit8 p1, p2, 0x1

    :goto_1
    iput p1, p4, LO1/y;->c:I

    :cond_4
    iget p1, p4, LO1/y;->c:I

    and-int/lit8 p1, p1, 0x3

    if-ne p1, v1, :cond_5

    return v3

    :cond_5
    return v2
.end method

.method public o()Z
    .locals 2

    iget-object v0, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, LA1/i;

    iget-object v0, v0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LL0/A0;

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iget-object v0, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v0, LA1/i;

    iget-object v0, v0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LL0/A0;

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v0, LA1/i;

    iget-object v0, v0, LA1/i;->u:Ljava/lang/Object;

    check-cast v0, LL0/A0;

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    xor-int/2addr v0, v1

    return v0
.end method

.method public p()LA4/f;
    .locals 5

    iget-object v0, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v0, Ljava/lang/CharSequence;

    iget-object v1, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v1, Ljava/util/regex/Matcher;

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->end()I

    move-result v2

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->end()I

    move-result v3

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->start()I

    move-result v4

    if-ne v3, v4, :cond_0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    :goto_0
    add-int/2addr v2, v3

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v3

    const/4 v4, 0x0

    if-gt v2, v3, :cond_2

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->pattern()Ljava/util/regex/Pattern;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    const-string v3, "matcher(...)"

    invoke-static {v1, v3}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/util/regex/Matcher;->find(I)Z

    move-result v2

    if-nez v2, :cond_1

    return-object v4

    :cond_1
    new-instance v2, LA4/f;

    invoke-direct {v2, v1, v0}, LA4/f;-><init>(Ljava/util/regex/Matcher;Ljava/lang/CharSequence;)V

    return-object v2

    :cond_2
    return-object v4
.end method

.method public q(Landroidx/lifecycle/o;)V
    .locals 2

    iget-object v0, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v0, Landroidx/lifecycle/Z;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroidx/lifecycle/Z;->run()V

    :cond_0
    new-instance v0, Landroidx/lifecycle/Z;

    iget-object v1, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v1, Landroidx/lifecycle/y;

    invoke-direct {v0, v1, p1}, Landroidx/lifecycle/Z;-><init>(Landroidx/lifecycle/y;Landroidx/lifecycle/o;)V

    iput-object v0, p0, LA4/f;->w:Ljava/lang/Object;

    iget-object p1, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast p1, Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public r(Ljava/lang/CharSequence;IIIZLO1/p;)Ljava/lang/Object;
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    move/from16 v3, p4

    move-object/from16 v4, p6

    new-instance v5, LO1/s;

    iget-object v6, v0, LA4/f;->v:Ljava/lang/Object;

    check-cast v6, LP2/i;

    iget-object v6, v6, LP2/i;->v:Ljava/lang/Object;

    check-cast v6, LO1/v;

    invoke-direct {v5, v6}, LO1/s;-><init>(LO1/v;)V

    invoke-static/range {p1 .. p2}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    move-result v6

    const/4 v7, 0x0

    const/4 v8, 0x1

    move v9, v6

    move v10, v7

    move v11, v8

    move/from16 v6, p2

    :cond_0
    :goto_0
    move v7, v6

    :goto_1
    const/4 v12, 0x2

    if-ge v6, v2, :cond_f

    if-ge v10, v3, :cond_f

    if-eqz v11, :cond_f

    iget-object v13, v5, LO1/s;->c:LO1/v;

    iget-object v13, v13, LO1/v;->a:Landroid/util/SparseArray;

    if-nez v13, :cond_1

    const/4 v13, 0x0

    goto :goto_2

    :cond_1
    invoke-virtual {v13, v9}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, LO1/v;

    :goto_2
    iget v14, v5, LO1/s;->a:I

    const/4 v15, 0x3

    if-eq v14, v12, :cond_3

    if-nez v13, :cond_2

    invoke-virtual {v5}, LO1/s;->a()V

    :goto_3
    move v13, v8

    goto :goto_6

    :cond_2
    iput v12, v5, LO1/s;->a:I

    iput-object v13, v5, LO1/s;->c:LO1/v;

    iput v8, v5, LO1/s;->f:I

    :goto_4
    move v13, v12

    goto :goto_6

    :cond_3
    if-eqz v13, :cond_4

    iput-object v13, v5, LO1/s;->c:LO1/v;

    iget v13, v5, LO1/s;->f:I

    add-int/2addr v13, v8

    iput v13, v5, LO1/s;->f:I

    goto :goto_4

    :cond_4
    const v13, 0xfe0e

    if-ne v9, v13, :cond_5

    invoke-virtual {v5}, LO1/s;->a()V

    goto :goto_3

    :cond_5
    const v13, 0xfe0f

    if-ne v9, v13, :cond_6

    goto :goto_4

    :cond_6
    iget-object v13, v5, LO1/s;->c:LO1/v;

    iget-object v14, v13, LO1/v;->b:LO1/y;

    if-eqz v14, :cond_9

    iget v14, v5, LO1/s;->f:I

    if-ne v14, v8, :cond_8

    invoke-virtual {v5}, LO1/s;->b()Z

    move-result v13

    if-eqz v13, :cond_7

    iget-object v13, v5, LO1/s;->c:LO1/v;

    iput-object v13, v5, LO1/s;->d:LO1/v;

    invoke-virtual {v5}, LO1/s;->a()V

    :goto_5
    move v13, v15

    goto :goto_6

    :cond_7
    invoke-virtual {v5}, LO1/s;->a()V

    goto :goto_3

    :cond_8
    iput-object v13, v5, LO1/s;->d:LO1/v;

    invoke-virtual {v5}, LO1/s;->a()V

    goto :goto_5

    :cond_9
    invoke-virtual {v5}, LO1/s;->a()V

    goto :goto_3

    :goto_6
    iput v9, v5, LO1/s;->e:I

    if-eq v13, v8, :cond_e

    if-eq v13, v12, :cond_c

    if-eq v13, v15, :cond_a

    goto :goto_1

    :cond_a
    if-nez p5, :cond_b

    iget-object v12, v5, LO1/s;->d:LO1/v;

    iget-object v12, v12, LO1/v;->b:LO1/y;

    invoke-virtual {v0, v1, v7, v6, v12}, LA4/f;->n(Ljava/lang/CharSequence;IILO1/y;)Z

    move-result v12

    if-nez v12, :cond_0

    :cond_b
    iget-object v11, v5, LO1/s;->d:LO1/v;

    iget-object v11, v11, LO1/v;->b:LO1/y;

    invoke-interface {v4, v1, v7, v6, v11}, LO1/p;->a(Ljava/lang/CharSequence;IILO1/y;)Z

    move-result v11

    add-int/lit8 v10, v10, 0x1

    goto/16 :goto_0

    :cond_c
    invoke-static {v9}, Ljava/lang/Character;->charCount(I)I

    move-result v12

    add-int/2addr v12, v6

    if-ge v12, v2, :cond_d

    invoke-static {v1, v12}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    move-result v6

    move v9, v6

    :cond_d
    move v6, v12

    goto/16 :goto_1

    :cond_e
    invoke-static {v1, v7}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Character;->charCount(I)I

    move-result v6

    add-int/2addr v6, v7

    if-ge v6, v2, :cond_0

    invoke-static {v1, v6}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    move-result v7

    move v9, v7

    goto/16 :goto_0

    :cond_f
    iget v2, v5, LO1/s;->a:I

    if-ne v2, v12, :cond_12

    iget-object v2, v5, LO1/s;->c:LO1/v;

    iget-object v2, v2, LO1/v;->b:LO1/y;

    if-eqz v2, :cond_12

    iget v2, v5, LO1/s;->f:I

    if-gt v2, v8, :cond_10

    invoke-virtual {v5}, LO1/s;->b()Z

    move-result v2

    if-eqz v2, :cond_12

    :cond_10
    if-ge v10, v3, :cond_12

    if-eqz v11, :cond_12

    if-nez p5, :cond_11

    iget-object v2, v5, LO1/s;->c:LO1/v;

    iget-object v2, v2, LO1/v;->b:LO1/y;

    invoke-virtual {v0, v1, v7, v6, v2}, LA4/f;->n(Ljava/lang/CharSequence;IILO1/y;)Z

    move-result v2

    if-nez v2, :cond_12

    :cond_11
    iget-object v2, v5, LO1/s;->c:LO1/v;

    iget-object v2, v2, LO1/v;->b:LO1/y;

    invoke-interface {v4, v1, v7, v6, v2}, LO1/p;->a(Ljava/lang/CharSequence;IILO1/y;)Z

    :cond_12
    invoke-interface {v4}, LO1/p;->b()Ljava/lang/Object;

    move-result-object v1

    return-object v1
.end method

.method public s(I)Z
    .locals 7

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-ne p1, v4, :cond_0

    invoke-virtual {p0}, LA4/f;->l()LI/X;

    goto :goto_0

    :cond_0
    if-ne p1, v2, :cond_1

    invoke-virtual {p0}, LA4/f;->l()LI/X;

    goto :goto_0

    :cond_1
    if-ne p1, v1, :cond_2

    invoke-virtual {p0}, LA4/f;->l()LI/X;

    goto :goto_0

    :cond_2
    if-ne p1, v0, :cond_3

    invoke-virtual {p0}, LA4/f;->l()LI/X;

    goto :goto_0

    :cond_3
    const/4 v5, 0x3

    if-ne p1, v5, :cond_4

    invoke-virtual {p0}, LA4/f;->l()LI/X;

    goto :goto_0

    :cond_4
    const/4 v5, 0x4

    if-ne p1, v5, :cond_5

    invoke-virtual {p0}, LA4/f;->l()LI/X;

    goto :goto_0

    :cond_5
    if-ne p1, v3, :cond_6

    goto :goto_0

    :cond_6
    if-nez p1, :cond_c

    :goto_0
    const/4 v5, 0x0

    const-string v6, "focusManager"

    if-ne p1, v1, :cond_8

    iget-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast p1, Lr0/i;

    if-eqz p1, :cond_7

    check-cast p1, Lr0/j;

    invoke-virtual {p1, v3}, Lr0/j;->f(I)Z

    return v3

    :cond_7
    invoke-static {v6}, Ls7/j;->k(Ljava/lang/String;)V

    throw v5

    :cond_8
    if-ne p1, v0, :cond_a

    iget-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast p1, Lr0/i;

    if-eqz p1, :cond_9

    check-cast p1, Lr0/j;

    invoke-virtual {p1, v2}, Lr0/j;->f(I)Z

    return v3

    :cond_9
    invoke-static {v6}, Ls7/j;->k(Ljava/lang/String;)V

    throw v5

    :cond_a
    if-ne p1, v4, :cond_b

    iget-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast p1, LM0/O0;

    if-eqz p1, :cond_b

    check-cast p1, LM0/s0;

    invoke-virtual {p1}, LM0/s0;->a()V

    return v3

    :cond_b
    const/4 p1, 0x0

    return p1

    :cond_c
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "invalid ImeAction"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public shutdown()V
    .locals 2

    iget-object v0, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, Landroid/net/ConnectivityManager;

    iget-object v1, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v1, LL2/e;

    invoke-virtual {v0, v1}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V

    return-void
.end method

.method public t(Lb1/b;LL4/K1;LI1/C;Lj7/c;)Ljava/lang/Object;
    .locals 5

    instance-of v0, p4, La1/i;

    if-eqz v0, :cond_0

    move-object v0, p4

    check-cast v0, La1/i;

    iget v1, v0, La1/i;->z:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    iput v1, v0, La1/i;->z:I

    goto :goto_0

    :cond_0
    new-instance v0, La1/i;

    invoke-direct {v0, p0, p4}, La1/i;-><init>(LA4/f;Lj7/c;)V

    :goto_0
    iget-object p4, v0, La1/i;->x:Ljava/lang/Object;

    sget-object v1, Li7/a;->t:Li7/a;

    iget v2, v0, La1/i;->z:I

    const/4 v3, 0x1

    if-eqz v2, :cond_2

    if-ne v2, v3, :cond_1

    iget-object p1, v0, La1/i;->w:La1/h;

    invoke-static {p4}, Ld7/a;->e(Ljava/lang/Object;)V

    goto :goto_2

    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    invoke-static {p4}, Ld7/a;->e(Ljava/lang/Object;)V

    new-instance p4, La1/h;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p4, p1}, La1/h;-><init>(Lb1/b;)V

    iget-object p1, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast p1, LT5/q;

    monitor-enter p1

    :try_start_0
    iget-object p2, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast p2, Lcom/google/android/gms/internal/ads/bM;

    invoke-virtual {p2, p4}, Lcom/google/android/gms/internal/ads/bM;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La1/g;

    if-nez p2, :cond_3

    iget-object p2, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast p2, Lp/H;

    invoke-virtual {p2, p4}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La1/g;

    goto :goto_1

    :catchall_0
    move-exception p2

    goto :goto_5

    :cond_3
    :goto_1
    if-eqz p2, :cond_4

    iget-object p2, p2, La1/g;->a:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p1

    return-object p2

    :cond_4
    monitor-exit p1

    iput-object p4, v0, La1/i;->w:La1/h;

    iput v3, v0, La1/i;->z:I

    invoke-virtual {p3, v0}, LI1/C;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_5

    return-object v1

    :cond_5
    move-object v4, p4

    move-object p4, p1

    move-object p1, v4

    :goto_2
    iget-object p2, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast p2, LT5/q;

    monitor-enter p2

    if-nez p4, :cond_6

    :try_start_1
    iget-object p3, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast p3, Lp/H;

    new-instance v0, La1/g;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La1/g;-><init>(Ljava/lang/Object;)V

    invoke-virtual {p3, p1, v0}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_3

    :catchall_1
    move-exception p1

    goto :goto_4

    :cond_6
    iget-object p3, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast p3, Lcom/google/android/gms/internal/ads/bM;

    new-instance v0, La1/g;

    invoke-direct {v0, p4}, La1/g;-><init>(Ljava/lang/Object;)V

    invoke-virtual {p3, p1, v0}, Lcom/google/android/gms/internal/ads/bM;->d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_3
    monitor-exit p2

    return-object p4

    :goto_4
    monitor-exit p2

    throw p1

    :goto_5
    monitor-exit p1

    throw p2
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    iget v0, p0, LA4/f;->t:I

    sparse-switch v0, :sswitch_data_0

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :sswitch_0
    iget-object v0, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "NavDeepLinkRequest{"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v3, Landroid/net/Uri;

    if-eqz v3, :cond_0

    const-string v4, " uri="

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    if-eqz v1, :cond_1

    const-string v3, " action="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    if-eqz v0, :cond_2

    const-string v1, " mimetype="

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const-string v0, " }"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "toString(...)"

    invoke-static {v0, v1}, Ls7/j;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :sswitch_1
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x20

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    iget-object v1, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x7b

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v1, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v1, Lj6/b;

    iget-object v1, v1, Lj6/b;->b:Ljava/lang/Object;

    check-cast v1, Lj6/b;

    const-string v2, ""

    :goto_0
    if-eqz v1, :cond_4

    iget-object v3, v1, Lj6/b;->a:Ljava/lang/Object;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v3, :cond_3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->isArray()Z

    move-result v2

    if-eqz v2, :cond_3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Arrays;->deepToString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    invoke-virtual {v0, v2, v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_3
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :goto_1
    iget-object v1, v1, Lj6/b;->b:Ljava/lang/Object;

    check-cast v1, Lj6/b;

    const-string v2, ", "

    goto :goto_0

    :cond_4
    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :sswitch_2
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x20

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    iget-object v1, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x7b

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v1, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v1, LA4/f;

    iget-object v1, v1, LA4/f;->w:Ljava/lang/Object;

    check-cast v1, LA4/f;

    const-string v2, ""

    :goto_2
    if-eqz v1, :cond_7

    iget-object v3, v1, LA4/f;->v:Ljava/lang/Object;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v1, LA4/f;->u:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    if-eqz v2, :cond_5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x3d

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_5
    if-eqz v3, :cond_6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->isArray()Z

    move-result v2

    if-eqz v2, :cond_6

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Arrays;->deepToString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v2, v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    goto :goto_3

    :cond_6
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :goto_3
    iget-object v1, v1, LA4/f;->w:Ljava/lang/Object;

    check-cast v1, LA4/f;

    const-string v2, ", "

    goto :goto_2

    :cond_7
    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        0x9 -> :sswitch_2
        0x13 -> :sswitch_1
        0x18 -> :sswitch_0
    .end sparse-switch
.end method

.method public u(Ljava/lang/String;)V
    .locals 1

    if-eqz p1, :cond_0

    iput-object p1, p0, LA4/f;->u:Ljava/lang/Object;

    return-void

    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "Null backendName"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public v(Ljava/lang/String;DD)V
    .locals 9

    iget-object v0, p0, LA4/f;->v:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    iget-object v1, p0, LA4/f;->w:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayList;

    const/4 v2, 0x0

    :goto_0
    iget-object v3, p0, LA4/f;->u:Ljava/lang/Object;

    check-cast v3, Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Double;

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Double;

    invoke-virtual {v6}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v6

    cmpg-double v8, p2, v4

    if-gez v8, :cond_0

    goto :goto_1

    :cond_0
    cmpl-double v4, v4, p2

    if-nez v4, :cond_1

    cmpg-double v4, p4, v6

    if-ltz v4, :cond_2

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    invoke-virtual {v3, v2, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p1

    invoke-virtual {v1, v2, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-static {p4, p5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p1

    invoke-virtual {v0, v2, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method public declared-synchronized w(IIJJ)V
    .locals 17

    move-object/from16 v1, p0

    monitor-enter p0

    :try_start_0
    iget-object v0, v1, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, LL4/m0;

    iget-object v0, v0, LL4/m0;->D:Lv4/a;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-object v0, v1, LA4/f;->w:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v4

    const-wide/16 v6, -0x1

    cmp-long v4, v4, v6

    if-nez v4, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    sub-long v4, v2, v4

    const-wide/32 v6, 0x1b7740

    cmp-long v0, v4, v6

    if-gtz v0, :cond_1

    monitor-exit p0

    return-void

    :cond_1
    :goto_0
    :try_start_1
    iget-object v0, v1, LA4/f;->v:Ljava/lang/Object;

    check-cast v0, Lr4/b;

    new-instance v4, Lp4/n;

    new-instance v5, Lp4/k;

    const/4 v14, 0x0

    const/4 v15, 0x0

    const v6, 0x8dcd

    const/4 v8, 0x0

    const/4 v13, 0x0

    move/from16 v7, p1

    move/from16 v16, p2

    move-wide/from16 v9, p3

    move-wide/from16 v11, p5

    invoke-direct/range {v5 .. v16}, Lp4/k;-><init>(IIIJJLjava/lang/String;Ljava/lang/String;II)V

    filled-new-array {v5}, [Lp4/k;

    move-result-object v5

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const/4 v6, 0x0

    invoke-direct {v4, v6, v5}, Lp4/n;-><init>(ILjava/util/List;)V

    invoke-virtual {v0, v4}, Lr4/b;->d(Lp4/n;)LO4/o;

    move-result-object v0

    new-instance v4, LF4/A7;

    const/4 v5, 0x2

    invoke-direct {v4, v1, v2, v3, v5}, LF4/A7;-><init>(Ljava/lang/Object;JI)V

    invoke-virtual {v0, v4}, LO4/o;->b(LO4/d;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method
