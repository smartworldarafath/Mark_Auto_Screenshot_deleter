.class public final LA4/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, LA4/g;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;Landroid/os/Looper;LT3/o;Ljava/lang/Object;Ln4/g;Ln4/h;)Ln4/c;
    .locals 9

    iget v0, p0, LA4/g;->a:I

    packed-switch v0, :pswitch_data_0

    move-object v6, p5

    check-cast v6, Lo4/k;

    move-object v7, p6

    check-cast v7, Lo4/k;

    iget p5, p0, LA4/g;->a:I

    packed-switch p5, :pswitch_data_1

    :pswitch_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "buildClient must be implemented"

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1

    :pswitch_1
    check-cast p4, Ln4/a;

    new-instance v1, Lt4/h;

    const/16 v4, 0x134

    move-object v2, p1

    move-object v3, p2

    move-object v5, p3

    invoke-direct/range {v1 .. v7}, Lp4/h;-><init>(Landroid/content/Context;Landroid/os/Looper;ILT3/o;Ln4/g;Ln4/h;)V

    goto :goto_0

    :pswitch_2
    move-object v2, p1

    move-object v3, p2

    move-object v5, p3

    check-cast p4, Lp4/o;

    new-instance v1, Lr4/c;

    move-object v4, v5

    move-object v5, p4

    invoke-direct/range {v1 .. v7}, Lr4/c;-><init>(Landroid/content/Context;Landroid/os/Looper;LT3/o;Lp4/o;Lo4/k;Lo4/k;)V

    goto :goto_0

    :pswitch_3
    move-object v2, p1

    move-object v3, p2

    move-object v5, p3

    check-cast p4, Ln4/a;

    new-instance v1, LA4/b;

    const/16 v4, 0x12c

    invoke-direct/range {v1 .. v7}, Lp4/h;-><init>(Landroid/content/Context;Landroid/os/Looper;ILT3/o;Ln4/g;Ln4/h;)V

    :goto_0
    return-object v1

    :pswitch_4
    invoke-static {p4}, Lq3/h;->f(Ljava/lang/Object;)Ljava/lang/ClassCastException;

    move-result-object p1

    throw p1

    :pswitch_5
    move-object v2, p1

    move-object v3, p2

    move-object v5, p3

    check-cast p4, LM4/a;

    move-object v4, v3

    move-object v3, v2

    new-instance v2, LN4/a;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, v5, LT3/o;->y:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    new-instance v6, Landroid/os/Bundle;

    invoke-direct {v6}, Landroid/os/Bundle;-><init>()V

    const-string p2, "com.google.android.gms.signin.internal.clientRequestedAccount"

    const/4 p3, 0x0

    invoke-virtual {v6, p2, p3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    if-eqz p1, :cond_0

    const-string p2, "com.google.android.gms.common.internal.ClientSettings.sessionId"

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-virtual {v6, p2, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_0
    const-string p1, "com.google.android.gms.signin.internal.offlineAccessRequested"

    const/4 p2, 0x0

    invoke-virtual {v6, p1, p2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const-string p1, "com.google.android.gms.signin.internal.idTokenRequested"

    invoke-virtual {v6, p1, p2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const-string p1, "com.google.android.gms.signin.internal.serverClientId"

    invoke-virtual {v6, p1, p3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "com.google.android.gms.signin.internal.usePromptModeForAuthCode"

    const/4 p4, 0x1

    invoke-virtual {v6, p1, p4}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const-string p1, "com.google.android.gms.signin.internal.forceCodeForRefreshToken"

    invoke-virtual {v6, p1, p2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const-string p1, "com.google.android.gms.signin.internal.hostedDomain"

    invoke-virtual {v6, p1, p3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "com.google.android.gms.signin.internal.logSessionId"

    invoke-virtual {v6, p1, p3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "com.google.android.gms.signin.internal.waitForAccessTokenRefresh"

    invoke-virtual {v6, p1, p2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    move-object v7, p5

    move-object v8, p6

    invoke-direct/range {v2 .. v8}, LN4/a;-><init>(Landroid/content/Context;Landroid/os/Looper;LT3/o;Landroid/os/Bundle;Ln4/g;Ln4/h;)V

    return-object v2

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_5
        :pswitch_4
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_3
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method
