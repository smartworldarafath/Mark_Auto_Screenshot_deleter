.class public final LA4/i;
.super Ln4/f;
.source "SourceFile"

# interfaces
.implements Lj4/a;


# static fields
.field public static final D:Lj6/b;


# instance fields
.field public final B:Landroid/content/Context;

.field public final C:Lm4/f;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    new-instance v0, LS1/e;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, LS1/e;-><init>(I)V

    new-instance v1, LA4/g;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, LA4/g;-><init>(I)V

    new-instance v2, Lj6/b;

    const-string v3, "AppSet.API"

    invoke-direct {v2, v3, v1, v0}, Lj6/b;-><init>(Ljava/lang/String;LA4/g;LS1/e;)V

    sput-object v2, LA4/i;->D:Lj6/b;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lm4/f;)V
    .locals 3

    sget-object v0, Ln4/b;->a:Ln4/a;

    sget-object v1, Ln4/e;->b:Ln4/e;

    sget-object v2, LA4/i;->D:Lj6/b;

    invoke-direct {p0, p1, v2, v0, v1}, Ln4/f;-><init>(Landroid/content/Context;Lj6/b;Ln4/b;Ln4/e;)V

    iput-object p1, p0, LA4/i;->B:Landroid/content/Context;

    iput-object p2, p0, LA4/i;->C:Lm4/f;

    return-void
.end method


# virtual methods
.method public final a()LO4/o;
    .locals 4

    iget-object v0, p0, LA4/i;->B:Landroid/content/Context;

    const v1, 0xcaf1200

    iget-object v2, p0, LA4/i;->C:Lm4/f;

    invoke-virtual {v2, v0, v1}, Lm4/f;->c(Landroid/content/Context;I)I

    move-result v0

    if-nez v0, :cond_0

    new-instance v0, LS1/a;

    invoke-direct {v0}, LS1/a;-><init>()V

    sget-object v1, Lj4/d;->a:Lm4/d;

    filled-new-array {v1}, [Lm4/d;

    move-result-object v1

    iput-object v1, v0, LS1/a;->e:Ljava/lang/Object;

    new-instance v1, LD4/w;

    invoke-direct {v1, p0}, LD4/w;-><init>(LA4/i;)V

    iput-object v1, v0, LS1/a;->d:Ljava/lang/Object;

    const/4 v1, 0x0

    iput-boolean v1, v0, LS1/a;->b:Z

    const/16 v2, 0x6bd1

    iput v2, v0, LS1/a;->c:I

    invoke-virtual {v0}, LS1/a;->a()LS1/a;

    move-result-object v0

    invoke-virtual {p0, v1, v0}, Ln4/f;->c(ILS1/a;)LO4/o;

    move-result-object v0

    return-object v0

    :cond_0
    new-instance v0, Ln4/d;

    new-instance v1, Lcom/google/android/gms/common/api/Status;

    const/16 v2, 0x11

    const/4 v3, 0x0

    invoke-direct {v1, v2, v3, v3, v3}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;Lm4/b;)V

    invoke-direct {v0, v1}, Ln4/d;-><init>(Lcom/google/android/gms/common/api/Status;)V

    invoke-static {v0}, LE4/j4;->d(Ljava/lang/Exception;)LO4/o;

    move-result-object v0

    return-object v0
.end method
