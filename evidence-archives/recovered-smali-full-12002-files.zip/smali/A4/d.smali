.class public final LA4/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA4/d;->t:I

    iput-object p2, p0, LA4/d;->u:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LF4/z7;LT5/q;)V
    .locals 0

    const/4 p2, 0x2

    iput p2, p0, LA4/d;->t:I

    sget-object p2, LF4/n5;->u:LF4/n5;

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA4/d;->u:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LL4/J1;LL4/K1;)V
    .locals 0

    const/4 p2, 0x7

    iput p2, p0, LA4/d;->t:I

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA4/d;->u:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LL4/X;Z)V
    .locals 0

    const/4 p2, 0x3

    iput p2, p0, LA4/d;->t:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA4/d;->u:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 21

    move-object/from16 v1, p0

    iget v0, v1, LA4/d;->t:I

    const/4 v2, 0x2

    const-wide/16 v3, 0x0

    const/4 v5, 0x3

    const-wide/16 v6, -0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    packed-switch v0, :pswitch_data_0

    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, Lo4/t;

    iget-object v0, v0, Lo4/t;->A:LV3/q;

    new-instance v2, Lm4/b;

    const/4 v3, 0x4

    invoke-direct {v2, v3, v9, v9}, Lm4/b;-><init>(ILandroid/app/PendingIntent;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, LV3/q;->d(Lm4/b;)V

    return-void

    :pswitch_0
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LW2/g;

    iget-object v0, v0, LW2/g;->u:Ljava/lang/Object;

    check-cast v0, Lo4/k;

    iget-object v0, v0, Lo4/k;->u:Ln4/c;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const-string v3, " disconnecting because it was signed out."

    invoke-virtual {v2, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ln4/c;->c(Ljava/lang/String;)V

    return-void

    :pswitch_1
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, Lo4/k;

    invoke-virtual {v0}, Lo4/k;->e()V

    return-void

    :pswitch_2
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, Landroidx/appcompat/widget/Toolbar;

    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->t:Landroidx/appcompat/widget/ActionMenuView;

    if-eqz v0, :cond_0

    iget-object v0, v0, Landroidx/appcompat/widget/ActionMenuView;->L:Ll/i;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ll/i;->k()Z

    :cond_0
    return-void

    :pswitch_3
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    iget-boolean v2, v0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->y:Z

    if-eqz v2, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const-string v3, "input_method"

    invoke-virtual {v2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/inputmethod/InputMethodManager;

    invoke-virtual {v2, v0, v8}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    iput-boolean v8, v0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->y:Z

    :cond_1
    return-void

    :pswitch_4
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, Ll/N;

    iput-object v9, v0, Ll/N;->E:LA4/d;

    invoke-virtual {v0}, Ll/N;->drawableStateChanged()V

    return-void

    :cond_2
    :goto_0
    :pswitch_5
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, LY7/d;

    monitor-enter v2

    :try_start_0
    invoke-virtual {v2}, LY7/d;->c()LY7/a;

    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit v2

    if-nez v3, :cond_3

    return-void

    :cond_3
    iget-object v2, v3, LY7/a;->c:LY7/c;

    invoke-static {v2}, Ls7/j;->b(Ljava/lang/Object;)V

    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, LY7/d;

    sget-object v0, LY7/d;->j:Ljava/util/logging/Logger;

    sget-object v5, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    invoke-virtual {v0, v5}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v8

    const-string v0, "starting"

    invoke-static {v3, v2, v0}, LF4/d5;->a(LY7/a;LY7/c;Ljava/lang/String;)V

    goto :goto_1

    :cond_4
    move-wide v8, v6

    :goto_1
    :try_start_1
    invoke-static {v4, v3}, LY7/d;->a(LY7/d;LY7/a;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v5, :cond_2

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    sub-long/2addr v4, v8

    invoke-static {v4, v5}, LF4/d5;->b(J)Ljava/lang/String;

    move-result-object v0

    const-string v4, "finished run in "

    invoke-virtual {v4, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v2, v0}, LF4/d5;->a(LY7/a;LY7/c;Ljava/lang/String;)V

    goto :goto_0

    :catchall_0
    move-exception v0

    :try_start_2
    iget-object v4, v4, LY7/d;->a:LU2/h;

    iget-object v4, v4, LU2/h;->t:Ljava/lang/Object;

    check-cast v4, Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {v4, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catchall_1
    move-exception v0

    if-eqz v5, :cond_5

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    sub-long/2addr v4, v8

    invoke-static {v4, v5}, LF4/d5;->b(J)Ljava/lang/String;

    move-result-object v4

    const-string v5, "failed a run in "

    invoke-virtual {v5, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v2, v4}, LF4/d5;->a(LY7/a;LY7/c;Ljava/lang/String;)V

    :cond_5
    throw v0

    :catchall_2
    move-exception v0

    monitor-exit v2

    throw v0

    :pswitch_6
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LW3/H;

    iget-boolean v2, v0, LW3/H;->b:Z

    if-nez v2, :cond_6

    goto :goto_3

    :cond_6
    invoke-virtual {v0}, LW3/H;->k()Z

    move-result v2

    if-eqz v2, :cond_7

    invoke-virtual {v0}, LW3/H;->l()Z

    move-result v2

    if-nez v2, :cond_c

    :cond_7
    sget-object v2, Lcom/google/android/gms/internal/ads/B8;->b:Lcom/google/android/gms/internal/ads/Z3;

    invoke-virtual {v2}, Lcom/google/android/gms/internal/ads/Z3;->n()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_8

    goto :goto_3

    :cond_8
    iget-object v2, v0, LW3/H;->a:Ljava/lang/Object;

    monitor-enter v2

    :try_start_3
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    if-nez v3, :cond_9

    monitor-exit v2

    goto :goto_3

    :catchall_3
    move-exception v0

    goto :goto_5

    :cond_9
    iget-object v3, v0, LW3/H;->e:Lcom/google/android/gms/internal/ads/v6;

    if-nez v3, :cond_a

    new-instance v3, Lcom/google/android/gms/internal/ads/v6;

    invoke-direct {v3}, Lcom/google/android/gms/internal/ads/v6;-><init>()V

    iput-object v3, v0, LW3/H;->e:Lcom/google/android/gms/internal/ads/v6;

    :cond_a
    iget-object v0, v0, LW3/H;->e:Lcom/google/android/gms/internal/ads/v6;

    iget-object v3, v0, Lcom/google/android/gms/internal/ads/v6;->v:Ljava/lang/Object;

    monitor-enter v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    :try_start_4
    iget-boolean v4, v0, Lcom/google/android/gms/internal/ads/v6;->t:Z

    if-eqz v4, :cond_b

    const-string v0, "Content hash thread already started, quitting..."

    invoke-static {v0}, LX3/l;->c(Ljava/lang/String;)V

    monitor-exit v3

    goto :goto_2

    :catchall_4
    move-exception v0

    goto :goto_4

    :cond_b
    iput-boolean v10, v0, Lcom/google/android/gms/internal/ads/v6;->t:Z

    monitor-exit v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    :try_start_5
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    :goto_2
    const-string v0, "start fetching content..."

    invoke-static {v0}, LX3/l;->g(Ljava/lang/String;)V

    monitor-exit v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    :cond_c
    :goto_3
    return-void

    :goto_4
    :try_start_6
    monitor-exit v3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    :try_start_7
    throw v0

    :goto_5
    monitor-exit v2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    throw v0

    :pswitch_7
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LE/V;

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, LE/V;->G()V

    return-void

    :pswitch_8
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LV3/c;

    invoke-virtual {v0}, LV3/c;->g4()V

    return-void

    :pswitch_9
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LV3/a;

    iget-boolean v2, v0, LV3/a;->A:Z

    if-eqz v2, :cond_d

    iget-object v0, v0, LV3/a;->v:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    :cond_d
    return-void

    :pswitch_a
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/gms/internal/ads/md;

    if-eqz v0, :cond_e

    :try_start_8
    invoke-interface {v0, v10}, Lcom/google/android/gms/internal/ads/md;->t(I)V
    :try_end_8
    .catch Landroid/os/RemoteException; {:try_start_8 .. :try_end_8} :catch_0

    goto :goto_6

    :catch_0
    move-exception v0

    const-string v2, "#007 Could not call remote method."

    invoke-static {v2, v0}, LX3/l;->k(Ljava/lang/String;Ljava/lang/Exception;)V

    :cond_e
    :goto_6
    return-void

    :pswitch_b
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LT3/T0;

    iget-object v0, v0, LT3/T0;->t:Lcom/google/android/gms/internal/ads/ya;

    if-eqz v0, :cond_f

    :try_start_9
    sget-object v2, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    invoke-interface {v0, v2}, Lcom/google/android/gms/internal/ads/ya;->d3(Ljava/util/List;)V
    :try_end_9
    .catch Landroid/os/RemoteException; {:try_start_9 .. :try_end_9} :catch_1

    goto :goto_7

    :catch_1
    move-exception v0

    const-string v2, "Could not notify onComplete event."

    invoke-static {v2, v0}, LX3/l;->i(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_f
    :goto_7
    return-void

    :pswitch_c
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LT3/S0;

    iget-object v0, v0, LT3/S0;->t:LT3/y;

    if-eqz v0, :cond_10

    :try_start_a
    invoke-interface {v0, v10}, LT3/y;->G(I)V
    :try_end_a
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_a} :catch_2

    goto :goto_8

    :catch_2
    move-exception v0

    const-string v2, "Could not notify onAdFailedToLoad event."

    invoke-static {v2, v0}, LX3/l;->i(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_10
    :goto_8
    return-void

    :pswitch_d
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LT3/Q0;

    iget-object v0, v0, LT3/Q0;->t:LT3/R0;

    iget-object v0, v0, LT3/R0;->t:LT3/y;

    if-eqz v0, :cond_11

    :try_start_b
    invoke-interface {v0, v10}, LT3/y;->G(I)V
    :try_end_b
    .catch Landroid/os/RemoteException; {:try_start_b .. :try_end_b} :catch_3

    goto :goto_9

    :catch_3
    move-exception v0

    const-string v2, "Could not notify onAdFailedToLoad event."

    invoke-static {v2, v0}, LX3/l;->i(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_11
    :goto_9
    return-void

    :pswitch_e
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LS1/k;

    invoke-virtual {v0}, LS1/k;->t()V

    throw v9

    :pswitch_f
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LS1/d;

    iget-object v0, v0, LS1/d;->C:LS1/c;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    :pswitch_10
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LO4/l;

    iget-object v3, v0, LO4/l;->v:Ljava/lang/Object;

    monitor-enter v3

    :try_start_c
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LO4/l;

    iget-object v0, v0, LO4/l;->w:Ljava/lang/Object;

    check-cast v0, LO4/b;

    invoke-interface {v0}, LO4/b;->c()V

    monitor-exit v3

    return-void

    :catchall_5
    move-exception v0

    monitor-exit v3
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_5

    throw v0

    :pswitch_11
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LM0/x;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v12, v0, LM0/x;->L0:Landroid/view/MotionEvent;

    if-eqz v12, :cond_15

    invoke-virtual {v12, v8}, Landroid/view/MotionEvent;->getToolType(I)I

    move-result v0

    if-ne v0, v5, :cond_12

    move v8, v10

    :cond_12
    invoke-virtual {v12}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    if-eqz v8, :cond_13

    const/16 v3, 0xa

    if-eq v0, v3, :cond_15

    if-eq v0, v10, :cond_15

    goto :goto_a

    :cond_13
    if-eq v0, v10, :cond_15

    :goto_a
    const/4 v3, 0x7

    if-eq v0, v3, :cond_14

    const/16 v4, 0x9

    if-eq v0, v4, :cond_14

    move v13, v2

    goto :goto_b

    :cond_14
    move v13, v3

    :goto_b
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, LM0/x;

    iget-wide v14, v11, LM0/x;->M0:J

    const/16 v16, 0x0

    invoke-virtual/range {v11 .. v16}, LM0/x;->H(Landroid/view/MotionEvent;IJZ)V

    :cond_15
    return-void

    :pswitch_12
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LL4/m0;

    iget-object v2, v0, LL4/m0;->B:LL4/P1;

    iget-object v3, v0, LL4/m0;->F:LL4/Q0;

    invoke-static {v2}, LL4/m0;->j(LE/V;)V

    invoke-virtual {v2}, LE/V;->I()V

    invoke-virtual {v2}, LL4/P1;->c0()J

    move-result-wide v6

    const-wide/16 v8, 0x1

    cmp-long v2, v6, v8

    if-nez v2, :cond_17

    invoke-static {v3}, LL4/m0;->k(LL4/C;)V

    invoke-virtual {v3}, LL4/x;->I()V

    iget-object v0, v3, LL4/Q0;->F:LL4/E0;

    if-eqz v0, :cond_16

    invoke-virtual {v0}, LL4/n;->c()V

    :cond_16
    new-instance v0, Ljava/lang/Thread;

    invoke-static {v3}, LL4/m0;->k(LL4/C;)V

    new-instance v2, LL4/D0;

    invoke-direct {v2, v3, v5}, LL4/D0;-><init>(LL4/Q0;I)V

    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    goto :goto_c

    :cond_17
    iget-object v0, v0, LL4/m0;->y:LL4/Q;

    invoke-static {v0}, LL4/m0;->l(LL4/u0;)V

    iget-object v0, v0, LL4/Q;->C:LL4/O;

    const-string v2, "registerTrigger called but app not eligible"

    invoke-virtual {v0, v2}, LL4/O;->f(Ljava/lang/String;)V

    :goto_c
    return-void

    :pswitch_13
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LL4/S1;

    iget-object v0, v0, LL4/S1;->b:Ljava/lang/Object;

    check-cast v0, LL4/m0;

    iget-object v2, v0, LL4/m0;->N:LL4/V0;

    invoke-static {v2}, LL4/m0;->i(LL4/x;)V

    iget-object v0, v0, LL4/m0;->N:LL4/V0;

    sget-object v2, LL4/A;->D:LL4/z;

    invoke-virtual {v2, v9}, LL4/z;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {v0, v2, v3}, LL4/V0;->M(J)V

    return-void

    :pswitch_14
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LL4/J1;

    invoke-virtual {v0}, LL4/J1;->b()LL4/j0;

    move-result-object v2

    invoke-virtual {v2}, LL4/j0;->I()V

    new-instance v2, LL4/c0;

    invoke-direct {v2, v0}, LL4/c0;-><init>(LL4/J1;)V

    iput-object v2, v0, LL4/J1;->D:LL4/c0;

    new-instance v2, LL4/m;

    invoke-direct {v2, v0}, LL4/m;-><init>(LL4/J1;)V

    invoke-virtual {v2}, LL4/E1;->K()V

    iput-object v2, v0, LL4/J1;->v:LL4/m;

    iget-object v2, v0, LL4/J1;->t:LL4/f0;

    invoke-virtual {v0}, LL4/J1;->d0()LL4/g;

    move-result-object v5

    invoke-static {v2}, Lp4/y;->h(Ljava/lang/Object;)V

    iput-object v2, v5, LL4/g;->x:LL4/f;

    new-instance v2, LL4/o1;

    invoke-direct {v2, v0}, LL4/o1;-><init>(LL4/J1;)V

    invoke-virtual {v2}, LL4/E1;->K()V

    iput-object v2, v0, LL4/J1;->B:LL4/o1;

    new-instance v2, LL4/c;

    invoke-direct {v2, v0}, LL4/E1;-><init>(LL4/J1;)V

    invoke-virtual {v2}, LL4/E1;->K()V

    iput-object v2, v0, LL4/J1;->y:LL4/c;

    new-instance v2, LL4/V;

    invoke-direct {v2, v0, v10}, LL4/V;-><init>(LL4/J1;I)V

    invoke-virtual {v2}, LL4/E1;->K()V

    iput-object v2, v0, LL4/J1;->A:LL4/V;

    new-instance v2, LL4/z1;

    invoke-direct {v2, v0}, LL4/z1;-><init>(LL4/J1;)V

    invoke-virtual {v2}, LL4/E1;->K()V

    iput-object v2, v0, LL4/J1;->x:LL4/z1;

    new-instance v2, LL4/X;

    invoke-direct {v2, v0}, LL4/X;-><init>(LL4/J1;)V

    iput-object v2, v0, LL4/J1;->w:LL4/X;

    iget v2, v0, LL4/J1;->K:I

    iget v5, v0, LL4/J1;->L:I

    if-eq v2, v5, :cond_18

    invoke-virtual {v0}, LL4/J1;->a()LL4/Q;

    move-result-object v2

    iget-object v2, v2, LL4/Q;->z:LL4/O;

    iget v5, v0, LL4/J1;->K:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget v6, v0, LL4/J1;->L:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const-string v7, "Not all upload components initialized"

    invoke-virtual {v2, v7, v5, v6}, LL4/O;->h(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_18
    iget-object v2, v0, LL4/J1;->F:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    invoke-virtual {v0}, LL4/J1;->a()LL4/Q;

    move-result-object v2

    iget-object v2, v2, LL4/Q;->H:LL4/O;

    const-string v5, "UploadController is now fully initialized"

    invoke-virtual {v2, v5}, LL4/O;->f(Ljava/lang/String;)V

    invoke-virtual {v0}, LL4/J1;->b()LL4/j0;

    move-result-object v2

    invoke-virtual {v2}, LL4/j0;->I()V

    iget-object v2, v0, LL4/J1;->v:LL4/m;

    invoke-static {v2}, LL4/J1;->T(LL4/E1;)V

    invoke-virtual {v2}, LL4/m;->S()V

    iget-object v2, v0, LL4/J1;->v:LL4/m;

    invoke-static {v2}, LL4/J1;->T(LL4/E1;)V

    invoke-virtual {v2}, LE/V;->I()V

    invoke-virtual {v2}, LL4/E1;->J()V

    invoke-virtual {v2}, LL4/m;->p0()Z

    move-result v5

    if-eqz v5, :cond_1a

    sget-object v5, LL4/A;->v0:LL4/z;

    invoke-virtual {v5, v9}, LL4/z;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Long;

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    cmp-long v6, v6, v3

    if-nez v6, :cond_19

    goto :goto_d

    :cond_19
    invoke-virtual {v2}, LL4/m;->x0()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v6

    iget-object v2, v2, LE/V;->u:Ljava/lang/Object;

    check-cast v2, LL4/m0;

    iget-object v7, v2, LL4/m0;->D:Lv4/a;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v9}, LL4/z;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v7, v5}, [Ljava/lang/String;

    move-result-object v5

    const-string v7, "trigger_uris"

    const-string v8, "abs(timestamp_millis - ?) > cast(? as integer)"

    invoke-virtual {v6, v7, v8, v5}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v5

    if-lez v5, :cond_1a

    iget-object v2, v2, LL4/m0;->y:LL4/Q;

    invoke-static {v2}, LL4/m0;->l(LL4/u0;)V

    iget-object v2, v2, LL4/Q;->H:LL4/O;

    const-string v6, "Deleted stale trigger uris. rowsDeleted"

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v2, v5, v6}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_1a
    :goto_d
    iget-object v2, v0, LL4/J1;->B:LL4/o1;

    iget-object v2, v2, LL4/o1;->B:LL4/Z;

    invoke-virtual {v2}, LL4/Z;->a()J

    move-result-wide v5

    cmp-long v2, v5, v3

    if-nez v2, :cond_1b

    iget-object v2, v0, LL4/J1;->B:LL4/o1;

    iget-object v2, v2, LL4/o1;->B:LL4/Z;

    invoke-virtual {v0}, LL4/J1;->f()Lv4/a;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, LL4/Z;->b(J)V

    :cond_1b
    invoke-virtual {v0}, LL4/J1;->N()V

    return-void

    :pswitch_15
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LL4/r1;

    iget-object v3, v0, LL4/r1;->v:LP2/l;

    iget-object v3, v3, LP2/l;->u:Ljava/lang/Object;

    check-cast v3, LL4/u1;

    invoke-virtual {v3}, LL4/x;->I()V

    iget-object v4, v3, LE/V;->u:Ljava/lang/Object;

    check-cast v4, LL4/m0;

    iget-object v5, v4, LL4/m0;->y:LL4/Q;

    iget-object v6, v4, LL4/m0;->t:Landroid/content/Context;

    invoke-static {v5}, LL4/m0;->l(LL4/u0;)V

    iget-object v7, v5, LL4/Q;->G:LL4/O;

    const-string v11, "Application going to the background"

    invoke-virtual {v7, v11}, LL4/O;->f(Ljava/lang/String;)V

    iget-object v7, v4, LL4/m0;->x:LL4/a0;

    invoke-static {v7}, LL4/m0;->j(LE/V;)V

    iget-object v7, v7, LL4/a0;->M:LL4/Y;

    invoke-virtual {v7, v10}, LL4/Y;->b(Z)V

    invoke-virtual {v3}, LL4/x;->I()V

    iput-boolean v10, v3, LL4/u1;->x:Z

    iget-object v7, v4, LL4/m0;->w:LL4/g;

    invoke-virtual {v7}, LL4/g;->W()Z

    move-result v11

    if-nez v11, :cond_1c

    iget-wide v11, v0, LL4/r1;->u:J

    iget-object v3, v3, LL4/u1;->z:LL4/t1;

    invoke-virtual {v3, v8, v8, v11, v12}, LL4/t1;->a(ZZJ)Z

    iget-object v3, v3, LL4/t1;->v:Ljava/lang/Object;

    check-cast v3, LL4/s1;

    invoke-virtual {v3}, LL4/n;->c()V

    :cond_1c
    iget-wide v11, v0, LL4/r1;->t:J

    invoke-static {v5}, LL4/m0;->l(LL4/u0;)V

    iget-object v0, v5, LL4/Q;->F:LL4/O;

    const-string v3, "Application backgrounded at: timestamp_millis"

    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    invoke-virtual {v0, v8, v3}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v4, LL4/m0;->F:LL4/Q0;

    invoke-static {v0}, LL4/m0;->k(LL4/C;)V

    invoke-virtual {v0}, LL4/x;->I()V

    iget-object v3, v0, LE/V;->u:Ljava/lang/Object;

    check-cast v3, LL4/m0;

    invoke-virtual {v0}, LL4/C;->J()V

    invoke-virtual {v3}, LL4/m0;->o()LL4/m1;

    move-result-object v0

    invoke-virtual {v0}, LL4/x;->I()V

    invoke-virtual {v0}, LL4/C;->J()V

    invoke-virtual {v0}, LL4/m1;->P()Z

    move-result v8

    if-nez v8, :cond_1d

    goto :goto_e

    :cond_1d
    iget-object v0, v0, LE/V;->u:Ljava/lang/Object;

    check-cast v0, LL4/m0;

    iget-object v0, v0, LL4/m0;->B:LL4/P1;

    invoke-static {v0}, LL4/m0;->j(LE/V;)V

    invoke-virtual {v0}, LL4/P1;->n0()I

    move-result v0

    const v8, 0x3b3a8

    if-lt v0, v8, :cond_1e

    :goto_e
    invoke-virtual {v3}, LL4/m0;->o()LL4/m1;

    move-result-object v0

    invoke-virtual {v0}, LL4/x;->I()V

    invoke-virtual {v0}, LL4/C;->J()V

    invoke-virtual {v0, v10}, LL4/m1;->Y(Z)LL4/R1;

    move-result-object v3

    new-instance v8, LL4/h1;

    invoke-direct {v8, v0, v3, v2}, LL4/h1;-><init>(LL4/m1;LL4/R1;I)V

    invoke-virtual {v0, v8}, LL4/m1;->W(Ljava/lang/Runnable;)V

    :cond_1e
    sget-object v0, LL4/A;->N0:LL4/z;

    invoke-virtual {v7, v9, v0}, LL4/g;->S(Ljava/lang/String;LL4/z;)Z

    move-result v0

    if-eqz v0, :cond_20

    iget-object v0, v4, LL4/m0;->B:LL4/P1;

    invoke-static {v0}, LL4/m0;->j(LE/V;)V

    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    iget-object v3, v7, LL4/g;->w:Ljava/lang/String;

    invoke-virtual {v0, v2, v3}, LL4/P1;->h0(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1f

    const-wide/16 v2, 0x3e8

    goto :goto_f

    :cond_1f
    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    sget-object v2, LL4/A;->E:LL4/z;

    invoke-virtual {v7, v0, v2}, LL4/g;->P(Ljava/lang/String;LL4/z;)J

    move-result-wide v2

    :goto_f
    invoke-static {v5}, LL4/m0;->l(LL4/u0;)V

    iget-object v0, v5, LL4/Q;->H:LL4/O;

    const-string v5, "[sgtm] Scheduling batch upload with minimum latency in millis"

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v0, v6, v5}, LL4/O;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v4, LL4/m0;->N:LL4/V0;

    invoke-static {v0}, LL4/m0;->i(LL4/x;)V

    iget-object v0, v4, LL4/m0;->N:LL4/V0;

    invoke-virtual {v0, v2, v3}, LL4/V0;->M(J)V

    :cond_20
    return-void

    :pswitch_16
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LX4/a;

    iget-object v0, v0, LX4/a;->v:Ljava/lang/Object;

    check-cast v0, LL4/l1;

    iget-object v0, v0, LL4/l1;->v:LL4/m1;

    iget-object v2, v0, LE/V;->u:Ljava/lang/Object;

    check-cast v2, LL4/m0;

    iget-object v2, v2, LL4/m0;->z:LL4/j0;

    invoke-static {v2}, LL4/m0;->l(LL4/u0;)V

    new-instance v3, LL4/k1;

    invoke-direct {v3, v0, v8}, LL4/k1;-><init>(LL4/m1;I)V

    invoke-virtual {v2, v3}, LL4/j0;->R(Ljava/lang/Runnable;)V

    return-void

    :pswitch_17
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LL4/l1;

    iget-object v0, v0, LL4/l1;->v:LL4/m1;

    new-instance v2, Landroid/content/ComponentName;

    iget-object v3, v0, LE/V;->u:Ljava/lang/Object;

    check-cast v3, LL4/m0;

    iget-object v3, v3, LL4/m0;->t:Landroid/content/Context;

    const-string v4, "com.google.android.gms.measurement.AppMeasurementService"

    invoke-direct {v2, v3, v4}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, LL4/m1;->T(Landroid/content/ComponentName;)V

    return-void

    :pswitch_18
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LL4/X;

    iget-object v0, v0, LL4/X;->d:Ljava/lang/Object;

    check-cast v0, LL4/J1;

    invoke-virtual {v0}, LL4/J1;->N()V

    return-void

    :pswitch_19
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, LF4/z7;

    sget-object v13, LF4/n5;->A1:LF4/n5;

    iget-object v0, v11, LF4/z7;->j:Ljava/util/HashMap;

    invoke-virtual {v0, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LF4/x7;

    if-eqz v2, :cond_26

    move-object v6, v2

    check-cast v6, LF4/e7;

    iget-object v7, v6, LF4/e7;->t:LF4/x3;

    if-nez v7, :cond_21

    move-object v7, v6

    check-cast v7, LF4/x7;

    new-instance v10, LF4/x3;

    iget-object v12, v7, LF4/x7;->v:LF4/e;

    invoke-direct {v10, v7, v12}, LF4/x3;-><init>(LF4/x7;Ljava/util/Map;)V

    iput-object v10, v6, LF4/e7;->t:LF4/x3;

    move-object v7, v10

    :cond_21
    invoke-virtual {v7}, LF4/x3;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_10
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_25

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    new-instance v10, Ljava/util/ArrayList;

    iget-object v12, v2, LF4/x7;->v:LF4/e;

    invoke-virtual {v12, v7}, LF4/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/util/Collection;

    if-nez v12, :cond_22

    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12, v5}, Ljava/util/ArrayList;-><init>(I)V

    :cond_22
    check-cast v12, Ljava/util/List;

    instance-of v14, v12, Ljava/util/RandomAccess;

    if-eqz v14, :cond_23

    new-instance v14, LF4/Y3;

    invoke-direct {v14, v2, v7, v12, v9}, LF4/Q5;-><init>(LF4/x7;Ljava/lang/Object;Ljava/util/List;LF4/Q5;)V

    goto :goto_11

    :cond_23
    new-instance v14, LF4/Q5;

    invoke-direct {v14, v2, v7, v12, v9}, LF4/Q5;-><init>(LF4/x7;Ljava/lang/Object;Ljava/util/List;LF4/Q5;)V

    :goto_11
    invoke-direct {v10, v14}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v10}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    new-instance v12, LF4/R4;

    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v14

    move-wide v15, v3

    move-wide/from16 v17, v15

    move v3, v8

    :goto_12
    if-ge v3, v14, :cond_24

    invoke-virtual {v10, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    add-int/lit8 v3, v3, 0x1

    check-cast v4, Ljava/lang/Long;

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v19

    add-long v15, v19, v15

    goto :goto_12

    :cond_24
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v3

    int-to-long v3, v3

    div-long/2addr v15, v3

    const-wide v3, 0x7fffffffffffffffL

    and-long v14, v15, v3

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    iput-object v14, v12, LF4/R4;->c:Ljava/lang/Long;

    const-wide/high16 v14, 0x4059000000000000L    # 100.0

    invoke-static {v10, v14, v15}, LF4/z7;->a(Ljava/util/ArrayList;D)J

    move-result-wide v14

    and-long/2addr v14, v3

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    iput-object v14, v12, LF4/R4;->a:Ljava/lang/Long;

    const-wide v14, 0x4052c00000000000L    # 75.0

    invoke-static {v10, v14, v15}, LF4/z7;->a(Ljava/util/ArrayList;D)J

    move-result-wide v14

    and-long/2addr v14, v3

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    iput-object v14, v12, LF4/R4;->f:Ljava/lang/Long;

    const-wide/high16 v14, 0x4049000000000000L    # 50.0

    invoke-static {v10, v14, v15}, LF4/z7;->a(Ljava/util/ArrayList;D)J

    move-result-wide v14

    and-long/2addr v14, v3

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    iput-object v14, v12, LF4/R4;->e:Ljava/lang/Long;

    const-wide/high16 v14, 0x4039000000000000L    # 25.0

    invoke-static {v10, v14, v15}, LF4/z7;->a(Ljava/util/ArrayList;D)J

    move-result-wide v14

    and-long/2addr v14, v3

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    iput-object v14, v12, LF4/R4;->d:Ljava/lang/Long;

    const-wide/16 v14, 0x0

    invoke-static {v10, v14, v15}, LF4/z7;->a(Ljava/util/ArrayList;D)J

    move-result-wide v14

    and-long/2addr v3, v14

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    iput-object v3, v12, LF4/R4;->b:Ljava/lang/Long;

    new-instance v3, LF4/S4;

    invoke-direct {v3, v12}, LF4/S4;-><init>(LF4/R4;)V

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v4

    check-cast v7, LF4/X;

    new-instance v10, LT3/o;

    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    sget-object v12, LF4/l5;->u:LF4/l5;

    iput-object v12, v10, LT3/o;->v:Ljava/lang/Object;

    new-instance v12, LF4/A;

    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    const v14, 0x7fffffff

    and-int/2addr v4, v14

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    iput-object v4, v12, LF4/A;->u:Ljava/lang/Object;

    iput-object v7, v12, LF4/A;->t:Ljava/lang/Object;

    iput-object v3, v12, LF4/A;->v:Ljava/lang/Object;

    new-instance v3, LF4/Y;

    invoke-direct {v3, v12}, LF4/Y;-><init>(LF4/A;)V

    iput-object v3, v10, LT3/o;->y:Ljava/lang/Object;

    new-instance v12, LD4/f;

    invoke-direct {v12, v10, v8}, LD4/f;-><init>(LT3/o;I)V

    invoke-virtual {v11}, LF4/z7;->b()Ljava/lang/String;

    move-result-object v14

    sget-object v3, LT5/l;->t:LT5/l;

    new-instance v10, LA1/P;

    const/4 v15, 0x1

    invoke-direct/range {v10 .. v15}, LA1/P;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v3, v10}, LT5/l;->execute(Ljava/lang/Runnable;)V

    move-wide/from16 v3, v17

    goto/16 :goto_10

    :cond_25
    invoke-virtual {v0, v13}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_26
    return-void

    :pswitch_1a
    move-wide/from16 v17, v3

    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LE1/d;

    iget-object v2, v0, LE1/d;->v:Ll/N;

    iget-object v3, v0, LE1/d;->t:LE1/a;

    iget-boolean v4, v0, LE1/d;->H:Z

    if-nez v4, :cond_27

    goto/16 :goto_14

    :cond_27
    iget-boolean v4, v0, LE1/d;->F:Z

    if-eqz v4, :cond_28

    iput-boolean v8, v0, LE1/d;->F:Z

    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    move-result-wide v4

    iput-wide v4, v3, LE1/a;->e:J

    iput-wide v6, v3, LE1/a;->g:J

    iput-wide v4, v3, LE1/a;->f:J

    const/high16 v4, 0x3f000000    # 0.5f

    iput v4, v3, LE1/a;->h:F

    :cond_28
    iget-wide v4, v3, LE1/a;->g:J

    cmp-long v4, v4, v17

    if-lez v4, :cond_29

    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    move-result-wide v4

    iget-wide v6, v3, LE1/a;->g:J

    iget v9, v3, LE1/a;->i:I

    int-to-long v9, v9

    add-long/2addr v6, v9

    cmp-long v4, v4, v6

    if-lez v4, :cond_29

    goto :goto_13

    :cond_29
    invoke-virtual {v0}, LE1/d;->g()Z

    move-result v4

    if-nez v4, :cond_2a

    :goto_13
    iput-boolean v8, v0, LE1/d;->H:Z

    goto :goto_14

    :cond_2a
    iget-boolean v4, v0, LE1/d;->G:Z

    if-eqz v4, :cond_2b

    iput-boolean v8, v0, LE1/d;->G:Z

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v9

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x0

    move-wide v11, v9

    invoke-static/range {v9 .. v16}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v4

    invoke-virtual {v2, v4}, Ll/N;->onTouchEvent(Landroid/view/MotionEvent;)Z

    invoke-virtual {v4}, Landroid/view/MotionEvent;->recycle()V

    :cond_2b
    iget-wide v4, v3, LE1/a;->f:J

    cmp-long v4, v4, v17

    if-eqz v4, :cond_2c

    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    move-result-wide v4

    invoke-virtual {v3, v4, v5}, LE1/a;->a(J)F

    move-result v6

    const/high16 v7, -0x3f800000    # -4.0f

    mul-float/2addr v7, v6

    mul-float/2addr v7, v6

    const/high16 v8, 0x40800000    # 4.0f

    mul-float/2addr v6, v8

    add-float/2addr v6, v7

    iget-wide v7, v3, LE1/a;->f:J

    sub-long v7, v4, v7

    iput-wide v4, v3, LE1/a;->f:J

    long-to-float v4, v7

    mul-float/2addr v4, v6

    iget v3, v3, LE1/a;->d:F

    mul-float/2addr v4, v3

    float-to-int v3, v4

    iget-object v0, v0, LE1/d;->J:Ll/N;

    invoke-virtual {v0, v3}, Landroid/widget/AbsListView;->scrollListBy(I)V

    sget-object v0, LA1/J;->a:Ljava/lang/reflect/Field;

    invoke-virtual {v2, v1}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    :goto_14
    return-void

    :cond_2c
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v2, "Cannot compute scroll delta before calling start()"

    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_1b
    iget-object v0, v1, LA4/d;->u:Ljava/lang/Object;

    check-cast v0, LA4/f;

    iget-object v0, v0, LA4/f;->u:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-static {v0}, LA4/f;->x(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v3, "app_set_id_last_used_time"

    invoke-interface {v2, v3, v6, v7}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v4

    cmp-long v2, v4, v6

    if-eqz v2, :cond_2d

    const-wide v9, 0x7d8702800L

    add-long/2addr v4, v9

    goto :goto_15

    :cond_2d
    move-wide v4, v6

    :goto_15
    cmp-long v2, v4, v6

    if-eqz v2, :cond_31

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    cmp-long v2, v6, v4

    if-lez v2, :cond_31

    const-string v2, "AppSet"

    invoke-static {v0}, LA4/f;->x(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v5, "app_set_id"

    invoke-interface {v4, v5}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v4

    if-nez v4, :cond_2f

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "Failed to clear app set ID generated for App "

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v6

    if-eqz v6, :cond_2e

    invoke-virtual {v5, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_16

    :cond_2e
    new-instance v4, Ljava/lang/String;

    invoke-direct {v4, v5}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    :goto_16
    invoke-static {v2, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2f
    const-string v4, "app_set_id_storage"

    invoke-virtual {v0, v4, v8}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v3

    if-nez v3, :cond_31

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "Failed to clear app set ID last used time for App "

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    if-eqz v4, :cond_30

    invoke-virtual {v3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_17

    :cond_30
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v3}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    :goto_17
    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_31
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
