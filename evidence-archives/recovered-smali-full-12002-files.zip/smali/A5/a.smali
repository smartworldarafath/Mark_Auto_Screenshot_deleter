.class public interface abstract LA5/a;
.super Ljava/lang/Object;
.source "SourceFile"
