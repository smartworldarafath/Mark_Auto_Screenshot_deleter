.class public final La6/a;
.super LW5/b;
.source "SourceFile"

# interfaces
.implements LX5/b;


# virtual methods
.method public final f()[Lm4/d;
    .locals 1

    sget-object v0, LT5/i;->a:[Lm4/d;

    return-object v0
.end method
