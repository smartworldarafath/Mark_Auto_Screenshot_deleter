.class public final La0/T;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/Z0;


# instance fields
.field public final a:Ld7/p;


# direct methods
.method public constructor <init>(Lr7/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Ld7/a;->d(Lr7/a;)Ld7/p;

    move-result-object p1

    iput-object p1, p0, La0/T;->a:Ld7/p;

    return-void
.end method


# virtual methods
.method public final a(La0/n0;)Ljava/lang/Object;
    .locals 0

    iget-object p1, p0, La0/T;->a:Ld7/p;

    invoke-virtual {p1}, Ld7/p;->getValue()Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
