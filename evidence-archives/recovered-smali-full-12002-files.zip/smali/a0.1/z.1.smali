.class public interface abstract La0/z;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final c:La0/y;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget-object v0, La0/y;->a:La0/y;

    sput-object v0, La0/z;->c:La0/y;

    return-void
.end method
