.class public final La0/m;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:La0/U;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, La0/U;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, La0/U;-><init>(I)V

    sput-object v0, La0/m;->a:La0/U;

    return-void
.end method
