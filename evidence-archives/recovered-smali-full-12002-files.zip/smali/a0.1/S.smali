.class public final La0/S;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/A0;
.implements LD7/t;


# instance fields
.field public final t:Lh7/h;

.field public final u:Lr7/e;

.field public final v:LI7/d;

.field public w:LD7/B;


# direct methods
.method public constructor <init>(Lh7/h;Lr7/e;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/S;->t:Lh7/h;

    iput-object p2, p0, La0/S;->u:Lr7/e;

    sget-object p2, Ll0/b;->u:LS6/b;

    invoke-interface {p1, p2}, Lh7/h;->W(Lh7/g;)Lh7/f;

    move-result-object p2

    if-eqz p2, :cond_0

    move-object p2, p0

    goto :goto_0

    :cond_0
    sget-object p2, Lh7/i;->t:Lh7/i;

    :goto_0
    invoke-interface {p1, p2}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object p1

    invoke-static {p1}, LD7/y;->b(Lh7/h;)LI7/d;

    move-result-object p1

    iput-object p1, p0, La0/S;->v:LI7/d;

    return-void
.end method


# virtual methods
.method public final J(Lh7/g;)Lh7/h;
    .locals 0

    invoke-static {p0, p1}, LF4/r7;->b(Lh7/f;Lh7/g;)Lh7/h;

    move-result-object p1

    return-object p1
.end method

.method public final S(Lh7/h;)Lh7/h;
    .locals 0

    invoke-static {p0, p1}, LF4/r7;->c(Lh7/f;Lh7/h;)Lh7/h;

    move-result-object p1

    return-object p1
.end method

.method public final W(Lh7/g;)Lh7/f;
    .locals 0

    invoke-static {p0, p1}, LF4/r7;->a(Lh7/f;Lh7/g;)Lh7/f;

    move-result-object p1

    return-object p1
.end method

.method public final X(Ljava/lang/Object;Lr7/e;)Ljava/lang/Object;
    .locals 0

    invoke-interface {p2, p1, p0}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final a()V
    .locals 3

    iget-object v0, p0, La0/S;->w:LD7/B;

    if-eqz v0, :cond_0

    new-instance v1, La0/J;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, La0/J;-><init>(I)V

    invoke-virtual {v0, v1}, LD7/k0;->s(Ljava/util/concurrent/CancellationException;)V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, La0/S;->w:LD7/B;

    return-void
.end method

.method public final b()V
    .locals 3

    iget-object v0, p0, La0/S;->w:LD7/B;

    if-eqz v0, :cond_0

    new-instance v1, La0/J;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, La0/J;-><init>(I)V

    invoke-virtual {v0, v1}, LD7/k0;->s(Ljava/util/concurrent/CancellationException;)V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, La0/S;->w:LD7/B;

    return-void
.end method

.method public final d()V
    .locals 4

    iget-object v0, p0, La0/S;->w:LD7/B;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    new-instance v2, Ljava/util/concurrent/CancellationException;

    const-string v3, "Old job was still running!"

    invoke-direct {v2, v3}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    invoke-virtual {v0, v2}, LD7/k0;->f(Ljava/util/concurrent/CancellationException;)V

    :cond_0
    iget-object v0, p0, La0/S;->u:Lr7/e;

    const/4 v2, 0x3

    iget-object v3, p0, La0/S;->v:LI7/d;

    invoke-static {v3, v1, v1, v0, v2}, LD7/y;->x(LD7/v;Lh7/h;LD7/w;Lr7/e;I)LD7/B;

    move-result-object v0

    iput-object v0, p0, La0/S;->w:LD7/B;

    return-void
.end method

.method public final getKey()Lh7/g;
    .locals 1

    sget-object v0, LD7/s;->t:LD7/s;

    return-object v0
.end method

.method public final l(Lh7/h;Ljava/lang/Throwable;)V
    .locals 3

    sget-object v0, Ll0/b;->u:LS6/b;

    invoke-interface {p1, v0}, Lh7/h;->W(Lh7/g;)Lh7/f;

    move-result-object v0

    check-cast v0, Ll0/b;

    if-eqz v0, :cond_0

    new-instance v1, LD/j;

    const/16 v2, 0x16

    invoke-direct {v1, v2, v0, p0}, LD/j;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {p2, v1}, LH4/Y;->a(Ljava/lang/Throwable;Lr7/a;)Z

    :cond_0
    iget-object v0, p0, La0/S;->t:Lh7/h;

    sget-object v1, LD7/s;->t:LD7/s;

    invoke-interface {v0, v1}, Lh7/h;->W(Lh7/g;)Lh7/f;

    move-result-object v0

    check-cast v0, LD7/t;

    if-eqz v0, :cond_1

    invoke-interface {v0, p1, p2}, LD7/t;->l(Lh7/h;Ljava/lang/Throwable;)V

    return-void

    :cond_1
    throw p2
.end method
