.class public final La0/h0;
.super Lk0/u;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable;
.implements Lk0/m;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "La0/h0;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final u:La0/N0;

.field public v:La0/M0;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La0/g0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La0/h0;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;La0/N0;)V
    .locals 3

    invoke-direct {p0}, Lk0/u;-><init>()V

    iput-object p2, p0, La0/h0;->u:La0/N0;

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object p2

    new-instance v0, La0/M0;

    invoke-virtual {p2}, Lk0/f;->g()J

    move-result-wide v1

    invoke-direct {v0, v1, v2, p1}, La0/M0;-><init>(JLjava/lang/Object;)V

    instance-of p2, p2, Lk0/a;

    if-nez p2, :cond_0

    new-instance p2, La0/M0;

    const/4 v1, 0x1

    int-to-long v1, v1

    invoke-direct {p2, v1, v2, p1}, La0/M0;-><init>(JLjava/lang/Object;)V

    iput-object p2, v0, Lk0/v;->b:Lk0/v;

    :cond_0
    iput-object v0, p0, La0/h0;->v:La0/M0;

    return-void
.end method


# virtual methods
.method public final b()Lk0/v;
    .locals 1

    iget-object v0, p0, La0/h0;->v:La0/M0;

    return-object v0
.end method

.method public final c(Lk0/v;Lk0/v;Lk0/v;)Lk0/v;
    .locals 1

    check-cast p1, La0/M0;

    move-object p1, p2

    check-cast p1, La0/M0;

    check-cast p3, La0/M0;

    iget-object p1, p1, La0/M0;->c:Ljava/lang/Object;

    iget-object p3, p3, La0/M0;->c:Ljava/lang/Object;

    iget-object v0, p0, La0/h0;->u:La0/N0;

    invoke-interface {v0, p1, p3}, La0/N0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    return-object p2

    :cond_0
    const/4 p1, 0x0

    return-object p1
.end method

.method public final d()La0/N0;
    .locals 1

    iget-object v0, p0, La0/h0;->u:La0/N0;

    return-object v0
.end method

.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final e(Lk0/v;)V
    .locals 1

    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableStateImpl.StateStateRecord<T of androidx.compose.runtime.SnapshotMutableStateImpl>"

    invoke-static {p1, v0}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, La0/M0;

    iput-object p1, p0, La0/h0;->v:La0/M0;

    return-void
.end method

.method public final getValue()Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, La0/h0;->v:La0/M0;

    invoke-static {v0, p0}, Lk0/l;->t(Lk0/v;Lk0/t;)Lk0/v;

    move-result-object v0

    check-cast v0, La0/M0;

    iget-object v0, v0, La0/M0;->c:Ljava/lang/Object;

    return-object v0
.end method

.method public final setValue(Ljava/lang/Object;)V
    .locals 4

    iget-object v0, p0, La0/h0;->v:La0/M0;

    invoke-static {v0}, Lk0/l;->i(Lk0/v;)Lk0/v;

    move-result-object v0

    check-cast v0, La0/M0;

    iget-object v1, p0, La0/h0;->u:La0/N0;

    iget-object v2, v0, La0/M0;->c:Ljava/lang/Object;

    invoke-interface {v1, v2, p1}, La0/N0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, La0/h0;->v:La0/M0;

    sget-object v2, Lk0/l;->c:Ljava/lang/Object;

    monitor-enter v2

    :try_start_0
    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v3

    invoke-static {v1, p0, v3, v0}, Lk0/l;->o(Lk0/v;Lk0/u;Lk0/f;Lk0/v;)Lk0/v;

    move-result-object v0

    check-cast v0, La0/M0;

    iput-object p1, v0, La0/M0;->c:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v2

    invoke-static {v3, p0}, Lk0/l;->n(Lk0/f;Lk0/t;)V

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v2

    throw p1

    :cond_0
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, La0/h0;->v:La0/M0;

    invoke-static {v0}, Lk0/l;->i(Lk0/v;)Lk0/v;

    move-result-object v0

    check-cast v0, La0/M0;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "MutableState(value="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, v0, La0/M0;->c:Ljava/lang/Object;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ")@"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    invoke-virtual {p0}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeValue(Ljava/lang/Object;)V

    sget-object p2, La0/U;->v:La0/U;

    iget-object v0, p0, La0/h0;->u:La0/N0;

    invoke-static {v0, p2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    const/4 p2, 0x0

    goto :goto_0

    :cond_0
    sget-object p2, La0/U;->y:La0/U;

    invoke-static {v0, p2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_1

    const/4 p2, 0x1

    goto :goto_0

    :cond_1
    sget-object p2, La0/U;->w:La0/U;

    invoke-static {v0, p2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_2

    const/4 p2, 0x2

    :goto_0
    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    return-void

    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Only known types of MutableState\'s SnapshotMutationPolicy are supported"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
