.class public final La0/U;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh7/g;
.implements La0/N0;


# static fields
.field public static final synthetic u:La0/U;

.field public static final v:La0/U;

.field public static final w:La0/U;

.field public static final x:La0/U;

.field public static final y:La0/U;


# instance fields
.field public final synthetic t:I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    new-instance v0, La0/U;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La0/U;-><init>(I)V

    sput-object v0, La0/U;->u:La0/U;

    new-instance v0, La0/U;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, La0/U;-><init>(I)V

    sput-object v0, La0/U;->v:La0/U;

    new-instance v0, La0/U;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, La0/U;-><init>(I)V

    sput-object v0, La0/U;->w:La0/U;

    new-instance v0, La0/U;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, La0/U;-><init>(I)V

    sput-object v0, La0/U;->x:La0/U;

    new-instance v0, La0/U;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, La0/U;-><init>(I)V

    sput-object v0, La0/U;->y:La0/U;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, La0/U;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final b(La0/U;)V
    .locals 9

    sget-object v0, La0/y0;->y:LG7/g0;

    :cond_0
    sget-object v0, La0/y0;->y:LG7/g0;

    invoke-virtual {v0}, LG7/g0;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld0/b;

    move-object v2, v1

    check-cast v2, Lg0/b;

    iget-object v3, v2, Lg0/b;->v:Lf0/c;

    invoke-virtual {v3, p0}, Lf0/c;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lg0/a;

    if-nez v4, :cond_1

    goto :goto_3

    :cond_1
    iget-object v5, v4, Lg0/a;->a:Ljava/lang/Object;

    iget-object v4, v4, Lg0/a;->b:Ljava/lang/Object;

    iget-object v6, v3, Lf0/c;->t:Lf0/l;

    const/4 v7, 0x0

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v8

    goto :goto_0

    :cond_2
    move v8, v7

    :goto_0
    invoke-virtual {v6, v8, v7, p0}, Lf0/l;->v(IILjava/lang/Object;)Lf0/l;

    move-result-object v7

    if-ne v6, v7, :cond_3

    goto :goto_1

    :cond_3
    if-nez v7, :cond_4

    sget-object v3, Lf0/c;->v:Lf0/c;

    goto :goto_1

    :cond_4
    new-instance v6, Lf0/c;

    iget v3, v3, Lf0/c;->u:I

    add-int/lit8 v3, v3, -0x1

    invoke-direct {v6, v7, v3}, Lf0/c;-><init>(Lf0/l;I)V

    move-object v3, v6

    :goto_1
    sget-object v6, Lh0/b;->a:Lh0/b;

    if-eq v5, v6, :cond_5

    invoke-interface {v3, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    invoke-static {v7}, Ls7/j;->b(Ljava/lang/Object;)V

    check-cast v7, Lg0/a;

    new-instance v8, Lg0/a;

    iget-object v7, v7, Lg0/a;->a:Ljava/lang/Object;

    invoke-direct {v8, v7, v4}, Lg0/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v3, v5, v8}, Lf0/c;->a(Ljava/lang/Object;Lg0/a;)Lf0/c;

    move-result-object v3

    :cond_5
    if-eq v4, v6, :cond_6

    invoke-interface {v3, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    invoke-static {v7}, Ls7/j;->b(Ljava/lang/Object;)V

    check-cast v7, Lg0/a;

    new-instance v8, Lg0/a;

    iget-object v7, v7, Lg0/a;->b:Ljava/lang/Object;

    invoke-direct {v8, v5, v7}, Lg0/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v3, v4, v8}, Lf0/c;->a(Ljava/lang/Object;Lg0/a;)Lf0/c;

    move-result-object v3

    :cond_6
    if-eq v5, v6, :cond_7

    iget-object v7, v2, Lg0/b;->t:Ljava/lang/Object;

    goto :goto_2

    :cond_7
    move-object v7, v4

    :goto_2
    if-eq v4, v6, :cond_8

    iget-object v5, v2, Lg0/b;->u:Ljava/lang/Object;

    :cond_8
    new-instance v2, Lg0/b;

    invoke-direct {v2, v7, v5, v3}, Lg0/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lf0/c;)V

    :goto_3
    if-eq v1, v2, :cond_9

    invoke-virtual {v0, v1, v2}, LG7/g0;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    :cond_9
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 1

    iget v0, p0, La0/U;->t:I

    packed-switch v0, :pswitch_data_0

    invoke-static {p1, p2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    return p1

    :pswitch_0
    if-ne p1, p2, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1

    :pswitch_1
    const/4 p1, 0x0

    return p1

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    iget v0, p0, La0/U;->t:I

    packed-switch v0, :pswitch_data_0

    :pswitch_0
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_1
    const-string v0, "Empty"

    return-object v0

    :pswitch_2
    const-string v0, "StructuralEqualityPolicy"

    return-object v0

    :pswitch_3
    const-string v0, "ReferentialEqualityPolicy"

    return-object v0

    :pswitch_4
    const-string v0, "NeverEqualPolicy"

    return-object v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_4
        :pswitch_3
        :pswitch_0
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method
