.class public final La0/j;
.super Lj7/h;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public final synthetic A:La0/k;

.field public v:I

.field public w:I

.field public x:I

.field public y:I

.field public synthetic z:Ljava/lang/Object;


# direct methods
.method public constructor <init>(La0/k;Lh7/c;)V
    .locals 0

    iput-object p1, p0, La0/j;->A:La0/k;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lj7/h;-><init>(ILh7/c;)V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Lz7/g;

    check-cast p2, Lh7/c;

    invoke-virtual {p0, p2, p1}, La0/j;->n(Lh7/c;Ljava/lang/Object;)Lh7/c;

    move-result-object p1

    check-cast p1, La0/j;

    sget-object p2, Ld7/z;->a:Ld7/z;

    invoke-virtual {p1, p2}, La0/j;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final n(Lh7/c;Ljava/lang/Object;)Lh7/c;
    .locals 2

    new-instance v0, La0/j;

    iget-object v1, p0, La0/j;->A:La0/k;

    invoke-direct {v0, v1, p1}, La0/j;-><init>(La0/k;Lh7/c;)V

    iput-object p2, v0, La0/j;->z:Ljava/lang/Object;

    return-object v0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    iget-object v0, p0, La0/j;->A:La0/k;

    iget-object v1, v0, La0/k;->t:Lp/D;

    iget-object v2, v0, La0/k;->v:Lp/v;

    iget v3, p0, La0/j;->y:I

    const/4 v4, 0x1

    if-eqz v3, :cond_1

    if-ne v3, v4, :cond_0

    iget v3, p0, La0/j;->x:I

    iget v5, p0, La0/j;->w:I

    iget v6, p0, La0/j;->v:I

    iget-object v7, p0, La0/j;->z:Ljava/lang/Object;

    check-cast v7, Lz7/g;

    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    iget-object p1, p0, La0/j;->z:Ljava/lang/Object;

    move-object v7, p1

    check-cast v7, Lz7/g;

    const/4 v3, 0x0

    move v5, v3

    move v6, v5

    :goto_0
    iget p1, v0, La0/k;->w:I

    iget v8, v2, Lp/v;->b:I

    invoke-static {p1, v8}, Ljava/lang/Math;->min(II)I

    move-result p1

    if-ge v6, p1, :cond_2

    add-int/lit8 p1, v6, 0x1

    invoke-virtual {v2, v6}, Lp/v;->c(I)I

    move-result v8

    const/16 v9, 0x20

    packed-switch v8, :pswitch_data_0

    const-string v0, "unknown op: "

    invoke-static {v8, v0}, Lcom/google/android/gms/internal/measurement/q1;->j(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :pswitch_0
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "reuse "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, v0, La0/k;->u:Lp/D;

    add-int/lit8 v2, v3, 0x1

    invoke-virtual {v0, v3}, Lp/D;->e(I)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move v3, v2

    goto/16 :goto_2

    :pswitch_1
    add-int/lit8 v0, v5, 0x1

    invoke-virtual {v1, v5}, Lp/D;->e(I)Ljava/lang/Object;

    move-result-object v2

    const-string v8, "null cannot be cast to non-null type @[ExtensionFunctionType] kotlin.Function2<kotlin.Any?, kotlin.Any?, kotlin.Unit>"

    invoke-static {v2, v8}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x2

    invoke-static {v8, v2}, Ls7/x;->c(ILjava/lang/Object;)V

    check-cast v2, Lr7/e;

    add-int/lit8 v5, v5, 0x2

    invoke-virtual {v1, v0}, Lp/D;->e(I)Ljava/lang/Object;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v8, "apply "

    invoke-direct {v1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :pswitch_2
    add-int/lit8 v0, v6, 0x2

    invoke-virtual {v2, p1}, Lp/v;->c(I)I

    move-result p1

    add-int/lit8 v2, v5, 0x1

    invoke-virtual {v1, v5}, Lp/D;->e(I)Ljava/lang/Object;

    move-result-object v1

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v8, "insertTopDown "

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_1
    move v5, v0

    move-object v0, p1

    move p1, v5

    move v5, v2

    goto/16 :goto_2

    :pswitch_3
    add-int/lit8 v0, v6, 0x2

    invoke-virtual {v2, p1}, Lp/v;->c(I)I

    move-result p1

    add-int/lit8 v2, v5, 0x1

    invoke-virtual {v1, v5}, Lp/D;->e(I)Ljava/lang/Object;

    move-result-object v1

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v8, "insertBottomUp "

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_1

    :pswitch_4
    const-string v0, "clear"

    goto :goto_2

    :pswitch_5
    add-int/lit8 v0, v6, 0x2

    invoke-virtual {v2, p1}, Lp/v;->c(I)I

    move-result p1

    add-int/lit8 v1, v6, 0x3

    invoke-virtual {v2, v0}, Lp/v;->c(I)I

    move-result v0

    add-int/lit8 v8, v6, 0x4

    invoke-virtual {v2, v1}, Lp/v;->c(I)I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v10, "move "

    invoke-direct {v2, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move p1, v8

    goto :goto_2

    :pswitch_6
    add-int/lit8 v0, v6, 0x2

    invoke-virtual {v2, p1}, Lp/v;->c(I)I

    move-result p1

    add-int/lit8 v1, v6, 0x3

    invoke-virtual {v2, v0}, Lp/v;->c(I)I

    move-result v0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v8, "remove "

    invoke-direct {v2, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move p1, v1

    goto :goto_2

    :pswitch_7
    add-int/lit8 v0, v5, 0x1

    invoke-virtual {v1, v5}, Lp/D;->e(I)Ljava/lang/Object;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v5, "down "

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    move v5, v0

    move-object v0, v1

    goto :goto_2

    :pswitch_8
    const-string v0, "up"

    :goto_2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v7, p0, La0/j;->z:Ljava/lang/Object;

    iput p1, p0, La0/j;->v:I

    iput v5, p0, La0/j;->w:I

    iput v3, p0, La0/j;->x:I

    iput v4, p0, La0/j;->y:I

    invoke-virtual {v7, v0, p0}, Lz7/g;->c(Ljava/lang/Object;Lj7/h;)V

    sget-object p1, Li7/a;->t:Li7/a;

    return-object p1

    :cond_2
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
