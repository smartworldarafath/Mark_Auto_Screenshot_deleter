.class public final synthetic La0/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/a;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:La0/r;


# direct methods
.method public synthetic constructor <init>(ILa0/r;)V
    .locals 0

    .line 1
    iput p1, p0, La0/n;->t:I

    iput-object p2, p0, La0/n;->u:La0/r;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(La0/r;La0/Y;)V
    .locals 0

    .line 2
    const/4 p2, 0x0

    iput p2, p0, La0/n;->t:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/n;->u:La0/r;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 1

    iget v0, p0, La0/n;->t:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, La0/n;->u:La0/r;

    invoke-virtual {v0}, La0/r;->m()Ljava/util/List;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, La0/n;->u:La0/r;

    invoke-virtual {v0}, La0/r;->m()Ljava/util/List;

    move-result-object v0

    return-object v0

    :pswitch_1
    const/4 v0, 0x0

    throw v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
