.class public final La0/F;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/A0;


# instance fields
.field public final t:Lr7/c;

.field public u:La0/G;


# direct methods
.method public constructor <init>(Lr7/c;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/F;->t:Lr7/c;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 0

    return-void
.end method

.method public final b()V
    .locals 1

    iget-object v0, p0, La0/F;->u:La0/G;

    if-eqz v0, :cond_0

    invoke-interface {v0}, La0/G;->a()V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, La0/F;->u:La0/G;

    return-void
.end method

.method public final d()V
    .locals 2

    iget-object v0, p0, La0/F;->t:Lr7/c;

    sget-object v1, La0/b;->b:La0/H;

    invoke-interface {v0, v1}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La0/G;

    iput-object v0, p0, La0/F;->u:La0/G;

    return-void
.end method
