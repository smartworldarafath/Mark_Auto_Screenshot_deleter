.class public final La0/y0;
.super La0/u;
.source "SourceFile"


# static fields
.field public static final y:LG7/g0;

.field public static final z:Ljava/util/concurrent/atomic/AtomicReference;


# instance fields
.field public final a:La0/e;

.field public final b:Ljava/lang/Object;

.field public c:LD7/c0;

.field public d:Ljava/lang/Throwable;

.field public final e:Ljava/util/ArrayList;

.field public f:Ljava/lang/Object;

.field public g:Lp/I;

.field public final h:Lc0/e;

.field public final i:Ljava/util/ArrayList;

.field public final j:Ljava/util/ArrayList;

.field public final k:Lp/H;

.field public final l:LP2/c;

.field public final m:Lp/H;

.field public final n:Lp/H;

.field public o:Ljava/util/ArrayList;

.field public p:Ljava/util/LinkedHashSet;

.field public q:LD7/h;

.field public r:LU2/h;

.field public s:Z

.field public final t:LG7/g0;

.field public final u:Lcom/google/android/gms/internal/play_billing/l;

.field public final v:LD7/e0;

.field public final w:Lh7/h;

.field public final x:La0/U;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    sget-object v0, Lg0/b;->w:Lg0/b;

    invoke-static {v0}, LG7/W;->b(Ljava/lang/Object;)LG7/g0;

    move-result-object v0

    sput-object v0, La0/y0;->y:LG7/g0;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, La0/y0;->z:Ljava/util/concurrent/atomic/AtomicReference;

    return-void
.end method

.method public constructor <init>(Lh7/h;)V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, La0/e;

    new-instance v1, LE/F;

    const/16 v2, 0x18

    invoke-direct {v1, v2, p0}, LE/F;-><init>(ILjava/lang/Object;)V

    invoke-direct {v0, v1}, La0/e;-><init>(LE/F;)V

    iput-object v0, p0, La0/y0;->a:La0/e;

    new-instance v1, Ljava/lang/Object;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, La0/y0;->b:Ljava/lang/Object;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La0/y0;->e:Ljava/util/ArrayList;

    new-instance v1, Lp/I;

    invoke-direct {v1}, Lp/I;-><init>()V

    iput-object v1, p0, La0/y0;->g:Lp/I;

    new-instance v1, Lc0/e;

    const/16 v2, 0x10

    new-array v2, v2, [La0/x;

    invoke-direct {v1, v2}, Lc0/e;-><init>([Ljava/lang/Object;)V

    iput-object v1, p0, La0/y0;->h:Lc0/e;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La0/y0;->i:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La0/y0;->j:Ljava/util/ArrayList;

    new-instance v1, Lp/H;

    invoke-direct {v1}, Lp/H;-><init>()V

    iput-object v1, p0, La0/y0;->k:Lp/H;

    new-instance v1, LP2/c;

    const/4 v2, 0x7

    invoke-direct {v1, v2}, LP2/c;-><init>(I)V

    iput-object v1, p0, La0/y0;->l:LP2/c;

    new-instance v1, Lp/H;

    invoke-direct {v1}, Lp/H;-><init>()V

    iput-object v1, p0, La0/y0;->m:Lp/H;

    new-instance v1, Lp/H;

    invoke-direct {v1}, Lp/H;-><init>()V

    iput-object v1, p0, La0/y0;->n:Lp/H;

    sget-object v1, La0/s0;->v:La0/s0;

    invoke-static {v1}, LG7/W;->b(Ljava/lang/Object;)LG7/g0;

    move-result-object v1

    iput-object v1, p0, La0/y0;->t:LG7/g0;

    new-instance v1, Lcom/google/android/gms/internal/play_billing/l;

    const/4 v2, 0x6

    invoke-direct {v1, v2}, Lcom/google/android/gms/internal/play_billing/l;-><init>(I)V

    iput-object v1, p0, La0/y0;->u:Lcom/google/android/gms/internal/play_billing/l;

    sget-object v1, LD7/s;->u:LD7/s;

    invoke-interface {p1, v1}, Lh7/h;->W(Lh7/g;)Lh7/f;

    move-result-object v1

    check-cast v1, LD7/c0;

    new-instance v2, LD7/e0;

    invoke-direct {v2, v1}, LD7/e0;-><init>(LD7/c0;)V

    new-instance v1, LA7/j;

    const/16 v3, 0x1a

    invoke-direct {v1, v3, p0}, LA7/j;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v2, v1}, LD7/k0;->a0(Lr7/c;)LD7/K;

    iput-object v2, p0, La0/y0;->v:LD7/e0;

    invoke-interface {p1, v0}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object p1

    invoke-interface {p1, v2}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object p1

    iput-object p1, p0, La0/y0;->w:Lh7/h;

    new-instance p1, La0/U;

    const/16 v0, 0x8

    invoke-direct {p1, v0}, La0/U;-><init>(I)V

    iput-object p1, p0, La0/y0;->x:La0/U;

    return-void
.end method

.method public static final B(Ljava/util/ArrayList;La0/y0;La0/x;)V
    .locals 0

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    iget-object p0, p1, La0/y0;->b:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    iget-object p1, p1, La0/y0;->j:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez p2, :cond_0

    monitor-exit p0

    return-void

    :cond_0
    :try_start_1
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La0/Y;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p1, 0x0

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public static u(Lk0/b;)V
    .locals 2

    :try_start_0
    invoke-virtual {p0}, Lk0/b;->w()Lk0/p;

    move-result-object v0

    instance-of v0, v0, Lk0/g;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lk0/b;->c()V

    return-void

    :cond_0
    :try_start_1
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Unsupported concurrent change during composition. A state object was modified by composition as well as being modified outside composition."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception v0

    invoke-virtual {p0}, Lk0/b;->c()V

    throw v0
.end method


# virtual methods
.method public final A(La0/x;)V
    .locals 2

    iget-object p1, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter p1

    :try_start_0
    iget-object v0, p0, La0/y0;->j:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-gtz v1, :cond_0

    monitor-exit p1

    return-void

    :cond_0
    const/4 v1, 0x0

    :try_start_1
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La0/Y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception v0

    monitor-exit p1

    throw v0
.end method

.method public final C(Ljava/util/List;Lp/I;)Ljava/util/List;
    .locals 17

    move-object/from16 v1, p0

    new-instance v0, Ljava/util/HashMap;

    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    move-result v2

    invoke-direct {v0, v2}, Ljava/util/HashMap;-><init>(I)V

    invoke-interface/range {p1 .. p1}, Ljava/util/Collection;->size()I

    move-result v2

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v2, :cond_1

    move-object/from16 v5, p1

    invoke-interface {v5, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    move-object v7, v6

    check-cast v7, La0/Y;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v7, 0x0

    invoke-virtual {v0, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    if-nez v8, :cond_0

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    check-cast v8, Ljava/util/ArrayList;

    invoke-virtual {v8, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_11

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La0/x;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/List;

    iget-object v6, v5, La0/x;->O:La0/r;

    iget-boolean v6, v6, La0/r;->F:Z

    if-eqz v6, :cond_2

    const-string v6, "Check failed"

    invoke-static {v6}, La0/s;->c(Ljava/lang/String;)V

    :cond_2
    new-instance v6, LA7/j;

    const/16 v7, 0x19

    invoke-direct {v6, v7, v5}, LA7/j;-><init>(ILjava/lang/Object;)V

    new-instance v7, LA/Q;

    const/16 v8, 0x15

    move-object/from16 v9, p2

    invoke-direct {v7, v8, v5, v9}, LA/Q;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v8

    instance-of v10, v8, Lk0/b;

    const/4 v11, 0x0

    if-eqz v10, :cond_3

    check-cast v8, Lk0/b;

    goto :goto_2

    :cond_3
    move-object v8, v11

    :goto_2
    if-eqz v8, :cond_10

    invoke-virtual {v8, v6, v7}, Lk0/b;->C(Lr7/c;Lr7/c;)Lk0/b;

    move-result-object v6

    if-eqz v6, :cond_10

    :try_start_0
    invoke-virtual {v6}, Lk0/f;->j()Lk0/f;

    move-result-object v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    iget-object v8, v1, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v8
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    new-instance v10, Ljava/util/ArrayList;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v12

    invoke-direct {v10, v12}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v4}, Ljava/util/Collection;->size()I

    move-result v12

    const/4 v13, 0x0

    :goto_3
    if-ge v13, v12, :cond_4

    invoke-interface {v4, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, La0/Y;

    iget-object v15, v1, La0/y0;->k:Lp/H;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v15}, Lc0/a;->a(Lp/H;)Ljava/lang/Object;

    move-result-object v15

    move-object/from16 v16, v15

    check-cast v16, La0/Y;

    new-instance v3, Ld7/k;

    invoke-direct {v3, v14, v15}, Ld7/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v10, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v13, v13, 0x1

    goto :goto_3

    :catchall_0
    move-exception v0

    goto/16 :goto_d

    :cond_4
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x0

    :goto_4
    if-ge v4, v3, :cond_8

    invoke-virtual {v10, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ld7/k;

    iget-object v13, v12, Ld7/k;->u:Ljava/lang/Object;

    if-nez v13, :cond_7

    iget-object v13, v1, La0/y0;->l:LP2/c;

    iget-object v12, v12, Ld7/k;->t:Ljava/lang/Object;

    check-cast v12, La0/Y;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v12, v13, LP2/c;->u:Ljava/lang/Object;

    check-cast v12, Lp/H;

    invoke-virtual {v12, v11}, Lp/H;->b(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_7

    new-instance v3, Ljava/util/ArrayList;

    const/16 v4, 0xa

    invoke-static {v10, v4}, Le7/n;->l(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v11, 0x0

    :goto_5
    if-ge v11, v4, :cond_6

    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    add-int/lit8 v11, v11, 0x1

    check-cast v12, Ld7/k;

    iget-object v13, v12, Ld7/k;->u:Ljava/lang/Object;

    if-nez v13, :cond_5

    iget-object v13, v1, La0/y0;->l:LP2/c;

    iget-object v14, v12, Ld7/k;->t:Ljava/lang/Object;

    check-cast v14, La0/Y;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v14, v13, LP2/c;->u:Ljava/lang/Object;

    check-cast v14, Lp/H;

    invoke-static {v14}, Lc0/a;->a(Lp/H;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, La0/a0;

    invoke-virtual {v14}, Lp/H;->i()Z

    move-result v14

    if-eqz v14, :cond_5

    iget-object v13, v13, LP2/c;->v:Ljava/lang/Object;

    check-cast v13, Lp/H;

    invoke-virtual {v13}, Lp/H;->a()V

    :cond_5
    invoke-virtual {v3, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_5

    :cond_6
    move-object v10, v3

    goto :goto_6

    :cond_7
    add-int/lit8 v4, v4, 0x1

    goto :goto_4

    :cond_8
    :goto_6
    :try_start_3
    monitor-exit v8

    invoke-interface {v10}, Ljava/util/Collection;->size()I

    move-result v3

    const/4 v4, 0x0

    :goto_7
    if-ge v4, v3, :cond_f

    invoke-interface {v10, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld7/k;

    iget-object v8, v8, Ld7/k;->u:Ljava/lang/Object;

    if-nez v8, :cond_9

    add-int/lit8 v4, v4, 0x1

    goto :goto_7

    :cond_9
    invoke-interface {v10}, Ljava/util/Collection;->size()I

    move-result v3

    const/4 v4, 0x0

    :goto_8
    if-ge v4, v3, :cond_f

    invoke-interface {v10, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ld7/k;

    iget-object v8, v8, Ld7/k;->u:Ljava/lang/Object;

    if-eqz v8, :cond_a

    add-int/lit8 v4, v4, 0x1

    goto :goto_8

    :cond_a
    new-instance v3, Ljava/util/ArrayList;

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v10}, Ljava/util/Collection;->size()I

    move-result v4

    const/4 v8, 0x0

    :goto_9
    if-ge v8, v4, :cond_c

    invoke-interface {v10, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ld7/k;

    iget-object v12, v11, Ld7/k;->u:Ljava/lang/Object;

    if-nez v12, :cond_b

    iget-object v11, v11, Ld7/k;->t:Ljava/lang/Object;

    check-cast v11, La0/Y;

    goto :goto_a

    :catchall_1
    move-exception v0

    goto :goto_e

    :cond_b
    :goto_a
    add-int/lit8 v8, v8, 0x1

    goto :goto_9

    :cond_c
    iget-object v4, v1, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    iget-object v8, v1, La0/y0;->j:Ljava/util/ArrayList;

    invoke-static {v3, v8}, Le7/r;->o(Ljava/lang/Iterable;Ljava/util/AbstractCollection;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    :try_start_5
    monitor-exit v4

    new-instance v3, Ljava/util/ArrayList;

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v10}, Ljava/util/Collection;->size()I

    move-result v4

    const/4 v8, 0x0

    :goto_b
    if-ge v8, v4, :cond_e

    invoke-interface {v10, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    move-object v12, v11

    check-cast v12, Ld7/k;

    iget-object v12, v12, Ld7/k;->u:Ljava/lang/Object;

    if-eqz v12, :cond_d

    invoke-virtual {v3, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_d
    add-int/lit8 v8, v8, 0x1

    goto :goto_b

    :cond_e
    move-object v10, v3

    goto :goto_c

    :catchall_2
    move-exception v0

    monitor-exit v4

    throw v0

    :cond_f
    :goto_c
    invoke-virtual {v5, v10}, La0/x;->r(Ljava/util/ArrayList;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :try_start_6
    invoke-static {v7}, Lk0/f;->q(Lk0/f;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    invoke-static {v6}, La0/y0;->u(Lk0/b;)V

    goto/16 :goto_1

    :catchall_3
    move-exception v0

    goto :goto_f

    :goto_d
    :try_start_7
    monitor-exit v8

    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    :goto_e
    :try_start_8
    invoke-static {v7}, Lk0/f;->q(Lk0/f;)V

    throw v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    :goto_f
    invoke-static {v6}, La0/y0;->u(Lk0/b;)V

    throw v0

    :cond_10
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "Cannot create a mutable snapshot of an read-only snapshot"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_11
    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Le7/l;->M(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public final D(La0/x;Lp/I;)La0/x;
    .locals 6

    iget-object v0, p1, La0/x;->O:La0/r;

    iget-boolean v0, v0, La0/r;->F:Z

    const/4 v1, 0x0

    if-nez v0, :cond_6

    iget v0, p1, La0/x;->P:I

    const/4 v2, 0x3

    if-ne v0, v2, :cond_0

    return-object v1

    :cond_0
    iget-object v0, p0, La0/y0;->p:Ljava/util/LinkedHashSet;

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-ne v0, v2, :cond_1

    goto/16 :goto_4

    :cond_1
    new-instance v0, LA7/j;

    const/16 v3, 0x19

    invoke-direct {v0, v3, p1}, LA7/j;-><init>(ILjava/lang/Object;)V

    new-instance v3, LA/Q;

    const/16 v4, 0x15

    invoke-direct {v3, v4, p1, p2}, LA/Q;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v4

    instance-of v5, v4, Lk0/b;

    if-eqz v5, :cond_2

    check-cast v4, Lk0/b;

    goto :goto_0

    :cond_2
    move-object v4, v1

    :goto_0
    if-eqz v4, :cond_5

    invoke-virtual {v4, v0, v3}, Lk0/b;->C(Lr7/c;Lr7/c;)Lk0/b;

    move-result-object v0

    if-eqz v0, :cond_5

    :try_start_0
    invoke-virtual {v0}, Lk0/f;->j()Lk0/f;

    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    if-eqz p2, :cond_4

    :try_start_1
    invoke-virtual {p2}, Lp/I;->h()Z

    move-result v4

    if-ne v4, v2, :cond_4

    new-instance v4, LD/j;

    const/16 v5, 0x13

    invoke-direct {v4, v5, p2, p1}, LD/j;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    iget-object p2, p1, La0/x;->O:La0/r;

    iget-boolean v5, p2, La0/r;->F:Z

    if-eqz v5, :cond_3

    const-string v5, "Preparing a composition while composing is not supported"

    invoke-static {v5}, La0/s;->c(Ljava/lang/String;)V

    :cond_3
    iput-boolean v2, p2, La0/r;->F:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v2, 0x0

    :try_start_2
    invoke-virtual {v4}, LD/j;->a()Ljava/lang/Object;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    iput-boolean v2, p2, La0/r;->F:Z

    goto :goto_1

    :catchall_0
    move-exception p1

    iput-boolean v2, p2, La0/r;->F:Z

    throw p1

    :catchall_1
    move-exception p1

    goto :goto_2

    :cond_4
    :goto_1
    invoke-virtual {p1}, La0/x;->x()Z

    move-result p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    invoke-static {v3}, Lk0/f;->q(Lk0/f;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    invoke-static {v0}, La0/y0;->u(Lk0/b;)V

    if-eqz p2, :cond_6

    return-object p1

    :catchall_2
    move-exception p1

    goto :goto_3

    :goto_2
    :try_start_5
    invoke-static {v3}, Lk0/f;->q(Lk0/f;)V

    throw p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :goto_3
    invoke-static {v0}, La0/y0;->u(Lk0/b;)V

    throw p1

    :cond_5
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Cannot create a mutable snapshot of an read-only snapshot"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_6
    :goto_4
    return-object v1
.end method

.method public final E(Ljava/lang/Throwable;La0/x;)V
    .locals 3

    sget-object v0, La0/y0;->z:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    instance-of v0, p1, La0/l;

    if-nez v0, :cond_1

    iget-object v0, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    const-string v1, "Error was captured in composition while live edit was enabled."

    const-string v2, "ComposeInternal"

    invoke-static {v2, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    iget-object v1, p0, La0/y0;->i:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, La0/y0;->h:Lc0/e;

    invoke-virtual {v1}, Lc0/e;->h()V

    new-instance v1, Lp/I;

    invoke-direct {v1}, Lp/I;-><init>()V

    iput-object v1, p0, La0/y0;->g:Lp/I;

    iget-object v1, p0, La0/y0;->j:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, La0/y0;->k:Lp/H;

    invoke-virtual {v1}, Lp/H;->a()V

    iget-object v1, p0, La0/y0;->m:Lp/H;

    invoke-virtual {v1}, Lp/H;->a()V

    new-instance v1, LU2/h;

    invoke-direct {v1, p1}, LU2/h;-><init>(Ljava/lang/Object;)V

    iput-object v1, p0, La0/y0;->r:LU2/h;

    if-eqz p2, :cond_0

    invoke-virtual {p0, p2}, La0/y0;->G(La0/x;)V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    invoke-virtual {p0}, La0/y0;->w()LD7/f;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0

    throw p1

    :cond_1
    iget-object p2, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter p2

    :try_start_1
    iget-object v0, p0, La0/y0;->r:LU2/h;

    if-nez v0, :cond_2

    new-instance v0, LU2/h;

    invoke-direct {v0, p1}, LU2/h;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, La0/y0;->r:LU2/h;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    monitor-exit p2

    throw p1

    :catchall_1
    move-exception p1

    goto :goto_2

    :cond_2
    :try_start_2
    iget-object p1, v0, LU2/h;->t:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Throwable;

    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :goto_2
    monitor-exit p2

    throw p1
.end method

.method public final F()Z
    .locals 8

    iget-object v0, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La0/y0;->g:Lp/I;

    invoke-virtual {v1}, Lp/I;->g()Z

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_3

    iget-object v1, p0, La0/y0;->h:Lc0/e;

    iget v1, v1, Lc0/e;->v:I

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La0/y0;->x()Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v1, p0, La0/y0;->k:Lp/H;

    invoke-virtual {v1}, Lp/H;->j()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    move v2, v3

    :cond_2
    :goto_0
    monitor-exit v0

    return v2

    :cond_3
    :try_start_1
    invoke-virtual {p0}, La0/y0;->z()Ljava/util/List;

    move-result-object v1

    iget-object v4, p0, La0/y0;->g:Lp/I;

    new-instance v5, Lc0/h;

    invoke-direct {v5, v4}, Lc0/h;-><init>(Lp/I;)V

    new-instance v4, Lp/I;

    invoke-direct {v4}, Lp/I;-><init>()V

    iput-object v4, p0, La0/y0;->g:Lp/I;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    monitor-exit v0

    :try_start_2
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    move-result v0

    move v4, v3

    :goto_1
    if-ge v4, v0, :cond_4

    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La0/x;

    invoke-virtual {v6, v5}, La0/x;->y(Lc0/h;)V

    iget-object v6, p0, La0/y0;->t:LG7/g0;

    invoke-virtual {v6}, LG7/g0;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La0/s0;

    sget-object v7, La0/s0;->u:La0/s0;

    invoke-virtual {v6, v7}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v6
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-lez v6, :cond_4

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_3

    :cond_4
    iget-object v0, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    invoke-virtual {p0}, La0/y0;->w()LD7/f;

    move-result-object v1

    if-nez v1, :cond_8

    iget-object v1, p0, La0/y0;->h:Lc0/e;

    iget v1, v1, Lc0/e;->v:I

    if-eqz v1, :cond_5

    goto :goto_2

    :cond_5
    invoke-virtual {p0}, La0/y0;->x()Z

    move-result v1

    if-nez v1, :cond_7

    iget-object v1, p0, La0/y0;->k:Lp/H;

    invoke-virtual {v1}, Lp/H;->j()Z

    move-result v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    if-eqz v1, :cond_6

    goto :goto_2

    :cond_6
    move v2, v3

    :cond_7
    :goto_2
    monitor-exit v0

    return v2

    :cond_8
    :try_start_4
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "called outside of runRecomposeAndApplyChanges"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception v1

    monitor-exit v0

    throw v1

    :goto_3
    iget-object v1, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v1

    :try_start_5
    iget-object v2, p0, La0/y0;->g:Lp/I;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_4
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_9

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v2, v4}, Lp/I;->j(Ljava/lang/Object;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto :goto_4

    :cond_9
    monitor-exit v1

    throw v0

    :catchall_2
    move-exception v0

    monitor-exit v1

    throw v0

    :catchall_3
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public final G(La0/x;)V
    .locals 2

    iget-object v0, p0, La0/y0;->o:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La0/y0;->o:Ljava/util/ArrayList;

    :cond_0
    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_1
    iget-object v0, p0, La0/y0;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    const/4 p1, 0x0

    iput-object p1, p0, La0/y0;->f:Ljava/lang/Object;

    :cond_2
    return-void
.end method

.method public final a(La0/x;Lr7/e;)V
    .locals 7

    iget-object v0, p1, La0/x;->O:La0/r;

    iget-boolean v0, v0, La0/r;->F:Z

    iget-object v1, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    iget-object v2, p0, La0/y0;->t:LG7/g0;

    invoke-virtual {v2}, LG7/g0;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La0/s0;

    sget-object v3, La0/s0;->u:La0/s0;

    invoke-virtual {v2, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v2

    const/4 v3, 0x0

    if-lez v2, :cond_0

    invoke-virtual {p0}, La0/y0;->z()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    xor-int/lit8 v4, v2, 0x1

    if-nez v2, :cond_1

    iget-object v2, p0, La0/y0;->e:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iput-object v3, p0, La0/y0;->f:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto/16 :goto_5

    :cond_0
    const/4 v4, 0x1

    :cond_1
    :goto_0
    monitor-exit v1

    :try_start_1
    new-instance v1, LA7/j;

    const/16 v2, 0x19

    invoke-direct {v1, v2, p1}, LA7/j;-><init>(ILjava/lang/Object;)V

    new-instance v2, LA/Q;

    const/16 v5, 0x15

    invoke-direct {v2, v5, p1, v3}, LA/Q;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v5

    instance-of v6, v5, Lk0/b;

    if-eqz v6, :cond_2

    check-cast v5, Lk0/b;

    goto :goto_1

    :cond_2
    move-object v5, v3

    :goto_1
    if-eqz v5, :cond_4

    invoke-virtual {v5, v1, v2}, Lk0/b;->C(Lr7/c;Lr7/c;)Lk0/b;

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    if-eqz v1, :cond_4

    :try_start_2
    invoke-virtual {v1}, Lk0/f;->j()Lk0/f;

    move-result-object v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_4

    :try_start_3
    invoke-virtual {p1, p2}, La0/x;->j(Lr7/e;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_5

    :try_start_4
    invoke-static {v2}, Lk0/f;->q(Lk0/f;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    :try_start_5
    invoke-static {v1}, La0/y0;->u(Lk0/b;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    if-nez v0, :cond_3

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object p2

    invoke-virtual {p2}, Lk0/f;->m()V

    :cond_3
    :try_start_6
    invoke-virtual {p0, p1}, La0/y0;->A(La0/x;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :try_start_7
    invoke-virtual {p1}, La0/x;->d()V

    invoke-virtual {p1}, La0/x;->f()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    if-nez v0, :cond_6

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object p1

    invoke-virtual {p1}, Lk0/f;->m()V

    return-void

    :catchall_1
    move-exception p1

    invoke-virtual {p0, p1, v3}, La0/y0;->E(Ljava/lang/Throwable;La0/x;)V

    return-void

    :catchall_2
    move-exception p2

    invoke-virtual {p0, p2, p1}, La0/y0;->E(Ljava/lang/Throwable;La0/x;)V

    return-void

    :catchall_3
    move-exception p2

    goto :goto_3

    :catchall_4
    move-exception p2

    goto :goto_2

    :catchall_5
    move-exception p2

    :try_start_8
    invoke-static {v2}, Lk0/f;->q(Lk0/f;)V

    throw p2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    :goto_2
    :try_start_9
    invoke-static {v1}, La0/y0;->u(Lk0/b;)V

    throw p2

    :cond_4
    new-instance p2, Ljava/lang/IllegalStateException;

    const-string v0, "Cannot create a mutable snapshot of an read-only snapshot"

    invoke-direct {p2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    :goto_3
    invoke-virtual {p0, p2, p1}, La0/y0;->E(Ljava/lang/Throwable;La0/x;)V

    if-eqz v4, :cond_6

    iget-object p2, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter p2

    :try_start_a
    iget-object v0, p0, La0/y0;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5

    iput-object v3, p0, La0/y0;->f:Ljava/lang/Object;
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_6

    :cond_5
    monitor-exit p2

    goto :goto_4

    :catchall_6
    move-exception p1

    monitor-exit p2

    throw p1

    :cond_6
    :goto_4
    return-void

    :goto_5
    monitor-exit v1

    throw p1
.end method

.method public final b(La0/x;LA1/c;Lr7/e;)Lp/I;
    .locals 3

    iget-object v0, p0, La0/y0;->u:Lcom/google/android/gms/internal/play_billing/l;

    const/4 v1, 0x0

    :try_start_0
    iget-object v2, p1, La0/x;->I:LA1/c;

    iput-object p2, p1, La0/x;->I:LA1/c;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-virtual {p0, p1, p3}, La0/y0;->a(La0/x;Lr7/e;)V

    invoke-virtual {v0}, Lcom/google/android/gms/internal/play_billing/l;->e()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lp/I;

    if-eqz p2, :cond_0

    goto :goto_0

    :cond_0
    sget-object p2, Lp/Q;->a:Lp/I;

    const-string p3, "null cannot be cast to non-null type androidx.collection.ScatterSet<E of androidx.collection.ScatterSetKt.emptyScatterSet>"

    invoke-static {p2, p3}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_0
    :try_start_2
    iput-object v2, p1, La0/x;->I:LA1/c;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/play_billing/l;->r(Ljava/lang/Object;)V

    return-object p2

    :catchall_0
    move-exception p1

    goto :goto_1

    :catchall_1
    move-exception p2

    :try_start_3
    iput-object v2, p1, La0/x;->I:LA1/c;

    throw p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :goto_1
    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/play_billing/l;->r(Ljava/lang/Object;)V

    throw p1
.end method

.method public final d()Z
    .locals 1

    sget-object v0, La0/y0;->z:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0
.end method

.method public final e()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final f()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final g()J
    .locals 2

    const/16 v0, 0x3e8

    int-to-long v0, v0

    return-wide v0
.end method

.method public final h()La0/t;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public final j()Lh7/h;
    .locals 1

    iget-object v0, p0, La0/y0;->w:Lh7/h;

    return-object v0
.end method

.method public final k(La0/x;)V
    .locals 2

    iget-object v0, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La0/y0;->h:Lc0/e;

    invoke-virtual {v1, p1}, Lc0/e;->i(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, La0/y0;->h:Lc0/e;

    invoke-virtual {v1, p1}, Lc0/e;->b(Ljava/lang/Object;)V

    invoke-virtual {p0}, La0/y0;->w()LD7/f;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    const/4 p1, 0x0

    :goto_0
    monitor-exit v0

    if-eqz p1, :cond_1

    sget-object v0, Ld7/z;->a:Ld7/z;

    check-cast p1, LD7/h;

    invoke-virtual {p1, v0}, LD7/h;->e(Ljava/lang/Object;)V

    :cond_1
    return-void

    :goto_1
    monitor-exit v0

    throw p1
.end method

.method public final l(La0/Y;)La0/X;
    .locals 2

    iget-object v0, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La0/y0;->m:Lp/H;

    invoke-virtual {v1, p1}, Lp/H;->k(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La0/X;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v0

    throw p1
.end method

.method public final m(La0/x;LA1/c;Lp/I;)Lp/I;
    .locals 3

    iget-object v0, p0, La0/y0;->u:Lcom/google/android/gms/internal/play_billing/l;

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {p0}, La0/y0;->F()Z

    new-instance v2, Lc0/h;

    invoke-direct {v2, p3}, Lc0/h;-><init>(Lp/I;)V

    invoke-virtual {p1, v2}, La0/x;->y(Lc0/h;)V

    iget-object p3, p1, La0/x;->I:LA1/c;

    iput-object p2, p1, La0/x;->I:LA1/c;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-virtual {p0, p1, v1}, La0/y0;->D(La0/x;Lp/I;)La0/x;

    move-result-object p2

    if-eqz p2, :cond_0

    invoke-virtual {p0, p1}, La0/y0;->A(La0/x;)V

    invoke-virtual {p2}, La0/x;->d()V

    invoke-virtual {p2}, La0/x;->f()V

    goto :goto_0

    :catchall_0
    move-exception p2

    goto :goto_2

    :cond_0
    :goto_0
    invoke-virtual {v0}, Lcom/google/android/gms/internal/play_billing/l;->e()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lp/I;

    if-eqz p2, :cond_1

    goto :goto_1

    :cond_1
    sget-object p2, Lp/Q;->a:Lp/I;

    const-string v2, "null cannot be cast to non-null type androidx.collection.ScatterSet<E of androidx.collection.ScatterSetKt.emptyScatterSet>"

    invoke-static {p2, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_1
    :try_start_2
    iput-object p3, p1, La0/x;->I:LA1/c;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/play_billing/l;->r(Ljava/lang/Object;)V

    return-object p2

    :catchall_1
    move-exception p1

    goto :goto_3

    :goto_2
    :try_start_3
    iput-object p3, p1, La0/x;->I:LA1/c;

    throw p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :goto_3
    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/play_billing/l;->r(Ljava/lang/Object;)V

    throw p1
.end method

.method public final n(Ljava/util/Set;)V
    .locals 0

    return-void
.end method

.method public final p(La0/r0;)V
    .locals 2

    iget-object v0, p0, La0/y0;->u:Lcom/google/android/gms/internal/play_billing/l;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/play_billing/l;->e()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lp/I;

    if-nez v1, :cond_0

    sget-object v1, Lp/Q;->a:Lp/I;

    new-instance v1, Lp/I;

    invoke-direct {v1}, Lp/I;-><init>()V

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/play_billing/l;->r(Ljava/lang/Object;)V

    :cond_0
    invoke-virtual {v1, p1}, Lp/I;->a(Ljava/lang/Object;)Z

    return-void
.end method

.method public final q(La0/x;)V
    .locals 2

    iget-object v0, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La0/y0;->p:Ljava/util/LinkedHashSet;

    if-nez v1, :cond_0

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v1, p0, La0/y0;->p:Ljava/util/LinkedHashSet;

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    invoke-interface {v1, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0

    throw p1
.end method

.method public final t(La0/x;)V
    .locals 2

    iget-object v0, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La0/y0;->e:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x0

    iput-object v1, p0, La0/y0;->f:Ljava/lang/Object;

    :cond_0
    iget-object v1, p0, La0/y0;->h:Lc0/e;

    invoke-virtual {v1, p1}, Lc0/e;->l(Ljava/lang/Object;)Z

    iget-object v1, p0, La0/y0;->i:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v0

    throw p1
.end method

.method public final v()V
    .locals 4

    iget-object v0, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La0/y0;->t:LG7/g0;

    invoke-virtual {v1}, LG7/g0;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La0/s0;

    sget-object v2, La0/s0;->x:La0/s0;

    invoke-virtual {v1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v1

    const/4 v2, 0x0

    if-ltz v1, :cond_0

    iget-object v1, p0, La0/y0;->t:LG7/g0;

    sget-object v3, La0/s0;->u:La0/s0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v2, v3}, LG7/g0;->j(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit v0

    iget-object v0, p0, La0/y0;->v:LD7/e0;

    invoke-virtual {v0, v2}, LD7/k0;->f(Ljava/util/concurrent/CancellationException;)V

    return-void

    :goto_1
    monitor-exit v0

    throw v1
.end method

.method public final w()LD7/f;
    .locals 8

    iget-object v0, p0, La0/y0;->t:LG7/g0;

    invoke-virtual {v0}, LG7/g0;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La0/s0;

    sget-object v2, La0/s0;->u:La0/s0;

    invoke-virtual {v1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v1

    iget-object v2, p0, La0/y0;->j:Ljava/util/ArrayList;

    iget-object v3, p0, La0/y0;->i:Ljava/util/ArrayList;

    iget-object v4, p0, La0/y0;->h:Lc0/e;

    const/4 v5, 0x0

    if-gtz v1, :cond_2

    invoke-virtual {p0}, La0/y0;->z()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La0/x;

    goto :goto_0

    :cond_0
    iget-object v0, p0, La0/y0;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    sget-object v0, Le7/t;->t:Le7/t;

    iput-object v0, p0, La0/y0;->f:Ljava/lang/Object;

    new-instance v0, Lp/I;

    invoke-direct {v0}, Lp/I;-><init>()V

    iput-object v0, p0, La0/y0;->g:Lp/I;

    invoke-virtual {v4}, Lc0/e;->h()V

    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    iput-object v5, p0, La0/y0;->o:Ljava/util/ArrayList;

    iget-object v0, p0, La0/y0;->q:LD7/h;

    if-eqz v0, :cond_1

    invoke-virtual {v0, v5}, LD7/h;->m(Ljava/lang/Throwable;)Z

    :cond_1
    iput-object v5, p0, La0/y0;->q:LD7/h;

    iput-object v5, p0, La0/y0;->r:LU2/h;

    return-object v5

    :cond_2
    iget-object v1, p0, La0/y0;->r:LU2/h;

    sget-object v6, La0/s0;->y:La0/s0;

    sget-object v7, La0/s0;->v:La0/s0;

    if-eqz v1, :cond_3

    goto :goto_2

    :cond_3
    iget-object v1, p0, La0/y0;->c:LD7/c0;

    if-nez v1, :cond_4

    new-instance v1, Lp/I;

    invoke-direct {v1}, Lp/I;-><init>()V

    iput-object v1, p0, La0/y0;->g:Lp/I;

    invoke-virtual {v4}, Lc0/e;->h()V

    invoke-virtual {p0}, La0/y0;->x()Z

    move-result v1

    if-eqz v1, :cond_8

    sget-object v7, La0/s0;->w:La0/s0;

    goto :goto_2

    :cond_4
    iget v1, v4, Lc0/e;->v:I

    if-eqz v1, :cond_5

    goto :goto_1

    :cond_5
    iget-object v1, p0, La0/y0;->g:Lp/I;

    invoke-virtual {v1}, Lp/I;->h()Z

    move-result v1

    if-nez v1, :cond_7

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-virtual {p0}, La0/y0;->x()Z

    move-result v1

    if-nez v1, :cond_7

    iget-object v1, p0, La0/y0;->k:Lp/H;

    invoke-virtual {v1}, Lp/H;->j()Z

    move-result v1

    if-eqz v1, :cond_6

    goto :goto_1

    :cond_6
    sget-object v7, La0/s0;->x:La0/s0;

    goto :goto_2

    :cond_7
    :goto_1
    move-object v7, v6

    :cond_8
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, v5, v7}, LG7/g0;->j(Ljava/lang/Object;Ljava/lang/Object;)Z

    if-ne v7, v6, :cond_9

    iget-object v0, p0, La0/y0;->q:LD7/h;

    iput-object v5, p0, La0/y0;->q:LD7/h;

    return-object v0

    :cond_9
    return-object v5
.end method

.method public final x()Z
    .locals 2

    iget-boolean v0, p0, La0/y0;->s:Z

    if-nez v0, :cond_0

    iget-object v0, p0, La0/y0;->a:La0/e;

    iget-object v0, v0, La0/e;->w:Li0/a;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const v1, 0x7ffffff

    and-int/2addr v0, v1

    if-lez v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public final y()Z
    .locals 2

    iget-object v0, p0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La0/y0;->g:Lp/I;

    invoke-virtual {v1}, Lp/I;->h()Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v1, p0, La0/y0;->h:Lc0/e;

    iget v1, v1, Lc0/e;->v:I

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La0/y0;->x()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    goto :goto_1

    :catchall_0
    move-exception v1

    goto :goto_2

    :cond_2
    :goto_0
    const/4 v1, 0x1

    :goto_1
    monitor-exit v0

    return v1

    :goto_2
    monitor-exit v0

    throw v1
.end method

.method public final z()Ljava/util/List;
    .locals 2

    iget-object v0, p0, La0/y0;->f:Ljava/lang/Object;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    iget-object v0, p0, La0/y0;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    sget-object v0, Le7/t;->t:Le7/t;

    goto :goto_0

    :cond_1
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    move-object v0, v1

    :goto_0
    iput-object v0, p0, La0/y0;->f:Ljava/lang/Object;

    return-object v0
.end method
