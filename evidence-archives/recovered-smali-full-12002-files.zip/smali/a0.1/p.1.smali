.class public final La0/p;
.super La0/u;
.source "SourceFile"


# instance fields
.field public final a:J

.field public final b:Z

.field public final c:Z

.field public d:Ljava/util/HashSet;

.field public final e:Ljava/util/LinkedHashSet;

.field public final f:La0/h0;

.field public final synthetic g:La0/r;


# direct methods
.method public constructor <init>(La0/r;JZZLW2/g;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/p;->g:La0/r;

    iput-wide p2, p0, La0/p;->a:J

    iput-boolean p4, p0, La0/p;->b:Z

    iput-boolean p5, p0, La0/p;->c:Z

    new-instance p1, Ljava/util/LinkedHashSet;

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object p1, p0, La0/p;->e:Ljava/util/LinkedHashSet;

    sget-object p1, Li0/h;->w:Li0/h;

    sget-object p2, La0/U;->w:La0/U;

    new-instance p3, La0/h0;

    invoke-direct {p3, p1, p2}, La0/h0;-><init>(Ljava/lang/Object;La0/N0;)V

    iput-object p3, p0, La0/p;->f:La0/h0;

    return-void
.end method


# virtual methods
.method public final a(La0/x;Lr7/e;)V
    .locals 1

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v0, v0, La0/r;->b:La0/u;

    invoke-virtual {v0, p1, p2}, La0/u;->a(La0/x;Lr7/e;)V

    return-void
.end method

.method public final b(La0/x;LA1/c;Lr7/e;)Lp/I;
    .locals 1

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v0, v0, La0/r;->b:La0/u;

    invoke-virtual {v0, p1, p2, p3}, La0/u;->b(La0/x;LA1/c;Lr7/e;)Lp/I;

    move-result-object p1

    return-object p1
.end method

.method public final c()V
    .locals 2

    iget-object v0, p0, La0/p;->g:La0/r;

    iget v1, v0, La0/r;->A:I

    add-int/lit8 v1, v1, -0x1

    iput v1, v0, La0/r;->A:I

    return-void
.end method

.method public final d()Z
    .locals 1

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v0, v0, La0/r;->b:La0/u;

    invoke-virtual {v0}, La0/u;->d()Z

    move-result v0

    return v0
.end method

.method public final e()Z
    .locals 1

    iget-boolean v0, p0, La0/p;->b:Z

    return v0
.end method

.method public final f()Z
    .locals 1

    iget-boolean v0, p0, La0/p;->c:Z

    return v0
.end method

.method public final g()J
    .locals 2

    iget-wide v0, p0, La0/p;->a:J

    return-wide v0
.end method

.method public final h()La0/t;
    .locals 1

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v0, v0, La0/r;->h:La0/x;

    return-object v0
.end method

.method public final i()La0/n0;
    .locals 1

    iget-object v0, p0, La0/p;->f:La0/h0;

    invoke-virtual {v0}, La0/h0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La0/n0;

    return-object v0
.end method

.method public final j()Lh7/h;
    .locals 1

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v0, v0, La0/r;->b:La0/u;

    invoke-virtual {v0}, La0/u;->j()Lh7/h;

    move-result-object v0

    return-object v0
.end method

.method public final k(La0/x;)V
    .locals 3

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v1, v0, La0/r;->b:La0/u;

    iget-object v2, v0, La0/r;->h:La0/x;

    invoke-virtual {v1, v2}, La0/u;->k(La0/x;)V

    iget-object v0, v0, La0/r;->b:La0/u;

    invoke-virtual {v0, p1}, La0/u;->k(La0/x;)V

    return-void
.end method

.method public final l(La0/Y;)La0/X;
    .locals 1

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v0, v0, La0/r;->b:La0/u;

    invoke-virtual {v0, p1}, La0/u;->l(La0/Y;)La0/X;

    move-result-object p1

    return-object p1
.end method

.method public final m(La0/x;LA1/c;Lp/I;)Lp/I;
    .locals 1

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v0, v0, La0/r;->b:La0/u;

    invoke-virtual {v0, p1, p2, p3}, La0/u;->m(La0/x;LA1/c;Lp/I;)Lp/I;

    move-result-object p1

    return-object p1
.end method

.method public final n(Ljava/util/Set;)V
    .locals 1

    iget-object v0, p0, La0/p;->d:Ljava/util/HashSet;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, La0/p;->d:Ljava/util/HashSet;

    :cond_0
    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final o(La0/r;)V
    .locals 1

    iget-object v0, p0, La0/p;->e:Ljava/util/LinkedHashSet;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final p(La0/r0;)V
    .locals 1

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v0, v0, La0/r;->b:La0/u;

    invoke-virtual {v0, p1}, La0/u;->p(La0/r0;)V

    return-void
.end method

.method public final q(La0/x;)V
    .locals 1

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v0, v0, La0/r;->b:La0/u;

    invoke-virtual {v0, p1}, La0/u;->q(La0/x;)V

    return-void
.end method

.method public final r()V
    .locals 2

    iget-object v0, p0, La0/p;->g:La0/r;

    iget v1, v0, La0/r;->A:I

    add-int/lit8 v1, v1, 0x1

    iput v1, v0, La0/r;->A:I

    return-void
.end method

.method public final s(La0/r;)V
    .locals 3

    iget-object v0, p0, La0/p;->d:Ljava/util/HashSet;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Set;

    const-string v2, "null cannot be cast to non-null type androidx.compose.runtime.ComposerImpl"

    invoke-static {p1, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p1, La0/r;->c:La0/F0;

    invoke-interface {v1, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    iget-object v0, p0, La0/p;->e:Ljava/util/LinkedHashSet;

    invoke-static {v0}, Ls7/x;->a(Ljava/util/AbstractCollection;)Ljava/util/Collection;

    invoke-interface {v0, p1}, Ljava/util/Collection;->remove(Ljava/lang/Object;)Z

    return-void
.end method

.method public final t(La0/x;)V
    .locals 1

    iget-object v0, p0, La0/p;->g:La0/r;

    iget-object v0, v0, La0/r;->b:La0/u;

    invoke-virtual {v0, p1}, La0/u;->t(La0/x;)V

    return-void
.end method

.method public final u()V
    .locals 7

    iget-object v0, p0, La0/p;->e:Ljava/util/LinkedHashSet;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v1, p0, La0/p;->d:Ljava/util/HashSet;

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La0/r;

    invoke-virtual {v1}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Set;

    iget-object v6, v3, La0/r;->c:La0/F0;

    invoke-interface {v5, v6}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    invoke-interface {v0}, Ljava/util/Set;->clear()V

    :cond_2
    return-void
.end method
