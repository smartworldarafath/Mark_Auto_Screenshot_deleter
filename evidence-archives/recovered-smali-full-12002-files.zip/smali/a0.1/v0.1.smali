.class public final La0/v0;
.super Lj7/i;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public final synthetic A:La0/y0;

.field public final synthetic B:La0/x0;

.field public final synthetic C:La0/V;

.field public x:LA3/b;

.field public y:I

.field public synthetic z:Ljava/lang/Object;


# direct methods
.method public constructor <init>(La0/y0;La0/x0;La0/V;Lh7/c;)V
    .locals 0

    iput-object p1, p0, La0/v0;->A:La0/y0;

    iput-object p2, p0, La0/v0;->B:La0/x0;

    iput-object p3, p0, La0/v0;->C:La0/V;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lj7/i;-><init>(ILh7/c;)V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LD7/v;

    check-cast p2, Lh7/c;

    invoke-virtual {p0, p2, p1}, La0/v0;->n(Lh7/c;Ljava/lang/Object;)Lh7/c;

    move-result-object p1

    check-cast p1, La0/v0;

    sget-object p2, Ld7/z;->a:Ld7/z;

    invoke-virtual {p1, p2}, La0/v0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final n(Lh7/c;Ljava/lang/Object;)Lh7/c;
    .locals 4

    new-instance v0, La0/v0;

    iget-object v1, p0, La0/v0;->B:La0/x0;

    iget-object v2, p0, La0/v0;->C:La0/V;

    iget-object v3, p0, La0/v0;->A:La0/y0;

    invoke-direct {v0, v3, v1, v2, p1}, La0/v0;-><init>(La0/y0;La0/x0;La0/V;Lh7/c;)V

    iput-object p2, v0, La0/v0;->z:Ljava/lang/Object;

    return-object v0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    sget-object v0, Li7/a;->t:Li7/a;

    iget v1, p0, La0/v0;->y:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v3, :cond_0

    iget-object v0, p0, La0/v0;->x:LA3/b;

    iget-object v1, p0, La0/v0;->z:Ljava/lang/Object;

    check-cast v1, LD7/c0;

    :try_start_0
    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto/16 :goto_2

    :catchall_0
    move-exception p1

    goto/16 :goto_5

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    iget-object p1, p0, La0/v0;->z:Ljava/lang/Object;

    check-cast p1, LD7/v;

    invoke-interface {p1}, LD7/v;->N()Lh7/h;

    move-result-object p1

    invoke-static {p1}, LD7/y;->q(Lh7/h;)LD7/c0;

    move-result-object v1

    iget-object p1, p0, La0/v0;->A:La0/y0;

    iget-object v4, p1, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v4

    :try_start_1
    iget-object v5, p1, La0/y0;->d:Ljava/lang/Throwable;

    if-nez v5, :cond_c

    iget-object v5, p1, La0/y0;->t:LG7/g0;

    invoke-virtual {v5}, LG7/g0;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La0/s0;

    sget-object v6, La0/s0;->u:La0/s0;

    invoke-virtual {v5, v6}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v5

    if-lez v5, :cond_b

    iget-object v5, p1, La0/y0;->c:LD7/c0;

    if-nez v5, :cond_a

    iput-object v1, p1, La0/y0;->c:LD7/c0;

    invoke-virtual {p1}, La0/y0;->w()LD7/f;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_6

    monitor-exit v4

    iget-object p1, p0, La0/v0;->A:La0/y0;

    new-instance v4, LA/o0;

    const/16 v5, 0x14

    invoke-direct {v4, v5, p1}, LA/o0;-><init>(ILjava/lang/Object;)V

    sget-object p1, Lk0/l;->a:Lb2/a;

    invoke-static {p1}, Lk0/l;->f(Lr7/c;)Ljava/lang/Object;

    sget-object p1, Lk0/l;->c:Ljava/lang/Object;

    monitor-enter p1

    :try_start_2
    sget-object v5, Lk0/l;->h:Ljava/lang/Object;

    invoke-static {v5, v4}, Le7/l;->E(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v5

    sput-object v5, Lk0/l;->h:Ljava/lang/Object;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_5

    monitor-exit p1

    new-instance p1, LA3/b;

    const/16 v5, 0xe

    invoke-direct {p1, v5, v4}, LA3/b;-><init>(ILjava/lang/Object;)V

    sget-object v4, La0/y0;->y:LG7/g0;

    iget-object v4, p0, La0/v0;->A:La0/y0;

    iget-object v4, v4, La0/y0;->x:La0/U;

    :cond_2
    sget-object v5, La0/y0;->y:LG7/g0;

    invoke-virtual {v5}, LG7/g0;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld0/b;

    move-object v7, v6

    check-cast v7, Lg0/b;

    sget-object v8, Lh0/b;->a:Lh0/b;

    iget-object v9, v7, Lg0/b;->v:Lf0/c;

    invoke-virtual {v9, v4}, Lf0/c;->containsKey(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_3

    goto :goto_0

    :cond_3
    invoke-virtual {v7}, Le7/a;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_4

    new-instance v7, Lg0/a;

    invoke-direct {v7, v8, v8}, Lg0/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v9, v4, v7}, Lf0/c;->a(Ljava/lang/Object;Lg0/a;)Lf0/c;

    move-result-object v7

    new-instance v8, Lg0/b;

    invoke-direct {v8, v4, v4, v7}, Lg0/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lf0/c;)V

    move-object v7, v8

    goto :goto_0

    :cond_4
    iget-object v10, v7, Lg0/b;->u:Ljava/lang/Object;

    invoke-virtual {v9, v10}, Lf0/c;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    invoke-static {v11}, Ls7/j;->b(Ljava/lang/Object;)V

    check-cast v11, Lg0/a;

    new-instance v12, Lg0/a;

    iget-object v11, v11, Lg0/a;->a:Ljava/lang/Object;

    invoke-direct {v12, v11, v4}, Lg0/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v9, v10, v12}, Lf0/c;->a(Ljava/lang/Object;Lg0/a;)Lf0/c;

    move-result-object v9

    new-instance v11, Lg0/a;

    invoke-direct {v11, v10, v8}, Lg0/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v9, v4, v11}, Lf0/c;->a(Ljava/lang/Object;Lg0/a;)Lf0/c;

    move-result-object v8

    new-instance v9, Lg0/b;

    iget-object v7, v7, Lg0/b;->t:Ljava/lang/Object;

    invoke-direct {v9, v7, v4, v8}, Lg0/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lf0/c;)V

    move-object v7, v9

    :goto_0
    if-eq v6, v7, :cond_5

    invoke-virtual {v5, v6, v7}, LG7/g0;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    :cond_5
    :try_start_3
    iget-object v4, p0, La0/v0;->A:La0/y0;

    iget-object v5, v4, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    invoke-virtual {v4}, La0/y0;->z()Ljava/util/List;

    move-result-object v4
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    :try_start_5
    monitor-exit v5

    invoke-interface {v4}, Ljava/util/Collection;->size()I

    move-result v5

    const/4 v6, 0x0

    :goto_1
    if-ge v6, v5, :cond_6

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La0/x;

    invoke-virtual {v7}, La0/x;->t()V

    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :catchall_1
    move-exception v0

    move-object v13, v0

    move-object v0, p1

    move-object p1, v13

    goto :goto_5

    :cond_6
    new-instance v4, La0/u0;

    iget-object v5, p0, La0/v0;->B:La0/x0;

    iget-object v6, p0, La0/v0;->C:La0/V;

    invoke-direct {v4, v5, v6, v2}, La0/u0;-><init>(La0/x0;La0/V;Lh7/c;)V

    iput-object v1, p0, La0/v0;->z:Ljava/lang/Object;

    iput-object p1, p0, La0/v0;->x:LA3/b;

    iput v3, p0, La0/v0;->y:I

    invoke-static {v4, p0}, LD7/y;->j(Lr7/e;Lh7/c;)Ljava/lang/Object;

    move-result-object v3
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    if-ne v3, v0, :cond_7

    return-object v0

    :cond_7
    move-object v0, p1

    :goto_2
    invoke-virtual {v0}, LA3/b;->i()V

    iget-object p1, p0, La0/v0;->A:La0/y0;

    iget-object v0, p1, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_6
    iget-object v3, p1, La0/y0;->c:LD7/c0;

    if-ne v3, v1, :cond_8

    iput-object v2, p1, La0/y0;->c:LD7/c0;

    goto :goto_3

    :catchall_2
    move-exception p1

    goto :goto_4

    :cond_8
    :goto_3
    invoke-virtual {p1}, La0/y0;->w()LD7/f;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    monitor-exit v0

    sget-object p1, La0/y0;->y:LG7/g0;

    iget-object p1, p0, La0/v0;->A:La0/y0;

    iget-object p1, p1, La0/y0;->x:La0/U;

    invoke-static {p1}, La0/U;->b(La0/U;)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :goto_4
    monitor-exit v0

    throw p1

    :catchall_3
    move-exception v0

    :try_start_7
    monitor-exit v5

    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    :goto_5
    invoke-virtual {v0}, LA3/b;->i()V

    iget-object v0, p0, La0/v0;->A:La0/y0;

    iget-object v3, v0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v3

    :try_start_8
    iget-object v4, v0, La0/y0;->c:LD7/c0;

    if-ne v4, v1, :cond_9

    iput-object v2, v0, La0/y0;->c:LD7/c0;

    goto :goto_6

    :catchall_4
    move-exception p1

    goto :goto_7

    :cond_9
    :goto_6
    invoke-virtual {v0}, La0/y0;->w()LD7/f;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    monitor-exit v3

    sget-object v0, La0/y0;->y:LG7/g0;

    iget-object v0, p0, La0/v0;->A:La0/y0;

    iget-object v0, v0, La0/y0;->x:La0/U;

    invoke-static {v0}, La0/U;->b(La0/U;)V

    throw p1

    :goto_7
    monitor-exit v3

    throw p1

    :catchall_5
    move-exception v0

    monitor-exit p1

    throw v0

    :catchall_6
    move-exception p1

    goto :goto_8

    :cond_a
    :try_start_9
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Recomposer already running"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_b
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Recomposer shut down"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_c
    throw v5
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_6

    :goto_8
    monitor-exit v4

    throw p1
.end method
