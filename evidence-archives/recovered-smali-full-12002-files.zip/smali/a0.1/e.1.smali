.class public final La0/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/V;


# instance fields
.field public final t:LE/F;

.field public final u:Ljava/lang/Object;

.field public v:Ljava/lang/Throwable;

.field public final w:Li0/a;

.field public x:Lp/D;

.field public y:Lp/D;


# direct methods
.method public constructor <init>(LE/F;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/e;->t:LE/F;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/e;->u:Ljava/lang/Object;

    new-instance p1, Li0/a;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object p1, p0, La0/e;->w:Li0/a;

    new-instance p1, Lp/D;

    invoke-direct {p1}, Lp/D;-><init>()V

    iput-object p1, p0, La0/e;->x:Lp/D;

    new-instance p1, Lp/D;

    invoke-direct {p1}, Lp/D;-><init>()V

    iput-object p1, p0, La0/e;->y:Lp/D;

    return-void
.end method


# virtual methods
.method public final C(Lh7/c;Lr7/c;)Ljava/lang/Object;
    .locals 7

    new-instance v0, LD7/h;

    invoke-static {p1}, LG2/J;->c(Lh7/c;)Lh7/c;

    move-result-object p1

    const/4 v1, 0x1

    invoke-direct {v0, v1, p1}, LD7/h;-><init>(ILh7/c;)V

    invoke-virtual {v0}, LD7/h;->u()V

    new-instance p1, La0/d;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p2, p1, La0/d;->a:Lr7/c;

    iput-object v0, p1, La0/d;->b:LD7/h;

    new-instance p2, Ls7/s;

    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    const/4 v2, -0x1

    iput v2, p2, Ls7/s;->t:I

    iget-object v2, p0, La0/e;->u:Ljava/lang/Object;

    monitor-enter v2

    :try_start_0
    iget-object v3, p0, La0/e;->v:Ljava/lang/Throwable;

    if-eqz v3, :cond_0

    invoke-static {v3}, Ld7/a;->b(Ljava/lang/Throwable;)Ld7/m;

    move-result-object p1

    invoke-virtual {v0, p1}, LD7/h;->e(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v2

    goto/16 :goto_3

    :catchall_0
    move-exception p1

    goto/16 :goto_4

    :cond_0
    :try_start_1
    iget-object v3, p0, La0/e;->w:Li0/a;

    :cond_1
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v4

    add-int/lit8 v5, v4, 0x1

    invoke-virtual {v3, v4, v5}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v4

    if-eqz v4, :cond_1

    const v3, 0x7ffffff

    and-int/2addr v3, v5

    const/4 v4, 0x0

    if-ne v3, v1, :cond_2

    move v3, v1

    goto :goto_0

    :cond_2
    move v3, v4

    :goto_0
    ushr-int/lit8 v5, v5, 0x1b

    and-int/lit8 v5, v5, 0xf

    iput v5, p2, Ls7/s;->t:I

    iget-object v5, p0, La0/e;->x:Lp/D;

    invoke-virtual {v5, p1}, Lp/D;->a(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v2

    new-instance v2, LL6/h;

    const/4 v5, 0x1

    invoke-direct {v2, p1, p0, p2, v5}, LL6/h;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v2}, LD7/h;->w(Lr7/c;)V

    if-eqz v3, :cond_7

    iget-object p1, p0, La0/e;->t:LE/F;

    :try_start_2
    invoke-virtual {p1}, LE/F;->a()Ljava/lang/Object;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto :goto_3

    :catchall_1
    move-exception p1

    iget-object p2, p0, La0/e;->u:Ljava/lang/Object;

    monitor-enter p2

    :try_start_3
    iget-object v2, p0, La0/e;->v:Ljava/lang/Throwable;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    if-eqz v2, :cond_3

    monitor-exit p2

    goto :goto_3

    :cond_3
    :try_start_4
    iput-object p1, p0, La0/e;->v:Ljava/lang/Throwable;

    iget-object v2, p0, La0/e;->x:Lp/D;

    iget-object v3, v2, Lp/D;->a:[Ljava/lang/Object;

    iget v2, v2, Lp/D;->b:I

    :goto_1
    if-ge v4, v2, :cond_5

    aget-object v5, v3, v4

    check-cast v5, La0/d;

    iget-object v5, v5, La0/d;->b:LD7/h;

    if-eqz v5, :cond_4

    invoke-static {p1}, Ld7/a;->b(Ljava/lang/Throwable;)Ld7/m;

    move-result-object v6

    invoke-virtual {v5, v6}, LD7/h;->e(Ljava/lang/Object;)V

    :cond_4
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :catchall_2
    move-exception p1

    goto :goto_2

    :cond_5
    iget-object p1, p0, La0/e;->x:Lp/D;

    invoke-virtual {p1}, Lp/D;->c()V

    iget-object p1, p0, La0/e;->w:Li0/a;

    :cond_6
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v2

    ushr-int/lit8 v3, v2, 0x1b

    and-int/lit8 v3, v3, 0xf

    add-int/2addr v3, v1

    and-int/lit8 v3, v3, 0xf

    shl-int/lit8 v3, v3, 0x1b

    invoke-virtual {p1, v2, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    if-eqz v2, :cond_6

    monitor-exit p2

    goto :goto_3

    :goto_2
    monitor-exit p2

    throw p1

    :cond_7
    :goto_3
    invoke-virtual {v0}, LD7/h;->s()Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :goto_4
    monitor-exit v2

    throw p1
.end method

.method public final J(Lh7/g;)Lh7/h;
    .locals 0

    invoke-static {p0, p1}, LF4/r7;->b(Lh7/f;Lh7/g;)Lh7/h;

    move-result-object p1

    return-object p1
.end method

.method public final S(Lh7/h;)Lh7/h;
    .locals 0

    invoke-static {p0, p1}, LF4/r7;->c(Lh7/f;Lh7/h;)Lh7/h;

    move-result-object p1

    return-object p1
.end method

.method public final W(Lh7/g;)Lh7/f;
    .locals 0

    invoke-static {p0, p1}, LF4/r7;->a(Lh7/f;Lh7/g;)Lh7/f;

    move-result-object p1

    return-object p1
.end method

.method public final X(Ljava/lang/Object;Lr7/e;)Ljava/lang/Object;
    .locals 0

    invoke-interface {p2, p1, p0}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final a(J)V
    .locals 7

    iget-object v0, p0, La0/e;->u:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La0/e;->x:Lp/D;

    iget-object v2, p0, La0/e;->y:Lp/D;

    iput-object v2, p0, La0/e;->x:Lp/D;

    iput-object v1, p0, La0/e;->y:Lp/D;

    iget-object v2, p0, La0/e;->w:Li0/a;

    :cond_0
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v3

    ushr-int/lit8 v4, v3, 0x1b

    and-int/lit8 v4, v4, 0xf

    add-int/lit8 v4, v4, 0x1

    and-int/lit8 v4, v4, 0xf

    shl-int/lit8 v4, v4, 0x1b

    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v3

    if-eqz v3, :cond_0

    iget v2, v1, Lp/D;->b:I

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_3

    invoke-virtual {v1, v3}, Lp/D;->e(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La0/d;

    iget-object v5, v4, La0/d;->a:Lr7/c;

    if-nez v5, :cond_1

    goto :goto_2

    :cond_1
    iget-object v4, v4, La0/d;->b:LD7/h;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-eqz v4, :cond_2

    :try_start_1
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-interface {v5, v6}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v5

    :try_start_2
    invoke-static {v5}, Ld7/a;->b(Ljava/lang/Throwable;)Ld7/m;

    move-result-object v5

    :goto_1
    invoke-virtual {v4, v5}, LD7/h;->e(Ljava/lang/Object;)V

    :cond_2
    :goto_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :catchall_1
    move-exception p1

    goto :goto_3

    :cond_3
    invoke-virtual {v1}, Lp/D;->c()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    monitor-exit v0

    return-void

    :goto_3
    monitor-exit v0

    throw p1
.end method
