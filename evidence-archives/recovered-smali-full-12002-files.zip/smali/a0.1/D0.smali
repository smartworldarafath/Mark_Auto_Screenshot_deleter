.class public final La0/D0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD7/v;
.implements La0/A0;


# static fields
.field public static final w:La0/f;


# instance fields
.field public final t:Lh7/h;

.field public final u:La0/D0;

.field public volatile v:Lh7/h;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La0/f;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La0/D0;->w:La0/f;

    return-void
.end method

.method public constructor <init>(Lh7/h;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/D0;->t:Lh7/h;

    iput-object p0, p0, La0/D0;->u:La0/D0;

    return-void
.end method


# virtual methods
.method public final N()Lh7/h;
    .locals 6

    iget-object v0, p0, La0/D0;->v:Lh7/h;

    if-eqz v0, :cond_0

    sget-object v1, La0/D0;->w:La0/f;

    if-ne v0, v1, :cond_4

    :cond_0
    iget-object v0, p0, La0/D0;->t:Lh7/h;

    sget-object v1, Ll0/b;->u:LS6/b;

    invoke-interface {v0, v1}, Lh7/h;->W(Lh7/g;)Lh7/f;

    move-result-object v0

    check-cast v0, Ll0/b;

    if-eqz v0, :cond_1

    new-instance v1, La0/C0;

    invoke-direct {v1, v0, p0}, La0/C0;-><init>(Ll0/b;La0/D0;)V

    goto :goto_0

    :cond_1
    sget-object v1, Lh7/i;->t:Lh7/i;

    :goto_0
    iget-object v0, p0, La0/D0;->u:La0/D0;

    monitor-enter v0

    :try_start_0
    iget-object v2, p0, La0/D0;->v:Lh7/h;

    if-nez v2, :cond_2

    iget-object v2, p0, La0/D0;->t:Lh7/h;

    sget-object v3, LD7/s;->u:LD7/s;

    invoke-interface {v2, v3}, Lh7/h;->W(Lh7/g;)Lh7/f;

    move-result-object v3

    check-cast v3, LD7/c0;

    new-instance v4, LD7/e0;

    invoke-direct {v4, v3}, LD7/e0;-><init>(LD7/c0;)V

    invoke-interface {v2, v4}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object v2

    sget-object v3, Lh7/i;->t:Lh7/i;

    invoke-interface {v2, v3}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object v2

    invoke-interface {v2, v1}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object v1

    goto :goto_1

    :catchall_0
    move-exception v1

    goto :goto_2

    :cond_2
    sget-object v3, La0/D0;->w:La0/f;

    if-ne v2, v3, :cond_3

    iget-object v2, p0, La0/D0;->t:Lh7/h;

    sget-object v3, LD7/s;->u:LD7/s;

    invoke-interface {v2, v3}, Lh7/h;->W(Lh7/g;)Lh7/f;

    move-result-object v3

    check-cast v3, LD7/c0;

    new-instance v4, LD7/e0;

    invoke-direct {v4, v3}, LD7/e0;-><init>(LD7/c0;)V

    new-instance v3, La0/J;

    const/4 v5, 0x0

    invoke-direct {v3, v5}, La0/J;-><init>(I)V

    invoke-virtual {v4, v3}, LD7/k0;->r(Ljava/lang/Object;)Z

    invoke-interface {v2, v4}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object v2

    sget-object v3, Lh7/i;->t:Lh7/i;

    invoke-interface {v2, v3}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object v2

    invoke-interface {v2, v1}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object v1

    goto :goto_1

    :cond_3
    move-object v1, v2

    :goto_1
    iput-object v1, p0, La0/D0;->v:Lh7/h;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    move-object v0, v1

    :cond_4
    invoke-static {v0}, Ls7/j;->b(Ljava/lang/Object;)V

    return-object v0

    :goto_2
    monitor-exit v0

    throw v1
.end method

.method public final a()V
    .locals 0

    invoke-virtual {p0}, La0/D0;->c()V

    return-void
.end method

.method public final b()V
    .locals 0

    invoke-virtual {p0}, La0/D0;->c()V

    return-void
.end method

.method public final c()V
    .locals 4

    iget-object v0, p0, La0/D0;->u:La0/D0;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La0/D0;->v:Lh7/h;

    if-nez v1, :cond_0

    sget-object v1, La0/D0;->w:La0/f;

    iput-object v1, p0, La0/D0;->v:Lh7/h;

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_0
    new-instance v2, La0/J;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, La0/J;-><init>(I)V

    invoke-static {v1, v2}, LD7/y;->h(Lh7/h;Ljava/util/concurrent/CancellationException;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0

    throw v1
.end method

.method public final d()V
    .locals 0

    return-void
.end method
