.class public final La0/T0;
.super Lj7/i;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public final synthetic A:LG7/i;

.field public x:I

.field public synthetic y:Ljava/lang/Object;

.field public final synthetic z:Lh7/h;


# direct methods
.method public constructor <init>(Lh7/h;LG7/i;Lh7/c;)V
    .locals 0

    iput-object p1, p0, La0/T0;->z:Lh7/h;

    iput-object p2, p0, La0/T0;->A:LG7/i;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lj7/i;-><init>(ILh7/c;)V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, La0/p0;

    check-cast p2, Lh7/c;

    invoke-virtual {p0, p2, p1}, La0/T0;->n(Lh7/c;Ljava/lang/Object;)Lh7/c;

    move-result-object p1

    check-cast p1, La0/T0;

    sget-object p2, Ld7/z;->a:Ld7/z;

    invoke-virtual {p1, p2}, La0/T0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final n(Lh7/c;Ljava/lang/Object;)Lh7/c;
    .locals 3

    new-instance v0, La0/T0;

    iget-object v1, p0, La0/T0;->z:Lh7/h;

    iget-object v2, p0, La0/T0;->A:LG7/i;

    invoke-direct {v0, v1, v2, p1}, La0/T0;-><init>(Lh7/h;LG7/i;Lh7/c;)V

    iput-object p2, v0, La0/T0;->y:Ljava/lang/Object;

    return-object v0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    iget v0, p0, La0/T0;->x:I

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    if-eq v0, v2, :cond_1

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    :goto_0
    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    goto :goto_2

    :cond_2
    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    iget-object p1, p0, La0/T0;->y:Ljava/lang/Object;

    check-cast p1, La0/p0;

    sget-object v0, Lh7/i;->t:Lh7/i;

    iget-object v3, p0, La0/T0;->z:Lh7/h;

    invoke-static {v3, v0}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    iget-object v4, p0, La0/T0;->A:LG7/i;

    sget-object v5, Li7/a;->t:Li7/a;

    if-eqz v0, :cond_3

    new-instance v0, LW1/a;

    const/4 v1, 0x2

    invoke-direct {v0, p1, v1}, LW1/a;-><init>(La0/p0;I)V

    iput v2, p0, La0/T0;->x:I

    invoke-interface {v4, v0, p0}, LG7/i;->b(LG7/j;Lh7/c;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_4

    goto :goto_1

    :cond_3
    new-instance v0, La0/S0;

    const/4 v2, 0x0

    invoke-direct {v0, v4, p1, v2}, La0/S0;-><init>(LG7/i;La0/p0;Lh7/c;)V

    iput v1, p0, La0/T0;->x:I

    invoke-static {v3, v0, p0}, LD7/y;->G(Lh7/h;Lr7/e;Lh7/c;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_4

    :goto_1
    return-object v5

    :cond_4
    :goto_2
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1
.end method
