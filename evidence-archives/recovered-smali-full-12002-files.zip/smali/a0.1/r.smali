.class public final La0/r;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public A:I

.field public B:I

.field public C:Z

.field public final D:La0/q;

.field public final E:Ljava/util/ArrayList;

.field public F:Z

.field public G:La0/E0;

.field public H:La0/F0;

.field public I:La0/I0;

.field public J:Z

.field public K:La0/n0;

.field public L:Lb0/a;

.field public final M:Lb0/b;

.field public N:La0/a;

.field public O:Lb0/c;

.field public P:LA1/c;

.field public final Q:Ll0/b;

.field public final R:Lh7/h;

.field public S:Z

.field public T:J

.field public U:La0/w;

.field public final a:LL0/F0;

.field public final b:La0/u;

.field public final c:La0/F0;

.field public final d:Lp/K;

.field public final e:Lb0/a;

.field public final f:Lb0/a;

.field public final g:LW2/g;

.field public final h:La0/x;

.field public final i:Ljava/util/ArrayList;

.field public j:La0/m0;

.field public k:I

.field public l:I

.field public m:I

.field public final n:LL0/v;

.field public o:[I

.field public p:Lp/u;

.field public q:Z

.field public r:Z

.field public final s:Ljava/util/ArrayList;

.field public final t:LL0/v;

.field public u:La0/n0;

.field public v:Lp/w;

.field public w:Z

.field public final x:LL0/v;

.field public y:Z

.field public z:I


# direct methods
.method public constructor <init>(LL0/F0;La0/u;La0/F0;Lp/K;Lb0/a;Lb0/a;LW2/g;La0/x;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/r;->a:LL0/F0;

    iput-object p2, p0, La0/r;->b:La0/u;

    iput-object p3, p0, La0/r;->c:La0/F0;

    iput-object p4, p0, La0/r;->d:Lp/K;

    iput-object p5, p0, La0/r;->e:Lb0/a;

    iput-object p6, p0, La0/r;->f:Lb0/a;

    iput-object p7, p0, La0/r;->g:LW2/g;

    iput-object p8, p0, La0/r;->h:La0/x;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, La0/r;->i:Ljava/util/ArrayList;

    new-instance p1, LL0/v;

    invoke-direct {p1}, LL0/v;-><init>()V

    iput-object p1, p0, La0/r;->n:LL0/v;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, La0/r;->s:Ljava/util/ArrayList;

    new-instance p1, LL0/v;

    invoke-direct {p1}, LL0/v;-><init>()V

    iput-object p1, p0, La0/r;->t:LL0/v;

    sget-object p1, Li0/h;->w:Li0/h;

    iput-object p1, p0, La0/r;->u:La0/n0;

    new-instance p1, LL0/v;

    invoke-direct {p1}, LL0/v;-><init>()V

    iput-object p1, p0, La0/r;->x:LL0/v;

    const/4 p1, -0x1

    iput p1, p0, La0/r;->z:I

    invoke-virtual {p2}, La0/u;->f()Z

    move-result p1

    const/4 p4, 0x0

    const/4 p6, 0x1

    if-nez p1, :cond_1

    invoke-virtual {p2}, La0/u;->d()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    move p1, p4

    goto :goto_1

    :cond_1
    :goto_0
    move p1, p6

    :goto_1
    iput-boolean p1, p0, La0/r;->C:Z

    new-instance p1, La0/q;

    const/4 p7, 0x0

    invoke-direct {p1, p7, p0}, La0/q;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, La0/r;->D:La0/q;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, La0/r;->E:Ljava/util/ArrayList;

    invoke-virtual {p3}, La0/F0;->e()La0/E0;

    move-result-object p1

    invoke-virtual {p1}, La0/E0;->c()V

    iput-object p1, p0, La0/r;->G:La0/E0;

    new-instance p1, La0/F0;

    invoke-direct {p1}, La0/F0;-><init>()V

    invoke-virtual {p2}, La0/u;->f()Z

    move-result p3

    if-eqz p3, :cond_2

    invoke-virtual {p1}, La0/F0;->c()V

    :cond_2
    invoke-virtual {p2}, La0/u;->d()Z

    move-result p3

    if-eqz p3, :cond_3

    new-instance p3, Lp/w;

    invoke-direct {p3}, Lp/w;-><init>()V

    iput-object p3, p1, La0/F0;->D:Lp/w;

    :cond_3
    iput-object p1, p0, La0/r;->H:La0/F0;

    invoke-virtual {p1}, La0/F0;->f()La0/I0;

    move-result-object p1

    invoke-virtual {p1, p6}, La0/I0;->e(Z)V

    iput-object p1, p0, La0/r;->I:La0/I0;

    new-instance p1, Lb0/b;

    invoke-direct {p1, p0, p5}, Lb0/b;-><init>(La0/r;Lb0/a;)V

    iput-object p1, p0, La0/r;->M:Lb0/b;

    iget-object p1, p0, La0/r;->H:La0/F0;

    invoke-virtual {p1}, La0/F0;->e()La0/E0;

    move-result-object p1

    :try_start_0
    invoke-virtual {p1, p4}, La0/E0;->a(I)La0/a;

    move-result-object p3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p1}, La0/E0;->c()V

    iput-object p3, p0, La0/r;->N:La0/a;

    new-instance p1, Lb0/c;

    invoke-direct {p1}, Lb0/c;-><init>()V

    iput-object p1, p0, La0/r;->O:Lb0/c;

    new-instance p1, Ll0/b;

    invoke-direct {p1, p0}, Ll0/b;-><init>(La0/r;)V

    iput-object p1, p0, La0/r;->Q:Ll0/b;

    invoke-virtual {p2}, La0/u;->j()Lh7/h;

    move-result-object p1

    invoke-virtual {p0}, La0/r;->y()Ll0/b;

    move-result-object p2

    if-eqz p2, :cond_4

    goto :goto_2

    :cond_4
    sget-object p2, Lh7/i;->t:Lh7/i;

    :goto_2
    invoke-interface {p1, p2}, Lh7/h;->S(Lh7/h;)Lh7/h;

    move-result-object p1

    iput-object p1, p0, La0/r;->R:Lh7/h;

    return-void

    :catchall_0
    move-exception p2

    invoke-virtual {p1}, La0/E0;->c()V

    throw p2
.end method

.method public static final M(La0/r;IZI)I
    .locals 9

    iget-object v0, p0, La0/r;->G:La0/E0;

    invoke-virtual {v0, p1}, La0/E0;->j(I)Z

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_6

    invoke-virtual {v0, p1}, La0/E0;->i(I)I

    move-result p2

    iget-object p3, v0, La0/E0;->b:[I

    invoke-virtual {v0, p3, p1}, La0/E0;->p([II)Ljava/lang/Object;

    move-result-object p3

    const/16 v1, 0xce

    if-ne p2, v1, :cond_4

    sget-object p2, La0/s;->e:La0/b0;

    invoke-static {p3, p2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_4

    invoke-virtual {v0, p1, v2}, La0/E0;->h(II)Ljava/lang/Object;

    move-result-object p2

    instance-of p3, p2, La0/o;

    if-eqz p3, :cond_0

    check-cast p2, La0/o;

    goto :goto_0

    :cond_0
    const/4 p2, 0x0

    :goto_0
    if-eqz p2, :cond_3

    iget-object p2, p2, La0/o;->t:La0/p;

    iget-object p2, p2, La0/p;->e:Ljava/util/LinkedHashSet;

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_1
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_3

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, La0/r;

    iget-object v1, p3, La0/r;->c:La0/F0;

    iget v4, v1, La0/F0;->u:I

    if-lez v4, :cond_2

    iget-object v1, v1, La0/F0;->t:[I

    aget v1, v1, v3

    const/high16 v4, 0x4000000

    and-int/2addr v1, v4

    if-eqz v1, :cond_2

    iget-object v1, p3, La0/r;->h:La0/x;

    iget-object v4, v1, La0/x;->w:Ljava/lang/Object;

    monitor-enter v4

    :try_start_0
    invoke-virtual {v1}, La0/x;->p()V

    iget-object v5, v1, La0/x;->G:Lp/H;

    invoke-static {}, LF4/I5;->b()Lp/H;

    move-result-object v6

    iput-object v6, v1, La0/x;->G:Lp/H;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    iget-object v6, v1, La0/x;->O:La0/r;

    invoke-virtual {v6, v5}, La0/r;->c0(Lp/H;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    monitor-exit v4

    new-instance v1, Lb0/a;

    invoke-direct {v1}, Lb0/a;-><init>()V

    iput-object v1, p3, La0/r;->L:Lb0/a;

    iget-object v4, p3, La0/r;->c:La0/F0;

    invoke-virtual {v4}, La0/F0;->e()La0/E0;

    move-result-object v4

    :try_start_2
    iput-object v4, p3, La0/r;->G:La0/E0;

    iget-object v5, p3, La0/r;->M:Lb0/b;

    iget-object v6, v5, Lb0/b;->b:Lb0/a;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    iput-object v1, v5, Lb0/b;->b:Lb0/a;

    invoke-virtual {p3, v2}, La0/r;->L(I)V

    iget-object v1, p3, La0/r;->M:Lb0/b;

    invoke-virtual {v1}, Lb0/b;->b()V

    iget-boolean v7, v1, Lb0/b;->c:Z

    if-eqz v7, :cond_1

    iget-object v7, v1, Lb0/b;->b:Lb0/a;

    iget-object v7, v7, Lb0/a;->a:Lb0/L;

    sget-object v8, Lb0/C;->c:Lb0/C;

    invoke-virtual {v7, v8}, Lb0/L;->e(Lb0/J;)V

    iget-boolean v7, v1, Lb0/b;->c:Z

    if-eqz v7, :cond_1

    invoke-virtual {v1, v2}, Lb0/b;->d(Z)V

    invoke-virtual {v1, v2}, Lb0/b;->d(Z)V

    iget-object v7, v1, Lb0/b;->b:Lb0/a;

    iget-object v7, v7, Lb0/a;->a:Lb0/L;

    sget-object v8, Lb0/m;->c:Lb0/m;

    invoke-virtual {v7, v8}, Lb0/L;->e(Lb0/J;)V

    iput-boolean v2, v1, Lb0/b;->c:Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :cond_1
    :try_start_4
    iput-object v6, v5, Lb0/b;->b:Lb0/a;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    invoke-virtual {v4}, La0/E0;->c()V

    goto :goto_3

    :catchall_0
    move-exception p0

    goto :goto_2

    :catchall_1
    move-exception p0

    :try_start_5
    iput-object v6, v5, Lb0/b;->b:Lb0/a;

    throw p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :goto_2
    invoke-virtual {v4}, La0/E0;->c()V

    throw p0

    :catchall_2
    move-exception p0

    :try_start_6
    iput-object v5, v1, La0/x;->G:Lp/H;

    throw p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    :catchall_3
    move-exception p0

    monitor-exit v4

    throw p0

    :cond_2
    :goto_3
    iget-object v1, p0, La0/r;->b:La0/u;

    iget-object p3, p3, La0/r;->h:La0/x;

    invoke-virtual {v1, p3}, La0/u;->q(La0/x;)V

    goto/16 :goto_1

    :cond_3
    invoke-virtual {v0, p1}, La0/E0;->o(I)I

    move-result p0

    return p0

    :cond_4
    invoke-virtual {v0, p1}, La0/E0;->l(I)Z

    move-result p0

    if-eqz p0, :cond_5

    goto/16 :goto_8

    :cond_5
    invoke-virtual {v0, p1}, La0/E0;->o(I)I

    move-result p0

    return p0

    :cond_6
    invoke-virtual {v0, p1}, La0/E0;->d(I)Z

    move-result v1

    if-eqz v1, :cond_e

    iget-object v1, v0, La0/E0;->b:[I

    mul-int/lit8 v4, p1, 0x5

    add-int/lit8 v4, v4, 0x3

    aget v1, v1, v4

    add-int/2addr v1, p1

    add-int/lit8 v4, p1, 0x1

    move v5, v2

    :goto_4
    if-ge v4, v1, :cond_c

    invoke-virtual {v0, v4}, La0/E0;->l(I)Z

    move-result v6

    if-eqz v6, :cond_7

    iget-object v7, p0, La0/r;->M:Lb0/b;

    invoke-virtual {v7}, Lb0/b;->c()V

    iget-object v7, p0, La0/r;->M:Lb0/b;

    invoke-virtual {v0, v4}, La0/E0;->n(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7}, Lb0/b;->c()V

    iget-object v7, v7, Lb0/b;->h:Ljava/util/ArrayList;

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    if-nez v6, :cond_9

    if-eqz p2, :cond_8

    goto :goto_5

    :cond_8
    move v7, v2

    goto :goto_6

    :cond_9
    :goto_5
    move v7, v3

    :goto_6
    if-eqz v6, :cond_a

    move v8, v2

    goto :goto_7

    :cond_a
    add-int v8, p3, v5

    :goto_7
    invoke-static {p0, v4, v7, v8}, La0/r;->M(La0/r;IZI)I

    move-result v7

    add-int/2addr v5, v7

    if-eqz v6, :cond_b

    iget-object v6, p0, La0/r;->M:Lb0/b;

    invoke-virtual {v6}, Lb0/b;->c()V

    iget-object v6, p0, La0/r;->M:Lb0/b;

    invoke-virtual {v6}, Lb0/b;->a()V

    :cond_b
    iget-object v6, v0, La0/E0;->b:[I

    mul-int/lit8 v7, v4, 0x5

    add-int/lit8 v7, v7, 0x3

    aget v6, v6, v7

    add-int/2addr v4, v6

    goto :goto_4

    :cond_c
    invoke-virtual {v0, p1}, La0/E0;->l(I)Z

    move-result p0

    if-eqz p0, :cond_d

    goto :goto_8

    :cond_d
    return v5

    :cond_e
    invoke-virtual {v0, p1}, La0/E0;->l(I)Z

    move-result p0

    if-eqz p0, :cond_f

    :goto_8
    return v3

    :cond_f
    invoke-virtual {v0, p1}, La0/E0;->o(I)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final A(Ljava/util/ArrayList;)V
    .locals 4

    iget-object v0, p0, La0/r;->f:Lb0/a;

    iget-object v1, p0, La0/r;->M:Lb0/b;

    iget-object v2, v1, Lb0/b;->b:Lb0/a;

    :try_start_0
    iput-object v0, v1, Lb0/b;->b:Lb0/a;

    iget-object v0, v0, Lb0/a;->a:Lb0/L;

    sget-object v3, Lb0/A;->c:Lb0/A;

    invoke-virtual {v0, v3}, Lb0/L;->e(Lb0/J;)V

    invoke-interface {p1}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v3, 0x0

    if-gtz v0, :cond_0

    iget-object p1, v1, Lb0/b;->b:Lb0/a;

    iget-object p1, p1, Lb0/a;->a:Lb0/L;

    sget-object v0, Lb0/n;->c:Lb0/n;

    invoke-virtual {p1, v0}, Lb0/L;->e(Lb0/J;)V

    iput v3, v1, Lb0/b;->f:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iput-object v2, v1, Lb0/b;->b:Lb0/a;

    return-void

    :catchall_0
    move-exception p1

    goto :goto_0

    :cond_0
    :try_start_1
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ld7/k;

    iget-object v0, p1, Ld7/k;->t:Ljava/lang/Object;

    check-cast v0, La0/Y;

    iget-object p1, p1, Ld7/k;->u:Ljava/lang/Object;

    check-cast p1, La0/Y;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p1, 0x0

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    iput-object v2, v1, Lb0/b;->b:Lb0/a;

    throw p1
.end method

.method public final B(La0/n0;Ljava/lang/Object;)V
    .locals 8

    const v0, 0x78cc281

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, v0, v1, v2, v2}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    invoke-virtual {p0, p2}, La0/r;->h0(Ljava/lang/Object;)V

    iget-wide v3, p0, La0/r;->T:J

    int-to-long v5, v0

    :try_start_0
    iput-wide v5, p0, La0/r;->T:J

    iget-boolean v0, p0, La0/r;->S:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, La0/r;->I:La0/I0;

    invoke-static {v0}, La0/I0;->y(La0/I0;)V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_0
    :goto_0
    iget-boolean v0, p0, La0/r;->S:Z

    const/4 v5, 0x1

    if-eqz v0, :cond_2

    :cond_1
    move v0, v1

    goto :goto_1

    :cond_2
    iget-object v0, p0, La0/r;->G:La0/E0;

    invoke-virtual {v0}, La0/E0;->f()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    move v0, v5

    :goto_1
    if-eqz v0, :cond_3

    invoke-virtual {p0, p1}, La0/r;->I(La0/n0;)V

    :cond_3
    sget-object v6, La0/s;->c:La0/b0;

    const/16 v7, 0xca

    invoke-virtual {p0, v7, v1, v6, p1}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    iput-object v2, p0, La0/r;->K:La0/n0;

    iget-boolean p1, p0, La0/r;->w:Z

    iput-boolean v0, p0, La0/r;->w:Z

    new-instance v0, LH6/u;

    const/4 v6, 0x6

    invoke-direct {v0, v6, p2}, LH6/u;-><init>(ILjava/lang/Object;)V

    new-instance p2, Li0/d;

    const v6, 0x12d6006f

    invoke-direct {p2, v6, v0, v5}, Li0/d;-><init>(ILjava/lang/Object;Z)V

    invoke-static {p0, p2}, Li0/i;->c(La0/r;Lr7/e;)V

    iput-boolean p1, p0, La0/r;->w:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0, v1}, La0/r;->p(Z)V

    iput-object v2, p0, La0/r;->K:La0/n0;

    iput-wide v3, p0, La0/r;->T:J

    invoke-virtual {p0, v1}, La0/r;->p(Z)V

    return-void

    :goto_2
    :try_start_1
    new-instance p2, La0/n;

    const/4 v0, 0x2

    invoke-direct {p2, v0, p0}, La0/n;-><init>(ILa0/r;)V

    invoke-static {p1, p2}, LH4/Y;->a(Ljava/lang/Throwable;Lr7/a;)Z

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p1

    invoke-virtual {p0, v1}, La0/r;->p(Z)V

    iput-object v2, p0, La0/r;->K:La0/n0;

    iput-wide v3, p0, La0/r;->T:J

    invoke-virtual {p0, v1}, La0/r;->p(Z)V

    throw p1
.end method

.method public final C()Ljava/lang/Object;
    .locals 3

    iget-boolean v0, p0, La0/r;->S:Z

    sget-object v1, La0/m;->a:La0/U;

    if-eqz v0, :cond_0

    iget-boolean v0, p0, La0/r;->r:Z

    if-eqz v0, :cond_1

    const-string v0, "A call to createNode(), emitNode() or useNode() expected"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    return-object v1

    :cond_0
    iget-object v0, p0, La0/r;->G:La0/E0;

    invoke-virtual {v0}, La0/E0;->m()Ljava/lang/Object;

    move-result-object v0

    iget-boolean v2, p0, La0/r;->y:Z

    if-eqz v2, :cond_2

    instance-of v2, v0, La0/o;

    if-nez v2, :cond_2

    :cond_1
    return-object v1

    :cond_2
    return-object v0
.end method

.method public final D()Ljava/util/List;
    .locals 5

    iget-object v0, p0, La0/r;->b:La0/u;

    invoke-virtual {v0}, La0/u;->h()La0/t;

    move-result-object v1

    if-eqz v1, :cond_0

    check-cast v1, La0/x;

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    if-nez v1, :cond_1

    goto :goto_1

    :cond_1
    iget-object v1, v1, La0/x;->y:La0/F0;

    invoke-virtual {v1}, La0/F0;->e()La0/E0;

    move-result-object v2

    :try_start_0
    iget v3, v2, La0/E0;->c:I

    const/4 v4, 0x0

    invoke-static {v2, v0, v4, v3}, LH4/X;->b(La0/E0;La0/u;II)Ljava/lang/Integer;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    invoke-virtual {v2}, La0/E0;->c()V

    if-eqz v0, :cond_2

    invoke-virtual {v1}, La0/F0;->e()La0/E0;

    move-result-object v1

    :try_start_1
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v0, v2}, LH4/X;->c(La0/E0;ILjava/lang/Integer;)Ljava/util/ArrayList;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-virtual {v1}, La0/E0;->c()V

    return-object v0

    :catchall_0
    move-exception v0

    invoke-virtual {v1}, La0/E0;->c()V

    throw v0

    :cond_2
    :goto_1
    sget-object v0, Le7/t;->t:Le7/t;

    return-object v0

    :catchall_1
    move-exception v0

    invoke-virtual {v2}, La0/E0;->c()V

    throw v0
.end method

.method public final E(I)I
    .locals 3

    iget-object v0, p0, La0/r;->G:La0/E0;

    invoke-virtual {v0, p1}, La0/E0;->q(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    const/4 v1, 0x0

    :goto_0
    if-ge v0, p1, :cond_1

    iget-object v2, p0, La0/r;->G:La0/E0;

    invoke-virtual {v2, v0}, La0/E0;->k(I)Z

    move-result v2

    if-nez v2, :cond_0

    add-int/lit8 v1, v1, 0x1

    :cond_0
    iget-object v2, p0, La0/r;->G:La0/E0;

    iget-object v2, v2, La0/E0;->b:[I

    invoke-static {v2, v0}, La0/H0;->a([II)I

    move-result v2

    add-int/2addr v0, v2

    goto :goto_0

    :cond_1
    return v1
.end method

.method public final F(La0/x;La0/x;Ljava/lang/Integer;Ljava/util/List;Lr7/a;)Ljava/lang/Object;
    .locals 8

    iget-boolean v0, p0, La0/r;->F:Z

    iget v1, p0, La0/r;->k:I

    const/4 v2, 0x1

    :try_start_0
    iput-boolean v2, p0, La0/r;->F:Z

    const/4 v2, 0x0

    iput v2, p0, La0/r;->k:I

    invoke-interface {p4}, Ljava/util/Collection;->size()I

    move-result v3

    move v4, v2

    :goto_0
    const/4 v5, 0x0

    if-ge v4, v3, :cond_1

    invoke-interface {p4, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ld7/k;

    iget-object v7, v6, Ld7/k;->t:Ljava/lang/Object;

    check-cast v7, La0/r0;

    iget-object v6, v6, Ld7/k;->u:Ljava/lang/Object;

    if-eqz v6, :cond_0

    invoke-virtual {p0, v7, v6}, La0/r;->b0(La0/r0;Ljava/lang/Object;)Z

    goto :goto_1

    :catchall_0
    move-exception p1

    goto :goto_4

    :cond_0
    invoke-virtual {p0, v7, v5}, La0/r;->b0(La0/r0;Ljava/lang/Object;)Z

    :goto_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    if-eqz p1, :cond_4

    if-eqz p3, :cond_2

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    goto :goto_2

    :cond_2
    const/4 p3, -0x1

    :goto_2
    if-eqz p2, :cond_3

    invoke-virtual {p2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p4

    if-nez p4, :cond_3

    if-ltz p3, :cond_3

    iput-object p2, p1, La0/x;->K:La0/x;

    iput p3, p1, La0/x;->L:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-interface {p5}, Lr7/a;->a()Ljava/lang/Object;

    move-result-object p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iput-object v5, p1, La0/x;->K:La0/x;

    iput v2, p1, La0/x;->L:I

    goto :goto_3

    :catchall_1
    move-exception p2

    iput-object v5, p1, La0/x;->K:La0/x;

    iput v2, p1, La0/x;->L:I

    throw p2

    :cond_3
    invoke-interface {p5}, Lr7/a;->a()Ljava/lang/Object;

    move-result-object p2

    :goto_3
    if-nez p2, :cond_5

    :cond_4
    invoke-interface {p5}, Lr7/a;->a()Ljava/lang/Object;

    move-result-object p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_5
    iput-boolean v0, p0, La0/r;->F:Z

    iput v1, p0, La0/r;->k:I

    return-object p2

    :goto_4
    iput-boolean v0, p0, La0/r;->F:Z

    iput v1, p0, La0/r;->k:I

    throw p1
.end method

.method public final G()V
    .locals 37

    move-object/from16 v1, p0

    iget-boolean v0, v1, La0/r;->F:Z

    const/4 v2, 0x1

    iput-boolean v2, v1, La0/r;->F:Z

    iget-object v3, v1, La0/r;->G:La0/E0;

    iget v4, v3, La0/E0;->i:I

    iget-object v5, v3, La0/E0;->b:[I

    mul-int/lit8 v6, v4, 0x5

    const/4 v7, 0x3

    add-int/2addr v6, v7

    aget v5, v5, v6

    add-int/2addr v5, v4

    iget v8, v1, La0/r;->k:I

    iget-wide v9, v1, La0/r;->T:J

    iget v11, v1, La0/r;->l:I

    iget v12, v1, La0/r;->m:I

    iget v3, v3, La0/E0;->g:I

    iget-object v13, v1, La0/r;->s:Ljava/util/ArrayList;

    invoke-static {v3, v13}, La0/s;->e(ILjava/util/List;)I

    move-result v3

    if-gez v3, :cond_0

    add-int/lit8 v3, v3, 0x1

    neg-int v3, v3

    :cond_0
    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    move-result v14

    if-ge v3, v14, :cond_1

    invoke-virtual {v13, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La0/N;

    iget v14, v3, La0/N;->b:I

    if-ge v14, v5, :cond_1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    :goto_0
    move/from16 v17, v7

    const/16 v16, 0x0

    move v7, v4

    :goto_1
    if-eqz v3, :cond_2a

    move/from16 v18, v2

    iget-object v2, v3, La0/N;->a:La0/r0;

    iget v15, v3, La0/N;->b:I

    invoke-static {v15, v13}, La0/s;->e(ILjava/util/List;)I

    move-result v14

    if-ltz v14, :cond_2

    invoke-virtual {v13, v14}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, La0/N;

    :cond_2
    iget-object v3, v3, La0/N;->c:Ljava/lang/Object;

    const-wide/16 v19, 0x80

    const-wide/16 v21, 0xff

    const/16 v23, 0x7

    const-wide v24, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    if-nez v3, :cond_5

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move/from16 v27, v6

    :cond_3
    :goto_2
    move/from16 v32, v8

    move-wide/from16 v33, v9

    move/from16 v30, v11

    move/from16 v31, v12

    :cond_4
    :goto_3
    move/from16 v3, v18

    goto/16 :goto_6

    :cond_5
    const/16 v26, 0x8

    iget-object v14, v2, La0/r0;->g:Lp/H;

    if-nez v14, :cond_6

    move/from16 v27, v6

    goto :goto_2

    :cond_6
    move/from16 v27, v6

    instance-of v6, v3, La0/E;

    if-eqz v6, :cond_7

    check-cast v3, La0/E;

    invoke-static {v3, v14}, La0/r0;->a(La0/E;Lp/H;)Z

    move-result v3

    move/from16 v32, v8

    move-wide/from16 v33, v9

    move/from16 v30, v11

    move/from16 v31, v12

    goto/16 :goto_6

    :cond_7
    instance-of v6, v3, Lp/I;

    if-eqz v6, :cond_3

    check-cast v3, Lp/I;

    invoke-virtual {v3}, Lp/I;->h()Z

    move-result v6

    if-eqz v6, :cond_c

    iget-object v6, v3, Lp/I;->b:[Ljava/lang/Object;

    iget-object v3, v3, Lp/I;->a:[J

    move-object/from16 v28, v6

    array-length v6, v3

    add-int/lit8 v6, v6, -0x2

    if-ltz v6, :cond_c

    move-object/from16 v29, v3

    move/from16 v30, v11

    move/from16 v31, v12

    const/4 v3, 0x0

    :goto_4
    aget-wide v11, v29, v3

    move/from16 v32, v8

    move-wide/from16 v33, v9

    not-long v8, v11

    shl-long v8, v8, v23

    and-long/2addr v8, v11

    and-long v8, v8, v24

    cmp-long v8, v8, v24

    if-eqz v8, :cond_b

    sub-int v8, v3, v6

    not-int v8, v8

    ushr-int/lit8 v8, v8, 0x1f

    rsub-int/lit8 v8, v8, 0x8

    const/4 v9, 0x0

    :goto_5
    if-ge v9, v8, :cond_a

    and-long v35, v11, v21

    cmp-long v10, v35, v19

    if-gez v10, :cond_8

    shl-int/lit8 v10, v3, 0x3

    add-int/2addr v10, v9

    aget-object v10, v28, v10

    move/from16 v35, v9

    instance-of v9, v10, La0/E;

    if-eqz v9, :cond_4

    check-cast v10, La0/E;

    invoke-static {v10, v14}, La0/r0;->a(La0/E;Lp/H;)Z

    move-result v9

    if-eqz v9, :cond_9

    goto :goto_3

    :cond_8
    move/from16 v35, v9

    :cond_9
    shr-long v11, v11, v26

    add-int/lit8 v9, v35, 0x1

    goto :goto_5

    :cond_a
    move/from16 v9, v26

    if-ne v8, v9, :cond_d

    :cond_b
    if-eq v3, v6, :cond_d

    add-int/lit8 v3, v3, 0x1

    move/from16 v8, v32

    move-wide/from16 v9, v33

    const/16 v26, 0x8

    goto :goto_4

    :cond_c
    move/from16 v32, v8

    move-wide/from16 v33, v9

    move/from16 v30, v11

    move/from16 v31, v12

    :cond_d
    const/4 v3, 0x0

    :goto_6
    if-eqz v3, :cond_20

    iget-object v3, v1, La0/r;->G:La0/E0;

    invoke-virtual {v3, v15}, La0/E0;->r(I)V

    iget-object v3, v1, La0/r;->G:La0/E0;

    iget v3, v3, La0/E0;->g:I

    invoke-virtual {v1, v7, v3, v4}, La0/r;->J(III)V

    iget-object v6, v1, La0/r;->G:La0/E0;

    invoke-virtual {v6, v3}, La0/E0;->q(I)I

    move-result v6

    :goto_7
    if-eq v6, v4, :cond_e

    iget-object v7, v1, La0/r;->G:La0/E0;

    invoke-virtual {v7, v6}, La0/E0;->l(I)Z

    move-result v7

    if-nez v7, :cond_e

    iget-object v7, v1, La0/r;->G:La0/E0;

    invoke-virtual {v7, v6}, La0/E0;->q(I)I

    move-result v6

    goto :goto_7

    :cond_e
    iget-object v7, v1, La0/r;->G:La0/E0;

    invoke-virtual {v7, v6}, La0/E0;->l(I)Z

    move-result v7

    if-eqz v7, :cond_f

    const/4 v7, 0x0

    goto :goto_8

    :cond_f
    move/from16 v7, v32

    :goto_8
    if-ne v6, v3, :cond_10

    goto :goto_b

    :cond_10
    invoke-virtual {v1, v6}, La0/r;->i0(I)I

    move-result v8

    iget-object v9, v1, La0/r;->G:La0/E0;

    invoke-virtual {v9, v3}, La0/E0;->o(I)I

    move-result v9

    sub-int/2addr v8, v9

    add-int/2addr v8, v7

    :cond_11
    if-ge v7, v8, :cond_13

    if-eq v6, v15, :cond_13

    add-int/lit8 v6, v6, 0x1

    :goto_9
    if-ge v6, v15, :cond_13

    iget-object v9, v1, La0/r;->G:La0/E0;

    iget-object v10, v9, La0/E0;->b:[I

    mul-int/lit8 v11, v6, 0x5

    add-int/lit8 v11, v11, 0x3

    aget v10, v10, v11

    add-int/2addr v10, v6

    if-lt v15, v10, :cond_11

    invoke-virtual {v9, v6}, La0/E0;->l(I)Z

    move-result v9

    if-eqz v9, :cond_12

    move/from16 v6, v18

    goto :goto_a

    :cond_12
    invoke-virtual {v1, v6}, La0/r;->i0(I)I

    move-result v6

    :goto_a
    add-int/2addr v7, v6

    move v6, v10

    goto :goto_9

    :cond_13
    :goto_b
    iput v7, v1, La0/r;->k:I

    invoke-virtual {v1, v3}, La0/r;->E(I)I

    move-result v6

    iput v6, v1, La0/r;->m:I

    iget-object v6, v1, La0/r;->G:La0/E0;

    invoke-virtual {v6, v3}, La0/E0;->q(I)I

    move-result v6

    const/4 v7, 0x0

    int-to-long v8, v7

    move/from16 v10, v17

    const/4 v7, 0x0

    :goto_c
    if-ltz v6, :cond_1c

    if-ne v6, v4, :cond_14

    move-wide/from16 v11, v33

    invoke-static {v11, v12, v7}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v6

    xor-long/2addr v8, v6

    move/from16 v16, v3

    goto/16 :goto_11

    :cond_14
    move-wide/from16 v11, v33

    iget-object v14, v1, La0/r;->G:La0/E0;

    invoke-virtual {v14, v6}, La0/E0;->k(I)Z

    move-result v15

    move/from16 v16, v3

    iget-object v3, v14, La0/E0;->b:[I

    if-eqz v15, :cond_17

    invoke-virtual {v14, v3, v6}, La0/E0;->p([II)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_16

    instance-of v14, v3, Ljava/lang/Enum;

    if-eqz v14, :cond_15

    check-cast v3, Ljava/lang/Enum;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    :goto_d
    move-wide/from16 v19, v8

    goto :goto_f

    :cond_15
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    goto :goto_d

    :cond_16
    move-wide/from16 v19, v8

    const/4 v3, 0x0

    goto :goto_f

    :cond_17
    invoke-virtual {v14, v6}, La0/E0;->i(I)I

    move-result v15

    move-wide/from16 v19, v8

    const/16 v8, 0xcf

    if-ne v15, v8, :cond_19

    invoke-virtual {v14, v3, v6}, La0/E0;->b([II)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_19

    sget-object v8, La0/m;->a:La0/U;

    invoke-virtual {v3, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_18

    goto :goto_e

    :cond_18
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    goto :goto_f

    :cond_19
    :goto_e
    move v3, v15

    :goto_f
    const v8, 0x78cc281

    if-ne v3, v8, :cond_1a

    int-to-long v8, v3

    invoke-static {v8, v9, v7}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v6

    xor-long v8, v19, v6

    goto :goto_11

    :cond_1a
    iget-object v8, v1, La0/r;->G:La0/E0;

    invoke-virtual {v8, v6}, La0/E0;->k(I)Z

    move-result v8

    if-eqz v8, :cond_1b

    const/4 v8, 0x0

    goto :goto_10

    :cond_1b
    invoke-virtual {v1, v6}, La0/r;->E(I)I

    move-result v8

    :goto_10
    int-to-long v14, v3

    invoke-static {v14, v15, v10}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v14

    xor-long v14, v19, v14

    int-to-long v8, v8

    invoke-static {v8, v9, v7}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v8

    xor-long/2addr v8, v14

    add-int/lit8 v10, v10, 0x6

    rem-int/lit8 v10, v10, 0x40

    add-int/lit8 v7, v7, 0x6

    rem-int/lit8 v7, v7, 0x40

    iget-object v3, v1, La0/r;->G:La0/E0;

    invoke-virtual {v3, v6}, La0/E0;->q(I)I

    move-result v6

    move-wide/from16 v33, v11

    move/from16 v3, v16

    goto/16 :goto_c

    :cond_1c
    move/from16 v16, v3

    move-wide/from16 v19, v8

    move-wide/from16 v11, v33

    :goto_11
    iput-wide v8, v1, La0/r;->T:J

    const/4 v3, 0x0

    iput-object v3, v1, La0/r;->K:La0/n0;

    iget-object v2, v2, La0/r0;->d:Lr7/e;

    if-eqz v2, :cond_1f

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v2, v1, v6}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-object v3, v1, La0/r;->K:La0/n0;

    iget-object v2, v1, La0/r;->G:La0/E0;

    iget-object v6, v2, La0/E0;->b:[I

    aget v6, v6, v27

    add-int/2addr v6, v4

    iget v7, v2, La0/E0;->g:I

    if-lt v7, v4, :cond_1d

    if-gt v7, v6, :cond_1d

    move/from16 v8, v18

    goto :goto_12

    :cond_1d
    const/4 v8, 0x0

    :goto_12
    if-nez v8, :cond_1e

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "Index "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, " is not a parent of "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, La0/s;->c(Ljava/lang/String;)V

    :cond_1e
    iput v4, v2, La0/E0;->i:I

    iput v6, v2, La0/E0;->h:I

    const/4 v7, 0x0

    iput v7, v2, La0/E0;->l:I

    iput v7, v2, La0/E0;->m:I

    move/from16 v28, v4

    move/from16 v29, v5

    move v3, v7

    move-wide/from16 v33, v11

    move/from16 v7, v16

    move/from16 v16, v18

    goto/16 :goto_1c

    :cond_1f
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "Invalid restart scope"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_20
    move-wide/from16 v11, v33

    const/4 v3, 0x0

    iget-object v6, v1, La0/r;->E:Ljava/util/ArrayList;

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v8, v1, La0/r;->g:LW2/g;

    invoke-virtual {v8}, LW2/g;->t()V

    iget-object v8, v2, La0/r0;->a:La0/x;

    if-eqz v8, :cond_26

    iget-object v9, v2, La0/r0;->f:Lp/C;

    if-eqz v9, :cond_26

    move/from16 v10, v18

    invoke-virtual {v2, v10}, La0/r0;->e(Z)V

    :try_start_0
    iget-object v10, v9, Lp/C;->b:[Ljava/lang/Object;

    iget-object v14, v9, Lp/C;->c:[I

    iget-object v9, v9, Lp/C;->a:[J

    array-length v15, v9

    add-int/lit8 v15, v15, -0x2

    if-ltz v15, :cond_25

    move-wide/from16 v33, v11

    const/4 v3, 0x0

    move-object v12, v10

    :goto_13
    aget-wide v10, v9, v3

    move/from16 v28, v4

    move/from16 v29, v5

    not-long v4, v10

    shl-long v4, v4, v23

    and-long/2addr v4, v10

    and-long v4, v4, v24

    cmp-long v4, v4, v24

    if-eqz v4, :cond_24

    sub-int v4, v3, v15

    not-int v4, v4

    ushr-int/lit8 v4, v4, 0x1f

    const/16 v26, 0x8

    rsub-int/lit8 v4, v4, 0x8

    const/4 v5, 0x0

    :goto_14
    if-ge v5, v4, :cond_22

    and-long v35, v10, v21

    cmp-long v35, v35, v19

    if-gez v35, :cond_21

    shl-int/lit8 v35, v3, 0x3

    add-int v35, v35, v5

    move/from16 v36, v5

    aget-object v5, v12, v35

    aget v35, v14, v35

    invoke-virtual {v8, v5}, La0/x;->z(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_15
    const/16 v5, 0x8

    goto :goto_16

    :catchall_0
    move-exception v0

    const/4 v3, 0x0

    goto :goto_1a

    :cond_21
    move/from16 v36, v5

    goto :goto_15

    :goto_16
    shr-long/2addr v10, v5

    add-int/lit8 v26, v36, 0x1

    move/from16 v5, v26

    goto :goto_14

    :cond_22
    const/16 v5, 0x8

    if-ne v4, v5, :cond_23

    goto :goto_18

    :cond_23
    :goto_17
    const/4 v3, 0x0

    goto :goto_19

    :cond_24
    const/16 v5, 0x8

    :goto_18
    if-eq v3, v15, :cond_23

    add-int/lit8 v3, v3, 0x1

    move/from16 v4, v28

    move/from16 v5, v29

    goto :goto_13

    :cond_25
    move/from16 v28, v4

    move/from16 v29, v5

    move-wide/from16 v33, v11

    goto :goto_17

    :goto_19
    invoke-virtual {v2, v3}, La0/r0;->e(Z)V

    goto :goto_1b

    :goto_1a
    invoke-virtual {v2, v3}, La0/r0;->e(Z)V

    throw v0

    :cond_26
    move/from16 v28, v4

    move/from16 v29, v5

    move-wide/from16 v33, v11

    const/4 v3, 0x0

    :goto_1b
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v18, 0x1

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :goto_1c
    iget-object v2, v1, La0/r;->G:La0/E0;

    iget v2, v2, La0/E0;->g:I

    invoke-static {v2, v13}, La0/s;->e(ILjava/util/List;)I

    move-result v2

    if-gez v2, :cond_27

    add-int/lit8 v2, v2, 0x1

    neg-int v2, v2

    :cond_27
    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_28

    invoke-virtual {v13, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La0/N;

    iget v4, v2, La0/N;->b:I

    move/from16 v5, v29

    if-ge v4, v5, :cond_29

    goto :goto_1d

    :cond_28
    move/from16 v5, v29

    :cond_29
    const/4 v2, 0x0

    :goto_1d
    move-object v3, v2

    move/from16 v2, v18

    move/from16 v6, v27

    move/from16 v4, v28

    move/from16 v11, v30

    move/from16 v12, v31

    move/from16 v8, v32

    move-wide/from16 v9, v33

    goto/16 :goto_1

    :cond_2a
    move/from16 v28, v4

    move/from16 v32, v8

    move-wide/from16 v33, v9

    move/from16 v30, v11

    move/from16 v31, v12

    if-eqz v16, :cond_2b

    move/from16 v2, v28

    invoke-virtual {v1, v7, v2, v2}, La0/r;->J(III)V

    iget-object v3, v1, La0/r;->G:La0/E0;

    invoke-virtual {v3}, La0/E0;->t()V

    invoke-virtual {v1, v2}, La0/r;->i0(I)I

    move-result v2

    add-int v8, v32, v2

    iput v8, v1, La0/r;->k:I

    add-int v11, v30, v2

    iput v11, v1, La0/r;->l:I

    move/from16 v2, v31

    iput v2, v1, La0/r;->m:I

    :goto_1e
    move-wide/from16 v11, v33

    goto :goto_1f

    :cond_2b
    invoke-virtual {v1}, La0/r;->P()V

    goto :goto_1e

    :goto_1f
    iput-wide v11, v1, La0/r;->T:J

    iput-boolean v0, v1, La0/r;->F:Z

    return-void
.end method

.method public final H()V
    .locals 9

    iget-object v0, p0, La0/r;->G:La0/E0;

    iget v0, v0, La0/E0;->g:I

    invoke-virtual {p0, v0}, La0/r;->L(I)V

    iget-object v0, p0, La0/r;->M:Lb0/b;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lb0/b;->d(Z)V

    iget-object v2, v0, Lb0/b;->d:LL0/v;

    iget-object v3, v0, Lb0/b;->a:La0/r;

    iget-object v4, v3, La0/r;->G:La0/E0;

    iget v5, v4, La0/E0;->c:I

    if-lez v5, :cond_1

    iget v5, v4, La0/E0;->i:I

    const/4 v6, -0x2

    invoke-virtual {v2, v6}, LL0/v;->a(I)I

    move-result v6

    if-eq v6, v5, :cond_1

    iget-boolean v6, v0, Lb0/b;->c:Z

    const/4 v7, 0x1

    if-nez v6, :cond_0

    iget-boolean v6, v0, Lb0/b;->e:Z

    if-eqz v6, :cond_0

    invoke-virtual {v0, v1}, Lb0/b;->d(Z)V

    iget-object v6, v0, Lb0/b;->b:Lb0/a;

    iget-object v6, v6, Lb0/a;->a:Lb0/L;

    sget-object v8, Lb0/q;->c:Lb0/q;

    invoke-virtual {v6, v8}, Lb0/L;->e(Lb0/J;)V

    iput-boolean v7, v0, Lb0/b;->c:Z

    :cond_0
    if-lez v5, :cond_1

    invoke-virtual {v4, v5}, La0/E0;->a(I)La0/a;

    move-result-object v4

    invoke-virtual {v2, v5}, LL0/v;->c(I)V

    invoke-virtual {v0, v1}, Lb0/b;->d(Z)V

    iget-object v2, v0, Lb0/b;->b:Lb0/a;

    iget-object v2, v2, Lb0/a;->a:Lb0/L;

    sget-object v5, Lb0/p;->c:Lb0/p;

    invoke-virtual {v2, v5}, Lb0/L;->e(Lb0/J;)V

    invoke-static {v2, v1, v4}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    iput-boolean v7, v0, Lb0/b;->c:Z

    :cond_1
    iget-object v1, v0, Lb0/b;->b:Lb0/a;

    iget-object v1, v1, Lb0/a;->a:Lb0/L;

    sget-object v2, Lb0/y;->c:Lb0/y;

    invoke-virtual {v1, v2}, Lb0/L;->e(Lb0/J;)V

    iget v1, v0, Lb0/b;->f:I

    iget-object v2, v3, La0/r;->G:La0/E0;

    iget-object v3, v2, La0/E0;->b:[I

    iget v2, v2, La0/E0;->g:I

    mul-int/lit8 v2, v2, 0x5

    add-int/lit8 v2, v2, 0x3

    aget v2, v3, v2

    add-int/2addr v2, v1

    iput v2, v0, Lb0/b;->f:I

    return-void
.end method

.method public final I(La0/n0;)V
    .locals 2

    iget-object v0, p0, La0/r;->v:Lp/w;

    if-nez v0, :cond_0

    new-instance v0, Lp/w;

    invoke-direct {v0}, Lp/w;-><init>()V

    iput-object v0, p0, La0/r;->v:Lp/w;

    :cond_0
    iget-object v1, p0, La0/r;->G:La0/E0;

    iget v1, v1, La0/E0;->g:I

    invoke-virtual {v0, v1, p1}, Lp/w;->h(ILjava/lang/Object;)V

    return-void
.end method

.method public final J(III)V
    .locals 6

    iget-object v0, p0, La0/r;->G:La0/E0;

    if-ne p1, p2, :cond_0

    goto :goto_0

    :cond_0
    if-eq p1, p3, :cond_9

    if-ne p2, p3, :cond_1

    goto/16 :goto_6

    :cond_1
    invoke-virtual {v0, p1}, La0/E0;->q(I)I

    move-result v1

    if-ne v1, p2, :cond_2

    move p3, p2

    goto/16 :goto_6

    :cond_2
    invoke-virtual {v0, p2}, La0/E0;->q(I)I

    move-result v1

    if-ne v1, p1, :cond_3

    :goto_0
    move p3, p1

    goto :goto_6

    :cond_3
    invoke-virtual {v0, p1}, La0/E0;->q(I)I

    move-result v1

    invoke-virtual {v0, p2}, La0/E0;->q(I)I

    move-result v2

    if-ne v1, v2, :cond_4

    invoke-virtual {v0, p1}, La0/E0;->q(I)I

    move-result p3

    goto :goto_6

    :cond_4
    const/4 v1, 0x0

    move v2, p1

    move v3, v1

    :goto_1
    if-lez v2, :cond_5

    if-eq v2, p3, :cond_5

    invoke-virtual {v0, v2}, La0/E0;->q(I)I

    move-result v2

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_5
    move v2, p2

    move v4, v1

    :goto_2
    if-lez v2, :cond_6

    if-eq v2, p3, :cond_6

    invoke-virtual {v0, v2}, La0/E0;->q(I)I

    move-result v2

    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_6
    sub-int p3, v3, v4

    move v5, p1

    move v2, v1

    :goto_3
    if-ge v2, p3, :cond_7

    invoke-virtual {v0, v5}, La0/E0;->q(I)I

    move-result v5

    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_7
    sub-int/2addr v4, v3

    move p3, p2

    :goto_4
    if-ge v1, v4, :cond_8

    invoke-virtual {v0, p3}, La0/E0;->q(I)I

    move-result p3

    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    :cond_8
    move v1, p3

    move p3, v5

    :goto_5
    if-eq p3, v1, :cond_9

    invoke-virtual {v0, p3}, La0/E0;->q(I)I

    move-result p3

    invoke-virtual {v0, v1}, La0/E0;->q(I)I

    move-result v1

    goto :goto_5

    :cond_9
    :goto_6
    if-lez p1, :cond_b

    if-eq p1, p3, :cond_b

    invoke-virtual {v0, p1}, La0/E0;->l(I)Z

    move-result v1

    if-eqz v1, :cond_a

    iget-object v1, p0, La0/r;->M:Lb0/b;

    invoke-virtual {v1}, Lb0/b;->a()V

    :cond_a
    invoke-virtual {v0, p1}, La0/E0;->q(I)I

    move-result p1

    goto :goto_6

    :cond_b
    invoke-virtual {p0, p2, p3}, La0/r;->o(II)V

    return-void
.end method

.method public final K()Ljava/lang/Object;
    .locals 3

    iget-boolean v0, p0, La0/r;->S:Z

    sget-object v1, La0/m;->a:La0/U;

    if-eqz v0, :cond_0

    iget-boolean v0, p0, La0/r;->r:Z

    if-eqz v0, :cond_1

    const-string v0, "A call to createNode(), emitNode() or useNode() expected"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    return-object v1

    :cond_0
    iget-object v0, p0, La0/r;->G:La0/E0;

    invoke-virtual {v0}, La0/E0;->m()Ljava/lang/Object;

    move-result-object v0

    iget-boolean v2, p0, La0/r;->y:Z

    if-eqz v2, :cond_2

    instance-of v2, v0, La0/o;

    if-nez v2, :cond_2

    :cond_1
    return-object v1

    :cond_2
    instance-of v1, v0, La0/B0;

    if-eqz v1, :cond_3

    check-cast v0, La0/B0;

    iget-object v0, v0, La0/B0;->a:La0/A0;

    :cond_3
    return-object v0
.end method

.method public final L(I)V
    .locals 4

    iget-object v0, p0, La0/r;->G:La0/E0;

    invoke-virtual {v0, p1}, La0/E0;->l(I)Z

    move-result v0

    iget-object v1, p0, La0/r;->M:Lb0/b;

    if-eqz v0, :cond_0

    invoke-virtual {v1}, Lb0/b;->c()V

    iget-object v2, p0, La0/r;->G:La0/E0;

    invoke-virtual {v2, p1}, La0/E0;->n(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1}, Lb0/b;->c()V

    iget-object v3, v1, Lb0/b;->h:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v2, 0x0

    invoke-static {p0, p1, v0, v2}, La0/r;->M(La0/r;IZI)I

    invoke-virtual {v1}, Lb0/b;->c()V

    if-eqz v0, :cond_1

    invoke-virtual {v1}, Lb0/b;->a()V

    :cond_1
    return-void
.end method

.method public final N(IZ)Z
    .locals 2

    const/4 v0, 0x1

    and-int/2addr p1, v0

    const/4 v1, 0x0

    if-nez p1, :cond_3

    iget-boolean p1, p0, La0/r;->S:Z

    if-nez p1, :cond_0

    iget-boolean p1, p0, La0/r;->y:Z

    if-eqz p1, :cond_3

    :cond_0
    iget-object p1, p0, La0/r;->P:LA1/c;

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, La0/r;->w()La0/r0;

    move-result-object p2

    if-nez p2, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_0

    :cond_3
    if-nez p2, :cond_5

    invoke-virtual {p0}, La0/r;->z()Z

    move-result p1

    if-nez p1, :cond_4

    goto :goto_0

    :cond_4
    return v1

    :cond_5
    :goto_0
    return v0
.end method

.method public final O()V
    .locals 16

    move-object/from16 v0, p0

    iget-object v1, v0, La0/r;->s:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    iget v1, v0, La0/r;->l:I

    iget-object v2, v0, La0/r;->G:La0/E0;

    invoke-virtual {v2}, La0/E0;->s()I

    move-result v2

    add-int/2addr v2, v1

    iput v2, v0, La0/r;->l:I

    return-void

    :cond_0
    iget-object v1, v0, La0/r;->G:La0/E0;

    invoke-virtual {v1}, La0/E0;->g()I

    move-result v2

    iget-object v3, v1, La0/E0;->b:[I

    iget v4, v1, La0/E0;->g:I

    iget v5, v1, La0/E0;->h:I

    const/4 v6, 0x0

    if-ge v4, v5, :cond_1

    invoke-virtual {v1, v3, v4}, La0/E0;->p([II)Ljava/lang/Object;

    move-result-object v4

    goto :goto_0

    :cond_1
    move-object v4, v6

    :goto_0
    invoke-virtual {v1}, La0/E0;->f()Ljava/lang/Object;

    move-result-object v5

    iget v7, v0, La0/r;->m:I

    sget-object v8, La0/m;->a:La0/U;

    const/16 v9, 0xcf

    const/4 v11, 0x3

    if-nez v4, :cond_3

    if-eqz v5, :cond_2

    if-ne v2, v9, :cond_2

    invoke-virtual {v5, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_2

    invoke-virtual {v5}, Ljava/lang/Object;->hashCode()I

    move-result v12

    iget-wide v13, v0, La0/r;->T:J

    invoke-static {v13, v14, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v13

    int-to-long v9, v12

    xor-long/2addr v9, v13

    invoke-static {v9, v10, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v9

    int-to-long v12, v7

    xor-long/2addr v9, v12

    iput-wide v9, v0, La0/r;->T:J

    goto :goto_3

    :cond_2
    iget-wide v9, v0, La0/r;->T:J

    invoke-static {v9, v10, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v9

    int-to-long v12, v2

    xor-long/2addr v9, v12

    invoke-static {v9, v10, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v9

    int-to-long v12, v7

    xor-long/2addr v9, v12

    :goto_1
    iput-wide v9, v0, La0/r;->T:J

    goto :goto_3

    :cond_3
    instance-of v9, v4, Ljava/lang/Enum;

    if-eqz v9, :cond_4

    move-object v9, v4

    check-cast v9, Ljava/lang/Enum;

    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    move-result v9

    iget-wide v12, v0, La0/r;->T:J

    invoke-static {v12, v13, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v12

    int-to-long v9, v9

    xor-long/2addr v9, v12

    invoke-static {v9, v10, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v9

    const/4 v12, 0x0

    :goto_2
    int-to-long v13, v12

    xor-long/2addr v9, v13

    goto :goto_1

    :cond_4
    const/4 v12, 0x0

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v9

    iget-wide v13, v0, La0/r;->T:J

    invoke-static {v13, v14, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v13

    int-to-long v9, v9

    xor-long/2addr v9, v13

    invoke-static {v9, v10, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v9

    goto :goto_2

    :goto_3
    iget v9, v1, La0/E0;->g:I

    mul-int/lit8 v9, v9, 0x5

    const/4 v12, 0x1

    add-int/2addr v9, v12

    aget v3, v3, v9

    const/high16 v9, 0x40000000    # 2.0f

    and-int/2addr v3, v9

    if-eqz v3, :cond_5

    goto :goto_4

    :cond_5
    const/4 v12, 0x0

    :goto_4
    invoke-virtual {v0, v6, v12}, La0/r;->U(Ljava/lang/Object;Z)V

    invoke-virtual {v0}, La0/r;->G()V

    invoke-virtual {v1}, La0/E0;->e()V

    if-nez v4, :cond_7

    if-eqz v5, :cond_6

    const/16 v15, 0xcf

    if-ne v2, v15, :cond_6

    invoke-virtual {v5, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    invoke-virtual {v5}, Ljava/lang/Object;->hashCode()I

    move-result v1

    iget-wide v2, v0, La0/r;->T:J

    int-to-long v4, v7

    xor-long/2addr v2, v4

    invoke-static {v2, v3, v11}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v2

    int-to-long v4, v1

    xor-long v1, v2, v4

    invoke-static {v1, v2, v11}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v1

    iput-wide v1, v0, La0/r;->T:J

    return-void

    :cond_6
    iget-wide v3, v0, La0/r;->T:J

    int-to-long v5, v7

    xor-long/2addr v3, v5

    invoke-static {v3, v4, v11}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v3

    int-to-long v1, v2

    xor-long/2addr v1, v3

    invoke-static {v1, v2, v11}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v1

    iput-wide v1, v0, La0/r;->T:J

    return-void

    :cond_7
    instance-of v1, v4, Ljava/lang/Enum;

    if-eqz v1, :cond_8

    check-cast v4, Ljava/lang/Enum;

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    iget-wide v2, v0, La0/r;->T:J

    const/4 v12, 0x0

    int-to-long v4, v12

    xor-long/2addr v2, v4

    invoke-static {v2, v3, v11}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v2

    int-to-long v4, v1

    xor-long v1, v2, v4

    invoke-static {v1, v2, v11}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v1

    iput-wide v1, v0, La0/r;->T:J

    return-void

    :cond_8
    const/4 v12, 0x0

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v1

    iget-wide v2, v0, La0/r;->T:J

    int-to-long v4, v12

    xor-long/2addr v2, v4

    invoke-static {v2, v3, v11}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v2

    int-to-long v4, v1

    xor-long v1, v2, v4

    invoke-static {v1, v2, v11}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v1

    iput-wide v1, v0, La0/r;->T:J

    return-void
.end method

.method public final P()V
    .locals 3

    iget-object v0, p0, La0/r;->G:La0/E0;

    iget v1, v0, La0/E0;->i:I

    if-ltz v1, :cond_0

    iget-object v2, v0, La0/E0;->b:[I

    mul-int/lit8 v1, v1, 0x5

    add-int/lit8 v1, v1, 0x1

    aget v1, v2, v1

    const v2, 0x3ffffff

    and-int/2addr v1, v2

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    iput v1, p0, La0/r;->l:I

    invoke-virtual {v0}, La0/E0;->t()V

    return-void
.end method

.method public final Q()V
    .locals 3

    iget v0, p0, La0/r;->l:I

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const-string v0, "No nodes can be emitted before calling skipAndEndGroup"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :goto_0
    iget-boolean v0, p0, La0/r;->S:Z

    if-nez v0, :cond_4

    invoke-virtual {p0}, La0/r;->w()La0/r0;

    move-result-object v0

    if-eqz v0, :cond_2

    iget v1, v0, La0/r0;->b:I

    and-int/lit16 v2, v1, 0x80

    if-eqz v2, :cond_1

    goto :goto_1

    :cond_1
    or-int/lit8 v1, v1, 0x10

    iput v1, v0, La0/r0;->b:I

    :cond_2
    :goto_1
    iget-object v0, p0, La0/r;->s:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p0}, La0/r;->P()V

    return-void

    :cond_3
    invoke-virtual {p0}, La0/r;->G()V

    :cond_4
    return-void
.end method

.method public final R(IILjava/lang/Object;Ljava/lang/Object;)V
    .locals 26

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    const/4 v5, -0x1

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    iget-boolean v7, v0, La0/r;->r:Z

    if-eqz v7, :cond_0

    const-string v7, "A call to createNode(), emitNode() or useNode() expected"

    invoke-static {v7}, La0/s;->c(Ljava/lang/String;)V

    :cond_0
    iget v7, v0, La0/r;->m:I

    sget-object v8, La0/m;->a:La0/U;

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-nez v3, :cond_2

    if-eqz v4, :cond_1

    const/16 v11, 0xcf

    if-ne v1, v11, :cond_1

    invoke-virtual {v4, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_1

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v11

    iget-wide v12, v0, La0/r;->T:J

    invoke-static {v12, v13, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v12

    int-to-long v14, v11

    xor-long v11, v12, v14

    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v11

    int-to-long v13, v7

    xor-long/2addr v11, v13

    iput-wide v11, v0, La0/r;->T:J

    goto :goto_2

    :cond_1
    iget-wide v11, v0, La0/r;->T:J

    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v11

    int-to-long v13, v1

    xor-long/2addr v11, v13

    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v11

    int-to-long v13, v7

    :goto_0
    xor-long/2addr v11, v13

    iput-wide v11, v0, La0/r;->T:J

    goto :goto_2

    :cond_2
    instance-of v7, v3, Ljava/lang/Enum;

    if-eqz v7, :cond_3

    move-object v7, v3

    check-cast v7, Ljava/lang/Enum;

    invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I

    move-result v7

    :goto_1
    iget-wide v11, v0, La0/r;->T:J

    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v11

    int-to-long v13, v7

    xor-long/2addr v11, v13

    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v11

    int-to-long v13, v10

    goto :goto_0

    :cond_3
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v7

    goto :goto_1

    :goto_2
    const/4 v7, 0x1

    if-nez v3, :cond_4

    iget v9, v0, La0/r;->m:I

    add-int/2addr v9, v7

    iput v9, v0, La0/r;->m:I

    :cond_4
    if-eqz v2, :cond_5

    move v9, v7

    goto :goto_3

    :cond_5
    move v9, v10

    :goto_3
    iget-boolean v11, v0, La0/r;->S:Z

    const/4 v12, -0x2

    const/4 v13, 0x0

    if-eqz v11, :cond_b

    iget-object v2, v0, La0/r;->G:La0/E0;

    iget v11, v2, La0/E0;->k:I

    add-int/2addr v11, v7

    iput v11, v2, La0/E0;->k:I

    iget-object v2, v0, La0/r;->I:La0/I0;

    iget v11, v2, La0/I0;->t:I

    if-eqz v9, :cond_6

    invoke-virtual {v2, v1, v8, v8, v7}, La0/I0;->P(ILjava/lang/Object;Ljava/lang/Object;Z)V

    goto :goto_4

    :cond_6
    if-eqz v4, :cond_8

    if-nez v3, :cond_7

    move-object v3, v8

    :cond_7
    invoke-virtual {v2, v1, v3, v4, v10}, La0/I0;->P(ILjava/lang/Object;Ljava/lang/Object;Z)V

    goto :goto_4

    :cond_8
    if-nez v3, :cond_9

    move-object v3, v8

    :cond_9
    invoke-virtual {v2, v1, v3, v8, v10}, La0/I0;->P(ILjava/lang/Object;Ljava/lang/Object;Z)V

    :goto_4
    iget-object v2, v0, La0/r;->j:La0/m0;

    if-eqz v2, :cond_a

    new-instance v3, La0/Q;

    sub-int/2addr v12, v11

    invoke-direct {v3, v6, v1, v12, v5}, La0/Q;-><init>(Ljava/lang/Object;III)V

    iget v1, v0, La0/r;->k:I

    iget v4, v2, La0/m0;->b:I

    sub-int/2addr v1, v4

    iget-object v4, v2, La0/m0;->e:Lp/w;

    new-instance v6, La0/K;

    invoke-direct {v6, v5, v1, v10}, La0/K;-><init>(III)V

    invoke-virtual {v4, v12, v6}, Lp/w;->h(ILjava/lang/Object;)V

    iget-object v1, v2, La0/m0;->d:Ljava/util/ArrayList;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_a
    invoke-virtual {v0, v9, v13}, La0/r;->u(ZLa0/m0;)V

    return-void

    :cond_b
    if-eq v2, v7, :cond_c

    goto :goto_5

    :cond_c
    iget-boolean v2, v0, La0/r;->y:Z

    if-eqz v2, :cond_d

    move v2, v7

    goto :goto_6

    :cond_d
    :goto_5
    move v2, v10

    :goto_6
    iget-object v11, v0, La0/r;->j:La0/m0;

    if-nez v11, :cond_f

    iget-object v11, v0, La0/r;->G:La0/E0;

    invoke-virtual {v11}, La0/E0;->g()I

    move-result v11

    if-nez v2, :cond_10

    if-ne v11, v1, :cond_10

    iget-object v11, v0, La0/r;->G:La0/E0;

    iget v14, v11, La0/E0;->g:I

    iget v15, v11, La0/E0;->h:I

    if-ge v14, v15, :cond_e

    iget-object v15, v11, La0/E0;->b:[I

    invoke-virtual {v11, v15, v14}, La0/E0;->p([II)Ljava/lang/Object;

    move-result-object v11

    goto :goto_7

    :cond_e
    move-object v11, v13

    :goto_7
    invoke-static {v3, v11}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_10

    invoke-virtual {v0, v4, v9}, La0/r;->U(Ljava/lang/Object;Z)V

    :cond_f
    move/from16 p2, v2

    goto :goto_b

    :cond_10
    new-instance v11, La0/m0;

    iget-object v14, v0, La0/r;->G:La0/E0;

    iget-object v15, v14, La0/E0;->b:[I

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iget v13, v14, La0/E0;->k:I

    if-lez v13, :cond_12

    :cond_11
    move/from16 p2, v2

    goto :goto_a

    :cond_12
    iget v13, v14, La0/E0;->g:I

    :goto_8
    iget v12, v14, La0/E0;->h:I

    if-ge v13, v12, :cond_11

    new-instance v12, La0/Q;

    mul-int/lit8 v18, v13, 0x5

    aget v7, v15, v18

    invoke-virtual {v14, v15, v13}, La0/E0;->p([II)Ljava/lang/Object;

    move-result-object v10

    add-int/lit8 v20, v18, 0x1

    aget v20, v15, v20

    const/high16 v21, 0x40000000    # 2.0f

    and-int v21, v20, v21

    if-eqz v21, :cond_13

    move/from16 p2, v2

    const/4 v2, 0x1

    goto :goto_9

    :cond_13
    const v21, 0x3ffffff

    and-int v20, v20, v21

    move/from16 p2, v2

    move/from16 v2, v20

    :goto_9
    invoke-direct {v12, v10, v7, v13, v2}, La0/Q;-><init>(Ljava/lang/Object;III)V

    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v18, v18, 0x3

    aget v2, v15, v18

    add-int/2addr v13, v2

    move/from16 v2, p2

    const/4 v7, 0x1

    const/4 v10, 0x0

    goto :goto_8

    :goto_a
    iget v2, v0, La0/r;->k:I

    invoke-direct {v11, v2, v5}, La0/m0;-><init>(ILjava/util/ArrayList;)V

    iput-object v11, v0, La0/r;->j:La0/m0;

    :goto_b
    iget-object v2, v0, La0/r;->j:La0/m0;

    if-eqz v2, :cond_2b

    iget-object v5, v2, La0/m0;->d:Ljava/util/ArrayList;

    iget-object v7, v2, La0/m0;->e:Lp/w;

    iget v10, v2, La0/m0;->b:I

    if-eqz v3, :cond_14

    new-instance v11, La0/P;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-direct {v11, v12, v3}, La0/P;-><init>(Ljava/lang/Integer;Ljava/lang/Object;)V

    goto :goto_c

    :cond_14
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    :goto_c
    iget-object v12, v2, La0/m0;->f:Ld7/p;

    invoke-virtual {v12}, Ld7/p;->getValue()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lc0/a;

    iget-object v12, v12, Lc0/a;->a:Lp/H;

    invoke-virtual {v12, v11}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    if-nez v13, :cond_15

    const/4 v13, 0x0

    goto :goto_d

    :cond_15
    instance-of v14, v13, Lp/D;

    if-eqz v14, :cond_18

    check-cast v13, Lp/D;

    const/4 v14, 0x0

    invoke-virtual {v13, v14}, Lp/D;->j(I)Ljava/lang/Object;

    move-result-object v15

    invoke-virtual {v13}, Lp/D;->g()Z

    move-result v14

    if-eqz v14, :cond_16

    invoke-virtual {v12, v11}, Lp/H;->k(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_16
    iget v14, v13, Lp/D;->b:I

    const/4 v3, 0x1

    if-ne v14, v3, :cond_17

    invoke-virtual {v13}, Lp/D;->d()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v12, v11, v3}, Lp/H;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_17
    move-object v13, v15

    goto :goto_d

    :cond_18
    invoke-virtual {v12, v11}, Lp/H;->k(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_d
    check-cast v13, La0/Q;

    if-nez p2, :cond_2c

    if-eqz v13, :cond_2c

    iget v1, v13, La0/Q;->c:I

    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v7, v1}, Lp/l;->b(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La0/K;

    if-eqz v3, :cond_19

    iget v3, v3, La0/K;->b:I

    goto :goto_e

    :cond_19
    const/4 v3, -0x1

    :goto_e
    add-int/2addr v3, v10

    iput v3, v0, La0/r;->k:I

    invoke-virtual {v7, v1}, Lp/l;->b(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La0/K;

    if-eqz v3, :cond_1a

    iget v5, v3, La0/K;->a:I

    goto :goto_f

    :cond_1a
    const/4 v5, -0x1

    :goto_f
    iget v2, v2, La0/m0;->c:I

    sub-int v3, v5, v2

    const/16 v8, 0x8

    if-le v5, v2, :cond_21

    const/16 p1, 0x7

    iget-object v6, v7, Lp/l;->c:[Ljava/lang/Object;

    iget-object v7, v7, Lp/l;->a:[J

    const-wide/16 p2, 0x80

    array-length v10, v7

    add-int/lit8 v10, v10, -0x2

    if-ltz v10, :cond_20

    const/4 v11, 0x0

    const-wide/16 v20, 0xff

    :goto_10
    aget-wide v12, v7, v11

    const-wide v22, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    not-long v14, v12

    shl-long v14, v14, p1

    and-long/2addr v14, v12

    and-long v14, v14, v22

    cmp-long v14, v14, v22

    if-eqz v14, :cond_1f

    sub-int v14, v11, v10

    not-int v14, v14

    ushr-int/lit8 v14, v14, 0x1f

    rsub-int/lit8 v14, v14, 0x8

    const/4 v15, 0x0

    :goto_11
    if-ge v15, v14, :cond_1e

    and-long v24, v12, v20

    cmp-long v16, v24, p2

    if-gez v16, :cond_1c

    shl-int/lit8 v16, v11, 0x3

    add-int v16, v16, v15

    aget-object v16, v6, v16

    move/from16 v18, v8

    move-object/from16 v8, v16

    check-cast v8, La0/K;

    move/from16 v16, v3

    iget v3, v8, La0/K;->a:I

    if-ne v3, v5, :cond_1b

    iput v2, v8, La0/K;->a:I

    goto :goto_12

    :cond_1b
    if-gt v2, v3, :cond_1d

    if-ge v3, v5, :cond_1d

    add-int/lit8 v3, v3, 0x1

    iput v3, v8, La0/K;->a:I

    goto :goto_12

    :cond_1c
    move/from16 v16, v3

    move/from16 v18, v8

    :cond_1d
    :goto_12
    shr-long v12, v12, v18

    add-int/lit8 v15, v15, 0x1

    move/from16 v3, v16

    move/from16 v8, v18

    goto :goto_11

    :cond_1e
    move/from16 v16, v3

    move v3, v8

    if-ne v14, v3, :cond_27

    goto :goto_13

    :cond_1f
    move/from16 v16, v3

    :goto_13
    if-eq v11, v10, :cond_27

    add-int/lit8 v11, v11, 0x1

    move/from16 v3, v16

    const/16 v8, 0x8

    goto :goto_10

    :cond_20
    move/from16 v16, v3

    goto/16 :goto_1a

    :cond_21
    move/from16 v16, v3

    const/16 p1, 0x7

    const-wide/16 p2, 0x80

    const-wide/16 v20, 0xff

    const-wide v22, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    if-le v2, v5, :cond_27

    iget-object v3, v7, Lp/l;->c:[Ljava/lang/Object;

    iget-object v6, v7, Lp/l;->a:[J

    array-length v7, v6

    add-int/lit8 v7, v7, -0x2

    if-ltz v7, :cond_27

    const/4 v8, 0x0

    :goto_14
    aget-wide v10, v6, v8

    not-long v12, v10

    shl-long v12, v12, p1

    and-long/2addr v12, v10

    and-long v12, v12, v22

    cmp-long v12, v12, v22

    if-eqz v12, :cond_26

    sub-int v12, v8, v7

    not-int v12, v12

    ushr-int/lit8 v12, v12, 0x1f

    const/16 v18, 0x8

    rsub-int/lit8 v12, v12, 0x8

    const/4 v13, 0x0

    :goto_15
    if-ge v13, v12, :cond_25

    and-long v14, v10, v20

    cmp-long v14, v14, p2

    if-gez v14, :cond_24

    shl-int/lit8 v14, v8, 0x3

    add-int/2addr v14, v13

    aget-object v14, v3, v14

    check-cast v14, La0/K;

    iget v15, v14, La0/K;->a:I

    if-ne v15, v5, :cond_22

    iput v2, v14, La0/K;->a:I

    goto :goto_17

    :cond_22
    move-object/from16 v24, v3

    add-int/lit8 v3, v5, 0x1

    if-gt v3, v15, :cond_23

    if-ge v15, v2, :cond_23

    add-int/lit8 v15, v15, -0x1

    iput v15, v14, La0/K;->a:I

    :cond_23
    :goto_16
    const/16 v3, 0x8

    goto :goto_18

    :cond_24
    :goto_17
    move-object/from16 v24, v3

    goto :goto_16

    :goto_18
    shr-long/2addr v10, v3

    add-int/lit8 v13, v13, 0x1

    move-object/from16 v3, v24

    goto :goto_15

    :cond_25
    move-object/from16 v24, v3

    const/16 v3, 0x8

    if-ne v12, v3, :cond_27

    goto :goto_19

    :cond_26
    move-object/from16 v24, v3

    const/16 v3, 0x8

    :goto_19
    if-eq v8, v7, :cond_27

    add-int/lit8 v8, v8, 0x1

    move-object/from16 v3, v24

    goto :goto_14

    :cond_27
    :goto_1a
    iget-object v2, v0, La0/r;->M:Lb0/b;

    iget v3, v2, Lb0/b;->f:I

    iget-object v5, v2, Lb0/b;->a:La0/r;

    iget-object v6, v5, La0/r;->G:La0/E0;

    iget v6, v6, La0/E0;->g:I

    sub-int v6, v1, v6

    add-int/2addr v6, v3

    iput v6, v2, Lb0/b;->f:I

    iget-object v3, v0, La0/r;->G:La0/E0;

    invoke-virtual {v3, v1}, La0/E0;->r(I)V

    if-lez v16, :cond_2a

    const/4 v14, 0x0

    invoke-virtual {v2, v14}, Lb0/b;->d(Z)V

    iget-object v1, v2, Lb0/b;->d:LL0/v;

    iget-object v3, v5, La0/r;->G:La0/E0;

    iget v5, v3, La0/E0;->c:I

    if-lez v5, :cond_29

    iget v5, v3, La0/E0;->i:I

    const/4 v6, -0x2

    invoke-virtual {v1, v6}, LL0/v;->a(I)I

    move-result v6

    if-eq v6, v5, :cond_29

    iget-boolean v6, v2, Lb0/b;->c:Z

    if-nez v6, :cond_28

    iget-boolean v6, v2, Lb0/b;->e:Z

    if-eqz v6, :cond_28

    const/4 v14, 0x0

    invoke-virtual {v2, v14}, Lb0/b;->d(Z)V

    iget-object v6, v2, Lb0/b;->b:Lb0/a;

    iget-object v6, v6, Lb0/a;->a:Lb0/L;

    sget-object v7, Lb0/q;->c:Lb0/q;

    invoke-virtual {v6, v7}, Lb0/L;->e(Lb0/J;)V

    const/4 v6, 0x1

    iput-boolean v6, v2, Lb0/b;->c:Z

    :cond_28
    if-lez v5, :cond_29

    invoke-virtual {v3, v5}, La0/E0;->a(I)La0/a;

    move-result-object v3

    invoke-virtual {v1, v5}, LL0/v;->c(I)V

    const/4 v14, 0x0

    invoke-virtual {v2, v14}, Lb0/b;->d(Z)V

    iget-object v1, v2, Lb0/b;->b:Lb0/a;

    iget-object v1, v1, Lb0/a;->a:Lb0/L;

    sget-object v5, Lb0/p;->c:Lb0/p;

    invoke-virtual {v1, v5}, Lb0/L;->e(Lb0/J;)V

    invoke-static {v1, v14, v3}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    const/4 v3, 0x1

    iput-boolean v3, v2, Lb0/b;->c:Z

    :cond_29
    iget-object v1, v2, Lb0/b;->b:Lb0/a;

    iget-object v1, v1, Lb0/a;->a:Lb0/L;

    sget-object v2, Lb0/u;->c:Lb0/u;

    invoke-virtual {v1, v2}, Lb0/L;->e(Lb0/J;)V

    iget-object v2, v1, Lb0/L;->c:[I

    iget v3, v1, Lb0/L;->d:I

    iget-object v5, v1, Lb0/L;->a:[Lb0/J;

    iget v1, v1, Lb0/L;->b:I

    const/16 v19, 0x1

    add-int/lit8 v1, v1, -0x1

    aget-object v1, v5, v1

    iget v1, v1, Lb0/J;->a:I

    sub-int/2addr v3, v1

    aput v16, v2, v3

    :cond_2a
    invoke-virtual {v0, v4, v9}, La0/r;->U(Ljava/lang/Object;Z)V

    :cond_2b
    const/4 v2, 0x0

    goto/16 :goto_20

    :cond_2c
    iget-object v2, v0, La0/r;->G:La0/E0;

    iget v3, v2, La0/E0;->k:I

    const/4 v11, 0x1

    add-int/2addr v3, v11

    iput v3, v2, La0/E0;->k:I

    iput-boolean v11, v0, La0/r;->S:Z

    const/4 v2, 0x0

    iput-object v2, v0, La0/r;->K:La0/n0;

    iget-object v3, v0, La0/r;->I:La0/I0;

    iget-boolean v3, v3, La0/I0;->w:Z

    if-eqz v3, :cond_2d

    iget-object v3, v0, La0/r;->H:La0/F0;

    invoke-virtual {v3}, La0/F0;->f()La0/I0;

    move-result-object v3

    iput-object v3, v0, La0/r;->I:La0/I0;

    invoke-virtual {v3}, La0/I0;->L()V

    const/4 v14, 0x0

    iput-boolean v14, v0, La0/r;->J:Z

    iput-object v2, v0, La0/r;->K:La0/n0;

    :cond_2d
    iget-object v2, v0, La0/r;->I:La0/I0;

    invoke-virtual {v2}, La0/I0;->d()V

    iget-object v2, v0, La0/r;->I:La0/I0;

    iget v3, v2, La0/I0;->t:I

    if-eqz v9, :cond_2e

    const/4 v11, 0x1

    invoke-virtual {v2, v1, v8, v8, v11}, La0/I0;->P(ILjava/lang/Object;Ljava/lang/Object;Z)V

    const/4 v14, 0x0

    goto :goto_1e

    :cond_2e
    if-eqz v4, :cond_30

    if-nez p3, :cond_2f

    :goto_1b
    const/4 v14, 0x0

    goto :goto_1c

    :cond_2f
    move-object/from16 v8, p3

    goto :goto_1b

    :goto_1c
    invoke-virtual {v2, v1, v8, v4, v14}, La0/I0;->P(ILjava/lang/Object;Ljava/lang/Object;Z)V

    goto :goto_1e

    :cond_30
    const/4 v14, 0x0

    if-nez p3, :cond_31

    move-object v4, v8

    goto :goto_1d

    :cond_31
    move-object/from16 v4, p3

    :goto_1d
    invoke-virtual {v2, v1, v4, v8, v14}, La0/I0;->P(ILjava/lang/Object;Ljava/lang/Object;Z)V

    :goto_1e
    iget-object v2, v0, La0/r;->I:La0/I0;

    invoke-virtual {v2, v3}, La0/I0;->b(I)La0/a;

    move-result-object v2

    iput-object v2, v0, La0/r;->N:La0/a;

    new-instance v2, La0/Q;

    const/16 v17, -0x2

    rsub-int/lit8 v12, v3, -0x2

    const/4 v3, -0x1

    invoke-direct {v2, v6, v1, v12, v3}, La0/Q;-><init>(Ljava/lang/Object;III)V

    iget v1, v0, La0/r;->k:I

    sub-int/2addr v1, v10

    new-instance v4, La0/K;

    invoke-direct {v4, v3, v1, v14}, La0/K;-><init>(III)V

    invoke-virtual {v7, v12, v4}, Lp/w;->h(ILjava/lang/Object;)V

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v13, La0/m0;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    if-eqz v9, :cond_32

    move v10, v14

    goto :goto_1f

    :cond_32
    iget v10, v0, La0/r;->k:I

    :goto_1f
    invoke-direct {v13, v10, v1}, La0/m0;-><init>(ILjava/util/ArrayList;)V

    goto :goto_21

    :goto_20
    move-object v13, v2

    :goto_21
    invoke-virtual {v0, v9, v13}, La0/r;->u(ZLa0/m0;)V

    return-void
.end method

.method public final S()V
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/16 v2, -0x7f

    invoke-virtual {p0, v2, v1, v0, v0}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method public final T(ILa0/b0;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v0, p2, v1}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method public final U(Ljava/lang/Object;Z)V
    .locals 2

    if-eqz p2, :cond_2

    iget-object p1, p0, La0/r;->G:La0/E0;

    iget p2, p1, La0/E0;->k:I

    if-gtz p2, :cond_1

    iget-object p2, p1, La0/E0;->b:[I

    iget v0, p1, La0/E0;->g:I

    mul-int/lit8 v0, v0, 0x5

    add-int/lit8 v0, v0, 0x1

    aget p2, p2, v0

    const/high16 v0, 0x40000000    # 2.0f

    and-int/2addr p2, v0

    if-eqz p2, :cond_0

    goto :goto_0

    :cond_0
    const-string p2, "Expected a node group"

    invoke-static {p2}, La0/o0;->a(Ljava/lang/String;)V

    :goto_0
    invoke-virtual {p1}, La0/E0;->u()V

    :cond_1
    return-void

    :cond_2
    if-eqz p1, :cond_3

    iget-object p2, p0, La0/r;->G:La0/E0;

    invoke-virtual {p2}, La0/E0;->f()Ljava/lang/Object;

    move-result-object p2

    if-eq p2, p1, :cond_3

    iget-object p2, p0, La0/r;->M:Lb0/b;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Lb0/b;->d(Z)V

    iget-object p2, p2, Lb0/b;->b:Lb0/a;

    iget-object p2, p2, Lb0/a;->a:Lb0/L;

    sget-object v1, Lb0/F;->c:Lb0/F;

    invoke-virtual {p2, v1}, Lb0/L;->e(Lb0/J;)V

    invoke-static {p2, v0, p1}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    :cond_3
    iget-object p1, p0, La0/r;->G:La0/E0;

    invoke-virtual {p1}, La0/E0;->u()V

    return-void
.end method

.method public final V(I)V
    .locals 9

    iget-object v0, p0, La0/r;->j:La0/m0;

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1, v1, v2, v2}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    return-void

    :cond_0
    iget-boolean v0, p0, La0/r;->r:Z

    if-eqz v0, :cond_1

    const-string v0, "A call to createNode(), emitNode() or useNode() expected"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :cond_1
    iget v0, p0, La0/r;->m:I

    iget-wide v3, p0, La0/r;->T:J

    const/4 v5, 0x3

    invoke-static {v3, v4, v5}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v3

    int-to-long v6, p1

    xor-long/2addr v3, v6

    invoke-static {v3, v4, v5}, Ljava/lang/Long;->rotateLeft(JI)J

    move-result-wide v3

    int-to-long v5, v0

    xor-long/2addr v3, v5

    iput-wide v3, p0, La0/r;->T:J

    iget v0, p0, La0/r;->m:I

    const/4 v3, 0x1

    add-int/2addr v0, v3

    iput v0, p0, La0/r;->m:I

    iget-object v0, p0, La0/r;->G:La0/E0;

    iget-boolean v4, p0, La0/r;->S:Z

    sget-object v5, La0/m;->a:La0/U;

    if-eqz v4, :cond_2

    iget v4, v0, La0/E0;->k:I

    add-int/2addr v4, v3

    iput v4, v0, La0/E0;->k:I

    iget-object v0, p0, La0/r;->I:La0/I0;

    invoke-virtual {v0, p1, v5, v5, v1}, La0/I0;->P(ILjava/lang/Object;Ljava/lang/Object;Z)V

    invoke-virtual {p0, v1, v2}, La0/r;->u(ZLa0/m0;)V

    return-void

    :cond_2
    invoke-virtual {v0}, La0/E0;->g()I

    move-result v4

    if-ne v4, p1, :cond_4

    iget v4, v0, La0/E0;->g:I

    iget v6, v0, La0/E0;->h:I

    if-ge v4, v6, :cond_3

    iget-object v6, v0, La0/E0;->b:[I

    mul-int/lit8 v4, v4, 0x5

    add-int/2addr v4, v3

    aget v4, v6, v4

    const/high16 v6, 0x20000000

    and-int/2addr v4, v6

    if-eqz v4, :cond_3

    goto :goto_0

    :cond_3
    invoke-virtual {v0}, La0/E0;->u()V

    invoke-virtual {p0, v1, v2}, La0/r;->u(ZLa0/m0;)V

    return-void

    :cond_4
    :goto_0
    iget v4, v0, La0/E0;->k:I

    if-lez v4, :cond_5

    goto :goto_1

    :cond_5
    iget v4, v0, La0/E0;->g:I

    iget v6, v0, La0/E0;->h:I

    if-ne v4, v6, :cond_6

    goto :goto_1

    :cond_6
    iget v6, p0, La0/r;->k:I

    invoke-virtual {p0}, La0/r;->H()V

    invoke-virtual {v0}, La0/E0;->s()I

    move-result v7

    iget-object v8, p0, La0/r;->M:Lb0/b;

    invoke-virtual {v8, v6, v7}, Lb0/b;->e(II)V

    iget-object v6, p0, La0/r;->s:Ljava/util/ArrayList;

    iget v7, v0, La0/E0;->g:I

    invoke-static {v4, v7, v6}, La0/s;->a(IILjava/util/List;)V

    :goto_1
    iget v4, v0, La0/E0;->k:I

    add-int/2addr v4, v3

    iput v4, v0, La0/E0;->k:I

    iput-boolean v3, p0, La0/r;->S:Z

    iput-object v2, p0, La0/r;->K:La0/n0;

    iget-object v0, p0, La0/r;->I:La0/I0;

    iget-boolean v0, v0, La0/I0;->w:Z

    if-eqz v0, :cond_7

    iget-object v0, p0, La0/r;->H:La0/F0;

    invoke-virtual {v0}, La0/F0;->f()La0/I0;

    move-result-object v0

    iput-object v0, p0, La0/r;->I:La0/I0;

    invoke-virtual {v0}, La0/I0;->L()V

    iput-boolean v1, p0, La0/r;->J:Z

    iput-object v2, p0, La0/r;->K:La0/n0;

    :cond_7
    iget-object v0, p0, La0/r;->I:La0/I0;

    invoke-virtual {v0}, La0/I0;->d()V

    iget v3, v0, La0/I0;->t:I

    invoke-virtual {v0, p1, v5, v5, v1}, La0/I0;->P(ILjava/lang/Object;Ljava/lang/Object;Z)V

    invoke-virtual {v0, v3}, La0/I0;->b(I)La0/a;

    move-result-object p1

    iput-object p1, p0, La0/r;->N:La0/a;

    invoke-virtual {p0, v1, v2}, La0/r;->u(ZLa0/m0;)V

    return-void
.end method

.method public final W(I)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v1, v0, v0}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method public final X(I)La0/r;
    .locals 6

    invoke-virtual {p0, p1}, La0/r;->V(I)V

    iget-boolean p1, p0, La0/r;->S:Z

    iget-object v0, p0, La0/r;->g:LW2/g;

    iget-object v1, p0, La0/r;->E:Ljava/util/ArrayList;

    iget-object v2, p0, La0/r;->h:La0/x;

    if-eqz p1, :cond_0

    new-instance p1, La0/r0;

    invoke-direct {p1, v2}, La0/r0;-><init>(La0/x;)V

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p0, p1}, La0/r;->h0(Ljava/lang/Object;)V

    iget v1, p0, La0/r;->B:I

    iput v1, p1, La0/r0;->e:I

    iget v1, p1, La0/r0;->b:I

    and-int/lit8 v1, v1, -0x11

    iput v1, p1, La0/r0;->b:I

    invoke-virtual {v0}, LW2/g;->t()V

    return-object p0

    :cond_0
    iget-object p1, p0, La0/r;->G:La0/E0;

    iget p1, p1, La0/E0;->i:I

    iget-object v3, p0, La0/r;->s:Ljava/util/ArrayList;

    invoke-static {p1, v3}, La0/s;->e(ILjava/util/List;)I

    move-result p1

    if-ltz p1, :cond_1

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La0/N;

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    iget-object v3, p0, La0/r;->G:La0/E0;

    invoke-virtual {v3}, La0/E0;->m()Ljava/lang/Object;

    move-result-object v3

    sget-object v4, La0/m;->a:La0/U;

    invoke-static {v3, v4}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    new-instance v3, La0/r0;

    invoke-direct {v3, v2}, La0/r0;-><init>(La0/x;)V

    invoke-virtual {p0, v3}, La0/r;->h0(Ljava/lang/Object;)V

    goto :goto_1

    :cond_2
    const-string v2, "null cannot be cast to non-null type androidx.compose.runtime.RecomposeScopeImpl"

    invoke-static {v3, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, La0/r0;

    :goto_1
    const/4 v2, 0x0

    const/4 v4, 0x1

    if-nez p1, :cond_6

    iget p1, v3, La0/r0;->b:I

    and-int/lit8 v5, p1, 0x40

    if-eqz v5, :cond_3

    move v5, v4

    goto :goto_2

    :cond_3
    move v5, v2

    :goto_2
    if-eqz v5, :cond_4

    and-int/lit8 p1, p1, -0x41

    iput p1, v3, La0/r0;->b:I

    :cond_4
    if-eqz v5, :cond_5

    goto :goto_3

    :cond_5
    move p1, v2

    goto :goto_4

    :cond_6
    :goto_3
    move p1, v4

    :goto_4
    iget v5, v3, La0/r0;->b:I

    if-eqz p1, :cond_7

    or-int/lit8 p1, v5, 0x8

    goto :goto_5

    :cond_7
    and-int/lit8 p1, v5, -0x9

    :goto_5
    iput p1, v3, La0/r0;->b:I

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget p1, p0, La0/r;->B:I

    iput p1, v3, La0/r0;->e:I

    iget p1, v3, La0/r0;->b:I

    and-int/lit8 p1, p1, -0x11

    iput p1, v3, La0/r0;->b:I

    invoke-virtual {v0}, LW2/g;->t()V

    iget p1, v3, La0/r0;->b:I

    and-int/lit16 v0, p1, 0x100

    if-eqz v0, :cond_8

    and-int/lit16 p1, p1, -0x101

    or-int/lit16 p1, p1, 0x200

    iput p1, v3, La0/r0;->b:I

    iget-object p1, p0, La0/r;->M:Lb0/b;

    iget-object p1, p1, Lb0/b;->b:Lb0/a;

    iget-object p1, p1, Lb0/a;->a:Lb0/L;

    sget-object v0, Lb0/D;->c:Lb0/D;

    invoke-virtual {p1, v0}, Lb0/L;->e(Lb0/J;)V

    invoke-static {p1, v2, v3}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    iget-boolean p1, p0, La0/r;->y:Z

    if-nez p1, :cond_8

    iget p1, v3, La0/r0;->b:I

    and-int/lit16 v0, p1, 0x80

    if-eqz v0, :cond_8

    iput-boolean v4, p0, La0/r;->y:Z

    or-int/lit16 p1, p1, 0x400

    iput p1, v3, La0/r0;->b:I

    :cond_8
    return-object p0
.end method

.method public final Y(Ljava/lang/Object;)V
    .locals 3

    iget-boolean v0, p0, La0/r;->S:Z

    const/16 v1, 0xcf

    if-nez v0, :cond_0

    iget-object v0, p0, La0/r;->G:La0/E0;

    invoke-virtual {v0}, La0/E0;->g()I

    move-result v0

    if-ne v0, v1, :cond_0

    iget-object v0, p0, La0/r;->G:La0/E0;

    invoke-virtual {v0}, La0/E0;->f()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget v0, p0, La0/r;->z:I

    if-gez v0, :cond_0

    iget-object v0, p0, La0/r;->G:La0/E0;

    iget v0, v0, La0/E0;->g:I

    iput v0, p0, La0/r;->z:I

    const/4 v0, 0x1

    iput-boolean v0, p0, La0/r;->y:Z

    :cond_0
    const/4 v0, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2, v0, p1}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method public final Z()V
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/16 v2, 0x7d

    invoke-virtual {p0, v2, v1, v0, v0}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, La0/r;->r:Z

    return-void
.end method

.method public final a()V
    .locals 4

    invoke-virtual {p0}, La0/r;->i()V

    iget-object v0, p0, La0/r;->i:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, La0/r;->n:LL0/v;

    const/4 v1, 0x0

    iput v1, v0, LL0/v;->b:I

    iget-object v0, p0, La0/r;->t:LL0/v;

    iput v1, v0, LL0/v;->b:I

    iget-object v0, p0, La0/r;->x:LL0/v;

    iput v1, v0, LL0/v;->b:I

    const/4 v0, 0x0

    iput-object v0, p0, La0/r;->v:Lp/w;

    iget-object v0, p0, La0/r;->O:Lb0/c;

    iget-object v2, v0, Lb0/c;->b:Lb0/L;

    invoke-virtual {v2}, Lb0/L;->a()V

    iget-object v0, v0, Lb0/c;->a:Lb0/L;

    invoke-virtual {v0}, Lb0/L;->a()V

    int-to-long v2, v1

    iput-wide v2, p0, La0/r;->T:J

    iput v1, p0, La0/r;->A:I

    iput-boolean v1, p0, La0/r;->r:Z

    iput-boolean v1, p0, La0/r;->S:Z

    iput-boolean v1, p0, La0/r;->y:Z

    iput-boolean v1, p0, La0/r;->F:Z

    const/4 v0, -0x1

    iput v0, p0, La0/r;->z:I

    iget-object v0, p0, La0/r;->G:La0/E0;

    iget-boolean v1, v0, La0/E0;->f:Z

    if-nez v1, :cond_0

    invoke-virtual {v0}, La0/E0;->c()V

    :cond_0
    iget-object v0, p0, La0/r;->I:La0/I0;

    iget-boolean v0, v0, La0/I0;->w:Z

    if-nez v0, :cond_1

    invoke-virtual {p0}, La0/r;->v()V

    :cond_1
    return-void
.end method

.method public final a0()V
    .locals 7

    const/4 v0, 0x0

    iput v0, p0, La0/r;->m:I

    iget-object v1, p0, La0/r;->c:La0/F0;

    invoke-virtual {v1}, La0/F0;->e()La0/E0;

    move-result-object v1

    iput-object v1, p0, La0/r;->G:La0/E0;

    const/16 v1, 0x64

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v0, v2, v2}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    iget-object v1, p0, La0/r;->b:La0/u;

    invoke-virtual {v1}, La0/u;->r()V

    invoke-virtual {v1}, La0/u;->i()La0/n0;

    move-result-object v3

    iget-object v4, p0, La0/r;->x:LL0/v;

    iget-boolean v5, p0, La0/r;->w:Z

    invoke-virtual {v4, v5}, LL0/v;->c(I)V

    invoke-virtual {p0, v3}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v4

    iput-boolean v4, p0, La0/r;->w:Z

    iput-object v2, p0, La0/r;->K:La0/n0;

    iget-boolean v4, p0, La0/r;->q:Z

    if-nez v4, :cond_0

    invoke-virtual {v1}, La0/u;->e()Z

    move-result v4

    iput-boolean v4, p0, La0/r;->q:Z

    :cond_0
    iget-boolean v4, p0, La0/r;->C:Z

    if-nez v4, :cond_1

    invoke-virtual {v1}, La0/u;->f()Z

    move-result v4

    iput-boolean v4, p0, La0/r;->C:Z

    :cond_1
    iget-boolean v4, p0, La0/r;->C:Z

    if-eqz v4, :cond_2

    sget-object v4, Ll0/c;->a:La0/X0;

    const-string v5, "null cannot be cast to non-null type androidx.compose.runtime.CompositionLocal<kotlin.Any?>"

    invoke-static {v4, v5}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v5, La0/Y0;

    invoke-virtual {p0}, La0/r;->y()Ll0/b;

    move-result-object v6

    invoke-direct {v5, v6}, La0/Y0;-><init>(Ljava/lang/Object;)V

    check-cast v3, Li0/h;

    invoke-virtual {v3, v4, v5}, Li0/h;->b(La0/q0;La0/Z0;)Li0/h;

    move-result-object v3

    :cond_2
    iput-object v3, p0, La0/r;->u:La0/n0;

    sget-object v4, Ll0/e;->a:La0/X0;

    invoke-static {v3, v4}, La0/b;->v(La0/n0;La0/q0;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Set;

    if-eqz v3, :cond_4

    iget-object v4, p0, La0/r;->U:La0/w;

    if-nez v4, :cond_3

    new-instance v4, La0/w;

    iget-object v5, p0, La0/r;->h:La0/x;

    invoke-direct {v4, v5}, La0/w;-><init>(La0/t;)V

    iput-object v4, p0, La0/r;->U:La0/w;

    :cond_3
    invoke-interface {v3, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1, v3}, La0/u;->n(Ljava/util/Set;)V

    :cond_4
    invoke-virtual {v1}, La0/u;->g()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->hashCode(J)I

    move-result v1

    invoke-virtual {p0, v1, v0, v2, v2}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method public final b(Ljava/lang/Object;Lr7/e;)V
    .locals 6

    iget-boolean v0, p0, La0/r;->S:Z

    const/4 v1, 0x2

    const-string v2, "null cannot be cast to non-null type @[ExtensionFunctionType] kotlin.Function2<kotlin.Any?, kotlin.Any?, kotlin.Unit>"

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    iget-object v0, p0, La0/r;->O:Lb0/c;

    iget-object v0, v0, Lb0/c;->a:Lb0/L;

    sget-object v5, Lb0/G;->c:Lb0/G;

    invoke-virtual {v0, v5}, Lb0/L;->e(Lb0/J;)V

    invoke-static {v0, v4, p1}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    invoke-static {p2, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1, p2}, Ls7/x;->c(ILjava/lang/Object;)V

    invoke-static {v0, v3, p2}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    return-void

    :cond_0
    iget-object v0, p0, La0/r;->M:Lb0/b;

    invoke-virtual {v0}, Lb0/b;->b()V

    iget-object v0, v0, Lb0/b;->b:Lb0/a;

    iget-object v0, v0, Lb0/a;->a:Lb0/L;

    sget-object v5, Lb0/G;->c:Lb0/G;

    invoke-virtual {v0, v5}, Lb0/L;->e(Lb0/J;)V

    invoke-static {p2, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1, p2}, Ls7/x;->c(ILjava/lang/Object;)V

    invoke-static {v0, v4, p1, v3, p2}, LF4/x5;->b(Lb0/L;ILjava/lang/Object;ILjava/lang/Object;)V

    return-void
.end method

.method public final b0(La0/r0;Ljava/lang/Object;)Z
    .locals 6

    iget-object v0, p1, La0/r0;->c:La0/a;

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object v1, p0, La0/r;->G:La0/E0;

    iget-object v1, v1, La0/E0;->a:La0/F0;

    invoke-virtual {v1, v0}, La0/F0;->b(La0/a;)I

    move-result v0

    iget-boolean v1, p0, La0/r;->F:Z

    if-eqz v1, :cond_6

    iget-object v1, p0, La0/r;->G:La0/E0;

    iget v1, v1, La0/E0;->g:I

    if-lt v0, v1, :cond_6

    iget-object v1, p0, La0/r;->s:Ljava/util/ArrayList;

    invoke-static {v0, v1}, La0/s;->e(ILjava/util/List;)I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-gez v2, :cond_2

    add-int/2addr v2, v3

    neg-int v2, v2

    instance-of v5, p2, La0/E;

    if-eqz v5, :cond_1

    goto :goto_0

    :cond_1
    move-object p2, v4

    :goto_0
    new-instance v4, La0/N;

    invoke-direct {v4, p1, v0, p2}, La0/N;-><init>(La0/r0;ILjava/lang/Object;)V

    invoke-virtual {v1, v2, v4}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    return v3

    :cond_2
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La0/N;

    instance-of v0, p2, La0/E;

    if-eqz v0, :cond_5

    iget-object v0, p1, La0/N;->c:Ljava/lang/Object;

    if-nez v0, :cond_3

    iput-object p2, p1, La0/N;->c:Ljava/lang/Object;

    return v3

    :cond_3
    instance-of v1, v0, Lp/I;

    if-eqz v1, :cond_4

    check-cast v0, Lp/I;

    invoke-virtual {v0, p2}, Lp/I;->a(Ljava/lang/Object;)Z

    return v3

    :cond_4
    sget-object v1, Lp/Q;->a:Lp/I;

    new-instance v1, Lp/I;

    const/4 v2, 0x2

    invoke-direct {v1, v2}, Lp/I;-><init>(I)V

    invoke-virtual {v1, v0}, Lp/I;->j(Ljava/lang/Object;)V

    invoke-virtual {v1, p2}, Lp/I;->j(Ljava/lang/Object;)V

    iput-object v1, p1, La0/N;->c:Ljava/lang/Object;

    return v3

    :cond_5
    iput-object v4, p1, La0/N;->c:Ljava/lang/Object;

    return v3

    :cond_6
    :goto_1
    const/4 p1, 0x0

    return p1
.end method

.method public final c(F)Z
    .locals 2

    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Float;

    if-eqz v1, :cond_0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    cmpg-float v0, p1, v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    invoke-virtual {p0, p1}, La0/r;->h0(Ljava/lang/Object;)V

    const/4 p1, 0x1

    return p1
.end method

.method public final c0(Lp/H;)V
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, La0/r;->s:Ljava/util/ArrayList;

    invoke-static {v2}, Le7/m;->f(Ljava/util/List;)I

    move-result v3

    :goto_0
    const/4 v4, -0x1

    if-ge v4, v3, :cond_2

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La0/N;

    iget-object v5, v4, La0/N;->a:La0/r0;

    iget-object v5, v5, La0/r0;->c:La0/a;

    if-eqz v5, :cond_0

    invoke-virtual {v5}, La0/a;->a()Z

    move-result v6

    if-eqz v6, :cond_0

    iget v6, v4, La0/N;->b:I

    iget v5, v5, La0/a;->a:I

    if-eq v6, v5, :cond_1

    iput v5, v4, La0/N;->b:I

    goto :goto_1

    :cond_0
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_1
    :goto_1
    add-int/lit8 v3, v3, -0x1

    goto :goto_0

    :cond_2
    iget-object v3, v1, Lp/H;->b:[Ljava/lang/Object;

    iget-object v4, v1, Lp/H;->c:[Ljava/lang/Object;

    iget-object v1, v1, Lp/H;->a:[J

    array-length v5, v1

    add-int/lit8 v5, v5, -0x2

    if-ltz v5, :cond_7

    const/4 v7, 0x0

    :goto_2
    aget-wide v8, v1, v7

    not-long v10, v8

    const/4 v12, 0x7

    shl-long/2addr v10, v12

    and-long/2addr v10, v8

    const-wide v12, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    and-long/2addr v10, v12

    cmp-long v10, v10, v12

    if-eqz v10, :cond_6

    sub-int v10, v7, v5

    not-int v10, v10

    ushr-int/lit8 v10, v10, 0x1f

    const/16 v11, 0x8

    rsub-int/lit8 v10, v10, 0x8

    const/4 v12, 0x0

    :goto_3
    if-ge v12, v10, :cond_5

    const-wide/16 v13, 0xff

    and-long/2addr v13, v8

    const-wide/16 v15, 0x80

    cmp-long v13, v13, v15

    if-gez v13, :cond_4

    shl-int/lit8 v13, v7, 0x3

    add-int/2addr v13, v12

    aget-object v14, v3, v13

    aget-object v13, v4, v13

    const-string v15, "null cannot be cast to non-null type androidx.compose.runtime.RecomposeScopeImpl"

    invoke-static {v14, v15}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v14, La0/r0;

    iget-object v15, v14, La0/r0;->c:La0/a;

    if-eqz v15, :cond_4

    iget v15, v15, La0/a;->a:I

    sget-object v6, La0/U;->x:La0/U;

    if-ne v13, v6, :cond_3

    const/4 v13, 0x0

    :cond_3
    new-instance v6, La0/N;

    invoke-direct {v6, v14, v15, v13}, La0/N;-><init>(La0/r0;ILjava/lang/Object;)V

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    shr-long/2addr v8, v11

    add-int/lit8 v12, v12, 0x1

    goto :goto_3

    :cond_5
    if-ne v10, v11, :cond_7

    :cond_6
    if-eq v7, v5, :cond_7

    add-int/lit8 v7, v7, 0x1

    goto :goto_2

    :cond_7
    sget-object v1, La0/s;->f:LE/a;

    invoke-static {v2, v1}, Le7/q;->n(Ljava/util/List;Ljava/util/Comparator;)V

    return-void
.end method

.method public final d(I)Z
    .locals 2

    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Integer;

    if-eqz v1, :cond_0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    if-ne p1, v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p0, p1}, La0/r;->h0(Ljava/lang/Object;)V

    const/4 p1, 0x1

    return p1
.end method

.method public final d0(II)V
    .locals 4

    invoke-virtual {p0, p1}, La0/r;->i0(I)I

    move-result v0

    if-eq v0, p2, :cond_3

    if-gez p1, :cond_1

    iget-object v0, p0, La0/r;->p:Lp/u;

    if-nez v0, :cond_0

    new-instance v0, Lp/u;

    invoke-direct {v0}, Lp/u;-><init>()V

    iput-object v0, p0, La0/r;->p:Lp/u;

    :cond_0
    invoke-virtual {v0, p1, p2}, Lp/u;->f(II)V

    return-void

    :cond_1
    iget-object v0, p0, La0/r;->o:[I

    if-nez v0, :cond_2

    iget-object v0, p0, La0/r;->G:La0/E0;

    iget v0, v0, La0/E0;->c:I

    new-array v1, v0, [I

    const/4 v2, -0x1

    const/4 v3, 0x0

    invoke-static {v1, v3, v0, v2}, Ljava/util/Arrays;->fill([IIII)V

    iput-object v1, p0, La0/r;->o:[I

    move-object v0, v1

    :cond_2
    aput p2, v0, p1

    :cond_3
    return-void
.end method

.method public final e(J)Z
    .locals 2

    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Long;

    if-eqz v1, :cond_0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    cmp-long v0, p1, v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-virtual {p0, p1}, La0/r;->h0(Ljava/lang/Object;)V

    const/4 p1, 0x1

    return p1
.end method

.method public final e0(II)V
    .locals 6

    invoke-virtual {p0, p1}, La0/r;->i0(I)I

    move-result v0

    if-eq v0, p2, :cond_3

    sub-int/2addr p2, v0

    iget-object v0, p0, La0/r;->i:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_0
    const/4 v2, -0x1

    if-eq p1, v2, :cond_3

    invoke-virtual {p0, p1}, La0/r;->i0(I)I

    move-result v3

    add-int/2addr v3, p2

    invoke-virtual {p0, p1, v3}, La0/r;->d0(II)V

    move v4, v1

    :goto_1
    if-ge v2, v4, :cond_1

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La0/m0;

    if-eqz v5, :cond_0

    invoke-virtual {v5, p1, v3}, La0/m0;->a(II)Z

    move-result v5

    if-eqz v5, :cond_0

    add-int/lit8 v4, v4, -0x1

    move v1, v4

    goto :goto_2

    :cond_0
    add-int/lit8 v4, v4, -0x1

    goto :goto_1

    :cond_1
    :goto_2
    if-gez p1, :cond_2

    iget-object p1, p0, La0/r;->G:La0/E0;

    iget p1, p1, La0/E0;->i:I

    goto :goto_0

    :cond_2
    iget-object v2, p0, La0/r;->G:La0/E0;

    invoke-virtual {v2, p1}, La0/E0;->l(I)Z

    move-result v2

    if-nez v2, :cond_3

    iget-object v2, p0, La0/r;->G:La0/E0;

    invoke-virtual {v2, p1}, La0/E0;->q(I)I

    move-result p1

    goto :goto_0

    :cond_3
    return-void
.end method

.method public final f(Ljava/lang/Object;)Z
    .locals 1

    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0, p1}, La0/r;->h0(Ljava/lang/Object;)V

    const/4 p1, 0x1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public final f0(La0/n0;Li0/h;)Li0/h;
    .locals 2

    check-cast p1, Li0/h;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Li0/g;

    invoke-direct {v0, p1}, Li0/g;-><init>(Li0/h;)V

    invoke-virtual {v0, p2}, Li0/g;->putAll(Ljava/util/Map;)V

    invoke-virtual {v0}, Li0/g;->a()Li0/h;

    move-result-object p1

    const/16 v0, 0xcc

    sget-object v1, La0/s;->d:La0/b0;

    invoke-virtual {p0, v0, v1}, La0/r;->T(ILa0/b0;)V

    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    invoke-virtual {p0, p1}, La0/r;->h0(Ljava/lang/Object;)V

    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    invoke-virtual {p0, p2}, La0/r;->h0(Ljava/lang/Object;)V

    const/4 p2, 0x0

    invoke-virtual {p0, p2}, La0/r;->p(Z)V

    return-object p1
.end method

.method public final g(Z)Z
    .locals 2

    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Boolean;

    if-eqz v1, :cond_0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-ne p1, v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p0, p1}, La0/r;->h0(Ljava/lang/Object;)V

    const/4 p1, 0x1

    return p1
.end method

.method public final g0(Ljava/lang/Object;)V
    .locals 7

    instance-of v0, p1, La0/A0;

    if-eqz v0, :cond_5

    new-instance v0, La0/B0;

    move-object v1, p1

    check-cast v1, La0/A0;

    iget-boolean v2, p0, La0/r;->S:Z

    const/4 v3, 0x0

    if-eqz v2, :cond_1

    iget-object v2, p0, La0/r;->I:La0/I0;

    iget v4, v2, La0/I0;->t:I

    iget v5, v2, La0/I0;->v:I

    add-int/lit8 v5, v5, 0x1

    if-le v4, v5, :cond_3

    add-int/lit8 v4, v4, -0x1

    iget-object v3, v2, La0/I0;->b:[I

    invoke-virtual {v2, v3, v4}, La0/I0;->D([II)I

    move-result v2

    :goto_0
    move v6, v4

    move v4, v2

    move v2, v6

    iget-object v3, p0, La0/r;->I:La0/I0;

    iget v5, v3, La0/I0;->v:I

    if-eq v4, v5, :cond_0

    if-ltz v4, :cond_0

    iget-object v2, v3, La0/I0;->b:[I

    invoke-virtual {v3, v2, v4}, La0/I0;->D([II)I

    move-result v2

    goto :goto_0

    :cond_0
    invoke-virtual {v3, v2}, La0/I0;->b(I)La0/a;

    move-result-object v3

    goto :goto_2

    :cond_1
    iget-object v2, p0, La0/r;->G:La0/E0;

    iget v4, v2, La0/E0;->g:I

    iget v5, v2, La0/E0;->i:I

    add-int/lit8 v5, v5, 0x1

    if-le v4, v5, :cond_3

    add-int/lit8 v4, v4, -0x1

    invoke-virtual {v2, v4}, La0/E0;->q(I)I

    move-result v2

    :goto_1
    move v6, v4

    move v4, v2

    move v2, v6

    iget-object v3, p0, La0/r;->G:La0/E0;

    iget v5, v3, La0/E0;->i:I

    if-eq v4, v5, :cond_2

    if-ltz v4, :cond_2

    invoke-virtual {v3, v4}, La0/E0;->q(I)I

    move-result v2

    goto :goto_1

    :cond_2
    invoke-virtual {v3, v2}, La0/E0;->a(I)La0/a;

    move-result-object v3

    :cond_3
    :goto_2
    invoke-direct {v0, v1, v3}, La0/B0;-><init>(La0/A0;La0/a;)V

    iget-boolean v1, p0, La0/r;->S:Z

    if-eqz v1, :cond_4

    iget-object v1, p0, La0/r;->M:Lb0/b;

    iget-object v1, v1, Lb0/b;->b:Lb0/a;

    iget-object v1, v1, Lb0/a;->a:Lb0/L;

    sget-object v2, Lb0/w;->c:Lb0/w;

    invoke-virtual {v1, v2}, Lb0/L;->e(Lb0/J;)V

    const/4 v2, 0x0

    invoke-static {v1, v2, v0}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    :cond_4
    iget-object v1, p0, La0/r;->d:Lp/K;

    invoke-virtual {v1, p1}, Lp/K;->add(Ljava/lang/Object;)Z

    move-object p1, v0

    :cond_5
    invoke-virtual {p0, p1}, La0/r;->h0(Ljava/lang/Object;)V

    return-void
.end method

.method public final h(Ljava/lang/Object;)Z
    .locals 1

    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    move-result-object v0

    if-eq v0, p1, :cond_0

    invoke-virtual {p0, p1}, La0/r;->h0(Ljava/lang/Object;)V

    const/4 p1, 0x1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public final h0(Ljava/lang/Object;)V
    .locals 6

    iget-boolean v0, p0, La0/r;->S:Z

    if-eqz v0, :cond_3

    iget-object v0, p0, La0/r;->I:La0/I0;

    iget v1, v0, La0/I0;->n:I

    if-lez v1, :cond_2

    iget v1, v0, La0/I0;->i:I

    iget v2, v0, La0/I0;->k:I

    if-eq v1, v2, :cond_2

    iget-object v1, v0, La0/I0;->s:Lp/w;

    if-nez v1, :cond_0

    new-instance v1, Lp/w;

    invoke-direct {v1}, Lp/w;-><init>()V

    :cond_0
    iput-object v1, v0, La0/I0;->s:Lp/w;

    iget v0, v0, La0/I0;->v:I

    invoke-virtual {v1, v0}, Lp/l;->b(I)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_1

    new-instance v2, Lp/D;

    invoke-direct {v2}, Lp/D;-><init>()V

    invoke-virtual {v1, v0, v2}, Lp/w;->h(ILjava/lang/Object;)V

    :cond_1
    check-cast v2, Lp/D;

    invoke-virtual {v2, p1}, Lp/D;->a(Ljava/lang/Object;)V

    goto :goto_0

    :cond_2
    invoke-virtual {v0, p1}, La0/I0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_0
    return-void

    :cond_3
    iget-object v0, p0, La0/r;->G:La0/E0;

    iget-boolean v1, v0, La0/E0;->n:Z

    iget-object v2, p0, La0/r;->M:Lb0/b;

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v1, :cond_5

    iget v1, v0, La0/E0;->l:I

    iget-object v5, v0, La0/E0;->b:[I

    iget v0, v0, La0/E0;->i:I

    invoke-static {v5, v0}, La0/H0;->c([II)I

    move-result v0

    sub-int/2addr v1, v0

    sub-int/2addr v1, v4

    iget-object v0, v2, Lb0/b;->a:La0/r;

    iget-object v0, v0, La0/r;->G:La0/E0;

    iget v0, v0, La0/E0;->i:I

    iget v5, v2, Lb0/b;->f:I

    sub-int/2addr v0, v5

    if-gez v0, :cond_4

    iget-object v0, p0, La0/r;->G:La0/E0;

    iget v5, v0, La0/E0;->i:I

    invoke-virtual {v0, v5}, La0/E0;->a(I)La0/a;

    move-result-object v0

    iget-object v2, v2, Lb0/b;->b:Lb0/a;

    iget-object v2, v2, Lb0/a;->a:Lb0/L;

    sget-object v5, Lb0/r;->f:Lb0/r;

    invoke-virtual {v2, v5}, Lb0/L;->e(Lb0/J;)V

    invoke-static {v2, v3, p1, v4, v0}, LF4/x5;->b(Lb0/L;ILjava/lang/Object;ILjava/lang/Object;)V

    iget-object p1, v2, Lb0/L;->c:[I

    iget v0, v2, Lb0/L;->d:I

    iget-object v3, v2, Lb0/L;->a:[Lb0/J;

    iget v2, v2, Lb0/L;->b:I

    sub-int/2addr v2, v4

    aget-object v2, v3, v2

    iget v2, v2, Lb0/J;->a:I

    sub-int/2addr v0, v2

    aput v1, p1, v0

    return-void

    :cond_4
    invoke-virtual {v2, v4}, Lb0/b;->d(Z)V

    iget-object v0, v2, Lb0/b;->b:Lb0/a;

    iget-object v0, v0, Lb0/a;->a:Lb0/L;

    sget-object v2, Lb0/r;->g:Lb0/r;

    invoke-virtual {v0, v2}, Lb0/L;->e(Lb0/J;)V

    invoke-static {v0, v3, p1}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    iget-object p1, v0, Lb0/L;->c:[I

    iget v2, v0, Lb0/L;->d:I

    iget-object v3, v0, Lb0/L;->a:[Lb0/J;

    iget v0, v0, Lb0/L;->b:I

    sub-int/2addr v0, v4

    aget-object v0, v3, v0

    iget v0, v0, Lb0/J;->a:I

    sub-int/2addr v2, v0

    aput v1, p1, v2

    return-void

    :cond_5
    iget v1, v0, La0/E0;->i:I

    invoke-virtual {v0, v1}, La0/E0;->a(I)La0/a;

    move-result-object v0

    iget-object v1, v2, Lb0/b;->b:Lb0/a;

    iget-object v1, v1, Lb0/a;->a:Lb0/L;

    sget-object v2, Lb0/e;->c:Lb0/e;

    invoke-virtual {v1, v2}, Lb0/L;->e(Lb0/J;)V

    invoke-static {v1, v3, v0, v4, p1}, LF4/x5;->b(Lb0/L;ILjava/lang/Object;ILjava/lang/Object;)V

    return-void
.end method

.method public final i()V
    .locals 4

    const/4 v0, 0x0

    iput-object v0, p0, La0/r;->j:La0/m0;

    const/4 v1, 0x0

    iput v1, p0, La0/r;->k:I

    iput v1, p0, La0/r;->l:I

    const-wide/16 v2, 0x0

    iput-wide v2, p0, La0/r;->T:J

    iput-boolean v1, p0, La0/r;->r:Z

    iget-object v2, p0, La0/r;->M:Lb0/b;

    iput-boolean v1, v2, Lb0/b;->c:Z

    iget-object v3, v2, Lb0/b;->d:LL0/v;

    iput v1, v3, LL0/v;->b:I

    iput v1, v2, Lb0/b;->f:I

    const/4 v3, 0x1

    iput-boolean v3, v2, Lb0/b;->e:Z

    iput v1, v2, Lb0/b;->g:I

    iget-object v3, v2, Lb0/b;->h:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    const/4 v3, -0x1

    iput v3, v2, Lb0/b;->i:I

    iput v3, v2, Lb0/b;->j:I

    iput v3, v2, Lb0/b;->k:I

    iput v1, v2, Lb0/b;->l:I

    iget-object v1, p0, La0/r;->E:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iput-object v0, p0, La0/r;->o:[I

    iput-object v0, p0, La0/r;->p:Lp/u;

    return-void
.end method

.method public final i0(I)I
    .locals 3

    if-gez p1, :cond_2

    iget-object v0, p0, La0/r;->p:Lp/u;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {v0, p1}, Lp/u;->c(I)I

    move-result v2

    if-ltz v2, :cond_1

    invoke-virtual {v0, p1}, Lp/u;->c(I)I

    move-result v1

    if-ltz v1, :cond_0

    iget-object p1, v0, Lp/u;->c:[I

    aget p1, p1, v1

    return p1

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Cannot find value for key "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lq/a;->e(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1

    :cond_1
    return v1

    :cond_2
    iget-object v0, p0, La0/r;->o:[I

    if-eqz v0, :cond_3

    aget v0, v0, p1

    if-ltz v0, :cond_3

    return v0

    :cond_3
    iget-object v0, p0, La0/r;->G:La0/E0;

    invoke-virtual {v0, p1}, La0/E0;->o(I)I

    move-result p1

    return p1
.end method

.method public final j(La0/q0;)Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0}, La0/r;->l()La0/n0;

    move-result-object v0

    invoke-static {v0, p1}, La0/b;->v(La0/n0;La0/q0;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final j0()V
    .locals 3

    iget-boolean v0, p0, La0/r;->r:Z

    if-nez v0, :cond_0

    const-string v0, "A call to createNode(), emitNode() or useNode() expected was not expected"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, La0/r;->r:Z

    iget-boolean v0, p0, La0/r;->S:Z

    if-eqz v0, :cond_1

    const-string v0, "useNode() called while inserting"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :cond_1
    iget-object v0, p0, La0/r;->G:La0/E0;

    iget v1, v0, La0/E0;->i:I

    invoke-virtual {v0, v1}, La0/E0;->n(I)Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, La0/r;->M:Lb0/b;

    invoke-virtual {v1}, Lb0/b;->c()V

    iget-object v2, v1, Lb0/b;->h:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-boolean v2, p0, La0/r;->y:Z

    if-eqz v2, :cond_3

    instance-of v2, v0, La0/i;

    if-eqz v2, :cond_3

    invoke-virtual {v1}, Lb0/b;->b()V

    iget-object v1, v1, Lb0/b;->b:Lb0/a;

    if-eqz v0, :cond_2

    iget-object v0, v1, Lb0/a;->a:Lb0/L;

    sget-object v1, Lb0/I;->c:Lb0/I;

    invoke-virtual {v0, v1}, Lb0/L;->e(Lb0/J;)V

    return-void

    :cond_2
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_3
    return-void
.end method

.method public final k(Lr7/a;)V
    .locals 9

    iget-boolean v0, p0, La0/r;->r:Z

    if-nez v0, :cond_0

    const-string v0, "A call to createNode(), emitNode() or useNode() expected was not expected"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, La0/r;->r:Z

    iget-boolean v1, p0, La0/r;->S:Z

    if-nez v1, :cond_1

    const-string v1, "createNode() can only be called when inserting"

    invoke-static {v1}, La0/s;->c(Ljava/lang/String;)V

    :cond_1
    iget-object v1, p0, La0/r;->n:LL0/v;

    iget-object v2, v1, LL0/v;->a:[I

    iget v1, v1, LL0/v;->b:I

    const/4 v3, 0x1

    sub-int/2addr v1, v3

    aget v1, v2, v1

    iget-object v2, p0, La0/r;->I:La0/I0;

    iget v4, v2, La0/I0;->v:I

    invoke-virtual {v2, v4}, La0/I0;->b(I)La0/a;

    move-result-object v2

    iget v4, p0, La0/r;->l:I

    add-int/2addr v4, v3

    iput v4, p0, La0/r;->l:I

    iget-object v4, p0, La0/r;->O:Lb0/c;

    iget-object v5, v4, Lb0/c;->a:Lb0/L;

    sget-object v6, Lb0/r;->d:Lb0/r;

    invoke-virtual {v5, v6}, Lb0/L;->e(Lb0/J;)V

    invoke-static {v5, v0, p1}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    iget-object p1, v5, Lb0/L;->c:[I

    iget v6, v5, Lb0/L;->d:I

    iget-object v7, v5, Lb0/L;->a:[Lb0/J;

    iget v8, v5, Lb0/L;->b:I

    sub-int/2addr v8, v3

    aget-object v7, v7, v8

    iget v7, v7, Lb0/J;->a:I

    sub-int/2addr v6, v7

    aput v1, p1, v6

    invoke-static {v5, v3, v2}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    iget-object p1, v4, Lb0/c;->b:Lb0/L;

    sget-object v4, Lb0/r;->e:Lb0/r;

    invoke-virtual {p1, v4}, Lb0/L;->e(Lb0/J;)V

    iget-object v4, p1, Lb0/L;->c:[I

    iget v5, p1, Lb0/L;->d:I

    iget-object v6, p1, Lb0/L;->a:[Lb0/J;

    iget v7, p1, Lb0/L;->b:I

    sub-int/2addr v7, v3

    aget-object v3, v6, v7

    iget v3, v3, Lb0/J;->a:I

    sub-int/2addr v5, v3

    aput v1, v4, v5

    invoke-static {p1, v0, v2}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    return-void
.end method

.method public final l()La0/n0;
    .locals 7

    iget-object v0, p0, La0/r;->K:La0/n0;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    iget-object v0, p0, La0/r;->G:La0/E0;

    iget v0, v0, La0/E0;->i:I

    iget-boolean v1, p0, La0/r;->S:Z

    const-string v2, "null cannot be cast to non-null type androidx.compose.runtime.PersistentCompositionLocalMap"

    sget-object v3, La0/s;->c:La0/b0;

    const/16 v4, 0xca

    if-eqz v1, :cond_2

    iget-boolean v1, p0, La0/r;->J:Z

    if-eqz v1, :cond_2

    iget-object v1, p0, La0/r;->I:La0/I0;

    iget v1, v1, La0/I0;->v:I

    :goto_0
    if-lez v1, :cond_2

    iget-object v5, p0, La0/r;->I:La0/I0;

    iget-object v6, v5, La0/I0;->b:[I

    invoke-virtual {v5, v1}, La0/I0;->r(I)I

    move-result v5

    mul-int/lit8 v5, v5, 0x5

    aget v5, v6, v5

    if-ne v5, v4, :cond_1

    iget-object v5, p0, La0/r;->I:La0/I0;

    invoke-virtual {v5, v1}, La0/I0;->s(I)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v5, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    iget-object v0, p0, La0/r;->I:La0/I0;

    invoke-virtual {v0, v1}, La0/I0;->q(I)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, La0/n0;

    iput-object v0, p0, La0/r;->K:La0/n0;

    return-object v0

    :cond_1
    iget-object v5, p0, La0/r;->I:La0/I0;

    iget-object v6, v5, La0/I0;->b:[I

    invoke-virtual {v5, v6, v1}, La0/I0;->D([II)I

    move-result v1

    goto :goto_0

    :cond_2
    iget-object v1, p0, La0/r;->G:La0/E0;

    iget v1, v1, La0/E0;->c:I

    if-lez v1, :cond_6

    :goto_1
    if-lez v0, :cond_6

    iget-object v1, p0, La0/r;->G:La0/E0;

    invoke-virtual {v1, v0}, La0/E0;->i(I)I

    move-result v1

    if-ne v1, v4, :cond_5

    iget-object v1, p0, La0/r;->G:La0/E0;

    iget-object v5, v1, La0/E0;->b:[I

    invoke-virtual {v1, v5, v0}, La0/E0;->p([II)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    iget-object v1, p0, La0/r;->v:Lp/w;

    if-eqz v1, :cond_3

    invoke-virtual {v1, v0}, Lp/l;->b(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La0/n0;

    if-nez v1, :cond_4

    :cond_3
    iget-object v1, p0, La0/r;->G:La0/E0;

    iget-object v3, v1, La0/E0;->b:[I

    invoke-virtual {v1, v3, v0}, La0/E0;->b([II)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v2}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v1, v0

    check-cast v1, La0/n0;

    :cond_4
    iput-object v1, p0, La0/r;->K:La0/n0;

    return-object v1

    :cond_5
    iget-object v1, p0, La0/r;->G:La0/E0;

    invoke-virtual {v1, v0}, La0/E0;->q(I)I

    move-result v0

    goto :goto_1

    :cond_6
    iget-object v0, p0, La0/r;->u:La0/n0;

    iput-object v0, p0, La0/r;->K:La0/n0;

    return-object v0
.end method

.method public final m()Ljava/util/List;
    .locals 6

    iget-boolean v0, p0, La0/r;->C:Z

    sget-object v1, Le7/t;->t:Le7/t;

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v2, p0, La0/r;->I:La0/I0;

    const/4 v3, 0x0

    iget v4, v2, La0/I0;->t:I

    invoke-static {v2, v3, v4, v3}, LH4/X;->a(La0/I0;Ljava/lang/Integer;ILjava/lang/Integer;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v2, p0, La0/r;->G:La0/E0;

    iget-boolean v3, v2, La0/E0;->f:Z

    if-nez v3, :cond_2

    iget v3, v2, La0/E0;->c:I

    if-eqz v3, :cond_2

    new-instance v1, Ll0/h;

    invoke-direct {v1, v2}, Ll0/h;-><init>(Ljava/lang/Object;)V

    iget v3, v2, La0/E0;->i:I

    iget v4, v2, La0/E0;->l:I

    iget-object v5, v2, La0/E0;->b:[I

    invoke-static {v5, v3}, La0/H0;->c([II)I

    move-result v5

    sub-int/2addr v4, v5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    :goto_0
    if-ltz v3, :cond_1

    iget-object v5, v2, La0/E0;->a:La0/F0;

    invoke-virtual {v5, v3}, La0/F0;->h(I)La0/M;

    move-result-object v5

    invoke-virtual {v1, v5, v4}, LE/V;->y(La0/M;Ljava/lang/Object;)V

    invoke-virtual {v2, v3}, La0/E0;->a(I)La0/a;

    move-result-object v4

    invoke-virtual {v2, v3}, La0/E0;->q(I)I

    move-result v3

    goto :goto_0

    :cond_1
    iget-object v1, v1, LE/V;->u:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayList;

    :cond_2
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {p0}, La0/r;->D()Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    return-object v0
.end method

.method public final n(Lp/H;Lr7/e;)V
    .locals 7

    const-string v0, "Check failed"

    iget-object v1, p0, La0/r;->s:Ljava/util/ArrayList;

    iget-boolean v2, p0, La0/r;->F:Z

    if-eqz v2, :cond_0

    const-string v2, "Reentrant composition is not supported"

    invoke-static {v2}, La0/s;->c(Ljava/lang/String;)V

    :cond_0
    iget-object v2, p0, La0/r;->g:LW2/g;

    invoke-virtual {v2}, LW2/g;->t()V

    const-string v2, "Compose:recompose"

    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_0
    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v2

    invoke-virtual {v2}, Lk0/f;->g()J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    iput v2, p0, La0/r;->B:I

    const/4 v2, 0x0

    iput-object v2, p0, La0/r;->v:Lp/w;

    invoke-virtual {p0, p1}, La0/r;->c0(Lp/H;)V

    const/4 p1, 0x0

    iput p1, p0, La0/r;->k:I

    const/4 v2, 0x1

    iput-boolean v2, p0, La0/r;->F:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    invoke-virtual {p0}, La0/r;->a0()V

    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    move-result-object v3

    if-eq v3, p2, :cond_1

    if-eqz p2, :cond_1

    invoke-virtual {p0, p2}, La0/r;->h0(Ljava/lang/Object;)V

    goto :goto_0

    :catchall_0
    move-exception p2

    goto :goto_3

    :cond_1
    :goto_0
    iget-object v4, p0, La0/r;->D:La0/q;

    invoke-static {}, La0/b;->o()Lc0/e;

    move-result-object v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v5, v4}, Lc0/e;->b(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    sget-object v4, La0/s;->a:La0/b0;

    const/16 v6, 0xc8

    if-eqz p2, :cond_2

    :try_start_3
    invoke-virtual {p0, v6, v4}, La0/r;->T(ILa0/b0;)V

    invoke-static {p0, p2}, Li0/i;->c(La0/r;Lr7/e;)V

    invoke-virtual {p0, p1}, La0/r;->p(Z)V

    goto :goto_1

    :catchall_1
    move-exception p2

    goto :goto_2

    :cond_2
    iget-boolean p2, p0, La0/r;->w:Z

    if-eqz p2, :cond_3

    if-eqz v3, :cond_3

    sget-object p2, La0/m;->a:La0/U;

    invoke-virtual {v3, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_3

    invoke-virtual {p0, v6, v4}, La0/r;->T(ILa0/b0;)V

    const/4 p2, 0x2

    invoke-static {p2, v3}, Ls7/x;->c(ILjava/lang/Object;)V

    check-cast v3, Lr7/e;

    invoke-static {p0, v3}, Li0/i;->c(La0/r;Lr7/e;)V

    invoke-virtual {p0, p1}, La0/r;->p(Z)V

    goto :goto_1

    :cond_3
    invoke-virtual {p0}, La0/r;->O()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :goto_1
    :try_start_4
    iget p2, v5, Lc0/e;->v:I

    sub-int/2addr p2, v2

    invoke-virtual {v5, p2}, Lc0/e;->m(I)Ljava/lang/Object;

    invoke-virtual {p0}, La0/r;->t()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :try_start_5
    iput-boolean p1, p0, La0/r;->F:Z

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object p1, p0, La0/r;->I:La0/I0;

    iget-boolean p1, p1, La0/I0;->w:Z

    if-nez p1, :cond_4

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :cond_4
    invoke-virtual {p0}, La0/r;->v()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    invoke-static {}, Landroid/os/Trace;->endSection()V

    return-void

    :catchall_2
    move-exception p1

    goto :goto_4

    :goto_2
    :try_start_6
    iget v3, v5, Lc0/e;->v:I

    sub-int/2addr v3, v2

    invoke-virtual {v5, v3}, Lc0/e;->m(I)Ljava/lang/Object;

    throw p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :goto_3
    :try_start_7
    new-instance v2, La0/n;

    const/4 v3, 0x1

    invoke-direct {v2, v3, p0}, La0/n;-><init>(ILa0/r;)V

    invoke-static {p2, v2}, LH4/Y;->a(Ljava/lang/Throwable;Lr7/a;)Z

    throw p2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    :catchall_3
    move-exception p2

    :try_start_8
    iput-boolean p1, p0, La0/r;->F:Z

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {p0}, La0/r;->a()V

    iget-object p1, p0, La0/r;->I:La0/I0;

    iget-boolean p1, p1, La0/I0;->w:Z

    if-nez p1, :cond_5

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :cond_5
    invoke-virtual {p0}, La0/r;->v()V

    throw p2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    :goto_4
    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p1
.end method

.method public final o(II)V
    .locals 1

    if-lez p1, :cond_0

    if-eq p1, p2, :cond_0

    iget-object v0, p0, La0/r;->G:La0/E0;

    invoke-virtual {v0, p1}, La0/E0;->q(I)I

    move-result v0

    invoke-virtual {p0, v0, p2}, La0/r;->o(II)V

    iget-object p2, p0, La0/r;->G:La0/E0;

    invoke-virtual {p2, p1}, La0/E0;->l(I)Z

    move-result p2

    if-eqz p2, :cond_0

    iget-object p2, p0, La0/r;->G:La0/E0;

    invoke-virtual {p2, p1}, La0/E0;->n(I)Ljava/lang/Object;

    move-result-object p1

    iget-object p2, p0, La0/r;->M:Lb0/b;

    invoke-virtual {p2}, Lb0/b;->c()V

    iget-object p2, p2, Lb0/b;->h:Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    return-void
.end method

.method public final p(Z)V
    .locals 42

    move-object/from16 v0, p0

    iget-object v1, v0, La0/r;->n:LL0/v;

    iget-object v2, v1, LL0/v;->a:[I

    iget v3, v1, LL0/v;->b:I

    add-int/lit8 v3, v3, -0x2

    aget v2, v2, v3

    const/4 v3, 0x1

    sub-int/2addr v2, v3

    iget-boolean v4, v0, La0/r;->S:Z

    sget-object v5, La0/m;->a:La0/U;

    const/16 v6, 0xcf

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-eqz v4, :cond_3

    iget-object v4, v0, La0/r;->I:La0/I0;

    iget v9, v4, La0/I0;->v:I

    iget-object v10, v4, La0/I0;->b:[I

    invoke-virtual {v4, v9}, La0/I0;->r(I)I

    move-result v4

    mul-int/lit8 v4, v4, 0x5

    aget v4, v10, v4

    iget-object v10, v0, La0/r;->I:La0/I0;

    invoke-virtual {v10, v9}, La0/I0;->s(I)Ljava/lang/Object;

    move-result-object v10

    iget-object v11, v0, La0/r;->I:La0/I0;

    invoke-virtual {v11, v9}, La0/I0;->q(I)Ljava/lang/Object;

    move-result-object v9

    if-nez v10, :cond_1

    if-eqz v9, :cond_0

    if-ne v4, v6, :cond_0

    invoke-virtual {v9, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_0

    invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I

    move-result v4

    iget-wide v5, v0, La0/r;->T:J

    int-to-long v9, v2

    xor-long/2addr v5, v9

    invoke-static {v5, v6, v8}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v5

    int-to-long v9, v4

    xor-long v4, v5, v9

    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v4

    iput-wide v4, v0, La0/r;->T:J

    goto/16 :goto_4

    :cond_0
    iget-wide v5, v0, La0/r;->T:J

    int-to-long v9, v2

    xor-long/2addr v5, v9

    invoke-static {v5, v6, v8}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v5

    int-to-long v9, v4

    xor-long v4, v5, v9

    :goto_0
    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v4

    iput-wide v4, v0, La0/r;->T:J

    goto/16 :goto_4

    :cond_1
    instance-of v2, v10, Ljava/lang/Enum;

    if-eqz v2, :cond_2

    check-cast v10, Ljava/lang/Enum;

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    :goto_1
    iget-wide v4, v0, La0/r;->T:J

    int-to-long v9, v7

    xor-long/2addr v4, v9

    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v4

    int-to-long v9, v2

    xor-long/2addr v4, v9

    goto :goto_0

    :cond_2
    invoke-virtual {v10}, Ljava/lang/Object;->hashCode()I

    move-result v2

    goto :goto_1

    :cond_3
    iget-object v4, v0, La0/r;->G:La0/E0;

    iget v9, v4, La0/E0;->i:I

    invoke-virtual {v4, v9}, La0/E0;->i(I)I

    move-result v4

    iget-object v10, v0, La0/r;->G:La0/E0;

    iget-object v11, v10, La0/E0;->b:[I

    invoke-virtual {v10, v11, v9}, La0/E0;->p([II)Ljava/lang/Object;

    move-result-object v10

    iget-object v11, v0, La0/r;->G:La0/E0;

    iget-object v12, v11, La0/E0;->b:[I

    invoke-virtual {v11, v12, v9}, La0/E0;->b([II)Ljava/lang/Object;

    move-result-object v9

    if-nez v10, :cond_5

    if-eqz v9, :cond_4

    if-ne v4, v6, :cond_4

    invoke-virtual {v9, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_4

    invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I

    move-result v4

    iget-wide v5, v0, La0/r;->T:J

    int-to-long v9, v2

    xor-long/2addr v5, v9

    invoke-static {v5, v6, v8}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v5

    int-to-long v9, v4

    xor-long v4, v5, v9

    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v4

    iput-wide v4, v0, La0/r;->T:J

    goto :goto_4

    :cond_4
    iget-wide v5, v0, La0/r;->T:J

    int-to-long v9, v2

    xor-long/2addr v5, v9

    invoke-static {v5, v6, v8}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v5

    int-to-long v9, v4

    xor-long v4, v5, v9

    :goto_2
    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v4

    iput-wide v4, v0, La0/r;->T:J

    goto :goto_4

    :cond_5
    instance-of v2, v10, Ljava/lang/Enum;

    if-eqz v2, :cond_6

    check-cast v10, Ljava/lang/Enum;

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    :goto_3
    iget-wide v4, v0, La0/r;->T:J

    int-to-long v9, v7

    xor-long/2addr v4, v9

    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v4

    int-to-long v9, v2

    xor-long/2addr v4, v9

    goto :goto_2

    :cond_6
    invoke-virtual {v10}, Ljava/lang/Object;->hashCode()I

    move-result v2

    goto :goto_3

    :goto_4
    iget v2, v0, La0/r;->l:I

    iget-object v4, v0, La0/r;->j:La0/m0;

    iget-object v5, v0, La0/r;->s:Ljava/util/ArrayList;

    iget-object v9, v0, La0/r;->M:Lb0/b;

    if-eqz v4, :cond_22

    iget-object v10, v4, La0/m0;->e:Lp/w;

    iget v11, v4, La0/m0;->b:I

    iget-object v12, v4, La0/m0;->a:Ljava/util/ArrayList;

    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v13

    if-lez v13, :cond_22

    iget-object v13, v4, La0/m0;->d:Ljava/util/ArrayList;

    new-instance v14, Ljava/util/HashSet;

    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    move-result v15

    invoke-direct {v14, v15}, Ljava/util/HashSet;-><init>(I)V

    invoke-interface {v13}, Ljava/util/Collection;->size()I

    move-result v15

    move/from16 v16, v8

    move v8, v7

    :goto_5
    if-ge v8, v15, :cond_7

    const/16 v17, -0x1

    invoke-interface {v13, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v14, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    add-int/lit8 v8, v8, 0x1

    goto :goto_5

    :cond_7
    const/16 v17, -0x1

    new-instance v6, Ljava/util/LinkedHashSet;

    invoke-direct {v6}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    move-result v8

    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v15

    move v3, v7

    move/from16 v19, v3

    move/from16 v20, v19

    :goto_6
    if-ge v3, v15, :cond_21

    invoke-virtual {v12, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v21

    move-object/from16 v7, v21

    check-cast v7, La0/Q;

    invoke-virtual {v14, v7}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v21

    if-nez v21, :cond_9

    move-object/from16 v21, v1

    iget v1, v7, La0/Q;->c:I

    invoke-virtual {v10, v1}, Lp/l;->b(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La0/K;

    if-eqz v1, :cond_8

    iget v1, v1, La0/K;->b:I

    move/from16 v22, v1

    goto :goto_7

    :cond_8
    move/from16 v22, v17

    :goto_7
    iget v1, v7, La0/Q;->c:I

    move/from16 v23, v3

    add-int v3, v22, v11

    iget v7, v7, La0/Q;->d:I

    invoke-virtual {v9, v3, v7}, Lb0/b;->e(II)V

    const/4 v3, 0x0

    invoke-virtual {v4, v1, v3}, La0/m0;->a(II)Z

    iget v3, v9, Lb0/b;->f:I

    iget-object v7, v9, Lb0/b;->a:La0/r;

    iget-object v7, v7, La0/r;->G:La0/E0;

    iget v7, v7, La0/E0;->g:I

    sub-int v7, v1, v7

    add-int/2addr v7, v3

    iput v7, v9, Lb0/b;->f:I

    iget-object v3, v0, La0/r;->G:La0/E0;

    invoke-virtual {v3, v1}, La0/E0;->r(I)V

    invoke-virtual {v0}, La0/r;->H()V

    iget-object v3, v0, La0/r;->G:La0/E0;

    invoke-virtual {v3}, La0/E0;->s()I

    iget-object v3, v0, La0/r;->G:La0/E0;

    iget-object v3, v3, La0/E0;->b:[I

    mul-int/lit8 v7, v1, 0x5

    add-int/lit8 v7, v7, 0x3

    aget v3, v3, v7

    add-int/2addr v3, v1

    invoke-static {v1, v3, v5}, La0/s;->a(IILjava/util/List;)V

    :goto_8
    add-int/lit8 v3, v23, 0x1

    move-object/from16 v1, v21

    :goto_9
    const/4 v7, 0x0

    goto :goto_6

    :cond_9
    move-object/from16 v21, v1

    move/from16 v23, v3

    invoke-interface {v6, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a

    goto :goto_8

    :cond_a
    move/from16 v1, v19

    if-ge v1, v8, :cond_20

    invoke-virtual {v13, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La0/Q;

    if-eq v3, v7, :cond_1e

    iget v7, v3, La0/Q;->c:I

    invoke-virtual {v10, v7}, Lp/l;->b(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La0/K;

    if-eqz v7, :cond_b

    iget v7, v7, La0/K;->b:I

    goto :goto_a

    :cond_b
    move/from16 v7, v17

    :goto_a
    invoke-interface {v6, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move/from16 v19, v1

    move/from16 v1, v20

    move-object/from16 v20, v4

    if-eq v7, v1, :cond_1c

    iget v4, v3, La0/Q;->c:I

    invoke-virtual {v10, v4}, Lp/l;->b(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La0/K;

    if-eqz v4, :cond_c

    iget v4, v4, La0/K;->c:I

    :goto_b
    move-object/from16 v22, v6

    goto :goto_c

    :cond_c
    iget v4, v3, La0/Q;->d:I

    goto :goto_b

    :goto_c
    add-int v6, v7, v11

    move/from16 v24, v8

    add-int v8, v1, v11

    if-lez v4, :cond_f

    move/from16 v25, v11

    iget v11, v9, Lb0/b;->l:I

    if-lez v11, :cond_d

    move/from16 v26, v11

    iget v11, v9, Lb0/b;->j:I

    move-object/from16 v27, v12

    sub-int v12, v6, v26

    if-ne v11, v12, :cond_e

    iget v11, v9, Lb0/b;->k:I

    sub-int v12, v8, v26

    if-ne v11, v12, :cond_e

    add-int v11, v26, v4

    iput v11, v9, Lb0/b;->l:I

    goto :goto_d

    :cond_d
    move-object/from16 v27, v12

    :cond_e
    invoke-virtual {v9}, Lb0/b;->c()V

    iput v6, v9, Lb0/b;->j:I

    iput v8, v9, Lb0/b;->k:I

    iput v4, v9, Lb0/b;->l:I

    goto :goto_d

    :cond_f
    move/from16 v25, v11

    move-object/from16 v27, v12

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_d
    const-wide/16 v28, 0xff

    const-wide v30, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    if-le v7, v1, :cond_16

    const/16 v26, 0x7

    iget-object v6, v10, Lp/l;->c:[Ljava/lang/Object;

    const-wide/16 v32, 0x80

    iget-object v11, v10, Lp/l;->a:[J

    array-length v12, v11

    add-int/lit8 v12, v12, -0x2

    if-ltz v12, :cond_15

    move-object/from16 v35, v13

    move-object/from16 v36, v14

    const/4 v8, 0x0

    :goto_e
    const/16 v34, 0x8

    aget-wide v13, v11, v8

    move/from16 v38, v4

    move-object/from16 v37, v5

    not-long v4, v13

    shl-long v4, v4, v26

    and-long/2addr v4, v13

    and-long v4, v4, v30

    cmp-long v4, v4, v30

    if-eqz v4, :cond_14

    sub-int v4, v8, v12

    not-int v4, v4

    ushr-int/lit8 v4, v4, 0x1f

    rsub-int/lit8 v4, v4, 0x8

    const/4 v5, 0x0

    :goto_f
    if-ge v5, v4, :cond_13

    and-long v39, v13, v28

    cmp-long v39, v39, v32

    if-gez v39, :cond_11

    shl-int/lit8 v39, v8, 0x3

    add-int v39, v39, v5

    aget-object v39, v6, v39

    move/from16 v40, v5

    move-object/from16 v5, v39

    check-cast v5, La0/K;

    move-object/from16 v39, v6

    iget v6, v5, La0/K;->b:I

    move-object/from16 v41, v11

    if-gt v7, v6, :cond_10

    add-int v11, v7, v38

    if-ge v6, v11, :cond_10

    sub-int/2addr v6, v7

    add-int/2addr v6, v1

    iput v6, v5, La0/K;->b:I

    goto :goto_10

    :cond_10
    if-gt v1, v6, :cond_12

    if-ge v6, v7, :cond_12

    add-int v6, v6, v38

    iput v6, v5, La0/K;->b:I

    goto :goto_10

    :cond_11
    move/from16 v40, v5

    move-object/from16 v39, v6

    move-object/from16 v41, v11

    :cond_12
    :goto_10
    shr-long v13, v13, v34

    add-int/lit8 v5, v40, 0x1

    move-object/from16 v6, v39

    move-object/from16 v11, v41

    goto :goto_f

    :cond_13
    move-object/from16 v39, v6

    move-object/from16 v41, v11

    move/from16 v5, v34

    if-ne v4, v5, :cond_1d

    goto :goto_11

    :cond_14
    move-object/from16 v39, v6

    move-object/from16 v41, v11

    :goto_11
    if-eq v8, v12, :cond_1d

    add-int/lit8 v8, v8, 0x1

    move-object/from16 v5, v37

    move/from16 v4, v38

    move-object/from16 v6, v39

    move-object/from16 v11, v41

    goto :goto_e

    :cond_15
    move-object/from16 v37, v5

    goto/16 :goto_17

    :cond_16
    move/from16 v38, v4

    move-object/from16 v37, v5

    move-object/from16 v35, v13

    move-object/from16 v36, v14

    const/16 v26, 0x7

    const-wide/16 v32, 0x80

    if-le v1, v7, :cond_1d

    iget-object v4, v10, Lp/l;->c:[Ljava/lang/Object;

    iget-object v5, v10, Lp/l;->a:[J

    array-length v6, v5

    add-int/lit8 v6, v6, -0x2

    if-ltz v6, :cond_1d

    const/4 v8, 0x0

    :goto_12
    aget-wide v11, v5, v8

    not-long v13, v11

    shl-long v13, v13, v26

    and-long/2addr v13, v11

    and-long v13, v13, v30

    cmp-long v13, v13, v30

    if-eqz v13, :cond_1b

    sub-int v13, v8, v6

    not-int v13, v13

    ushr-int/lit8 v13, v13, 0x1f

    const/16 v34, 0x8

    rsub-int/lit8 v13, v13, 0x8

    const/4 v14, 0x0

    :goto_13
    if-ge v14, v13, :cond_1a

    and-long v39, v11, v28

    cmp-long v39, v39, v32

    if-gez v39, :cond_19

    shl-int/lit8 v39, v8, 0x3

    add-int v39, v39, v14

    aget-object v39, v4, v39

    move-object/from16 v40, v4

    move-object/from16 v4, v39

    check-cast v4, La0/K;

    move-object/from16 v39, v5

    iget v5, v4, La0/K;->b:I

    move/from16 v41, v7

    if-gt v7, v5, :cond_17

    add-int v7, v41, v38

    if-ge v5, v7, :cond_17

    sub-int v5, v5, v41

    add-int/2addr v5, v1

    iput v5, v4, La0/K;->b:I

    goto :goto_14

    :cond_17
    add-int/lit8 v7, v41, 0x1

    if-gt v7, v5, :cond_18

    if-ge v5, v1, :cond_18

    sub-int v5, v5, v38

    iput v5, v4, La0/K;->b:I

    :cond_18
    :goto_14
    const/16 v5, 0x8

    goto :goto_15

    :cond_19
    move-object/from16 v40, v4

    move-object/from16 v39, v5

    move/from16 v41, v7

    goto :goto_14

    :goto_15
    shr-long/2addr v11, v5

    add-int/lit8 v14, v14, 0x1

    move-object/from16 v5, v39

    move-object/from16 v4, v40

    move/from16 v7, v41

    goto :goto_13

    :cond_1a
    move-object/from16 v40, v4

    move-object/from16 v39, v5

    move/from16 v41, v7

    const/16 v5, 0x8

    if-ne v13, v5, :cond_1d

    goto :goto_16

    :cond_1b
    move-object/from16 v40, v4

    move-object/from16 v39, v5

    move/from16 v41, v7

    const/16 v5, 0x8

    :goto_16
    if-eq v8, v6, :cond_1d

    add-int/lit8 v8, v8, 0x1

    move-object/from16 v5, v39

    move-object/from16 v4, v40

    move/from16 v7, v41

    goto :goto_12

    :cond_1c
    move-object/from16 v37, v5

    move-object/from16 v22, v6

    move/from16 v24, v8

    move/from16 v25, v11

    move-object/from16 v27, v12

    :goto_17
    move-object/from16 v35, v13

    move-object/from16 v36, v14

    :cond_1d
    move/from16 v4, v23

    goto :goto_18

    :cond_1e
    move/from16 v19, v1

    move-object/from16 v37, v5

    move-object/from16 v22, v6

    move/from16 v24, v8

    move/from16 v25, v11

    move-object/from16 v27, v12

    move-object/from16 v35, v13

    move-object/from16 v36, v14

    move/from16 v1, v20

    move-object/from16 v20, v4

    add-int/lit8 v4, v23, 0x1

    :goto_18
    add-int/lit8 v19, v19, 0x1

    iget v5, v3, La0/Q;->c:I

    invoke-virtual {v10, v5}, Lp/l;->b(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La0/K;

    if-eqz v5, :cond_1f

    iget v3, v5, La0/K;->c:I

    goto :goto_19

    :cond_1f
    iget v3, v3, La0/Q;->d:I

    :goto_19
    add-int/2addr v1, v3

    move v3, v4

    move-object/from16 v4, v20

    move-object/from16 v6, v22

    move/from16 v8, v24

    move/from16 v11, v25

    move-object/from16 v12, v27

    move-object/from16 v13, v35

    move-object/from16 v14, v36

    move-object/from16 v5, v37

    const/4 v7, 0x0

    move/from16 v20, v1

    move-object/from16 v1, v21

    goto/16 :goto_6

    :cond_20
    move/from16 v19, v1

    move/from16 v1, v20

    move-object/from16 v1, v21

    move/from16 v3, v23

    goto/16 :goto_9

    :cond_21
    move-object/from16 v21, v1

    move-object/from16 v37, v5

    move-object/from16 v27, v12

    invoke-virtual {v9}, Lb0/b;->c()V

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lez v1, :cond_23

    iget-object v1, v0, La0/r;->G:La0/E0;

    iget v3, v1, La0/E0;->h:I

    iget v4, v9, Lb0/b;->f:I

    iget-object v5, v9, Lb0/b;->a:La0/r;

    iget-object v5, v5, La0/r;->G:La0/E0;

    iget v5, v5, La0/E0;->g:I

    sub-int/2addr v3, v5

    add-int/2addr v3, v4

    iput v3, v9, Lb0/b;->f:I

    invoke-virtual {v1}, La0/E0;->t()V

    goto :goto_1a

    :cond_22
    move-object/from16 v21, v1

    move-object/from16 v37, v5

    const/16 v17, -0x1

    :cond_23
    :goto_1a
    iget-boolean v1, v0, La0/r;->S:Z

    const/4 v3, -0x2

    if-nez v1, :cond_27

    iget-object v4, v0, La0/r;->G:La0/E0;

    iget v5, v4, La0/E0;->m:I

    iget v4, v4, La0/E0;->l:I

    sub-int/2addr v5, v4

    if-lez v5, :cond_27

    if-lez v5, :cond_26

    const/4 v4, 0x0

    invoke-virtual {v9, v4}, Lb0/b;->d(Z)V

    iget-object v4, v9, Lb0/b;->d:LL0/v;

    iget-object v6, v9, Lb0/b;->a:La0/r;

    iget-object v6, v6, La0/r;->G:La0/E0;

    iget v7, v6, La0/E0;->c:I

    if-lez v7, :cond_25

    iget v7, v6, La0/E0;->i:I

    invoke-virtual {v4, v3}, LL0/v;->a(I)I

    move-result v8

    if-eq v8, v7, :cond_25

    iget-boolean v8, v9, Lb0/b;->c:Z

    if-nez v8, :cond_24

    iget-boolean v8, v9, Lb0/b;->e:Z

    if-eqz v8, :cond_24

    const/4 v8, 0x0

    invoke-virtual {v9, v8}, Lb0/b;->d(Z)V

    iget-object v8, v9, Lb0/b;->b:Lb0/a;

    iget-object v8, v8, Lb0/a;->a:Lb0/L;

    sget-object v10, Lb0/q;->c:Lb0/q;

    invoke-virtual {v8, v10}, Lb0/L;->e(Lb0/J;)V

    const/4 v8, 0x1

    iput-boolean v8, v9, Lb0/b;->c:Z

    :cond_24
    if-lez v7, :cond_25

    invoke-virtual {v6, v7}, La0/E0;->a(I)La0/a;

    move-result-object v6

    invoke-virtual {v4, v7}, LL0/v;->c(I)V

    const/4 v4, 0x0

    invoke-virtual {v9, v4}, Lb0/b;->d(Z)V

    iget-object v7, v9, Lb0/b;->b:Lb0/a;

    iget-object v7, v7, Lb0/a;->a:Lb0/L;

    sget-object v8, Lb0/p;->c:Lb0/p;

    invoke-virtual {v7, v8}, Lb0/L;->e(Lb0/J;)V

    invoke-static {v7, v4, v6}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    const/4 v8, 0x1

    iput-boolean v8, v9, Lb0/b;->c:Z

    :cond_25
    iget-object v4, v9, Lb0/b;->b:Lb0/a;

    iget-object v4, v4, Lb0/a;->a:Lb0/L;

    sget-object v6, Lb0/E;->c:Lb0/E;

    invoke-virtual {v4, v6}, Lb0/L;->e(Lb0/J;)V

    iget-object v6, v4, Lb0/L;->c:[I

    iget v7, v4, Lb0/L;->d:I

    iget-object v8, v4, Lb0/L;->a:[Lb0/J;

    iget v4, v4, Lb0/L;->b:I

    const/16 v18, 0x1

    add-int/lit8 v4, v4, -0x1

    aget-object v4, v8, v4

    iget v4, v4, Lb0/J;->a:I

    sub-int/2addr v7, v4

    aput v5, v6, v7

    goto :goto_1b

    :cond_26
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_27
    :goto_1b
    iget v4, v0, La0/r;->k:I

    :goto_1c
    iget-object v5, v0, La0/r;->G:La0/E0;

    iget v6, v5, La0/E0;->k:I

    if-lez v6, :cond_28

    goto :goto_1d

    :cond_28
    iget v6, v5, La0/E0;->g:I

    iget v5, v5, La0/E0;->h:I

    if-ne v6, v5, :cond_3a

    :goto_1d
    if-eqz v1, :cond_33

    if-eqz p1, :cond_2a

    iget-object v2, v0, La0/r;->O:Lb0/c;

    iget-object v4, v2, Lb0/c;->b:Lb0/L;

    invoke-virtual {v4}, Lb0/L;->d()Z

    move-result v5

    if-nez v5, :cond_29

    const-string v5, "Cannot end node insertion, there are no pending operations that can be realized."

    invoke-static {v5}, La0/s;->c(Ljava/lang/String;)V

    :cond_29
    iget-object v2, v2, Lb0/c;->a:Lb0/L;

    iget-object v5, v4, Lb0/L;->a:[Lb0/J;

    iget v6, v4, Lb0/L;->b:I

    add-int/lit8 v6, v6, -0x1

    iput v6, v4, Lb0/L;->b:I

    aget-object v7, v5, v6

    const/4 v8, 0x0

    aput-object v8, v5, v6

    invoke-virtual {v2, v7}, Lb0/L;->e(Lb0/J;)V

    iget-object v5, v4, Lb0/L;->e:[Ljava/lang/Object;

    iget-object v6, v2, Lb0/L;->e:[Ljava/lang/Object;

    iget v10, v2, Lb0/L;->f:I

    iget v11, v7, Lb0/J;->b:I

    sub-int/2addr v10, v11

    iget v12, v4, Lb0/L;->f:I

    sub-int v13, v12, v11

    sub-int/2addr v12, v13

    invoke-static {v5, v13, v6, v10, v12}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v5, v4, Lb0/L;->e:[Ljava/lang/Object;

    iget v6, v4, Lb0/L;->f:I

    sub-int v10, v6, v11

    invoke-static {v5, v10, v6, v8}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    iget-object v5, v4, Lb0/L;->c:[I

    iget-object v6, v2, Lb0/L;->c:[I

    iget v2, v2, Lb0/L;->d:I

    iget v7, v7, Lb0/J;->a:I

    sub-int/2addr v2, v7

    iget v8, v4, Lb0/L;->d:I

    sub-int v10, v8, v7

    invoke-static {v2, v10, v8, v5, v6}, Le7/k;->g(III[I[I)V

    iget v2, v4, Lb0/L;->f:I

    sub-int/2addr v2, v11

    iput v2, v4, Lb0/L;->f:I

    iget v2, v4, Lb0/L;->d:I

    sub-int/2addr v2, v7

    iput v2, v4, Lb0/L;->d:I

    const/4 v2, 0x1

    :cond_2a
    iget-object v4, v0, La0/r;->G:La0/E0;

    iget v5, v4, La0/E0;->k:I

    if-lez v5, :cond_2b

    goto :goto_1e

    :cond_2b
    const-string v5, "Unbalanced begin/end empty"

    invoke-static {v5}, La0/o0;->a(Ljava/lang/String;)V

    :goto_1e
    iget v5, v4, La0/E0;->k:I

    add-int/lit8 v5, v5, -0x1

    iput v5, v4, La0/E0;->k:I

    iget-object v4, v0, La0/r;->I:La0/I0;

    iget v5, v4, La0/I0;->v:I

    invoke-virtual {v4}, La0/I0;->j()V

    iget-object v4, v0, La0/r;->G:La0/E0;

    iget v4, v4, La0/E0;->k:I

    if-lez v4, :cond_2c

    goto/16 :goto_22

    :cond_2c
    rsub-int/lit8 v4, v5, -0x2

    iget-object v5, v0, La0/r;->I:La0/I0;

    invoke-virtual {v5}, La0/I0;->k()V

    iget-object v5, v0, La0/r;->I:La0/I0;

    const/4 v8, 0x1

    invoke-virtual {v5, v8}, La0/I0;->e(Z)V

    iget-object v5, v0, La0/r;->N:La0/a;

    iget-object v6, v0, La0/r;->O:Lb0/c;

    iget-object v6, v6, Lb0/c;->a:Lb0/L;

    invoke-virtual {v6}, Lb0/L;->c()Z

    move-result v6

    if-eqz v6, :cond_2f

    iget-object v6, v0, La0/r;->H:La0/F0;

    invoke-virtual {v9}, Lb0/b;->b()V

    const/4 v8, 0x0

    invoke-virtual {v9, v8}, Lb0/b;->d(Z)V

    iget-object v7, v9, Lb0/b;->d:LL0/v;

    iget-object v8, v9, Lb0/b;->a:La0/r;

    iget-object v8, v8, La0/r;->G:La0/E0;

    iget v10, v8, La0/E0;->c:I

    if-lez v10, :cond_2e

    iget v10, v8, La0/E0;->i:I

    invoke-virtual {v7, v3}, LL0/v;->a(I)I

    move-result v3

    if-eq v3, v10, :cond_2e

    iget-boolean v3, v9, Lb0/b;->c:Z

    if-nez v3, :cond_2d

    iget-boolean v3, v9, Lb0/b;->e:Z

    if-eqz v3, :cond_2d

    const/4 v3, 0x0

    invoke-virtual {v9, v3}, Lb0/b;->d(Z)V

    iget-object v3, v9, Lb0/b;->b:Lb0/a;

    iget-object v3, v3, Lb0/a;->a:Lb0/L;

    sget-object v11, Lb0/q;->c:Lb0/q;

    invoke-virtual {v3, v11}, Lb0/L;->e(Lb0/J;)V

    const/4 v3, 0x1

    iput-boolean v3, v9, Lb0/b;->c:Z

    :cond_2d
    if-lez v10, :cond_2e

    invoke-virtual {v8, v10}, La0/E0;->a(I)La0/a;

    move-result-object v3

    invoke-virtual {v7, v10}, LL0/v;->c(I)V

    const/4 v8, 0x0

    invoke-virtual {v9, v8}, Lb0/b;->d(Z)V

    iget-object v7, v9, Lb0/b;->b:Lb0/a;

    iget-object v7, v7, Lb0/a;->a:Lb0/L;

    sget-object v10, Lb0/p;->c:Lb0/p;

    invoke-virtual {v7, v10}, Lb0/L;->e(Lb0/J;)V

    invoke-static {v7, v8, v3}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    const/4 v8, 0x1

    iput-boolean v8, v9, Lb0/b;->c:Z

    goto :goto_1f

    :cond_2e
    const/4 v8, 0x1

    :goto_1f
    invoke-virtual {v9}, Lb0/b;->c()V

    iget-object v3, v9, Lb0/b;->b:Lb0/a;

    iget-object v3, v3, Lb0/a;->a:Lb0/L;

    sget-object v7, Lb0/s;->c:Lb0/s;

    invoke-virtual {v3, v7}, Lb0/L;->e(Lb0/J;)V

    const/4 v7, 0x0

    invoke-static {v3, v7, v5, v8, v6}, LF4/x5;->b(Lb0/L;ILjava/lang/Object;ILjava/lang/Object;)V

    move v3, v7

    goto/16 :goto_20

    :cond_2f
    const/4 v7, 0x0

    iget-object v6, v0, La0/r;->H:La0/F0;

    iget-object v8, v0, La0/r;->O:Lb0/c;

    invoke-virtual {v9}, Lb0/b;->b()V

    invoke-virtual {v9, v7}, Lb0/b;->d(Z)V

    iget-object v7, v9, Lb0/b;->d:LL0/v;

    iget-object v10, v9, Lb0/b;->a:La0/r;

    iget-object v10, v10, La0/r;->G:La0/E0;

    iget v11, v10, La0/E0;->c:I

    if-lez v11, :cond_31

    iget v11, v10, La0/E0;->i:I

    invoke-virtual {v7, v3}, LL0/v;->a(I)I

    move-result v3

    if-eq v3, v11, :cond_31

    iget-boolean v3, v9, Lb0/b;->c:Z

    if-nez v3, :cond_30

    iget-boolean v3, v9, Lb0/b;->e:Z

    if-eqz v3, :cond_30

    const/4 v3, 0x0

    invoke-virtual {v9, v3}, Lb0/b;->d(Z)V

    iget-object v3, v9, Lb0/b;->b:Lb0/a;

    iget-object v3, v3, Lb0/a;->a:Lb0/L;

    sget-object v12, Lb0/q;->c:Lb0/q;

    invoke-virtual {v3, v12}, Lb0/L;->e(Lb0/J;)V

    const/4 v3, 0x1

    iput-boolean v3, v9, Lb0/b;->c:Z

    :cond_30
    if-lez v11, :cond_31

    invoke-virtual {v10, v11}, La0/E0;->a(I)La0/a;

    move-result-object v3

    invoke-virtual {v7, v11}, LL0/v;->c(I)V

    const/4 v7, 0x0

    invoke-virtual {v9, v7}, Lb0/b;->d(Z)V

    iget-object v10, v9, Lb0/b;->b:Lb0/a;

    iget-object v10, v10, Lb0/a;->a:Lb0/L;

    sget-object v11, Lb0/p;->c:Lb0/p;

    invoke-virtual {v10, v11}, Lb0/L;->e(Lb0/J;)V

    invoke-static {v10, v7, v3}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    const/4 v3, 0x1

    iput-boolean v3, v9, Lb0/b;->c:Z

    :cond_31
    invoke-virtual {v9}, Lb0/b;->c()V

    iget-object v3, v9, Lb0/b;->b:Lb0/a;

    iget-object v3, v3, Lb0/a;->a:Lb0/L;

    sget-object v7, Lb0/t;->c:Lb0/t;

    invoke-virtual {v3, v7}, Lb0/L;->e(Lb0/J;)V

    iget v7, v3, Lb0/L;->f:I

    iget-object v9, v3, Lb0/L;->a:[Lb0/J;

    iget v10, v3, Lb0/L;->b:I

    const/16 v18, 0x1

    add-int/lit8 v10, v10, -0x1

    aget-object v9, v9, v10

    iget v9, v9, Lb0/J;->b:I

    sub-int/2addr v7, v9

    iget-object v3, v3, Lb0/L;->e:[Ljava/lang/Object;

    aput-object v5, v3, v7

    add-int/lit8 v5, v7, 0x1

    aput-object v6, v3, v5

    add-int/lit8 v7, v7, 0x2

    aput-object v8, v3, v7

    new-instance v3, Lb0/c;

    invoke-direct {v3}, Lb0/c;-><init>()V

    iput-object v3, v0, La0/r;->O:Lb0/c;

    const/4 v3, 0x0

    :goto_20
    iput-boolean v3, v0, La0/r;->S:Z

    iget-object v5, v0, La0/r;->c:La0/F0;

    iget v5, v5, La0/F0;->u:I

    if-nez v5, :cond_32

    goto :goto_22

    :cond_32
    invoke-virtual {v0, v4, v3}, La0/r;->d0(II)V

    invoke-virtual {v0, v4, v2}, La0/r;->e0(II)V

    goto :goto_22

    :cond_33
    if-eqz p1, :cond_34

    invoke-virtual {v9}, Lb0/b;->a()V

    :cond_34
    iget-object v3, v9, Lb0/b;->a:La0/r;

    iget-object v3, v3, La0/r;->G:La0/E0;

    iget v3, v3, La0/E0;->i:I

    iget-object v4, v9, Lb0/b;->d:LL0/v;

    move/from16 v5, v17

    invoke-virtual {v4, v5}, LL0/v;->a(I)I

    move-result v6

    if-gt v6, v3, :cond_35

    goto :goto_21

    :cond_35
    const-string v6, "Missed recording an endGroup"

    invoke-static {v6}, La0/s;->c(Ljava/lang/String;)V

    :goto_21
    invoke-virtual {v4, v5}, LL0/v;->a(I)I

    move-result v5

    if-ne v5, v3, :cond_36

    const/4 v8, 0x0

    invoke-virtual {v9, v8}, Lb0/b;->d(Z)V

    invoke-virtual {v4}, LL0/v;->b()I

    iget-object v3, v9, Lb0/b;->b:Lb0/a;

    iget-object v3, v3, Lb0/a;->a:Lb0/L;

    sget-object v4, Lb0/m;->c:Lb0/m;

    invoke-virtual {v3, v4}, Lb0/L;->e(Lb0/J;)V

    :cond_36
    iget-object v3, v0, La0/r;->G:La0/E0;

    iget v3, v3, La0/E0;->i:I

    invoke-virtual {v0, v3}, La0/r;->i0(I)I

    move-result v4

    if-eq v2, v4, :cond_37

    invoke-virtual {v0, v3, v2}, La0/r;->e0(II)V

    :cond_37
    if-eqz p1, :cond_38

    const/4 v2, 0x1

    :cond_38
    iget-object v3, v0, La0/r;->G:La0/E0;

    invoke-virtual {v3}, La0/E0;->e()V

    invoke-virtual {v9}, Lb0/b;->c()V

    :goto_22
    iget-object v3, v0, La0/r;->i:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/16 v18, 0x1

    add-int/lit8 v4, v4, -0x1

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La0/m0;

    if-eqz v3, :cond_39

    if-nez v1, :cond_39

    iget v1, v3, La0/m0;->c:I

    add-int/lit8 v1, v1, 0x1

    iput v1, v3, La0/m0;->c:I

    :cond_39
    iput-object v3, v0, La0/r;->j:La0/m0;

    invoke-virtual/range {v21 .. v21}, LL0/v;->b()I

    move-result v1

    add-int/2addr v1, v2

    iput v1, v0, La0/r;->k:I

    invoke-virtual/range {v21 .. v21}, LL0/v;->b()I

    move-result v1

    iput v1, v0, La0/r;->m:I

    invoke-virtual/range {v21 .. v21}, LL0/v;->b()I

    move-result v1

    add-int/2addr v1, v2

    iput v1, v0, La0/r;->l:I

    return-void

    :cond_3a
    move/from16 v5, v17

    const/4 v8, 0x0

    const/16 v18, 0x1

    invoke-virtual {v0}, La0/r;->H()V

    iget-object v7, v0, La0/r;->G:La0/E0;

    invoke-virtual {v7}, La0/E0;->s()I

    move-result v7

    invoke-virtual {v9, v4, v7}, Lb0/b;->e(II)V

    iget-object v7, v0, La0/r;->G:La0/E0;

    iget v7, v7, La0/E0;->g:I

    move-object/from16 v10, v37

    invoke-static {v6, v7, v10}, La0/s;->a(IILjava/util/List;)V

    goto/16 :goto_1c
.end method

.method public final q()V
    .locals 3

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La0/r;->p(Z)V

    invoke-virtual {p0}, La0/r;->w()La0/r0;

    move-result-object v0

    if-eqz v0, :cond_0

    iget v1, v0, La0/r0;->b:I

    and-int/lit8 v2, v1, 0x1

    if-eqz v2, :cond_0

    or-int/lit8 v1, v1, 0x2

    iput v1, v0, La0/r0;->b:I

    :cond_0
    return-void
.end method

.method public final r()La0/r0;
    .locals 21

    move-object/from16 v0, p0

    iget-object v1, v0, La0/r;->E:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    const/4 v3, 0x1

    if-nez v2, :cond_0

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    sub-int/2addr v2, v3

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La0/r0;

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    if-eqz v1, :cond_7

    iget v5, v1, La0/r0;->b:I

    and-int/lit8 v5, v5, -0x9

    iput v5, v1, La0/r0;->b:I

    iget-object v5, v0, La0/r;->g:LW2/g;

    invoke-virtual {v5}, LW2/g;->t()V

    iget v5, v0, La0/r;->B:I

    iget-object v6, v1, La0/r0;->f:Lp/C;

    if-eqz v6, :cond_5

    iget v7, v1, La0/r0;->b:I

    and-int/lit8 v7, v7, 0x10

    if-eqz v7, :cond_1

    goto :goto_3

    :cond_1
    iget-object v7, v6, Lp/C;->b:[Ljava/lang/Object;

    iget-object v8, v6, Lp/C;->c:[I

    iget-object v9, v6, Lp/C;->a:[J

    array-length v10, v9

    add-int/lit8 v10, v10, -0x2

    if-ltz v10, :cond_5

    const/4 v11, 0x0

    :goto_1
    aget-wide v12, v9, v11

    not-long v14, v12

    const/16 v16, 0x7

    shl-long v14, v14, v16

    and-long/2addr v14, v12

    const-wide v16, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    and-long v14, v14, v16

    cmp-long v14, v14, v16

    if-eqz v14, :cond_4

    sub-int v14, v11, v10

    not-int v14, v14

    ushr-int/lit8 v14, v14, 0x1f

    const/16 v15, 0x8

    rsub-int/lit8 v14, v14, 0x8

    const/4 v4, 0x0

    :goto_2
    if-ge v4, v14, :cond_3

    const-wide/16 v17, 0xff

    and-long v17, v12, v17

    const-wide/16 v19, 0x80

    cmp-long v17, v17, v19

    if-gez v17, :cond_2

    shl-int/lit8 v17, v11, 0x3

    add-int v17, v17, v4

    aget-object v18, v7, v17

    aget v2, v8, v17

    if-eq v2, v5, :cond_2

    new-instance v2, LI/N0;

    const/4 v4, 0x1

    invoke-direct {v2, v5, v4, v1, v6}, LI/N0;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V

    goto :goto_4

    :cond_2
    shr-long/2addr v12, v15

    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_3
    if-ne v14, v15, :cond_5

    :cond_4
    if-eq v11, v10, :cond_5

    add-int/lit8 v11, v11, 0x1

    goto :goto_1

    :cond_5
    :goto_3
    const/4 v2, 0x0

    :goto_4
    iget-object v4, v0, La0/r;->M:Lb0/b;

    if-eqz v2, :cond_6

    iget-object v5, v4, Lb0/b;->b:Lb0/a;

    iget-object v5, v5, Lb0/a;->a:Lb0/L;

    sget-object v6, Lb0/l;->c:Lb0/l;

    invoke-virtual {v5, v6}, Lb0/L;->e(Lb0/J;)V

    iget-object v6, v0, La0/r;->h:La0/x;

    const/4 v7, 0x0

    invoke-static {v5, v7, v2, v3, v6}, LF4/x5;->b(Lb0/L;ILjava/lang/Object;ILjava/lang/Object;)V

    :cond_6
    iget v2, v1, La0/r0;->b:I

    and-int/lit16 v5, v2, 0x200

    if-eqz v5, :cond_7

    and-int/lit16 v2, v2, -0x201

    iput v2, v1, La0/r0;->b:I

    iget-object v2, v4, Lb0/b;->b:Lb0/a;

    iget-object v2, v2, Lb0/a;->a:Lb0/L;

    sget-object v4, Lb0/o;->c:Lb0/o;

    invoke-virtual {v2, v4}, Lb0/L;->e(Lb0/J;)V

    const/4 v7, 0x0

    invoke-static {v2, v7, v1}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    iget v2, v1, La0/r0;->b:I

    and-int/lit16 v4, v2, -0x81

    iput v4, v1, La0/r0;->b:I

    and-int/lit16 v4, v2, 0x400

    if-eqz v4, :cond_7

    and-int/lit16 v2, v2, -0x481

    iput v2, v1, La0/r0;->b:I

    iput-boolean v7, v0, La0/r;->y:Z

    :cond_7
    if-eqz v1, :cond_c

    iget v2, v1, La0/r0;->b:I

    and-int/lit8 v4, v2, 0x10

    if-eqz v4, :cond_8

    goto :goto_8

    :cond_8
    and-int/2addr v2, v3

    if-eqz v2, :cond_9

    goto :goto_5

    :cond_9
    iget-boolean v2, v0, La0/r;->q:Z

    if-eqz v2, :cond_c

    :goto_5
    iget-object v2, v1, La0/r0;->c:La0/a;

    if-nez v2, :cond_b

    iget-boolean v2, v0, La0/r;->S:Z

    if-eqz v2, :cond_a

    iget-object v2, v0, La0/r;->I:La0/I0;

    iget v3, v2, La0/I0;->v:I

    invoke-virtual {v2, v3}, La0/I0;->b(I)La0/a;

    move-result-object v2

    goto :goto_6

    :cond_a
    iget-object v2, v0, La0/r;->G:La0/E0;

    iget v3, v2, La0/E0;->i:I

    invoke-virtual {v2, v3}, La0/E0;->a(I)La0/a;

    move-result-object v2

    :goto_6
    iput-object v2, v1, La0/r0;->c:La0/a;

    :cond_b
    iget v2, v1, La0/r0;->b:I

    and-int/lit8 v2, v2, -0x5

    iput v2, v1, La0/r0;->b:I

    move-object v4, v1

    :goto_7
    const/4 v7, 0x0

    goto :goto_9

    :cond_c
    :goto_8
    const/4 v4, 0x0

    goto :goto_7

    :goto_9
    invoke-virtual {v0, v7}, La0/r;->p(Z)V

    return-object v4
.end method

.method public final s()V
    .locals 2

    iget-boolean v0, p0, La0/r;->F:Z

    if-nez v0, :cond_0

    iget v0, p0, La0/r;->z:I

    const/16 v1, 0x64

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const-string v0, "Cannot disable reuse from root if it was caused by other groups"

    invoke-static {v0}, La0/o0;->a(Ljava/lang/String;)V

    :goto_0
    const/4 v0, -0x1

    iput v0, p0, La0/r;->z:I

    const/4 v0, 0x0

    iput-boolean v0, p0, La0/r;->y:Z

    return-void
.end method

.method public final t()V
    .locals 4

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La0/r;->p(Z)V

    iget-object v1, p0, La0/r;->b:La0/u;

    invoke-virtual {v1}, La0/u;->c()V

    invoke-virtual {p0, v0}, La0/r;->p(Z)V

    iget-object v1, p0, La0/r;->M:Lb0/b;

    iget-boolean v2, v1, Lb0/b;->c:Z

    if-eqz v2, :cond_0

    invoke-virtual {v1, v0}, Lb0/b;->d(Z)V

    invoke-virtual {v1, v0}, Lb0/b;->d(Z)V

    iget-object v2, v1, Lb0/b;->b:Lb0/a;

    iget-object v2, v2, Lb0/a;->a:Lb0/L;

    sget-object v3, Lb0/m;->c:Lb0/m;

    invoke-virtual {v2, v3}, Lb0/L;->e(Lb0/J;)V

    iput-boolean v0, v1, Lb0/b;->c:Z

    :cond_0
    invoke-virtual {v1}, Lb0/b;->b()V

    iget-object v1, v1, Lb0/b;->d:LL0/v;

    iget v1, v1, LL0/v;->b:I

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    const-string v1, "Missed recording an endGroup()"

    invoke-static {v1}, La0/s;->c(Ljava/lang/String;)V

    :goto_0
    iget-object v1, p0, La0/r;->i:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    const-string v1, "Start/end imbalance"

    invoke-static {v1}, La0/s;->c(Ljava/lang/String;)V

    :cond_2
    invoke-virtual {p0}, La0/r;->i()V

    iget-object v1, p0, La0/r;->G:La0/E0;

    invoke-virtual {v1}, La0/E0;->c()V

    iget-object v1, p0, La0/r;->x:LL0/v;

    invoke-virtual {v1}, LL0/v;->b()I

    move-result v1

    if-eqz v1, :cond_3

    const/4 v0, 0x1

    :cond_3
    iput-boolean v0, p0, La0/r;->w:Z

    return-void
.end method

.method public final u(ZLa0/m0;)V
    .locals 2

    iget-object v0, p0, La0/r;->i:Ljava/util/ArrayList;

    iget-object v1, p0, La0/r;->j:La0/m0;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iput-object p2, p0, La0/r;->j:La0/m0;

    iget p2, p0, La0/r;->l:I

    iget-object v0, p0, La0/r;->n:LL0/v;

    invoke-virtual {v0, p2}, LL0/v;->c(I)V

    iget p2, p0, La0/r;->m:I

    invoke-virtual {v0, p2}, LL0/v;->c(I)V

    iget p2, p0, La0/r;->k:I

    invoke-virtual {v0, p2}, LL0/v;->c(I)V

    const/4 p2, 0x0

    if-eqz p1, :cond_0

    iput p2, p0, La0/r;->k:I

    :cond_0
    iput p2, p0, La0/r;->l:I

    iput p2, p0, La0/r;->m:I

    return-void
.end method

.method public final v()V
    .locals 2

    new-instance v0, La0/F0;

    invoke-direct {v0}, La0/F0;-><init>()V

    iget-boolean v1, p0, La0/r;->C:Z

    if-eqz v1, :cond_0

    invoke-virtual {v0}, La0/F0;->c()V

    :cond_0
    iget-object v1, p0, La0/r;->b:La0/u;

    invoke-virtual {v1}, La0/u;->d()Z

    move-result v1

    if-eqz v1, :cond_1

    new-instance v1, Lp/w;

    invoke-direct {v1}, Lp/w;-><init>()V

    iput-object v1, v0, La0/F0;->D:Lp/w;

    :cond_1
    iput-object v0, p0, La0/r;->H:La0/F0;

    invoke-virtual {v0}, La0/F0;->f()La0/I0;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, La0/I0;->e(Z)V

    iput-object v0, p0, La0/r;->I:La0/I0;

    return-void
.end method

.method public final w()La0/r0;
    .locals 2

    iget v0, p0, La0/r;->A:I

    if-nez v0, :cond_0

    iget-object v0, p0, La0/r;->E:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La0/r0;

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final x()Z
    .locals 1

    invoke-virtual {p0}, La0/r;->z()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-boolean v0, p0, La0/r;->w:Z

    if-nez v0, :cond_1

    invoke-virtual {p0}, La0/r;->w()La0/r0;

    move-result-object v0

    if-eqz v0, :cond_0

    iget v0, v0, La0/r0;->b:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    return v0

    :cond_1
    :goto_0
    const/4 v0, 0x1

    return v0
.end method

.method public final y()Ll0/b;
    .locals 1

    iget-boolean v0, p0, La0/r;->C:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, La0/r;->Q:Ll0/b;

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final z()Z
    .locals 1

    iget-boolean v0, p0, La0/r;->S:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, La0/r;->y:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, La0/r;->w:Z

    if-nez v0, :cond_1

    invoke-virtual {p0}, La0/r;->w()La0/r0;

    move-result-object v0

    if-eqz v0, :cond_1

    iget v0, v0, La0/r0;->b:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    return v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return v0
.end method
