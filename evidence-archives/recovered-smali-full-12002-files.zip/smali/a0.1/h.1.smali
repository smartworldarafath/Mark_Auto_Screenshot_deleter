.class public abstract La0/h;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    sget-object v0, La0/g;->v:La0/g;

    new-instance v1, Li0/d;

    const v2, 0x38ea4dba

    const/4 v3, 0x0

    invoke-direct {v1, v2, v0, v3}, Li0/d;-><init>(ILjava/lang/Object;Z)V

    sget-object v0, La0/g;->u:La0/g;

    new-instance v1, Li0/d;

    const v2, 0x72535ae8

    invoke-direct {v1, v2, v0, v3}, Li0/d;-><init>(ILjava/lang/Object;Z)V

    return-void
.end method
