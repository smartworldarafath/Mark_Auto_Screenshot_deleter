.class public final La0/x0;
.super Lj7/i;
.source "SourceFile"

# interfaces
.implements Lr7/f;


# instance fields
.field public A:Lp/I;

.field public B:Lp/I;

.field public C:Lp/I;

.field public D:Ljava/util/Set;

.field public E:Lp/I;

.field public F:I

.field public synthetic G:La0/V;

.field public final synthetic H:La0/y0;

.field public x:Ljava/util/List;

.field public y:Ljava/util/List;

.field public z:Ljava/util/List;


# direct methods
.method public constructor <init>(La0/y0;Lh7/c;)V
    .locals 0

    iput-object p1, p0, La0/x0;->H:La0/y0;

    const/4 p1, 0x3

    invoke-direct {p0, p1, p2}, Lj7/i;-><init>(ILh7/c;)V

    return-void
.end method

.method public static final r(La0/y0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lp/I;Lp/I;Lp/I;Lp/I;)V
    .locals 22

    move-object/from16 v0, p0

    move-object/from16 v1, p4

    move-object/from16 v2, p5

    move-object/from16 v3, p7

    iget-object v4, v0, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v4

    :try_start_0
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->clear()V

    invoke-interface/range {p2 .. p2}, Ljava/util/List;->clear()V

    invoke-interface/range {p3 .. p3}, Ljava/util/Collection;->size()I

    move-result v5

    const/4 v7, 0x0

    :goto_0
    if-ge v7, v5, :cond_0

    move-object/from16 v8, p3

    invoke-interface {v8, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La0/x;

    invoke-virtual {v9}, La0/x;->a()V

    invoke-virtual {v0, v9}, La0/y0;->G(La0/x;)V

    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    goto/16 :goto_7

    :cond_0
    move-object/from16 v8, p3

    invoke-interface {v8}, Ljava/util/List;->clear()V

    iget-object v5, v1, Lp/I;->b:[Ljava/lang/Object;

    iget-object v7, v1, Lp/I;->a:[J

    array-length v8, v7

    add-int/lit8 v8, v8, -0x2

    const/16 v6, 0x8

    const-wide/16 p2, 0x80

    if-ltz v8, :cond_4

    const/4 v9, 0x0

    const-wide/16 v16, 0xff

    :goto_1
    aget-wide v11, v7, v9

    const/4 v10, 0x7

    const-wide v18, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    not-long v13, v11

    shl-long/2addr v13, v10

    and-long/2addr v13, v11

    and-long v13, v13, v18

    cmp-long v13, v13, v18

    if-eqz v13, :cond_3

    sub-int v13, v9, v8

    not-int v13, v13

    ushr-int/lit8 v13, v13, 0x1f

    rsub-int/lit8 v13, v13, 0x8

    const/4 v14, 0x0

    :goto_2
    if-ge v14, v13, :cond_2

    and-long v20, v11, v16

    cmp-long v15, v20, p2

    if-gez v15, :cond_1

    shl-int/lit8 v15, v9, 0x3

    add-int/2addr v15, v14

    aget-object v15, v5, v15

    check-cast v15, La0/x;

    invoke-virtual {v15}, La0/x;->a()V

    invoke-virtual {v0, v15}, La0/y0;->G(La0/x;)V

    :cond_1
    shr-long/2addr v11, v6

    add-int/lit8 v14, v14, 0x1

    goto :goto_2

    :cond_2
    if-ne v13, v6, :cond_5

    :cond_3
    if-eq v9, v8, :cond_5

    add-int/lit8 v9, v9, 0x1

    goto :goto_1

    :cond_4
    const/4 v10, 0x7

    const-wide/16 v16, 0xff

    const-wide v18, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    :cond_5
    invoke-virtual {v1}, Lp/I;->b()V

    iget-object v1, v2, Lp/I;->b:[Ljava/lang/Object;

    iget-object v5, v2, Lp/I;->a:[J

    array-length v7, v5

    add-int/lit8 v7, v7, -0x2

    if-ltz v7, :cond_9

    const/4 v8, 0x0

    :goto_3
    aget-wide v11, v5, v8

    not-long v13, v11

    shl-long/2addr v13, v10

    and-long/2addr v13, v11

    and-long v13, v13, v18

    cmp-long v9, v13, v18

    if-eqz v9, :cond_8

    sub-int v9, v8, v7

    not-int v9, v9

    ushr-int/lit8 v9, v9, 0x1f

    rsub-int/lit8 v9, v9, 0x8

    const/4 v13, 0x0

    :goto_4
    if-ge v13, v9, :cond_7

    and-long v14, v11, v16

    cmp-long v14, v14, p2

    if-gez v14, :cond_6

    shl-int/lit8 v14, v8, 0x3

    add-int/2addr v14, v13

    aget-object v14, v1, v14

    check-cast v14, La0/x;

    invoke-virtual {v14}, La0/x;->g()V

    :cond_6
    shr-long/2addr v11, v6

    add-int/lit8 v13, v13, 0x1

    goto :goto_4

    :cond_7
    if-ne v9, v6, :cond_9

    :cond_8
    if-eq v8, v7, :cond_9

    add-int/lit8 v8, v8, 0x1

    goto :goto_3

    :cond_9
    invoke-virtual {v2}, Lp/I;->b()V

    invoke-virtual/range {p6 .. p6}, Lp/I;->b()V

    iget-object v1, v3, Lp/I;->b:[Ljava/lang/Object;

    iget-object v2, v3, Lp/I;->a:[J

    array-length v5, v2

    add-int/lit8 v5, v5, -0x2

    if-ltz v5, :cond_d

    const/4 v7, 0x0

    :goto_5
    aget-wide v8, v2, v7

    not-long v11, v8

    shl-long/2addr v11, v10

    and-long/2addr v11, v8

    and-long v11, v11, v18

    cmp-long v11, v11, v18

    if-eqz v11, :cond_c

    sub-int v11, v7, v5

    not-int v11, v11

    ushr-int/lit8 v11, v11, 0x1f

    rsub-int/lit8 v11, v11, 0x8

    const/4 v12, 0x0

    :goto_6
    if-ge v12, v11, :cond_b

    and-long v13, v8, v16

    cmp-long v13, v13, p2

    if-gez v13, :cond_a

    shl-int/lit8 v13, v7, 0x3

    add-int/2addr v13, v12

    aget-object v13, v1, v13

    check-cast v13, La0/x;

    invoke-virtual {v13}, La0/x;->a()V

    invoke-virtual {v0, v13}, La0/y0;->G(La0/x;)V

    :cond_a
    shr-long/2addr v8, v6

    add-int/lit8 v12, v12, 0x1

    goto :goto_6

    :cond_b
    if-ne v11, v6, :cond_d

    :cond_c
    if-eq v7, v5, :cond_d

    add-int/lit8 v7, v7, 0x1

    goto :goto_5

    :cond_d
    invoke-virtual {v3}, Lp/I;->b()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v4

    return-void

    :goto_7
    monitor-exit v4

    throw v0
.end method

.method public static final s(Ljava/util/List;La0/y0;)V
    .locals 5

    invoke-interface {p0}, Ljava/util/List;->clear()V

    iget-object v0, p1, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p1, La0/y0;->j:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_0

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La0/Y;

    invoke-interface {p0, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    iget-object p0, p1, La0/y0;->j:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0

    throw p0
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    check-cast p1, LD7/v;

    check-cast p2, La0/V;

    check-cast p3, Lh7/c;

    new-instance p1, La0/x0;

    iget-object v0, p0, La0/x0;->H:La0/y0;

    invoke-direct {p1, v0, p3}, La0/x0;-><init>(La0/y0;Lh7/c;)V

    iput-object p2, p1, La0/x0;->G:La0/V;

    sget-object p2, Ld7/z;->a:Ld7/z;

    invoke-virtual {p1, p2}, La0/x0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Li7/a;->t:Li7/a;

    return-object p1
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    move-object/from16 v1, p0

    sget-object v0, Li7/a;->t:Li7/a;

    iget v2, v1, La0/x0;->F:I

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    if-eq v2, v5, :cond_1

    if-ne v2, v4, :cond_0

    iget-object v2, v1, La0/x0;->E:Lp/I;

    iget-object v6, v1, La0/x0;->D:Ljava/util/Set;

    check-cast v6, Ljava/util/Set;

    iget-object v7, v1, La0/x0;->C:Lp/I;

    iget-object v8, v1, La0/x0;->B:Lp/I;

    iget-object v9, v1, La0/x0;->A:Lp/I;

    iget-object v10, v1, La0/x0;->z:Ljava/util/List;

    iget-object v11, v1, La0/x0;->y:Ljava/util/List;

    iget-object v12, v1, La0/x0;->x:Ljava/util/List;

    iget-object v13, v1, La0/x0;->G:La0/V;

    invoke-static/range {p1 .. p1}, Ld7/a;->e(Ljava/lang/Object;)V

    move-object/from16 v19, v13

    move-object v13, v2

    move-object/from16 v2, v19

    goto/16 :goto_6

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    iget-object v2, v1, La0/x0;->E:Lp/I;

    iget-object v6, v1, La0/x0;->D:Ljava/util/Set;

    check-cast v6, Ljava/util/Set;

    iget-object v7, v1, La0/x0;->C:Lp/I;

    iget-object v8, v1, La0/x0;->B:Lp/I;

    iget-object v9, v1, La0/x0;->A:Lp/I;

    iget-object v10, v1, La0/x0;->z:Ljava/util/List;

    iget-object v11, v1, La0/x0;->y:Ljava/util/List;

    iget-object v12, v1, La0/x0;->x:Ljava/util/List;

    iget-object v13, v1, La0/x0;->G:La0/V;

    invoke-static/range {p1 .. p1}, Ld7/a;->e(Ljava/lang/Object;)V

    move-object v14, v9

    move-object v9, v2

    move-object v2, v13

    move-object v13, v10

    move-object v10, v12

    move-object v12, v14

    :goto_0
    move-object v15, v6

    move-object v14, v8

    move-object v8, v7

    goto/16 :goto_4

    :cond_2
    invoke-static/range {p1 .. p1}, Ld7/a;->e(Ljava/lang/Object;)V

    iget-object v2, v1, La0/x0;->G:La0/V;

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    sget-object v9, Lp/Q;->a:Lp/I;

    new-instance v9, Lp/I;

    invoke-direct {v9}, Lp/I;-><init>()V

    new-instance v10, Lp/I;

    invoke-direct {v10}, Lp/I;-><init>()V

    new-instance v11, Lp/I;

    invoke-direct {v11}, Lp/I;-><init>()V

    new-instance v12, Lc0/h;

    invoke-direct {v12, v11}, Lc0/h;-><init>(Lp/I;)V

    new-instance v13, Lp/I;

    invoke-direct {v13}, Lp/I;-><init>()V

    move-object/from16 v19, v12

    move-object v12, v6

    move-object/from16 v6, v19

    move-object/from16 v19, v11

    move-object v11, v7

    move-object/from16 v7, v19

    move-object/from16 v19, v10

    move-object v10, v8

    move-object/from16 v8, v19

    :goto_1
    iget-object v14, v1, La0/x0;->H:La0/y0;

    iget-object v14, v14, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v14

    monitor-exit v14

    iget-object v14, v1, La0/x0;->H:La0/y0;

    iput-object v2, v1, La0/x0;->G:La0/V;

    iput-object v12, v1, La0/x0;->x:Ljava/util/List;

    iput-object v11, v1, La0/x0;->y:Ljava/util/List;

    iput-object v10, v1, La0/x0;->z:Ljava/util/List;

    iput-object v9, v1, La0/x0;->A:Lp/I;

    iput-object v8, v1, La0/x0;->B:Lp/I;

    iput-object v7, v1, La0/x0;->C:Lp/I;

    move-object v15, v6

    check-cast v15, Ljava/util/Set;

    iput-object v15, v1, La0/x0;->D:Ljava/util/Set;

    iput-object v13, v1, La0/x0;->E:Lp/I;

    iput v5, v1, La0/x0;->F:I

    invoke-virtual {v14}, La0/y0;->y()Z

    move-result v15

    if-nez v15, :cond_6

    new-instance v15, LD7/h;

    invoke-static {v1}, LG2/J;->c(Lh7/c;)Lh7/c;

    move-result-object v3

    invoke-direct {v15, v5, v3}, LD7/h;-><init>(ILh7/c;)V

    invoke-virtual {v15}, LD7/h;->u()V

    iget-object v3, v14, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v3

    :try_start_0
    invoke-virtual {v14}, La0/y0;->y()Z

    move-result v16

    if-eqz v16, :cond_3

    move-object v14, v15

    goto :goto_2

    :cond_3
    iput-object v15, v14, La0/y0;->q:LD7/h;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v14, 0x0

    :goto_2
    monitor-exit v3

    if-eqz v14, :cond_4

    sget-object v3, Ld7/z;->a:Ld7/z;

    invoke-virtual {v14, v3}, LD7/h;->e(Ljava/lang/Object;)V

    :cond_4
    invoke-virtual {v15}, LD7/h;->s()Ljava/lang/Object;

    move-result-object v3

    sget-object v14, Li7/a;->t:Li7/a;

    if-ne v3, v14, :cond_5

    goto :goto_3

    :cond_5
    sget-object v3, Ld7/z;->a:Ld7/z;

    goto :goto_3

    :catchall_0
    move-exception v0

    monitor-exit v3

    throw v0

    :cond_6
    sget-object v3, Ld7/z;->a:Ld7/z;

    :goto_3
    if-ne v3, v0, :cond_7

    goto :goto_5

    :cond_7
    move-object v14, v12

    move-object v12, v9

    move-object v9, v13

    move-object v13, v10

    move-object v10, v14

    goto/16 :goto_0

    :goto_4
    iget-object v3, v1, La0/x0;->H:La0/y0;

    sget-object v6, La0/y0;->y:LG7/g0;

    invoke-virtual {v3}, La0/y0;->F()Z

    move-result v3

    if-eqz v3, :cond_c

    iget-object v7, v1, La0/x0;->H:La0/y0;

    new-instance v6, La0/w0;

    invoke-direct/range {v6 .. v15}, La0/w0;-><init>(La0/y0;Lp/I;Lp/I;Ljava/util/List;Ljava/util/List;Lp/I;Ljava/util/List;Lp/I;Ljava/util/Set;)V

    iput-object v2, v1, La0/x0;->G:La0/V;

    iput-object v10, v1, La0/x0;->x:Ljava/util/List;

    iput-object v11, v1, La0/x0;->y:Ljava/util/List;

    iput-object v13, v1, La0/x0;->z:Ljava/util/List;

    iput-object v12, v1, La0/x0;->A:Lp/I;

    iput-object v14, v1, La0/x0;->B:Lp/I;

    iput-object v8, v1, La0/x0;->C:Lp/I;

    move-object v3, v15

    check-cast v3, Ljava/util/Set;

    iput-object v3, v1, La0/x0;->D:Ljava/util/Set;

    iput-object v9, v1, La0/x0;->E:Lp/I;

    iput v4, v1, La0/x0;->F:I

    invoke-interface {v2, v1, v6}, La0/V;->C(Lh7/c;Lr7/c;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v0, :cond_8

    :goto_5
    return-object v0

    :cond_8
    move-object v6, v13

    move-object v13, v9

    move-object v9, v12

    move-object v12, v10

    move-object v10, v6

    move-object v7, v8

    move-object v8, v14

    move-object v6, v15

    :goto_6
    iget-object v3, v1, La0/x0;->H:La0/y0;

    iget-object v14, v3, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v14

    :try_start_1
    iget-object v15, v3, La0/y0;->k:Lp/H;

    invoke-virtual {v15}, Lp/H;->j()Z

    move-result v15

    const/16 v16, 0x0

    if-eqz v15, :cond_a

    iget-object v15, v3, La0/y0;->k:Lp/H;

    invoke-static {v15}, Lc0/a;->b(Lp/H;)Lp/D;

    move-result-object v15

    iget-object v4, v3, La0/y0;->k:Lp/H;

    invoke-virtual {v4}, Lp/H;->a()V

    iget-object v4, v3, La0/y0;->l:LP2/c;

    iget-object v5, v4, LP2/c;->u:Ljava/lang/Object;

    check-cast v5, Lp/H;

    invoke-virtual {v5}, Lp/H;->a()V

    iget-object v4, v4, LP2/c;->v:Ljava/lang/Object;

    check-cast v4, Lp/H;

    invoke-virtual {v4}, Lp/H;->a()V

    iget-object v4, v3, La0/y0;->n:Lp/H;

    invoke-virtual {v4}, Lp/H;->a()V

    new-instance v4, Lp/D;

    iget v5, v15, Lp/D;->b:I

    invoke-direct {v4, v5}, Lp/D;-><init>(I)V

    iget-object v5, v15, Lp/D;->a:[Ljava/lang/Object;

    iget v15, v15, Lp/D;->b:I

    move-object/from16 v17, v0

    move/from16 v0, v16

    :goto_7
    if-ge v0, v15, :cond_9

    aget-object v18, v5, v0

    move/from16 p1, v0

    move-object/from16 v0, v18

    check-cast v0, La0/Y;

    iget-object v1, v3, La0/y0;->m:Lp/H;

    invoke-virtual {v1, v0}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v18, v2

    new-instance v2, Ld7/k;

    invoke-direct {v2, v0, v1}, Ld7/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v4, v2}, Lp/D;->a(Ljava/lang/Object;)V

    add-int/lit8 v0, p1, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, v18

    goto :goto_7

    :catchall_1
    move-exception v0

    goto :goto_a

    :cond_9
    move-object/from16 v18, v2

    iget-object v0, v3, La0/y0;->m:Lp/H;

    invoke-virtual {v0}, Lp/H;->a()V

    goto :goto_8

    :cond_a
    move-object/from16 v17, v0

    move-object/from16 v18, v2

    sget-object v4, Lp/N;->b:Lp/D;

    const-string v0, "null cannot be cast to non-null type androidx.collection.ObjectList<E of androidx.collection.ObjectListKt.emptyObjectList>"

    invoke-static {v4, v0}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_8
    monitor-exit v14

    iget-object v0, v4, Lp/D;->a:[Ljava/lang/Object;

    iget v1, v4, Lp/D;->b:I

    move/from16 v2, v16

    :goto_9
    if-ge v2, v1, :cond_b

    aget-object v3, v0, v2

    check-cast v3, Ld7/k;

    iget-object v4, v3, Ld7/k;->t:Ljava/lang/Object;

    check-cast v4, La0/Y;

    iget-object v3, v3, Ld7/k;->u:Ljava/lang/Object;

    check-cast v3, La0/X;

    add-int/lit8 v2, v2, 0x1

    goto :goto_9

    :cond_b
    const/4 v4, 0x2

    const/4 v5, 0x1

    move-object/from16 v1, p0

    move-object/from16 v0, v17

    move-object/from16 v2, v18

    goto/16 :goto_1

    :goto_a
    monitor-exit v14

    throw v0

    :cond_c
    move-object v1, v13

    move-object v13, v9

    move-object v9, v12

    move-object v12, v10

    move-object v10, v1

    move-object/from16 v1, p0

    move-object v7, v8

    move-object v8, v14

    move-object v6, v15

    goto/16 :goto_1
.end method
