.class public abstract La0/q0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:La0/T;


# direct methods
.method public constructor <init>(Lr7/a;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, La0/T;

    invoke-direct {v0, p1}, La0/T;-><init>(Lr7/a;)V

    iput-object v0, p0, La0/q0;->a:La0/T;

    return-void
.end method


# virtual methods
.method public abstract a(Ljava/lang/Object;)LW3/E;
.end method

.method public b()La0/Z0;
    .locals 1

    iget-object v0, p0, La0/q0;->a:La0/T;

    return-object v0
.end method

.method public final c(LW3/E;La0/Z0;)La0/Z0;
    .locals 3

    instance-of v0, p2, La0/I;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-boolean v0, p1, LW3/E;->b:Z

    if-eqz v0, :cond_3

    move-object v1, p2

    check-cast v1, La0/I;

    iget-object p2, v1, La0/I;->a:La0/h0;

    invoke-virtual {p1}, LW3/E;->a()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p2, v0}, La0/h0;->setValue(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    instance-of v0, p2, La0/Y0;

    if-eqz v0, :cond_2

    iget-boolean v0, p1, LW3/E;->a:Z

    if-nez v0, :cond_1

    iget-object v0, p1, LW3/E;->f:Ljava/lang/Object;

    if-eqz v0, :cond_3

    :cond_1
    iget-boolean v0, p1, LW3/E;->b:Z

    if-nez v0, :cond_3

    invoke-virtual {p1}, LW3/E;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast p2, La0/Y0;

    iget-object v2, p2, La0/Y0;->a:Ljava/lang/Object;

    invoke-static {v0, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    move-object v1, p2

    goto :goto_0

    :cond_2
    instance-of v0, p2, La0/C;

    if-eqz v0, :cond_3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, La0/C;

    iget-object p2, p2, La0/C;->a:Lr7/c;

    :cond_3
    :goto_0
    if-nez v1, :cond_6

    iget-boolean p2, p1, LW3/E;->b:Z

    if-eqz p2, :cond_5

    new-instance p2, La0/I;

    iget-object v0, p1, LW3/E;->f:Ljava/lang/Object;

    iget-object p1, p1, LW3/E;->e:Ljava/lang/Object;

    check-cast p1, La0/N0;

    if-nez p1, :cond_4

    sget-object p1, La0/U;->y:La0/U;

    :cond_4
    new-instance v1, La0/h0;

    invoke-direct {v1, v0, p1}, La0/h0;-><init>(Ljava/lang/Object;La0/N0;)V

    invoke-direct {p2, v1}, La0/I;-><init>(La0/h0;)V

    return-object p2

    :cond_5
    new-instance p2, La0/Y0;

    invoke-virtual {p1}, LW3/E;->a()Ljava/lang/Object;

    move-result-object p1

    invoke-direct {p2, p1}, La0/Y0;-><init>(Ljava/lang/Object;)V

    return-object p2

    :cond_6
    return-object v1
.end method
