.class public final La0/u0;
.super Lj7/i;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public final synthetic A:La0/V;

.field public x:I

.field public synthetic y:Ljava/lang/Object;

.field public final synthetic z:La0/x0;


# direct methods
.method public constructor <init>(La0/x0;La0/V;Lh7/c;)V
    .locals 0

    iput-object p1, p0, La0/u0;->z:La0/x0;

    iput-object p2, p0, La0/u0;->A:La0/V;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lj7/i;-><init>(ILh7/c;)V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LD7/v;

    check-cast p2, Lh7/c;

    invoke-virtual {p0, p2, p1}, La0/u0;->n(Lh7/c;Ljava/lang/Object;)Lh7/c;

    move-result-object p1

    check-cast p1, La0/u0;

    sget-object p2, Ld7/z;->a:Ld7/z;

    invoke-virtual {p1, p2}, La0/u0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final n(Lh7/c;Ljava/lang/Object;)Lh7/c;
    .locals 3

    new-instance v0, La0/u0;

    iget-object v1, p0, La0/u0;->z:La0/x0;

    iget-object v2, p0, La0/u0;->A:La0/V;

    invoke-direct {v0, v1, v2, p1}, La0/u0;-><init>(La0/x0;La0/V;Lh7/c;)V

    iput-object p2, v0, La0/u0;->y:Ljava/lang/Object;

    return-object v0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    iget v0, p0, La0/u0;->x:I

    const/4 v1, 0x1

    if-eqz v0, :cond_1

    if-ne v0, v1, :cond_0

    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    iget-object p1, p0, La0/u0;->y:Ljava/lang/Object;

    check-cast p1, LD7/v;

    iput v1, p0, La0/u0;->x:I

    iget-object v0, p0, La0/u0;->z:La0/x0;

    iget-object v1, p0, La0/u0;->A:La0/V;

    invoke-virtual {v0, p1, v1, p0}, La0/x0;->f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Li7/a;->t:Li7/a;

    return-object p1
.end method
