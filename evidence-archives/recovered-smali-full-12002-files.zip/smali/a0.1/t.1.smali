.class public interface abstract La0/t;
.super Ljava/lang/Object;
.source "SourceFile"
