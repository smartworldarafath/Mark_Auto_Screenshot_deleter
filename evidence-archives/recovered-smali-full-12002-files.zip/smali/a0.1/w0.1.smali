.class public final synthetic La0/w0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic A:Lp/I;

.field public final synthetic B:Ljava/util/Set;

.field public final synthetic t:La0/y0;

.field public final synthetic u:Lp/I;

.field public final synthetic v:Lp/I;

.field public final synthetic w:Ljava/util/List;

.field public final synthetic x:Ljava/util/List;

.field public final synthetic y:Lp/I;

.field public final synthetic z:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(La0/y0;Lp/I;Lp/I;Ljava/util/List;Ljava/util/List;Lp/I;Ljava/util/List;Lp/I;Ljava/util/Set;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/w0;->t:La0/y0;

    iput-object p2, p0, La0/w0;->u:Lp/I;

    iput-object p3, p0, La0/w0;->v:Lp/I;

    iput-object p4, p0, La0/w0;->w:Ljava/util/List;

    iput-object p5, p0, La0/w0;->x:Ljava/util/List;

    iput-object p6, p0, La0/w0;->y:Lp/I;

    iput-object p7, p0, La0/w0;->z:Ljava/util/List;

    iput-object p8, p0, La0/w0;->A:Lp/I;

    iput-object p9, p0, La0/w0;->B:Ljava/util/Set;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 28

    move-object/from16 v1, p0

    iget-object v2, v1, La0/w0;->t:La0/y0;

    iget-object v8, v1, La0/w0;->u:Lp/I;

    iget-object v9, v1, La0/w0;->v:Lp/I;

    iget-object v3, v1, La0/w0;->w:Ljava/util/List;

    iget-object v4, v1, La0/w0;->x:Ljava/util/List;

    iget-object v6, v1, La0/w0;->y:Lp/I;

    iget-object v5, v1, La0/w0;->z:Ljava/util/List;

    iget-object v7, v1, La0/w0;->A:Lp/I;

    iget-object v0, v1, La0/w0;->B:Ljava/util/Set;

    move-object/from16 v10, p1

    check-cast v10, Ljava/lang/Long;

    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    iget-object v12, v2, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v12

    :try_start_0
    invoke-virtual {v2}, La0/y0;->x()Z

    move-result v13
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_11

    monitor-exit v12

    const/4 v12, 0x1

    const/4 v14, 0x0

    if-eqz v13, :cond_2

    const-string v13, "Recomposer:animation"

    invoke-static {v13}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_1
    iget-object v13, v2, La0/y0;->a:La0/e;

    invoke-virtual {v13, v10, v11}, La0/e;->a(J)V

    sget-object v10, Lk0/l;->c:Ljava/lang/Object;

    monitor-enter v10
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    sget-object v11, Lk0/l;->j:Lk0/a;

    iget-object v11, v11, Lk0/b;->h:Lp/I;

    if-eqz v11, :cond_0

    invoke-virtual {v11}, Lp/I;->h()Z

    move-result v11
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-ne v11, v12, :cond_0

    move v11, v12

    goto :goto_0

    :cond_0
    move v11, v14

    :goto_0
    :try_start_3
    monitor-exit v10

    if-eqz v11, :cond_1

    invoke-static {}, Lk0/l;->a()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :cond_1
    invoke-static {}, Landroid/os/Trace;->endSection()V

    goto :goto_1

    :catchall_0
    move-exception v0

    :try_start_4
    monitor-exit v10

    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception v0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :cond_2
    :goto_1
    const-string v10, "Recomposer:recompose"

    invoke-static {v10}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_5
    invoke-virtual {v2}, La0/y0;->F()Z

    iget-object v10, v2, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v10
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    :try_start_6
    iget-object v11, v2, La0/y0;->h:Lc0/e;

    iget-object v13, v11, Lc0/e;->t:[Ljava/lang/Object;

    iget v11, v11, Lc0/e;->v:I

    move v15, v14

    :goto_2
    if-ge v15, v11, :cond_3

    aget-object v16, v13, v15

    move-object/from16 v12, v16

    check-cast v12, La0/x;

    invoke-interface {v3, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v15, v15, 0x1

    const/4 v12, 0x1

    goto :goto_2

    :catchall_2
    move-exception v0

    goto/16 :goto_25

    :cond_3
    iget-object v11, v2, La0/y0;->h:Lc0/e;

    invoke-virtual {v11}, Lc0/e;->h()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :try_start_7
    monitor-exit v10

    invoke-virtual {v8}, Lp/I;->b()V

    invoke-virtual {v9}, Lp/I;->b()V

    :goto_3
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v10

    const/4 v11, 0x0

    if-eqz v10, :cond_4

    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_5

    :cond_4
    const/4 v10, 0x1

    goto/16 :goto_18

    :cond_5
    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v0

    instance-of v10, v0, Lk0/b;

    if-eqz v10, :cond_6

    new-instance v15, Lk0/x;

    move-object/from16 v16, v0

    check-cast v16, Lk0/b;

    const/16 v19, 0x1

    const/16 v20, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    invoke-direct/range {v15 .. v20}, Lk0/x;-><init>(Lk0/b;Lr7/c;Lr7/c;ZZ)V

    goto :goto_4

    :catchall_3
    move-exception v0

    goto/16 :goto_26

    :cond_6
    new-instance v15, Lk0/y;

    const/4 v10, 0x1

    invoke-direct {v15, v0, v11, v10, v14}, Lk0/y;-><init>(Lk0/f;Lr7/c;ZZ)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    :goto_4
    :try_start_8
    invoke-virtual {v15}, Lk0/f;->j()Lk0/f;

    move-result-object v10
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_6

    :try_start_9
    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    if-nez v0, :cond_9

    :try_start_a
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v0

    move v12, v14

    :goto_5
    if-ge v12, v0, :cond_7

    invoke-interface {v5, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La0/x;

    invoke-virtual {v7, v13}, Lp/I;->a(Ljava/lang/Object;)Z

    add-int/lit8 v12, v12, 0x1

    goto :goto_5

    :catchall_4
    move-exception v0

    goto :goto_7

    :cond_7
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v0

    move v12, v14

    :goto_6
    if-ge v12, v0, :cond_8

    invoke-interface {v5, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La0/x;

    invoke-virtual {v13}, La0/x;->d()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    add-int/lit8 v12, v12, 0x1

    goto :goto_6

    :cond_8
    :try_start_b
    invoke-interface {v5}, Ljava/util/List;->clear()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    goto :goto_9

    :catchall_5
    move-exception v0

    goto/16 :goto_16

    :goto_7
    :try_start_c
    invoke-virtual {v2, v0, v11}, La0/y0;->E(Ljava/lang/Throwable;La0/x;)V

    invoke-static/range {v2 .. v9}, La0/x0;->r(La0/y0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lp/I;Lp/I;Lp/I;Lp/I;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_7

    :try_start_d
    invoke-interface {v5}, Ljava/util/List;->clear()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_5

    :try_start_e
    invoke-static {v10}, Lk0/f;->q(Lk0/f;)V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_6

    :goto_8
    :try_start_f
    invoke-virtual {v15}, Lk0/f;->c()V
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_3

    goto/16 :goto_15

    :catchall_6
    move-exception v0

    goto/16 :goto_17

    :catchall_7
    move-exception v0

    :try_start_10
    invoke-interface {v5}, Ljava/util/List;->clear()V

    throw v0

    :cond_9
    :goto_9
    invoke-virtual {v6}, Lp/I;->h()Z

    move-result v0
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_5

    const-wide/16 v16, 0xff

    const/16 v18, 0x7

    const-wide v19, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    const-wide/16 v21, 0x80

    if-eqz v0, :cond_e

    :try_start_11
    invoke-virtual {v7, v6}, Lp/I;->k(Lp/I;)V

    iget-object v0, v6, Lp/I;->b:[Ljava/lang/Object;

    iget-object v13, v6, Lp/I;->a:[J

    array-length v14, v13

    add-int/lit8 v14, v14, -0x2

    if-ltz v14, :cond_d

    move-object/from16 v24, v13

    const/4 v11, 0x0

    :goto_a
    const/16 v23, 0x8

    aget-wide v12, v24, v11

    move-object/from16 v25, v0

    not-long v0, v12

    shl-long v0, v0, v18

    and-long/2addr v0, v12

    and-long v0, v0, v19

    cmp-long v0, v0, v19

    if-eqz v0, :cond_c

    sub-int v0, v11, v14

    not-int v0, v0

    ushr-int/lit8 v0, v0, 0x1f

    rsub-int/lit8 v0, v0, 0x8

    const/4 v1, 0x0

    :goto_b
    if-ge v1, v0, :cond_b

    and-long v26, v12, v16

    cmp-long v26, v26, v21

    if-gez v26, :cond_a

    shl-int/lit8 v26, v11, 0x3

    add-int v26, v26, v1

    aget-object v26, v25, v26

    check-cast v26, La0/x;

    invoke-virtual/range {v26 .. v26}, La0/x;->f()V
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_8

    goto :goto_c

    :catchall_8
    move-exception v0

    const/4 v1, 0x0

    goto :goto_d

    :cond_a
    :goto_c
    shr-long v12, v12, v23

    add-int/lit8 v1, v1, 0x1

    goto :goto_b

    :cond_b
    move/from16 v1, v23

    if-ne v0, v1, :cond_d

    :cond_c
    if-eq v11, v14, :cond_d

    add-int/lit8 v11, v11, 0x1

    move-object/from16 v1, p0

    move-object/from16 v0, v25

    goto :goto_a

    :cond_d
    :try_start_12
    invoke-virtual {v6}, Lp/I;->b()V
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_5

    goto :goto_e

    :goto_d
    :try_start_13
    invoke-virtual {v2, v0, v1}, La0/y0;->E(Ljava/lang/Throwable;La0/x;)V

    invoke-static/range {v2 .. v9}, La0/x0;->r(La0/y0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lp/I;Lp/I;Lp/I;Lp/I;)V
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_9

    :try_start_14
    invoke-virtual {v6}, Lp/I;->b()V
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_5

    :try_start_15
    invoke-static {v10}, Lk0/f;->q(Lk0/f;)V
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_6

    goto :goto_8

    :catchall_9
    move-exception v0

    :try_start_16
    invoke-virtual {v6}, Lp/I;->b()V

    throw v0

    :cond_e
    :goto_e
    invoke-virtual {v7}, Lp/I;->h()Z

    move-result v0
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_5

    if-eqz v0, :cond_13

    :try_start_17
    iget-object v0, v7, Lp/I;->b:[Ljava/lang/Object;

    iget-object v1, v7, Lp/I;->a:[J

    array-length v11, v1

    add-int/lit8 v11, v11, -0x2

    if-ltz v11, :cond_12

    const/4 v12, 0x0

    :goto_f
    aget-wide v13, v1, v12

    move-object/from16 v24, v0

    move-object/from16 v25, v1

    not-long v0, v13

    shl-long v0, v0, v18

    and-long/2addr v0, v13

    and-long v0, v0, v19

    cmp-long v0, v0, v19

    if-eqz v0, :cond_11

    sub-int v0, v12, v11

    not-int v0, v0

    ushr-int/lit8 v0, v0, 0x1f

    const/16 v23, 0x8

    rsub-int/lit8 v0, v0, 0x8

    const/4 v1, 0x0

    :goto_10
    if-ge v1, v0, :cond_10

    and-long v26, v13, v16

    cmp-long v26, v26, v21

    if-gez v26, :cond_f

    shl-int/lit8 v26, v12, 0x3

    add-int v26, v26, v1

    aget-object v26, v24, v26

    check-cast v26, La0/x;

    invoke-virtual/range {v26 .. v26}, La0/x;->g()V
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_a

    :cond_f
    move/from16 v26, v1

    const/16 v1, 0x8

    goto :goto_11

    :catchall_a
    move-exception v0

    const/4 v1, 0x0

    goto :goto_13

    :goto_11
    shr-long/2addr v13, v1

    add-int/lit8 v23, v26, 0x1

    move/from16 v1, v23

    goto :goto_10

    :cond_10
    const/16 v1, 0x8

    if-ne v0, v1, :cond_12

    goto :goto_12

    :cond_11
    const/16 v1, 0x8

    :goto_12
    if-eq v12, v11, :cond_12

    add-int/lit8 v12, v12, 0x1

    move-object/from16 v0, v24

    move-object/from16 v1, v25

    goto :goto_f

    :cond_12
    :try_start_18
    invoke-virtual {v7}, Lp/I;->b()V
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_5

    goto :goto_14

    :goto_13
    :try_start_19
    invoke-virtual {v2, v0, v1}, La0/y0;->E(Ljava/lang/Throwable;La0/x;)V

    invoke-static/range {v2 .. v9}, La0/x0;->r(La0/y0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lp/I;Lp/I;Lp/I;Lp/I;)V
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_b

    :try_start_1a
    invoke-virtual {v7}, Lp/I;->b()V
    :try_end_1a
    .catchall {:try_start_1a .. :try_end_1a} :catchall_5

    :try_start_1b
    invoke-static {v10}, Lk0/f;->q(Lk0/f;)V
    :try_end_1b
    .catchall {:try_start_1b .. :try_end_1b} :catchall_6

    goto/16 :goto_8

    :catchall_b
    move-exception v0

    :try_start_1c
    invoke-virtual {v7}, Lp/I;->b()V

    throw v0
    :try_end_1c
    .catchall {:try_start_1c .. :try_end_1c} :catchall_5

    :cond_13
    :goto_14
    :try_start_1d
    invoke-static {v10}, Lk0/f;->q(Lk0/f;)V
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_6

    :try_start_1e
    invoke-virtual {v15}, Lk0/f;->c()V

    iget-object v1, v2, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v1
    :try_end_1e
    .catchall {:try_start_1e .. :try_end_1e} :catchall_3

    :try_start_1f
    invoke-virtual {v2}, La0/y0;->w()LD7/f;
    :try_end_1f
    .catchall {:try_start_1f .. :try_end_1f} :catchall_c

    :try_start_20
    monitor-exit v1

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v0

    invoke-virtual {v0}, Lk0/f;->m()V

    invoke-virtual {v9}, Lp/I;->b()V

    invoke-virtual {v8}, Lp/I;->b()V

    const/4 v1, 0x0

    iput-object v1, v2, La0/y0;->p:Ljava/util/LinkedHashSet;
    :try_end_20
    .catchall {:try_start_20 .. :try_end_20} :catchall_3

    :goto_15
    invoke-static {}, Landroid/os/Trace;->endSection()V

    goto/16 :goto_24

    :catchall_c
    move-exception v0

    :try_start_21
    monitor-exit v1

    throw v0
    :try_end_21
    .catchall {:try_start_21 .. :try_end_21} :catchall_3

    :goto_16
    :try_start_22
    invoke-static {v10}, Lk0/f;->q(Lk0/f;)V

    throw v0
    :try_end_22
    .catchall {:try_start_22 .. :try_end_22} :catchall_6

    :goto_17
    :try_start_23
    invoke-virtual {v15}, Lk0/f;->c()V

    throw v0
    :try_end_23
    .catchall {:try_start_23 .. :try_end_23} :catchall_3

    :goto_18
    :try_start_24
    invoke-interface {v3}, Ljava/util/Collection;->size()I

    move-result v1

    const/4 v11, 0x0

    :goto_19
    if-ge v11, v1, :cond_15

    invoke-interface {v3, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, La0/x;

    invoke-virtual {v2, v12, v8}, La0/y0;->D(La0/x;Lp/I;)La0/x;

    move-result-object v13

    if-eqz v13, :cond_14

    invoke-interface {v5, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1a

    :catchall_d
    move-exception v0

    const/4 v1, 0x0

    goto/16 :goto_23

    :cond_14
    :goto_1a
    invoke-virtual {v9, v12}, Lp/I;->a(Ljava/lang/Object;)Z
    :try_end_24
    .catchall {:try_start_24 .. :try_end_24} :catchall_d

    add-int/lit8 v11, v11, 0x1

    goto :goto_19

    :cond_15
    :try_start_25
    invoke-interface {v3}, Ljava/util/List;->clear()V

    invoke-virtual {v8}, Lp/I;->h()Z

    move-result v1

    if-nez v1, :cond_16

    iget-object v1, v2, La0/y0;->h:Lc0/e;

    iget v1, v1, Lc0/e;->v:I

    if-eqz v1, :cond_1c

    :cond_16
    iget-object v1, v2, La0/y0;->b:Ljava/lang/Object;

    monitor-enter v1
    :try_end_25
    .catchall {:try_start_25 .. :try_end_25} :catchall_3

    :try_start_26
    invoke-virtual {v2}, La0/y0;->z()Ljava/util/List;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/Collection;->size()I

    move-result v12

    const/4 v13, 0x0

    :goto_1b
    if-ge v13, v12, :cond_18

    invoke-interface {v11, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, La0/x;

    invoke-virtual {v9, v14}, Lp/I;->c(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_17

    invoke-virtual {v14, v0}, La0/x;->w(Ljava/util/Set;)Z

    move-result v15

    if-eqz v15, :cond_17

    invoke-interface {v3, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1c

    :catchall_e
    move-exception v0

    goto/16 :goto_22

    :cond_17
    :goto_1c
    add-int/lit8 v13, v13, 0x1

    goto :goto_1b

    :cond_18
    iget-object v11, v2, La0/y0;->h:Lc0/e;

    iget v12, v11, Lc0/e;->v:I

    const/4 v13, 0x0

    const/4 v14, 0x0

    :goto_1d
    if-ge v13, v12, :cond_1b

    iget-object v15, v11, Lc0/e;->t:[Ljava/lang/Object;

    aget-object v15, v15, v13

    check-cast v15, La0/x;

    invoke-virtual {v9, v15}, Lp/I;->c(Ljava/lang/Object;)Z

    move-result v16

    if-nez v16, :cond_19

    invoke-interface {v3, v15}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v16

    if-nez v16, :cond_19

    invoke-interface {v3, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v14, v14, 0x1

    goto :goto_1e

    :cond_19
    if-lez v14, :cond_1a

    iget-object v15, v11, Lc0/e;->t:[Ljava/lang/Object;

    sub-int v16, v13, v14

    aget-object v17, v15, v13

    aput-object v17, v15, v16

    :cond_1a
    :goto_1e
    add-int/lit8 v13, v13, 0x1

    goto :goto_1d

    :cond_1b
    iget-object v13, v11, Lc0/e;->t:[Ljava/lang/Object;

    sub-int v14, v12, v14

    const/4 v15, 0x0

    invoke-static {v13, v14, v12, v15}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    iput v14, v11, Lc0/e;->v:I
    :try_end_26
    .catchall {:try_start_26 .. :try_end_26} :catchall_e

    :try_start_27
    monitor-exit v1

    :cond_1c
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v1
    :try_end_27
    .catchall {:try_start_27 .. :try_end_27} :catchall_3

    if-eqz v1, :cond_1e

    :try_start_28
    invoke-static {v4, v2}, La0/x0;->s(Ljava/util/List;La0/y0;)V

    :goto_1f
    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1e

    invoke-virtual {v2, v4, v8}, La0/y0;->C(Ljava/util/List;Lp/I;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_20
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_1d

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v6, v11}, Lp/I;->j(Ljava/lang/Object;)V

    goto :goto_20

    :cond_1d
    invoke-static {v4, v2}, La0/x0;->s(Ljava/util/List;La0/y0;)V
    :try_end_28
    .catchall {:try_start_28 .. :try_end_28} :catchall_f

    goto :goto_1f

    :catchall_f
    move-exception v0

    const/4 v1, 0x0

    goto :goto_21

    :cond_1e
    move-object/from16 v1, p0

    const/4 v14, 0x0

    goto/16 :goto_3

    :goto_21
    :try_start_29
    invoke-virtual {v2, v0, v1}, La0/y0;->E(Ljava/lang/Throwable;La0/x;)V

    invoke-static/range {v2 .. v9}, La0/x0;->r(La0/y0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lp/I;Lp/I;Lp/I;Lp/I;)V

    goto/16 :goto_15

    :goto_22
    monitor-exit v1

    throw v0
    :try_end_29
    .catchall {:try_start_29 .. :try_end_29} :catchall_3

    :goto_23
    :try_start_2a
    invoke-virtual {v2, v0, v1}, La0/y0;->E(Ljava/lang/Throwable;La0/x;)V

    invoke-static/range {v2 .. v9}, La0/x0;->r(La0/y0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lp/I;Lp/I;Lp/I;Lp/I;)V
    :try_end_2a
    .catchall {:try_start_2a .. :try_end_2a} :catchall_10

    :try_start_2b
    invoke-interface {v3}, Ljava/util/List;->clear()V
    :try_end_2b
    .catchall {:try_start_2b .. :try_end_2b} :catchall_3

    goto/16 :goto_15

    :goto_24
    sget-object v0, Ld7/z;->a:Ld7/z;

    return-object v0

    :catchall_10
    move-exception v0

    :try_start_2c
    invoke-interface {v3}, Ljava/util/List;->clear()V

    throw v0

    :goto_25
    monitor-exit v10

    throw v0
    :try_end_2c
    .catchall {:try_start_2c .. :try_end_2c} :catchall_3

    :goto_26
    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :catchall_11
    move-exception v0

    monitor-exit v12

    throw v0
.end method
