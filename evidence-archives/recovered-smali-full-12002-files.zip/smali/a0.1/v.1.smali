.class public abstract La0/v;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Li0/h;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget-object v0, Li0/h;->w:Li0/h;

    sput-object v0, La0/v;->a:Li0/h;

    return-void
.end method
