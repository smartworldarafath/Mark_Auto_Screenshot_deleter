.class public final La0/A;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/A0;


# instance fields
.field public final t:LD7/v;


# direct methods
.method public constructor <init>(LD7/v;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/A;->t:LD7/v;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    iget-object v0, p0, La0/A;->t:LD7/v;

    instance-of v1, v0, La0/D0;

    if-eqz v1, :cond_0

    check-cast v0, La0/D0;

    invoke-virtual {v0}, La0/D0;->c()V

    return-void

    :cond_0
    new-instance v1, La0/J;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, La0/J;-><init>(I)V

    invoke-static {v0, v1}, LD7/y;->g(LD7/v;Ljava/util/concurrent/CancellationException;)V

    return-void
.end method

.method public final b()V
    .locals 3

    iget-object v0, p0, La0/A;->t:LD7/v;

    instance-of v1, v0, La0/D0;

    if-eqz v1, :cond_0

    check-cast v0, La0/D0;

    invoke-virtual {v0}, La0/D0;->c()V

    return-void

    :cond_0
    new-instance v1, La0/J;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, La0/J;-><init>(I)V

    invoke-static {v0, v1}, LD7/y;->g(LD7/v;Ljava/util/concurrent/CancellationException;)V

    return-void
.end method

.method public final d()V
    .locals 0

    return-void
.end method
