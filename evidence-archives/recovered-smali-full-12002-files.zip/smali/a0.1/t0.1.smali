.class public final La0/t0;
.super Lj7/i;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public synthetic x:Ljava/lang/Object;


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, La0/s0;

    check-cast p2, Lh7/c;

    invoke-virtual {p0, p2, p1}, La0/t0;->n(Lh7/c;Ljava/lang/Object;)Lh7/c;

    move-result-object p1

    check-cast p1, La0/t0;

    sget-object p2, Ld7/z;->a:Ld7/z;

    invoke-virtual {p1, p2}, La0/t0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final n(Lh7/c;Ljava/lang/Object;)Lh7/c;
    .locals 2

    new-instance v0, La0/t0;

    const/4 v1, 0x2

    invoke-direct {v0, v1, p1}, Lj7/i;-><init>(ILh7/c;)V

    iput-object p2, v0, La0/t0;->x:Ljava/lang/Object;

    return-object v0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    iget-object p1, p0, La0/t0;->x:Ljava/lang/Object;

    check-cast p1, La0/s0;

    sget-object v0, La0/s0;->t:La0/s0;

    if-ne p1, v0, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method
