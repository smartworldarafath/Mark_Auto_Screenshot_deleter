.class public final La0/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/A0;


# instance fields
.field public final t:La0/p;


# direct methods
.method public constructor <init>(La0/p;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/o;->t:La0/p;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    iget-object v0, p0, La0/o;->t:La0/p;

    invoke-virtual {v0}, La0/p;->u()V

    return-void
.end method

.method public final b()V
    .locals 1

    iget-object v0, p0, La0/o;->t:La0/p;

    invoke-virtual {v0}, La0/p;->u()V

    return-void
.end method

.method public final d()V
    .locals 0

    return-void
.end method
