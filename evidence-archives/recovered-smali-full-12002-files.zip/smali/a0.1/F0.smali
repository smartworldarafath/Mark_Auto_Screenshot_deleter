.class public final La0/F0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Iterable;
.implements Lt7/a;


# instance fields
.field public A:I

.field public B:Ljava/util/ArrayList;

.field public C:Ljava/util/HashMap;

.field public D:Lp/w;

.field public t:[I

.field public u:I

.field public v:[Ljava/lang/Object;

.field public w:I

.field public x:I

.field public final y:Ljava/lang/Object;

.field public z:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    new-array v1, v0, [I

    iput-object v1, p0, La0/F0;->t:[I

    new-array v0, v0, [Ljava/lang/Object;

    iput-object v0, p0, La0/F0;->v:[Ljava/lang/Object;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, La0/F0;->y:Ljava/lang/Object;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La0/F0;->B:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final b(La0/a;)I
    .locals 1

    iget-boolean v0, p0, La0/F0;->z:Z

    if-eqz v0, :cond_0

    const-string v0, "Use active SlotWriter to determine anchor location instead"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :cond_0
    invoke-virtual {p1}, La0/a;->a()Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "Anchor refers to a group that was removed"

    invoke-static {v0}, La0/o0;->a(Ljava/lang/String;)V

    :cond_1
    iget p1, p1, La0/a;->a:I

    return p1
.end method

.method public final c()V
    .locals 1

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, La0/F0;->C:Ljava/util/HashMap;

    return-void
.end method

.method public final e()La0/E0;
    .locals 2

    iget-boolean v0, p0, La0/F0;->z:Z

    if-nez v0, :cond_0

    iget v0, p0, La0/F0;->x:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, La0/F0;->x:I

    new-instance v0, La0/E0;

    invoke-direct {v0, p0}, La0/E0;-><init>(La0/F0;)V

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Cannot read while a writer is pending"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final f()La0/I0;
    .locals 2

    iget-boolean v0, p0, La0/F0;->z:Z

    if-eqz v0, :cond_0

    const-string v0, "Cannot start a writer when another writer is pending"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :cond_0
    iget v0, p0, La0/F0;->x:I

    if-gtz v0, :cond_1

    goto :goto_0

    :cond_1
    const-string v0, "Cannot start a writer when a reader is pending"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :goto_0
    const/4 v0, 0x1

    iput-boolean v0, p0, La0/F0;->z:Z

    iget v1, p0, La0/F0;->A:I

    add-int/2addr v1, v0

    iput v1, p0, La0/F0;->A:I

    new-instance v0, La0/I0;

    invoke-direct {v0, p0}, La0/I0;-><init>(La0/F0;)V

    return-object v0
.end method

.method public final g(La0/a;)Z
    .locals 3

    invoke-virtual {p1}, La0/a;->a()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, La0/F0;->B:Ljava/util/ArrayList;

    iget v1, p1, La0/a;->a:I

    iget v2, p0, La0/F0;->u:I

    invoke-static {v0, v1, v2}, La0/H0;->e(Ljava/util/ArrayList;II)I

    move-result v0

    if-ltz v0, :cond_0

    iget-object v1, p0, La0/F0;->B:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public final h(I)La0/M;
    .locals 4

    iget-object v0, p0, La0/F0;->C:Ljava/util/HashMap;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    iget-boolean v2, p0, La0/F0;->z:Z

    if-eqz v2, :cond_0

    const-string v2, "use active SlotWriter to crate an anchor for location instead"

    invoke-static {v2}, La0/s;->c(Ljava/lang/String;)V

    :cond_0
    if-ltz p1, :cond_1

    iget v2, p0, La0/F0;->u:I

    if-ge p1, v2, :cond_1

    iget-object v3, p0, La0/F0;->B:Ljava/util/ArrayList;

    invoke-static {v3, p1, v2}, La0/H0;->e(Ljava/util/ArrayList;II)I

    move-result p1

    if-ltz p1, :cond_1

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La0/a;

    goto :goto_0

    :cond_1
    move-object p1, v1

    :goto_0
    if-eqz p1, :cond_2

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La0/M;

    return-object p1

    :cond_2
    return-object v1
.end method

.method public final iterator()Ljava/util/Iterator;
    .locals 3

    new-instance v0, La0/L;

    const/4 v1, 0x0

    iget v2, p0, La0/F0;->u:I

    invoke-direct {v0, p0, v1, v2}, La0/L;-><init>(La0/F0;II)V

    return-object v0
.end method
