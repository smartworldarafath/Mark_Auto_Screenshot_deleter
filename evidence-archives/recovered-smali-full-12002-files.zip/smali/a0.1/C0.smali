.class public final La0/C0;
.super Lh7/a;
.source "SourceFile"

# interfaces
.implements LD7/t;


# instance fields
.field public final synthetic u:Ll0/b;

.field public final synthetic v:La0/D0;


# direct methods
.method public constructor <init>(Ll0/b;La0/D0;)V
    .locals 1

    sget-object v0, LD7/s;->t:LD7/s;

    iput-object p1, p0, La0/C0;->u:Ll0/b;

    iput-object p2, p0, La0/C0;->v:La0/D0;

    invoke-direct {p0, v0}, Lh7/a;-><init>(Lh7/g;)V

    return-void
.end method


# virtual methods
.method public final l(Lh7/h;Ljava/lang/Throwable;)V
    .locals 4

    new-instance v0, LD/j;

    const/16 v1, 0x16

    iget-object v2, p0, La0/C0;->u:Ll0/b;

    iget-object v3, p0, La0/C0;->v:La0/D0;

    invoke-direct {v0, v1, v2, v3}, LD/j;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-static {p2, v0}, LH4/Y;->a(Ljava/lang/Throwable;Lr7/a;)Z

    sget-object v0, LD7/s;->t:LD7/s;

    iget-object v1, v3, La0/D0;->t:Lh7/h;

    invoke-interface {v1, v0}, Lh7/h;->W(Lh7/g;)Lh7/f;

    move-result-object v0

    check-cast v0, LD7/t;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1, p2}, LD7/t;->l(Lh7/h;Ljava/lang/Throwable;)V

    return-void

    :cond_0
    throw p2
.end method
