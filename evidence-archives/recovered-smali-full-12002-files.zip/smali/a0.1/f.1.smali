.class public final La0/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh7/f;


# static fields
.field public static final t:La0/U;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, La0/U;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, La0/U;-><init>(I)V

    sput-object v0, La0/f;->t:La0/U;

    return-void
.end method


# virtual methods
.method public final J(Lh7/g;)Lh7/h;
    .locals 0

    invoke-static {p0, p1}, LF4/r7;->b(Lh7/f;Lh7/g;)Lh7/h;

    move-result-object p1

    return-object p1
.end method

.method public final S(Lh7/h;)Lh7/h;
    .locals 0

    invoke-static {p0, p1}, LF4/r7;->c(Lh7/f;Lh7/h;)Lh7/h;

    move-result-object p1

    return-object p1
.end method

.method public final W(Lh7/g;)Lh7/f;
    .locals 0

    invoke-static {p0, p1}, LF4/r7;->a(Lh7/f;Lh7/g;)Lh7/f;

    move-result-object p1

    return-object p1
.end method

.method public final X(Ljava/lang/Object;Lr7/e;)Ljava/lang/Object;
    .locals 0

    invoke-interface {p2, p1, p0}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final getKey()Lh7/g;
    .locals 1

    sget-object v0, La0/f;->t:La0/U;

    return-object v0
.end method
