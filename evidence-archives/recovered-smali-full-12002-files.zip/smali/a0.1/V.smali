.class public interface abstract La0/V;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh7/f;


# virtual methods
.method public abstract C(Lh7/c;Lr7/c;)Ljava/lang/Object;
.end method

.method public getKey()Lh7/g;
    .locals 1

    sget-object v0, La0/U;->u:La0/U;

    return-object v0
.end method
