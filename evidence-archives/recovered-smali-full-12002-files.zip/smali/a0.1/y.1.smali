.class public final La0/y;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:La0/y;

.field public static final b:Li0/h;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La0/y;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La0/y;->a:La0/y;

    sget-object v0, Li0/h;->w:Li0/h;

    sput-object v0, La0/y;->b:Li0/h;

    return-void
.end method
