.class public abstract La0/a0;
.super Ljava/lang/Object;
.source "SourceFile"
