.class public final La0/U0;
.super Lj7/i;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public A:LA3/b;

.field public B:Ljava/lang/Object;

.field public C:I

.field public synthetic D:Ljava/lang/Object;

.field public final synthetic E:Lr7/a;

.field public x:Lp/I;

.field public y:Lr7/c;

.field public z:LF7/i;


# direct methods
.method public constructor <init>(Lr7/a;Lh7/c;)V
    .locals 0

    iput-object p1, p0, La0/U0;->E:Lr7/a;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lj7/i;-><init>(ILh7/c;)V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LG7/j;

    check-cast p2, Lh7/c;

    invoke-virtual {p0, p2, p1}, La0/U0;->n(Lh7/c;Ljava/lang/Object;)Lh7/c;

    move-result-object p1

    check-cast p1, La0/U0;

    sget-object p2, Ld7/z;->a:Ld7/z;

    invoke-virtual {p1, p2}, La0/U0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Li7/a;->t:Li7/a;

    return-object p1
.end method

.method public final n(Lh7/c;Ljava/lang/Object;)Lh7/c;
    .locals 2

    new-instance v0, La0/U0;

    iget-object v1, p0, La0/U0;->E:Lr7/a;

    invoke-direct {v0, v1, p1}, La0/U0;-><init>(Lr7/a;Lh7/c;)V

    iput-object p2, v0, La0/U0;->D:Ljava/lang/Object;

    return-object v0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 23

    move-object/from16 v1, p0

    sget-object v0, Li7/a;->t:Li7/a;

    iget v2, v1, La0/U0;->C:I

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_3

    if-eq v2, v5, :cond_2

    if-eq v2, v4, :cond_1

    if-ne v2, v3, :cond_0

    iget-object v2, v1, La0/U0;->B:Ljava/lang/Object;

    iget-object v6, v1, La0/U0;->A:LA3/b;

    iget-object v7, v1, La0/U0;->z:LF7/i;

    iget-object v8, v1, La0/U0;->y:Lr7/c;

    iget-object v9, v1, La0/U0;->x:Lp/I;

    iget-object v10, v1, La0/U0;->D:Ljava/lang/Object;

    check-cast v10, LG7/j;

    :try_start_0
    invoke-static/range {p1 .. p1}, Ld7/a;->e(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto/16 :goto_9

    :catchall_0
    move-exception v0

    goto/16 :goto_c

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    iget-object v2, v1, La0/U0;->B:Ljava/lang/Object;

    iget-object v6, v1, La0/U0;->A:LA3/b;

    iget-object v7, v1, La0/U0;->z:LF7/i;

    iget-object v8, v1, La0/U0;->y:Lr7/c;

    iget-object v9, v1, La0/U0;->x:Lp/I;

    iget-object v10, v1, La0/U0;->D:Ljava/lang/Object;

    check-cast v10, LG7/j;

    :try_start_1
    invoke-static/range {p1 .. p1}, Ld7/a;->e(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object/from16 v11, p1

    goto/16 :goto_1

    :cond_2
    iget-object v2, v1, La0/U0;->B:Ljava/lang/Object;

    iget-object v6, v1, La0/U0;->A:LA3/b;

    iget-object v7, v1, La0/U0;->z:LF7/i;

    iget-object v8, v1, La0/U0;->y:Lr7/c;

    iget-object v9, v1, La0/U0;->x:Lp/I;

    iget-object v10, v1, La0/U0;->D:Ljava/lang/Object;

    check-cast v10, LG7/j;

    :try_start_2
    invoke-static/range {p1 .. p1}, Ld7/a;->e(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    :cond_3
    invoke-static/range {p1 .. p1}, Ld7/a;->e(Ljava/lang/Object;)V

    iget-object v2, v1, La0/U0;->D:Ljava/lang/Object;

    move-object v10, v2

    check-cast v10, LG7/j;

    new-instance v9, Lp/I;

    invoke-direct {v9}, Lp/I;-><init>()V

    new-instance v8, LA7/j;

    const/16 v2, 0x1b

    invoke-direct {v8, v2, v9}, LA7/j;-><init>(ILjava/lang/Object;)V

    const v2, 0x7fffffff

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v2, v6, v7}, LE4/R2;->a(IILF7/a;)LF7/e;

    move-result-object v7

    new-instance v2, LA/o0;

    const/16 v6, 0x15

    invoke-direct {v2, v6, v7}, LA/o0;-><init>(ILjava/lang/Object;)V

    sget-object v6, Lk0/l;->a:Lb2/a;

    invoke-static {v6}, Lk0/l;->f(Lr7/c;)Ljava/lang/Object;

    sget-object v6, Lk0/l;->c:Ljava/lang/Object;

    monitor-enter v6

    :try_start_3
    sget-object v11, Lk0/l;->h:Ljava/lang/Object;

    invoke-static {v11, v2}, Le7/l;->E(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v11

    sput-object v11, Lk0/l;->h:Ljava/lang/Object;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_8

    monitor-exit v6

    new-instance v6, LA3/b;

    const/16 v11, 0xe

    invoke-direct {v6, v11, v2}, LA3/b;-><init>(ILjava/lang/Object;)V

    :try_start_4
    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v2

    invoke-virtual {v2, v8}, Lk0/f;->u(Lr7/c;)Lk0/f;

    move-result-object v2

    iget-object v11, v1, La0/U0;->E:Lr7/a;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :try_start_5
    invoke-virtual {v2}, Lk0/f;->j()Lk0/f;

    move-result-object v12
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_6

    :try_start_6
    invoke-interface {v11}, Lr7/a;->a()Ljava/lang/Object;

    move-result-object v11
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_7

    :try_start_7
    invoke-static {v12}, Lk0/f;->q(Lk0/f;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_6

    :try_start_8
    invoke-virtual {v2}, Lk0/f;->c()V

    iput-object v10, v1, La0/U0;->D:Ljava/lang/Object;

    iput-object v9, v1, La0/U0;->x:Lp/I;

    iput-object v8, v1, La0/U0;->y:Lr7/c;

    iput-object v7, v1, La0/U0;->z:LF7/i;

    iput-object v6, v1, La0/U0;->A:LA3/b;

    iput-object v11, v1, La0/U0;->B:Ljava/lang/Object;

    iput v5, v1, La0/U0;->C:I

    invoke-interface {v10, v11, v1}, LG7/j;->l(Ljava/lang/Object;Lh7/c;)Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v0, :cond_4

    goto/16 :goto_8

    :cond_4
    move-object v2, v11

    :goto_0
    iput-object v10, v1, La0/U0;->D:Ljava/lang/Object;

    iput-object v9, v1, La0/U0;->x:Lp/I;

    iput-object v8, v1, La0/U0;->y:Lr7/c;

    iput-object v7, v1, La0/U0;->z:LF7/i;

    iput-object v6, v1, La0/U0;->A:LA3/b;

    iput-object v2, v1, La0/U0;->B:Ljava/lang/Object;

    iput v4, v1, La0/U0;->C:I

    invoke-interface {v7, v1}, LF7/v;->k(Lh7/c;)Ljava/lang/Object;

    move-result-object v11

    if-ne v11, v0, :cond_5

    goto/16 :goto_8

    :cond_5
    :goto_1
    check-cast v11, Ljava/util/Set;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    const/4 v13, 0x0

    :goto_2
    if-nez v13, :cond_c

    :try_start_9
    iget-object v13, v9, Lp/I;->b:[Ljava/lang/Object;

    iget-object v14, v9, Lp/I;->a:[J

    array-length v15, v14

    sub-int/2addr v15, v4

    if-ltz v15, :cond_a

    move-object/from16 v16, v13

    const/4 v4, 0x0

    :goto_3
    aget-wide v12, v14, v4
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    move-object/from16 v17, v6

    not-long v5, v12

    const/16 v18, 0x7

    shl-long v5, v5, v18

    and-long/2addr v5, v12

    const-wide v18, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    and-long v5, v5, v18

    cmp-long v5, v5, v18

    if-eqz v5, :cond_9

    sub-int v5, v4, v15

    not-int v5, v5

    ushr-int/lit8 v5, v5, 0x1f

    const/16 v6, 0x8

    rsub-int/lit8 v5, v5, 0x8

    const/4 v3, 0x0

    :goto_4
    if-ge v3, v5, :cond_8

    const-wide/16 v19, 0xff

    and-long v19, v12, v19

    const-wide/16 v21, 0x80

    cmp-long v19, v19, v21

    if-gez v19, :cond_6

    shl-int/lit8 v19, v4, 0x3

    add-int v19, v19, v3

    move/from16 v20, v6

    :try_start_a
    aget-object v6, v16, v19

    invoke-interface {v11, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_7

    goto :goto_6

    :cond_6
    move/from16 v20, v6

    :cond_7
    shr-long v12, v12, v20

    add-int/lit8 v3, v3, 0x1

    move/from16 v6, v20

    goto :goto_4

    :cond_8
    move v3, v6

    if-ne v5, v3, :cond_b

    :cond_9
    if-eq v4, v15, :cond_b

    add-int/lit8 v4, v4, 0x1

    move-object/from16 v6, v17

    const/4 v3, 0x3

    const/4 v5, 0x1

    goto :goto_3

    :cond_a
    move-object/from16 v17, v6

    :cond_b
    const/4 v13, 0x0

    goto :goto_7

    :catchall_1
    move-exception v0

    move-object/from16 v17, v6

    :goto_5
    move-object/from16 v6, v17

    goto/16 :goto_c

    :cond_c
    move-object/from16 v17, v6

    :goto_6
    const/4 v13, 0x1

    :goto_7
    invoke-interface {v7}, LF7/v;->g()Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3}, LF7/l;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    move-object v11, v3

    check-cast v11, Ljava/util/Set;

    if-nez v11, :cond_f

    if-eqz v13, :cond_e

    invoke-virtual {v9}, Lp/I;->b()V

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v3

    invoke-virtual {v3, v8}, Lk0/f;->u(Lr7/c;)Lk0/f;

    move-result-object v3

    iget-object v4, v1, La0/U0;->E:Lr7/a;
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    :try_start_b
    invoke-virtual {v3}, Lk0/f;->j()Lk0/f;

    move-result-object v5
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    :try_start_c
    invoke-interface {v4}, Lr7/a;->a()Ljava/lang/Object;

    move-result-object v4
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    :try_start_d
    invoke-static {v5}, Lk0/f;->q(Lk0/f;)V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_3

    :try_start_e
    invoke-virtual {v3}, Lk0/f;->c()V

    invoke-static {v4, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_e

    iput-object v10, v1, La0/U0;->D:Ljava/lang/Object;

    iput-object v9, v1, La0/U0;->x:Lp/I;

    iput-object v8, v1, La0/U0;->y:Lr7/c;

    iput-object v7, v1, La0/U0;->z:LF7/i;
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_2

    move-object/from16 v6, v17

    :try_start_f
    iput-object v6, v1, La0/U0;->A:LA3/b;

    iput-object v4, v1, La0/U0;->B:Ljava/lang/Object;

    const/4 v3, 0x3

    iput v3, v1, La0/U0;->C:I

    invoke-interface {v10, v4, v1}, LG7/j;->l(Ljava/lang/Object;Lh7/c;)Ljava/lang/Object;

    move-result-object v2
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_0

    if-ne v2, v0, :cond_d

    :goto_8
    return-object v0

    :cond_d
    move-object v2, v4

    :goto_9
    const/4 v4, 0x2

    const/4 v5, 0x1

    goto/16 :goto_0

    :catchall_2
    move-exception v0

    goto :goto_5

    :cond_e
    move-object/from16 v6, v17

    const/4 v3, 0x3

    goto :goto_9

    :catchall_3
    move-exception v0

    move-object/from16 v6, v17

    goto :goto_a

    :catchall_4
    move-exception v0

    move-object/from16 v6, v17

    :try_start_10
    invoke-static {v5}, Lk0/f;->q(Lk0/f;)V

    throw v0
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_5

    :catchall_5
    move-exception v0

    :goto_a
    :try_start_11
    invoke-virtual {v3}, Lk0/f;->c()V

    throw v0
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_0

    :cond_f
    move-object/from16 v6, v17

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto/16 :goto_2

    :catchall_6
    move-exception v0

    goto :goto_b

    :catchall_7
    move-exception v0

    :try_start_12
    invoke-static {v12}, Lk0/f;->q(Lk0/f;)V

    throw v0
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_6

    :goto_b
    :try_start_13
    invoke-virtual {v2}, Lk0/f;->c()V

    throw v0
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_0

    :goto_c
    invoke-virtual {v6}, LA3/b;->i()V

    throw v0

    :catchall_8
    move-exception v0

    monitor-exit v6

    throw v0
.end method
