.class public final La0/d0;
.super Lk0/u;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable;
.implements Lk0/m;
.implements La0/Z;
.implements La0/W0;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "La0/d0;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public u:La0/J0;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, La0/c0;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La0/c0;-><init>(I)V

    sput-object v0, La0/d0;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(F)V
    .locals 4

    invoke-direct {p0}, Lk0/u;-><init>()V

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v0

    new-instance v1, La0/J0;

    invoke-virtual {v0}, Lk0/f;->g()J

    move-result-wide v2

    invoke-direct {v1, p1, v2, v3}, La0/J0;-><init>(FJ)V

    instance-of v0, v0, Lk0/a;

    if-nez v0, :cond_0

    new-instance v0, La0/J0;

    const/4 v2, 0x1

    int-to-long v2, v2

    invoke-direct {v0, p1, v2, v3}, La0/J0;-><init>(FJ)V

    iput-object v0, v1, Lk0/v;->b:Lk0/v;

    :cond_0
    iput-object v1, p0, La0/d0;->u:La0/J0;

    return-void
.end method


# virtual methods
.method public final b()Lk0/v;
    .locals 1

    iget-object v0, p0, La0/d0;->u:La0/J0;

    return-object v0
.end method

.method public final c(Lk0/v;Lk0/v;Lk0/v;)Lk0/v;
    .locals 0

    move-object p1, p2

    check-cast p1, La0/J0;

    check-cast p3, La0/J0;

    iget p1, p1, La0/J0;->c:F

    iget p3, p3, La0/J0;->c:F

    cmpg-float p1, p1, p3

    if-nez p1, :cond_0

    return-object p2

    :cond_0
    const/4 p1, 0x0

    return-object p1
.end method

.method public final d()La0/N0;
    .locals 1

    sget-object v0, La0/U;->y:La0/U;

    return-object v0
.end method

.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public final e(Lk0/v;)V
    .locals 1

    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableFloatStateImpl.FloatStateStateRecord"

    invoke-static {p1, v0}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, La0/J0;

    iput-object p1, p0, La0/d0;->u:La0/J0;

    return-void
.end method

.method public getValue()Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0}, La0/d0;->h()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0
.end method

.method public final h()F
    .locals 1

    iget-object v0, p0, La0/d0;->u:La0/J0;

    invoke-static {v0, p0}, Lk0/l;->t(Lk0/v;Lk0/t;)Lk0/v;

    move-result-object v0

    check-cast v0, La0/J0;

    iget v0, v0, La0/J0;->c:F

    return v0
.end method

.method public final i(F)V
    .locals 4

    iget-object v0, p0, La0/d0;->u:La0/J0;

    invoke-static {v0}, Lk0/l;->i(Lk0/v;)Lk0/v;

    move-result-object v0

    check-cast v0, La0/J0;

    iget v1, v0, La0/J0;->c:F

    cmpg-float v1, v1, p1

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, La0/d0;->u:La0/J0;

    sget-object v2, Lk0/l;->c:Ljava/lang/Object;

    monitor-enter v2

    :try_start_0
    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v3

    invoke-static {v1, p0, v3, v0}, Lk0/l;->o(Lk0/v;Lk0/u;Lk0/f;Lk0/v;)Lk0/v;

    move-result-object v0

    check-cast v0, La0/J0;

    iput p1, v0, La0/J0;->c:F
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v2

    invoke-static {v3, p0}, Lk0/l;->n(Lk0/f;Lk0/t;)V

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v2

    throw p1
.end method

.method public setValue(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    move-result p1

    invoke-virtual {p0, p1}, La0/d0;->i(F)V

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, La0/d0;->u:La0/J0;

    invoke-static {v0}, Lk0/l;->i(Lk0/v;)Lk0/v;

    move-result-object v0

    check-cast v0, La0/J0;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "MutableFloatState(value="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v0, v0, La0/J0;->c:F

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v0, ")@"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    invoke-virtual {p0}, La0/d0;->h()F

    move-result p2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeFloat(F)V

    return-void
.end method
