.class public interface abstract La0/Z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/W0;


# virtual methods
.method public abstract setValue(Ljava/lang/Object;)V
.end method
