.class public final La0/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/lang/Object;

.field public static final b:La0/H;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La0/b;->a:Ljava/lang/Object;

    new-instance v0, La0/H;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La0/b;->b:La0/H;

    return-void
.end method

.method public static final A(Lp/v;)I
    .locals 10

    iget v0, p0, Lp/v;->b:I

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lp/v;->c(I)I

    move-result v1

    :cond_0
    iget v2, p0, Lp/v;->b:I

    if-eqz v2, :cond_3

    invoke-virtual {p0, v0}, Lp/v;->c(I)I

    move-result v2

    if-ne v2, v1, :cond_3

    iget v2, p0, Lp/v;->b:I

    if-eqz v2, :cond_2

    iget-object v3, p0, Lp/v;->a:[I

    add-int/lit8 v2, v2, -0x1

    aget v2, v3, v2

    invoke-virtual {p0, v0, v2}, Lp/v;->e(II)V

    iget v2, p0, Lp/v;->b:I

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {p0, v2}, Lp/v;->d(I)V

    iget v2, p0, Lp/v;->b:I

    ushr-int/lit8 v3, v2, 0x1

    move v4, v0

    :goto_0
    if-ge v4, v3, :cond_0

    invoke-virtual {p0, v4}, Lp/v;->c(I)I

    move-result v5

    add-int/lit8 v6, v4, 0x1

    mul-int/lit8 v6, v6, 0x2

    add-int/lit8 v7, v6, -0x1

    invoke-virtual {p0, v7}, Lp/v;->c(I)I

    move-result v8

    if-ge v6, v2, :cond_1

    invoke-virtual {p0, v6}, Lp/v;->c(I)I

    move-result v9

    if-le v9, v8, :cond_1

    if-le v9, v5, :cond_0

    invoke-virtual {p0, v4, v9}, Lp/v;->e(II)V

    invoke-virtual {p0, v6, v5}, Lp/v;->e(II)V

    move v4, v6

    goto :goto_0

    :cond_1
    if-le v8, v5, :cond_0

    invoke-virtual {p0, v4, v8}, Lp/v;->e(II)V

    invoke-virtual {p0, v7, v5}, Lp/v;->e(II)V

    move v4, v7

    goto :goto_0

    :cond_2
    const-string p0, "IntList is empty."

    invoke-static {p0}, Lq/a;->e(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0

    :cond_3
    return v1
.end method

.method public static final B(I)I
    .locals 3

    const v0, 0x12492492

    and-int/2addr v0, p0

    const v1, 0x24924924

    and-int/2addr v1, p0

    const v2, -0x36db6db7

    and-int/2addr p0, v2

    shr-int/lit8 v2, v1, 0x1

    or-int/2addr v2, v0

    or-int/2addr p0, v2

    shl-int/lit8 v0, v0, 0x1

    and-int/2addr v0, v1

    or-int/2addr p0, v0

    return p0
.end method

.method public static final C([LW3/E;La0/n0;La0/n0;)Li0/h;
    .locals 6

    sget-object v0, Li0/h;->w:Li0/h;

    new-instance v1, Li0/g;

    invoke-direct {v1, v0}, Li0/g;-><init>(Li0/h;)V

    array-length v0, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_2

    aget-object v3, p0, v2

    iget-object v4, v3, LW3/E;->d:Ljava/lang/Object;

    check-cast v4, La0/q0;

    iget-boolean v5, v3, LW3/E;->c:Z

    if-nez v5, :cond_0

    move-object v5, p1

    check-cast v5, Li0/h;

    invoke-virtual {v5, v4}, Li0/h;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1

    :cond_0
    move-object v5, p2

    check-cast v5, Li0/h;

    invoke-virtual {v5, v4}, Li0/h;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La0/Z0;

    invoke-virtual {v4, v3, v5}, La0/q0;->c(LW3/E;La0/Z0;)La0/Z0;

    move-result-object v3

    invoke-virtual {v1, v4, v3}, Li0/g;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {v1}, Li0/g;->a()Li0/h;

    move-result-object p0

    return-object p0
.end method

.method public static final a(LW3/E;Lr7/e;La0/r;I)V
    .locals 11

    const v0, -0x8ed3d8b

    invoke-virtual {p2, v0}, La0/r;->X(I)La0/r;

    iget-object v0, p2, La0/r;->x:LL0/v;

    invoke-virtual {p2}, La0/r;->l()La0/n0;

    move-result-object v1

    const/16 v2, 0xc9

    sget-object v3, La0/s;->b:La0/b0;

    invoke-virtual {p2, v2, v3}, La0/r;->T(ILa0/b0;)V

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v2

    sget-object v3, La0/m;->a:La0/U;

    invoke-static {v2, v3}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_0

    move-object v2, v4

    goto :goto_0

    :cond_0
    const-string v3, "null cannot be cast to non-null type androidx.compose.runtime.ValueHolder<kotlin.Any?>"

    invoke-static {v2, v3}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, La0/Z0;

    :goto_0
    iget-object v3, p0, LW3/E;->d:Ljava/lang/Object;

    check-cast v3, La0/q0;

    invoke-virtual {v3, p0, v2}, La0/q0;->c(LW3/E;La0/Z0;)La0/Z0;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {p2, v5}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_1
    iget-boolean v6, p2, La0/r;->S:Z

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v6, :cond_5

    iget-boolean v2, p0, LW3/E;->c:Z

    if-nez v2, :cond_2

    move-object v2, v1

    check-cast v2, Li0/h;

    invoke-virtual {v2, v3}, Li0/h;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    :cond_2
    check-cast v1, Li0/h;

    invoke-virtual {v1, v3, v5}, Li0/h;->b(La0/q0;La0/Z0;)Li0/h;

    move-result-object v1

    :cond_3
    iput-boolean v7, p2, La0/r;->J:Z

    :cond_4
    move v2, v8

    goto :goto_4

    :cond_5
    iget-object v6, p2, La0/r;->G:La0/E0;

    iget v9, v6, La0/E0;->g:I

    iget-object v10, v6, La0/E0;->b:[I

    invoke-virtual {v6, v10, v9}, La0/E0;->b([II)Ljava/lang/Object;

    move-result-object v6

    const-string v9, "null cannot be cast to non-null type androidx.compose.runtime.PersistentCompositionLocalMap"

    invoke-static {v6, v9}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, La0/n0;

    invoke-virtual {p2}, La0/r;->z()Z

    move-result v9

    if-eqz v9, :cond_6

    if-nez v2, :cond_7

    :cond_6
    iget-boolean v9, p0, LW3/E;->c:Z

    if-nez v9, :cond_a

    move-object v9, v1

    check-cast v9, Li0/h;

    invoke-virtual {v9, v3}, Li0/h;->containsKey(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_7

    goto :goto_2

    :cond_7
    if-eqz v2, :cond_8

    iget-boolean v2, p2, La0/r;->w:Z

    if-nez v2, :cond_8

    goto :goto_1

    :cond_8
    iget-boolean v2, p2, La0/r;->w:Z

    if-eqz v2, :cond_9

    goto :goto_3

    :cond_9
    :goto_1
    move-object v1, v6

    goto :goto_3

    :cond_a
    :goto_2
    check-cast v1, Li0/h;

    invoke-virtual {v1, v3, v5}, Li0/h;->b(La0/q0;La0/Z0;)Li0/h;

    move-result-object v1

    :goto_3
    iget-boolean v2, p2, La0/r;->y:Z

    if-nez v2, :cond_b

    if-eq v6, v1, :cond_4

    :cond_b
    move v2, v7

    :goto_4
    if-eqz v2, :cond_c

    iget-boolean v3, p2, La0/r;->S:Z

    if-nez v3, :cond_c

    invoke-virtual {p2, v1}, La0/r;->I(La0/n0;)V

    :cond_c
    iget-boolean v3, p2, La0/r;->w:Z

    invoke-virtual {v0, v3}, LL0/v;->c(I)V

    iput-boolean v2, p2, La0/r;->w:Z

    iput-object v1, p2, La0/r;->K:La0/n0;

    const/16 v2, 0xca

    sget-object v3, La0/s;->c:La0/b0;

    invoke-virtual {p2, v2, v8, v3, v1}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    shr-int/lit8 v1, p3, 0x3

    and-int/lit8 v1, v1, 0xe

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, p2, v1}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p2, v8}, La0/r;->p(Z)V

    invoke-virtual {p2, v8}, La0/r;->p(Z)V

    invoke-virtual {v0}, LL0/v;->b()I

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_5

    :cond_d
    move v7, v8

    :goto_5
    iput-boolean v7, p2, La0/r;->w:Z

    iput-object v4, p2, La0/r;->K:La0/n0;

    invoke-virtual {p2}, La0/r;->r()La0/r0;

    move-result-object p2

    if-eqz p2, :cond_e

    new-instance v0, LC/h;

    const/4 v1, 0x4

    invoke-direct {v0, p3, v1, p0, p1}, LC/h;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V

    iput-object v0, p2, La0/r0;->d:Lr7/e;

    :cond_e
    return-void
.end method

.method public static final b([LW3/E;Lr7/e;La0/r;I)V
    .locals 8

    const v0, 0x18bf8a0a

    invoke-virtual {p2, v0}, La0/r;->X(I)La0/r;

    iget-object v0, p2, La0/r;->x:LL0/v;

    invoke-virtual {p2}, La0/r;->l()La0/n0;

    move-result-object v1

    const/16 v2, 0xc9

    sget-object v3, La0/s;->b:La0/b0;

    invoke-virtual {p2, v2, v3}, La0/r;->T(ILa0/b0;)V

    iget-boolean v2, p2, La0/r;->S:Z

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1

    sget-object v2, Li0/h;->w:Li0/h;

    invoke-static {p0, v1, v2}, La0/b;->C([LW3/E;La0/n0;La0/n0;)Li0/h;

    move-result-object v2

    invoke-virtual {p2, v1, v2}, La0/r;->f0(La0/n0;Li0/h;)Li0/h;

    move-result-object v1

    iput-boolean v3, p2, La0/r;->J:Z

    :cond_0
    :goto_0
    move v2, v4

    goto :goto_2

    :cond_1
    iget-object v2, p2, La0/r;->G:La0/E0;

    iget v5, v2, La0/E0;->g:I

    invoke-virtual {v2, v5, v4}, La0/E0;->h(II)Ljava/lang/Object;

    move-result-object v2

    const-string v5, "null cannot be cast to non-null type androidx.compose.runtime.PersistentCompositionLocalMap"

    invoke-static {v2, v5}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, La0/n0;

    iget-object v6, p2, La0/r;->G:La0/E0;

    iget v7, v6, La0/E0;->g:I

    invoke-virtual {v6, v7, v3}, La0/E0;->h(II)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v6, v5}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, La0/n0;

    invoke-static {p0, v1, v6}, La0/b;->C([LW3/E;La0/n0;La0/n0;)Li0/h;

    move-result-object v5

    invoke-virtual {p2}, La0/r;->z()Z

    move-result v7

    if-eqz v7, :cond_3

    iget-boolean v7, p2, La0/r;->y:Z

    if-nez v7, :cond_3

    invoke-virtual {v6, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_2

    goto :goto_1

    :cond_2
    iget v1, p2, La0/r;->l:I

    iget-object v5, p2, La0/r;->G:La0/E0;

    invoke-virtual {v5}, La0/E0;->s()I

    move-result v5

    add-int/2addr v5, v1

    iput v5, p2, La0/r;->l:I

    move-object v1, v2

    goto :goto_0

    :cond_3
    :goto_1
    invoke-virtual {p2, v1, v5}, La0/r;->f0(La0/n0;Li0/h;)Li0/h;

    move-result-object v1

    iget-boolean v5, p2, La0/r;->y:Z

    if-nez v5, :cond_4

    invoke-static {v1, v2}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    :cond_4
    move v2, v3

    :goto_2
    if-eqz v2, :cond_5

    iget-boolean v5, p2, La0/r;->S:Z

    if-nez v5, :cond_5

    invoke-virtual {p2, v1}, La0/r;->I(La0/n0;)V

    :cond_5
    iget-boolean v5, p2, La0/r;->w:Z

    invoke-virtual {v0, v5}, LL0/v;->c(I)V

    iput-boolean v2, p2, La0/r;->w:Z

    iput-object v1, p2, La0/r;->K:La0/n0;

    const/16 v2, 0xca

    sget-object v5, La0/s;->c:La0/b0;

    invoke-virtual {p2, v2, v4, v5, v1}, La0/r;->R(IILjava/lang/Object;Ljava/lang/Object;)V

    shr-int/lit8 v1, p3, 0x3

    and-int/lit8 v1, v1, 0xe

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, p2, v1}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p2, v4}, La0/r;->p(Z)V

    invoke-virtual {p2, v4}, La0/r;->p(Z)V

    invoke-virtual {v0}, LL0/v;->b()I

    move-result v0

    if-eqz v0, :cond_6

    goto :goto_3

    :cond_6
    move v3, v4

    :goto_3
    iput-boolean v3, p2, La0/r;->w:Z

    const/4 v0, 0x0

    iput-object v0, p2, La0/r;->K:La0/n0;

    invoke-virtual {p2}, La0/r;->r()La0/r0;

    move-result-object p2

    if-eqz p2, :cond_7

    new-instance v0, LC/h;

    const/4 v1, 0x5

    invoke-direct {v0, p3, v1, p0, p1}, LC/h;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V

    iput-object v0, p2, La0/r0;->d:Lr7/e;

    :cond_7
    return-void
.end method

.method public static final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lr7/c;La0/r;)V
    .locals 0

    invoke-virtual {p4, p0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p0

    invoke-virtual {p4, p1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p1

    or-int/2addr p0, p1

    invoke-virtual {p4, p2}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p1

    or-int/2addr p0, p1

    invoke-virtual {p4}, La0/r;->K()Ljava/lang/Object;

    move-result-object p1

    if-nez p0, :cond_0

    sget-object p0, La0/m;->a:La0/U;

    if-ne p1, p0, :cond_1

    :cond_0
    new-instance p1, La0/F;

    invoke-direct {p1, p3}, La0/F;-><init>(Lr7/c;)V

    invoke-virtual {p4, p1}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_1
    check-cast p1, La0/F;

    return-void
.end method

.method public static final d(Ljava/lang/Object;Ljava/lang/Object;Lr7/c;La0/r;)V
    .locals 0

    invoke-virtual {p3, p0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p0

    invoke-virtual {p3, p1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p1

    or-int/2addr p0, p1

    invoke-virtual {p3}, La0/r;->K()Ljava/lang/Object;

    move-result-object p1

    if-nez p0, :cond_0

    sget-object p0, La0/m;->a:La0/U;

    if-ne p1, p0, :cond_1

    :cond_0
    new-instance p1, La0/F;

    invoke-direct {p1, p2}, La0/F;-><init>(Lr7/c;)V

    invoke-virtual {p3, p1}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_1
    check-cast p1, La0/F;

    return-void
.end method

.method public static final e(Ljava/lang/Object;Lr7/c;La0/r;)V
    .locals 1

    invoke-virtual {p2, p0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p0

    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object v0

    if-nez p0, :cond_0

    sget-object p0, La0/m;->a:La0/U;

    if-ne v0, p0, :cond_1

    :cond_0
    new-instance v0, La0/F;

    invoke-direct {v0, p1}, La0/F;-><init>(Lr7/c;)V

    invoke-virtual {p2, v0}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_1
    check-cast v0, La0/F;

    return-void
.end method

.method public static final f([Ljava/lang/Object;Lr7/c;La0/r;)V
    .locals 4

    array-length v0, p0

    invoke-static {p0, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    array-length v0, p0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v1, v0, :cond_0

    aget-object v3, p0, v1

    invoke-virtual {p2, v3}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object p0

    if-nez v2, :cond_2

    sget-object v0, La0/m;->a:La0/U;

    if-ne p0, v0, :cond_1

    goto :goto_1

    :cond_1
    return-void

    :cond_2
    :goto_1
    new-instance p0, La0/F;

    invoke-direct {p0, p1}, La0/F;-><init>(Lr7/c;)V

    invoke-virtual {p2, p0}, La0/r;->g0(Ljava/lang/Object;)V

    return-void
.end method

.method public static final g(La0/r;Ljava/lang/Object;Lr7/e;)V
    .locals 2

    iget-object v0, p0, La0/r;->R:Lh7/h;

    invoke-virtual {p0, p1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p1

    invoke-virtual {p0}, La0/r;->K()Ljava/lang/Object;

    move-result-object v1

    if-nez p1, :cond_0

    sget-object p1, La0/m;->a:La0/U;

    if-ne v1, p1, :cond_1

    :cond_0
    new-instance v1, La0/S;

    invoke-direct {v1, v0, p2}, La0/S;-><init>(Lh7/h;Lr7/e;)V

    invoke-virtual {p0, v1}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_1
    check-cast v1, La0/S;

    return-void
.end method

.method public static final h(Ljava/lang/Object;Ljava/lang/Object;Lr7/e;La0/r;)V
    .locals 1

    iget-object v0, p3, La0/r;->R:Lh7/h;

    invoke-virtual {p3, p0}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p0

    invoke-virtual {p3, p1}, La0/r;->f(Ljava/lang/Object;)Z

    move-result p1

    or-int/2addr p0, p1

    invoke-virtual {p3}, La0/r;->K()Ljava/lang/Object;

    move-result-object p1

    if-nez p0, :cond_0

    sget-object p0, La0/m;->a:La0/U;

    if-ne p1, p0, :cond_1

    :cond_0
    new-instance p1, La0/S;

    invoke-direct {p1, v0, p2}, La0/S;-><init>(Lh7/h;Lr7/e;)V

    invoke-virtual {p3, p1}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_1
    check-cast p1, La0/S;

    return-void
.end method

.method public static final i([Ljava/lang/Object;Lr7/e;La0/r;)V
    .locals 5

    iget-object v0, p2, La0/r;->R:Lh7/h;

    array-length v1, p0

    invoke-static {p0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    array-length v1, p0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v2, v1, :cond_0

    aget-object v4, p0, v2

    invoke-virtual {p2, v4}, La0/r;->f(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p2}, La0/r;->K()Ljava/lang/Object;

    move-result-object p0

    if-nez v3, :cond_2

    sget-object v1, La0/m;->a:La0/U;

    if-ne p0, v1, :cond_1

    goto :goto_1

    :cond_1
    return-void

    :cond_2
    :goto_1
    new-instance p0, La0/S;

    invoke-direct {p0, v0, p1}, La0/S;-><init>(Lh7/h;Lr7/e;)V

    invoke-virtual {p2, p0}, La0/r;->g0(Ljava/lang/Object;)V

    return-void
.end method

.method public static final j(Lr7/a;La0/r;)V
    .locals 1

    iget-object p1, p1, La0/r;->M:Lb0/b;

    iget-object p1, p1, Lb0/b;->b:Lb0/a;

    iget-object p1, p1, Lb0/a;->a:Lb0/L;

    sget-object v0, Lb0/B;->c:Lb0/B;

    invoke-virtual {p1, v0}, Lb0/L;->e(Lb0/J;)V

    const/4 v0, 0x0

    invoke-static {p1, v0, p0}, LF4/x5;->a(Lb0/L;ILjava/lang/Object;)V

    return-void
.end method

.method public static final k(Lp/v;I)V
    .locals 3

    iget v0, p0, Lp/v;->b:I

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lp/v;->c(I)I

    move-result v0

    if-eq v0, p1, :cond_0

    iget v0, p0, Lp/v;->b:I

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Lp/v;->c(I)I

    move-result v0

    if-ne v0, p1, :cond_1

    :cond_0
    return-void

    :cond_1
    iget v0, p0, Lp/v;->b:I

    invoke-virtual {p0, p1}, Lp/v;->a(I)V

    :goto_0
    if-lez v0, :cond_2

    add-int/lit8 v1, v0, 0x1

    ushr-int/lit8 v1, v1, 0x1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {p0, v1}, Lp/v;->c(I)I

    move-result v2

    if-le p1, v2, :cond_2

    invoke-virtual {p0, v0, v2}, Lp/v;->e(II)V

    move v0, v1

    goto :goto_0

    :cond_2
    invoke-virtual {p0, v0, p1}, Lp/v;->e(II)V

    return-void
.end method

.method public static l(La0/I0;Ljava/util/List;La0/x;)V
    .locals 5

    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3

    invoke-interface {p1}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_3

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La0/a;

    invoke-virtual {p0, v2}, La0/I0;->c(La0/a;)I

    move-result v2

    invoke-virtual {p0, v2}, La0/I0;->r(I)I

    move-result v3

    iget-object v4, p0, La0/I0;->b:[I

    invoke-virtual {p0, v4, v3}, La0/I0;->M([II)I

    move-result v3

    iget-object v4, p0, La0/I0;->b:[I

    add-int/lit8 v2, v2, 0x1

    invoke-virtual {p0, v2}, La0/I0;->r(I)I

    move-result v2

    invoke-virtual {p0, v4, v2}, La0/I0;->g([II)I

    move-result v2

    if-ge v3, v2, :cond_0

    invoke-virtual {p0, v3}, La0/I0;->h(I)I

    move-result v2

    iget-object v3, p0, La0/I0;->c:[Ljava/lang/Object;

    aget-object v2, v3, v2

    goto :goto_1

    :cond_0
    sget-object v2, La0/m;->a:La0/U;

    :goto_1
    instance-of v3, v2, La0/r0;

    if-eqz v3, :cond_1

    check-cast v2, La0/r0;

    goto :goto_2

    :cond_1
    const/4 v2, 0x0

    :goto_2
    if-eqz v2, :cond_2

    iput-object p2, v2, La0/r0;->a:La0/x;

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    return-void
.end method

.method public static final m(LG7/e0;La0/r;)La0/Z;
    .locals 7

    invoke-interface {p0}, LG7/e0;->getValue()Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lh7/i;->t:Lh7/i;

    invoke-virtual {p1, v1}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v2

    invoke-virtual {p1, p0}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    invoke-virtual {p1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v3

    const/4 v4, 0x0

    sget-object v5, La0/m;->a:La0/U;

    if-nez v2, :cond_0

    if-ne v3, v5, :cond_1

    :cond_0
    new-instance v3, La0/T0;

    invoke-direct {v3, v1, p0, v4}, La0/T0;-><init>(Lh7/h;LG7/i;Lh7/c;)V

    invoke-virtual {p1, v3}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_1
    check-cast v3, Lr7/e;

    invoke-virtual {p1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v5, :cond_2

    invoke-static {v0}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v2

    invoke-virtual {p1, v2}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_2
    check-cast v2, La0/Z;

    invoke-virtual {p1, v3}, La0/r;->h(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {p1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v6

    if-nez v0, :cond_3

    if-ne v6, v5, :cond_4

    :cond_3
    new-instance v6, La0/Q0;

    invoke-direct {v6, v3, v2, v4}, La0/Q0;-><init>(Lr7/e;La0/Z;Lh7/c;)V

    invoke-virtual {p1, v6}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_4
    check-cast v6, Lr7/e;

    invoke-static {p0, v1, v6, p1}, La0/b;->h(Ljava/lang/Object;Ljava/lang/Object;Lr7/e;La0/r;)V

    return-object v2
.end method

.method public static final n(La0/r;)LD7/v;
    .locals 1

    iget-object p0, p0, La0/r;->R:Lh7/h;

    new-instance v0, La0/D0;

    invoke-direct {v0, p0}, La0/D0;-><init>(Lh7/h;)V

    return-object v0
.end method

.method public static final o()Lc0/e;
    .locals 3

    sget-object v0, La0/O0;->b:Lcom/google/android/gms/internal/play_billing/l;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/play_billing/l;->e()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc0/e;

    if-nez v1, :cond_0

    new-instance v1, Lc0/e;

    const/4 v2, 0x0

    new-array v2, v2, [La0/q;

    invoke-direct {v1, v2}, Lc0/e;-><init>([Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/play_billing/l;->r(Ljava/lang/Object;)V

    :cond_0
    return-object v1
.end method

.method public static final p(La0/N0;Lr7/a;)La0/E;
    .locals 1

    sget-object v0, La0/O0;->a:Lcom/google/android/gms/internal/play_billing/l;

    new-instance v0, La0/E;

    invoke-direct {v0, p0, p1}, La0/E;-><init>(La0/N0;Lr7/a;)V

    return-object v0
.end method

.method public static final q(Lr7/a;)La0/E;
    .locals 2

    sget-object v0, La0/O0;->a:Lcom/google/android/gms/internal/play_billing/l;

    new-instance v0, La0/E;

    const/4 v1, 0x0

    invoke-direct {v0, v1, p0}, La0/E;-><init>(La0/N0;Lr7/a;)V

    return-object v0
.end method

.method public static final r(La0/r;)I
    .locals 2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v0, p0, La0/r;->T:J

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result p0

    return p0
.end method

.method public static final s(Lh7/h;)La0/V;
    .locals 1

    sget-object v0, La0/U;->u:La0/U;

    invoke-interface {p0, v0}, Lh7/h;->W(Lh7/g;)Lh7/f;

    move-result-object p0

    check-cast p0, La0/V;

    if-eqz p0, :cond_0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "A MonotonicFrameClock is not available in this CoroutineContext. Callers should supply an appropriate MonotonicFrameClock using withContext."

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static t(La0/I0;ILa0/I0;ZZZ)Ljava/util/List;
    .locals 24

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    invoke-virtual/range {p0 .. p1}, La0/I0;->t(I)I

    move-result v3

    add-int v4, v1, v3

    invoke-virtual/range {p0 .. p1}, La0/I0;->f(I)I

    move-result v5

    invoke-virtual {v0, v4}, La0/I0;->f(I)I

    move-result v6

    sub-int v7, v6, v5

    const/4 v9, 0x1

    if-ltz v1, :cond_0

    iget-object v10, v0, La0/I0;->b:[I

    invoke-virtual/range {p0 .. p1}, La0/I0;->r(I)I

    move-result v11

    mul-int/lit8 v11, v11, 0x5

    add-int/2addr v11, v9

    aget v10, v10, v11

    const/high16 v11, 0xc000000

    and-int/2addr v10, v11

    if-eqz v10, :cond_0

    move v10, v9

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    :goto_0
    invoke-virtual {v2, v3}, La0/I0;->v(I)V

    iget v11, v2, La0/I0;->t:I

    invoke-virtual {v2, v7, v11}, La0/I0;->w(II)V

    iget v11, v0, La0/I0;->g:I

    if-ge v11, v4, :cond_1

    invoke-virtual {v0, v4}, La0/I0;->A(I)V

    :cond_1
    iget v11, v0, La0/I0;->k:I

    if-ge v11, v6, :cond_2

    invoke-virtual {v0, v6, v4}, La0/I0;->B(II)V

    :cond_2
    iget-object v6, v2, La0/I0;->b:[I

    iget v11, v2, La0/I0;->t:I

    iget-object v12, v0, La0/I0;->b:[I

    mul-int/lit8 v13, v11, 0x5

    mul-int/lit8 v14, v1, 0x5

    mul-int/lit8 v15, v4, 0x5

    invoke-static {v13, v14, v15, v12, v6}, Le7/k;->g(III[I[I)V

    iget-object v12, v2, La0/I0;->c:[Ljava/lang/Object;

    iget v14, v2, La0/I0;->i:I

    iget-object v15, v0, La0/I0;->c:[Ljava/lang/Object;

    invoke-static {v15, v5, v12, v14, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v15, v2, La0/I0;->v:I

    add-int/lit8 v16, v13, 0x2

    aput v15, v6, v16

    sub-int v16, v11, v1

    add-int v8, v11, v3

    invoke-virtual {v2, v6, v11}, La0/I0;->g([II)I

    move-result v18

    sub-int v18, v14, v18

    move/from16 v19, v9

    iget v9, v2, La0/I0;->m:I

    move/from16 v20, v9

    iget v9, v2, La0/I0;->l:I

    array-length v12, v12

    move/from16 v21, v10

    move/from16 v10, v20

    move/from16 v20, v13

    move v13, v11

    :goto_1
    if-ge v13, v8, :cond_6

    if-eq v13, v11, :cond_3

    mul-int/lit8 v22, v13, 0x5

    add-int/lit8 v22, v22, 0x2

    aget v23, v6, v22

    add-int v23, v23, v16

    aput v23, v6, v22

    :cond_3
    invoke-virtual {v2, v6, v13}, La0/I0;->g([II)I

    move-result v22

    move-object/from16 v23, v6

    add-int v6, v22, v18

    if-ge v10, v13, :cond_4

    move/from16 v22, v11

    const/4 v11, 0x0

    goto :goto_2

    :cond_4
    move/from16 v22, v11

    iget v11, v2, La0/I0;->k:I

    :goto_2
    invoke-static {v6, v11, v9, v12}, La0/I0;->i(IIII)I

    move-result v6

    mul-int/lit8 v11, v13, 0x5

    add-int/lit8 v11, v11, 0x4

    aput v6, v23, v11

    if-ne v13, v10, :cond_5

    add-int/lit8 v10, v10, 0x1

    :cond_5
    add-int/lit8 v13, v13, 0x1

    move/from16 v11, v22

    move-object/from16 v6, v23

    goto :goto_1

    :cond_6
    move-object/from16 v23, v6

    iput v10, v2, La0/I0;->m:I

    iget-object v6, v0, La0/I0;->d:Ljava/util/ArrayList;

    invoke-virtual {v0}, La0/I0;->p()I

    move-result v9

    invoke-static {v6, v1, v9}, La0/H0;->b(Ljava/util/ArrayList;II)I

    move-result v6

    iget-object v9, v0, La0/I0;->d:Ljava/util/ArrayList;

    invoke-virtual {v0}, La0/I0;->p()I

    move-result v10

    invoke-static {v9, v4, v10}, La0/H0;->b(Ljava/util/ArrayList;II)I

    move-result v4

    if-ge v6, v4, :cond_8

    iget-object v9, v0, La0/I0;->d:Ljava/util/ArrayList;

    new-instance v10, Ljava/util/ArrayList;

    sub-int v11, v4, v6

    invoke-direct {v10, v11}, Ljava/util/ArrayList;-><init>(I)V

    move v11, v6

    :goto_3
    if-ge v11, v4, :cond_7

    invoke-virtual {v9, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, La0/a;

    iget v13, v12, La0/a;->a:I

    add-int v13, v13, v16

    iput v13, v12, La0/a;->a:I

    invoke-virtual {v10, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v11, v11, 0x1

    goto :goto_3

    :cond_7
    iget-object v11, v2, La0/I0;->d:Ljava/util/ArrayList;

    iget v12, v2, La0/I0;->t:I

    invoke-virtual {v2}, La0/I0;->p()I

    move-result v13

    invoke-static {v11, v12, v13}, La0/H0;->b(Ljava/util/ArrayList;II)I

    move-result v11

    iget-object v12, v2, La0/I0;->d:Ljava/util/ArrayList;

    invoke-virtual {v12, v11, v10}, Ljava/util/ArrayList;->addAll(ILjava/util/Collection;)Z

    invoke-virtual {v9, v6, v4}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->clear()V

    goto :goto_4

    :cond_8
    sget-object v10, Le7/t;->t:Le7/t;

    :goto_4
    invoke-interface {v10}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_9

    iget-object v4, v0, La0/I0;->e:Ljava/util/HashMap;

    iget-object v6, v2, La0/I0;->e:Ljava/util/HashMap;

    if-eqz v4, :cond_9

    if-eqz v6, :cond_9

    invoke-interface {v10}, Ljava/util/Collection;->size()I

    move-result v6

    const/4 v9, 0x0

    :goto_5
    if-ge v9, v6, :cond_9

    invoke-interface {v10, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La0/a;

    invoke-virtual {v4, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La0/M;

    add-int/lit8 v9, v9, 0x1

    goto :goto_5

    :cond_9
    iget v4, v2, La0/I0;->v:I

    invoke-virtual {v2, v15}, La0/I0;->N(I)La0/M;

    iget-object v4, v0, La0/I0;->b:[I

    invoke-virtual {v0, v4, v1}, La0/I0;->D([II)I

    move-result v4

    if-nez p5, :cond_a

    const/16 v17, 0x0

    goto :goto_7

    :cond_a
    if-eqz p3, :cond_e

    if-ltz v4, :cond_b

    move/from16 v17, v19

    goto :goto_6

    :cond_b
    const/16 v17, 0x0

    :goto_6
    if-eqz v17, :cond_c

    invoke-virtual {v0}, La0/I0;->O()V

    iget v3, v0, La0/I0;->t:I

    sub-int/2addr v4, v3

    invoke-virtual {v0, v4}, La0/I0;->a(I)V

    invoke-virtual {v0}, La0/I0;->O()V

    :cond_c
    iget v3, v0, La0/I0;->t:I

    sub-int/2addr v1, v3

    invoke-virtual {v0, v1}, La0/I0;->a(I)V

    invoke-virtual {v0}, La0/I0;->G()Z

    move-result v1

    if-eqz v17, :cond_d

    invoke-virtual {v0}, La0/I0;->L()V

    invoke-virtual {v0}, La0/I0;->j()V

    invoke-virtual {v0}, La0/I0;->L()V

    invoke-virtual {v0}, La0/I0;->j()V

    :cond_d
    move/from16 v17, v1

    goto :goto_7

    :cond_e
    invoke-virtual {v0, v1, v3}, La0/I0;->H(II)Z

    move-result v3

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v5, v7, v1}, La0/I0;->I(III)V

    move/from16 v17, v3

    :goto_7
    if-eqz v17, :cond_f

    const-string v0, "Unexpectedly removed anchors"

    invoke-static {v0}, La0/s;->c(Ljava/lang/String;)V

    :cond_f
    iget v0, v2, La0/I0;->o:I

    add-int/lit8 v13, v20, 0x1

    aget v1, v23, v13

    const/high16 v3, 0x40000000    # 2.0f

    and-int/2addr v3, v1

    if-eqz v3, :cond_10

    move/from16 v9, v19

    goto :goto_8

    :cond_10
    const v3, 0x3ffffff

    and-int v9, v1, v3

    :goto_8
    add-int/2addr v0, v9

    iput v0, v2, La0/I0;->o:I

    if-eqz p4, :cond_11

    iput v8, v2, La0/I0;->t:I

    add-int/2addr v14, v7

    iput v14, v2, La0/I0;->i:I

    :cond_11
    if-eqz v21, :cond_12

    invoke-virtual {v2, v15}, La0/I0;->S(I)V

    :cond_12
    return-object v10
.end method

.method public static u(Ljava/lang/Object;)La0/h0;
    .locals 2

    sget-object v0, La0/U;->y:La0/U;

    new-instance v1, La0/h0;

    invoke-direct {v1, p0, v0}, La0/h0;-><init>(Ljava/lang/Object;La0/N0;)V

    return-object v1
.end method

.method public static final v(La0/n0;La0/q0;)Ljava/lang/Object;
    .locals 1

    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.CompositionLocal<kotlin.Any?>"

    invoke-static {p1, v0}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Li0/h;

    invoke-virtual {p0, p1}, Li0/h;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-virtual {p1}, La0/q0;->b()La0/Z0;

    move-result-object v0

    :cond_0
    check-cast v0, La0/Z0;

    invoke-interface {v0, p0}, La0/Z0;->a(La0/n0;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static final w(La0/r;)La0/p;
    .locals 8

    const/16 v0, 0xce

    sget-object v1, La0/s;->e:La0/b0;

    invoke-virtual {p0, v0, v1}, La0/r;->T(ILa0/b0;)V

    iget-boolean v0, p0, La0/r;->S:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, La0/r;->I:La0/I0;

    invoke-static {v0}, La0/I0;->y(La0/I0;)V

    :cond_0
    invoke-virtual {p0}, La0/r;->C()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, La0/o;

    if-eqz v1, :cond_1

    check-cast v0, La0/o;

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    if-nez v0, :cond_2

    new-instance v0, La0/o;

    new-instance v1, La0/p;

    iget-wide v3, p0, La0/r;->T:J

    iget-boolean v5, p0, La0/r;->q:Z

    iget-boolean v6, p0, La0/r;->C:Z

    iget-object v2, p0, La0/r;->h:La0/x;

    iget-object v7, v2, La0/x;->M:LW2/g;

    move-object v2, p0

    invoke-direct/range {v1 .. v7}, La0/p;-><init>(La0/r;JZZLW2/g;)V

    invoke-direct {v0, v1}, La0/o;-><init>(La0/p;)V

    invoke-virtual {v2, v0}, La0/r;->h0(Ljava/lang/Object;)V

    goto :goto_1

    :cond_2
    move-object v2, p0

    :goto_1
    iget-object p0, v0, La0/o;->t:La0/p;

    invoke-virtual {v2}, La0/r;->l()La0/n0;

    move-result-object v0

    iget-object v1, p0, La0/p;->f:La0/h0;

    invoke-virtual {v1, v0}, La0/h0;->setValue(Ljava/lang/Object;)V

    const/4 v0, 0x0

    invoke-virtual {v2, v0}, La0/r;->p(Z)V

    return-object p0
.end method

.method public static final x(Ljava/lang/Object;La0/r;)La0/Z;
    .locals 2

    invoke-virtual {p1}, La0/r;->K()Ljava/lang/Object;

    move-result-object v0

    sget-object v1, La0/m;->a:La0/U;

    if-ne v0, v1, :cond_0

    invoke-static {p0}, La0/b;->u(Ljava/lang/Object;)La0/h0;

    move-result-object v0

    invoke-virtual {p1, v0}, La0/r;->g0(Ljava/lang/Object;)V

    :cond_0
    check-cast v0, La0/Z;

    invoke-interface {v0, p0}, La0/Z;->setValue(Ljava/lang/Object;)V

    return-object v0
.end method

.method public static final y(La0/r;Ljava/lang/Object;Lr7/e;)V
    .locals 1

    iget-boolean v0, p0, La0/r;->S:Z

    if-nez v0, :cond_1

    invoke-virtual {p0}, La0/r;->K()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, p1}, Ls7/j;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    return-void

    :cond_1
    :goto_0
    invoke-virtual {p0, p1}, La0/r;->g0(Ljava/lang/Object;)V

    invoke-virtual {p0, p1, p2}, La0/r;->b(Ljava/lang/Object;Lr7/e;)V

    return-void
.end method

.method public static final z(Lr7/a;)LG7/Q;
    .locals 2

    new-instance v0, La0/U0;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, La0/U0;-><init>(Lr7/a;Lh7/c;)V

    new-instance p0, LG7/Q;

    invoke-direct {p0, v0}, LG7/Q;-><init>(Lr7/e;)V

    return-object p0
.end method
