.class public final La0/W;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/c;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Lr7/c;


# direct methods
.method public synthetic constructor <init>(Lr7/c;I)V
    .locals 0

    iput p2, p0, La0/W;->t:I

    iput-object p1, p0, La0/W;->u:Lr7/c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    iget v0, p0, La0/W;->t:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, Lk0/j;

    sget-object v0, Lk0/l;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    sget-wide v1, Lk0/l;->e:J

    const/4 v3, 0x1

    int-to-long v3, v3

    add-long/2addr v3, v1

    sput-wide v3, Lk0/l;->e:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    iget-object v0, p0, La0/W;->u:Lr7/c;

    new-instance v3, Lk0/e;

    invoke-direct {v3, v1, v2, p1, v0}, Lk0/e;-><init>(JLk0/j;Lr7/c;)V

    return-object v3

    :catchall_0
    move-exception p1

    monitor-exit v0

    throw p1

    :pswitch_0
    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    iget-object p1, p0, La0/W;->u:Lr7/c;

    const-wide/32 v2, 0xf4240

    div-long/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-interface {p1, v0}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
