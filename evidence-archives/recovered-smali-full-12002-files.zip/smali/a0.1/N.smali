.class public final La0/N;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:La0/r0;

.field public b:I

.field public c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(La0/r0;ILjava/lang/Object;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/N;->a:La0/r0;

    iput p2, p0, La0/N;->b:I

    iput-object p3, p0, La0/N;->c:Ljava/lang/Object;

    return-void
.end method
