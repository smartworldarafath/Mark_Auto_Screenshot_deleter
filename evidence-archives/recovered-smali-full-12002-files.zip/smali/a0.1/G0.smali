.class public final La0/G0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Iterable;
.implements Lt7/a;


# instance fields
.field public final t:La0/F0;

.field public final u:I

.field public final v:I


# direct methods
.method public constructor <init>(La0/F0;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/G0;->t:La0/F0;

    iput p2, p0, La0/G0;->u:I

    iput p3, p0, La0/G0;->v:I

    return-void
.end method


# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .locals 5

    iget-object v0, p0, La0/G0;->t:La0/F0;

    iget v1, v0, La0/F0;->A:I

    iget v2, p0, La0/G0;->v:I

    if-eq v1, v2, :cond_0

    invoke-static {}, La0/H0;->f()V

    :cond_0
    iget v1, p0, La0/G0;->u:I

    invoke-virtual {v0, v1}, La0/F0;->h(I)La0/M;

    new-instance v2, La0/L;

    add-int/lit8 v3, v1, 0x1

    iget-object v4, v0, La0/F0;->t:[I

    invoke-static {v4, v1}, La0/H0;->a([II)I

    move-result v4

    add-int/2addr v4, v1

    invoke-direct {v2, v0, v3, v4}, La0/L;-><init>(La0/F0;II)V

    return-object v2
.end method
