.class public final enum La0/k0;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final synthetic A:[La0/k0;

.field public static final enum t:La0/k0;

.field public static final enum u:La0/k0;

.field public static final enum v:La0/k0;

.field public static final enum w:La0/k0;

.field public static final enum x:La0/k0;

.field public static final enum y:La0/k0;

.field public static final enum z:La0/k0;


# direct methods
.method static constructor <clinit>()V
    .locals 9

    new-instance v0, La0/k0;

    const-string v1, "Invalid"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, La0/k0;->t:La0/k0;

    new-instance v1, La0/k0;

    const-string v2, "Cancelled"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, La0/k0;->u:La0/k0;

    new-instance v2, La0/k0;

    const-string v3, "InitialPending"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, La0/k0;->v:La0/k0;

    new-instance v3, La0/k0;

    const-string v4, "RecomposePending"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, La0/k0;->w:La0/k0;

    new-instance v4, La0/k0;

    const-string v5, "Recomposing"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, La0/k0;->x:La0/k0;

    new-instance v5, La0/k0;

    const-string v6, "ApplyPending"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, La0/k0;->y:La0/k0;

    new-instance v6, La0/k0;

    const-string v7, "Applied"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, La0/k0;->z:La0/k0;

    filled-new-array/range {v0 .. v6}, [La0/k0;

    move-result-object v0

    sput-object v0, La0/k0;->A:[La0/k0;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)La0/k0;
    .locals 1

    const-class v0, La0/k0;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, La0/k0;

    return-object p0
.end method

.method public static values()[La0/k0;
    .locals 1

    sget-object v0, La0/k0;->A:[La0/k0;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La0/k0;

    return-object v0
.end method
