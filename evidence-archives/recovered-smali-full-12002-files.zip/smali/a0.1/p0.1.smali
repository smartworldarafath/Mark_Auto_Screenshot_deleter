.class public final La0/p0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/Z;
.implements LD7/v;


# instance fields
.field public final synthetic t:La0/Z;

.field public final u:Lh7/h;


# direct methods
.method public constructor <init>(La0/Z;Lh7/h;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/p0;->t:La0/Z;

    iput-object p2, p0, La0/p0;->u:Lh7/h;

    return-void
.end method


# virtual methods
.method public final N()Lh7/h;
    .locals 1

    iget-object v0, p0, La0/p0;->u:Lh7/h;

    return-object v0
.end method

.method public final getValue()Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, La0/p0;->t:La0/Z;

    invoke-interface {v0}, La0/W0;->getValue()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final setValue(Ljava/lang/Object;)V
    .locals 1

    iget-object v0, p0, La0/p0;->t:La0/Z;

    invoke-interface {v0, p1}, La0/Z;->setValue(Ljava/lang/Object;)V

    return-void
.end method
