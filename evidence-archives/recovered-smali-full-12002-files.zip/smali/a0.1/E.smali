.class public final La0/E;
.super Lk0/u;
.source "SourceFile"

# interfaces
.implements La0/W0;


# instance fields
.field public final u:Lr7/a;

.field public final v:La0/N0;

.field public w:La0/D;


# direct methods
.method public constructor <init>(La0/N0;Lr7/a;)V
    .locals 2

    invoke-direct {p0}, Lk0/u;-><init>()V

    iput-object p2, p0, La0/E;->u:Lr7/a;

    iput-object p1, p0, La0/E;->v:La0/N0;

    new-instance p1, La0/D;

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object p2

    invoke-virtual {p2}, Lk0/f;->g()J

    move-result-wide v0

    invoke-direct {p1, v0, v1}, La0/D;-><init>(J)V

    iput-object p1, p0, La0/E;->w:La0/D;

    return-void
.end method


# virtual methods
.method public final b()Lk0/v;
    .locals 1

    iget-object v0, p0, La0/E;->w:La0/D;

    return-object v0
.end method

.method public final e(Lk0/v;)V
    .locals 1

    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.DerivedSnapshotState.ResultRecord<T of androidx.compose.runtime.DerivedSnapshotState>"

    invoke-static {p1, v0}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, La0/D;

    iput-object p1, p0, La0/E;->w:La0/D;

    return-void
.end method

.method public final getValue()Ljava/lang/Object;
    .locals 4

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v0

    invoke-virtual {v0}, Lk0/f;->e()Lr7/c;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {v0, p0}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v0

    iget-object v1, p0, La0/E;->w:La0/D;

    invoke-static {v1, v0}, Lk0/l;->j(Lk0/v;Lk0/f;)Lk0/v;

    move-result-object v1

    check-cast v1, La0/D;

    const/4 v2, 0x1

    iget-object v3, p0, La0/E;->u:Lr7/a;

    invoke-virtual {p0, v1, v0, v2, v3}, La0/E;->h(La0/D;Lk0/f;ZLr7/a;)La0/D;

    move-result-object v0

    iget-object v0, v0, La0/D;->f:Ljava/lang/Object;

    return-object v0
.end method

.method public final h(La0/D;Lk0/f;ZLr7/a;)La0/D;
    .locals 21

    move-object/from16 v1, p0

    move-object/from16 v6, p1

    move-object/from16 v0, p2

    invoke-virtual {v6, v1, v0}, La0/D;->c(La0/E;Lk0/f;)Z

    move-result v2

    if-eqz v2, :cond_9

    if-eqz p3, :cond_8

    invoke-static {}, La0/b;->o()Lc0/e;

    move-result-object v2

    iget-object v3, v2, Lc0/e;->t:[Ljava/lang/Object;

    iget v4, v2, Lc0/e;->v:I

    const/4 v5, 0x0

    :goto_0
    if-ge v5, v4, :cond_0

    aget-object v8, v3, v5

    check-cast v8, La0/q;

    invoke-virtual {v8}, La0/q;->b()V

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_0
    :try_start_0
    iget-object v3, v6, La0/D;->e:Lp/C;

    sget-object v4, La0/O0;->a:Lcom/google/android/gms/internal/play_billing/l;

    invoke-virtual {v4}, Lcom/google/android/gms/internal/play_billing/l;->e()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Li0/e;

    if-nez v5, :cond_1

    new-instance v5, Li0/e;

    invoke-direct {v5}, Li0/e;-><init>()V

    invoke-virtual {v4, v5}, Lcom/google/android/gms/internal/play_billing/l;->r(Ljava/lang/Object;)V

    goto :goto_1

    :catchall_0
    move-exception v0

    goto/16 :goto_6

    :cond_1
    :goto_1
    iget v4, v5, Li0/e;->a:I

    iget-object v8, v3, Lp/C;->b:[Ljava/lang/Object;

    iget-object v9, v3, Lp/C;->c:[I

    iget-object v3, v3, Lp/C;->a:[J

    array-length v10, v3

    add-int/lit8 v10, v10, -0x2

    if-ltz v10, :cond_6

    const/4 v11, 0x0

    :goto_2
    aget-wide v12, v3, v11

    not-long v14, v12

    const/16 v16, 0x7

    shl-long v14, v14, v16

    and-long/2addr v14, v12

    const-wide v16, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    and-long v14, v14, v16

    cmp-long v14, v14, v16

    if-eqz v14, :cond_5

    sub-int v14, v11, v10

    not-int v14, v14

    ushr-int/lit8 v14, v14, 0x1f

    const/16 v15, 0x8

    rsub-int/lit8 v14, v14, 0x8

    const/4 v7, 0x0

    :goto_3
    if-ge v7, v14, :cond_4

    const-wide/16 v17, 0xff

    and-long v17, v12, v17

    const-wide/16 v19, 0x80

    cmp-long v17, v17, v19

    if-gez v17, :cond_2

    shl-int/lit8 v17, v11, 0x3

    add-int v17, v17, v7

    aget-object v18, v8, v17

    aget v17, v9, v17

    move/from16 p3, v15

    move-object/from16 v15, v18

    check-cast v15, Lk0/t;

    add-int v0, v4, v17

    iput v0, v5, Li0/e;->a:I

    invoke-virtual/range {p2 .. p2}, Lk0/f;->e()Lr7/c;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-interface {v0, v15}, Lr7/c;->g(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4

    :cond_2
    move/from16 p3, v15

    :cond_3
    :goto_4
    shr-long v12, v12, p3

    add-int/lit8 v7, v7, 0x1

    move-object/from16 v0, p2

    move/from16 v15, p3

    goto :goto_3

    :cond_4
    move v0, v15

    if-ne v14, v0, :cond_6

    :cond_5
    if-eq v11, v10, :cond_6

    add-int/lit8 v11, v11, 0x1

    move-object/from16 v0, p2

    goto :goto_2

    :cond_6
    iput v4, v5, Li0/e;->a:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, v2, Lc0/e;->t:[Ljava/lang/Object;

    iget v2, v2, Lc0/e;->v:I

    const/4 v7, 0x0

    :goto_5
    if-ge v7, v2, :cond_8

    aget-object v3, v0, v7

    check-cast v3, La0/q;

    invoke-virtual {v3}, La0/q;->a()V

    add-int/lit8 v7, v7, 0x1

    goto :goto_5

    :goto_6
    iget-object v3, v2, Lc0/e;->t:[Ljava/lang/Object;

    iget v2, v2, Lc0/e;->v:I

    const/4 v7, 0x0

    :goto_7
    if-ge v7, v2, :cond_7

    aget-object v4, v3, v7

    check-cast v4, La0/q;

    invoke-virtual {v4}, La0/q;->a()V

    add-int/lit8 v7, v7, 0x1

    goto :goto_7

    :cond_7
    throw v0

    :cond_8
    return-object v6

    :cond_9
    new-instance v3, Lp/C;

    invoke-direct {v3}, Lp/C;-><init>()V

    sget-object v0, La0/O0;->a:Lcom/google/android/gms/internal/play_billing/l;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/play_billing/l;->e()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Li0/e;

    if-nez v2, :cond_a

    new-instance v2, Li0/e;

    invoke-direct {v2}, Li0/e;-><init>()V

    invoke-virtual {v0, v2}, Lcom/google/android/gms/internal/play_billing/l;->r(Ljava/lang/Object;)V

    :cond_a
    iget v4, v2, Li0/e;->a:I

    invoke-static {}, La0/b;->o()Lc0/e;

    move-result-object v7

    iget-object v0, v7, Lc0/e;->t:[Ljava/lang/Object;

    iget v5, v7, Lc0/e;->v:I

    const/4 v8, 0x0

    :goto_8
    if-ge v8, v5, :cond_b

    aget-object v9, v0, v8

    check-cast v9, La0/q;

    invoke-virtual {v9}, La0/q;->b()V

    add-int/lit8 v8, v8, 0x1

    goto :goto_8

    :cond_b
    add-int/lit8 v0, v4, 0x1

    :try_start_1
    iput v0, v2, Li0/e;->a:I

    new-instance v0, LA/a0;

    const/4 v5, 0x2

    invoke-direct/range {v0 .. v5}, LA/a0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V

    move-object/from16 v5, p4

    invoke-static {v5, v0}, LT5/p;->q(Lr7/a;Lr7/c;)Ljava/lang/Object;

    move-result-object v0

    iput v4, v2, Li0/e;->a:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    iget-object v2, v7, Lc0/e;->t:[Ljava/lang/Object;

    iget v4, v7, Lc0/e;->v:I

    const/4 v7, 0x0

    :goto_9
    if-ge v7, v4, :cond_c

    aget-object v5, v2, v7

    check-cast v5, La0/q;

    invoke-virtual {v5}, La0/q;->a()V

    add-int/lit8 v7, v7, 0x1

    goto :goto_9

    :cond_c
    sget-object v2, Lk0/l;->c:Ljava/lang/Object;

    monitor-enter v2

    :try_start_2
    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v4

    iget-object v5, v6, La0/D;->f:Ljava/lang/Object;

    sget-object v7, La0/D;->h:Ljava/lang/Object;

    if-eq v5, v7, :cond_d

    iget-object v7, v1, La0/E;->v:La0/N0;

    if-eqz v7, :cond_d

    invoke-interface {v7, v0, v5}, La0/N0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    const/4 v7, 0x1

    if-ne v5, v7, :cond_d

    iput-object v3, v6, La0/D;->e:Lp/C;

    invoke-virtual {v6, v1, v4}, La0/D;->d(La0/E;Lk0/f;)I

    move-result v0

    iput v0, v6, La0/D;->g:I

    move-object v5, v6

    goto :goto_a

    :catchall_1
    move-exception v0

    goto :goto_b

    :cond_d
    iget-object v5, v1, La0/E;->w:La0/D;

    monitor-enter v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    invoke-static {v5, v1}, Lk0/l;->m(Lk0/v;Lk0/t;)Lk0/v;

    move-result-object v6

    invoke-virtual {v6, v5}, Lk0/v;->a(Lk0/v;)V

    invoke-virtual {v4}, Lk0/f;->g()J

    move-result-wide v7

    iput-wide v7, v6, Lk0/v;->a:J
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    :try_start_4
    monitor-exit v2

    move-object v5, v6

    check-cast v5, La0/D;

    iput-object v3, v5, La0/D;->e:Lp/C;

    invoke-virtual {v5, v1, v4}, La0/D;->d(La0/E;Lk0/f;)I

    move-result v3

    iput v3, v5, La0/D;->g:I

    iput-object v0, v5, La0/D;->f:Ljava/lang/Object;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :goto_a
    monitor-exit v2

    sget-object v0, La0/O0;->a:Lcom/google/android/gms/internal/play_billing/l;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/play_billing/l;->e()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Li0/e;

    if-eqz v0, :cond_e

    iget v0, v0, Li0/e;->a:I

    if-nez v0, :cond_e

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v0

    invoke-virtual {v0}, Lk0/f;->m()V

    monitor-enter v2

    :try_start_5
    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v0

    invoke-virtual {v0}, Lk0/f;->g()J

    move-result-wide v3

    iput-wide v3, v5, La0/D;->c:J

    invoke-virtual {v0}, Lk0/f;->h()I

    move-result v0

    iput v0, v5, La0/D;->d:I
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    monitor-exit v2

    return-object v5

    :catchall_2
    move-exception v0

    monitor-exit v2

    throw v0

    :cond_e
    return-object v5

    :catchall_3
    move-exception v0

    :try_start_6
    monitor-exit v2

    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :goto_b
    monitor-exit v2

    throw v0

    :catchall_4
    move-exception v0

    iget-object v2, v7, Lc0/e;->t:[Ljava/lang/Object;

    iget v3, v7, Lc0/e;->v:I

    const/4 v7, 0x0

    :goto_c
    if-ge v7, v3, :cond_f

    aget-object v4, v2, v7

    check-cast v4, La0/q;

    invoke-virtual {v4}, La0/q;->a()V

    add-int/lit8 v7, v7, 0x1

    goto :goto_c

    :cond_f
    throw v0
.end method

.method public final i()La0/D;
    .locals 4

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v0

    iget-object v1, p0, La0/E;->w:La0/D;

    invoke-static {v1, v0}, Lk0/l;->j(Lk0/v;Lk0/f;)Lk0/v;

    move-result-object v1

    check-cast v1, La0/D;

    const/4 v2, 0x0

    iget-object v3, p0, La0/E;->u:Lr7/a;

    invoke-virtual {p0, v1, v0, v2, v3}, La0/E;->h(La0/D;Lk0/f;ZLr7/a;)La0/D;

    move-result-object v0

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, La0/E;->w:La0/D;

    invoke-static {v0}, Lk0/l;->i(Lk0/v;)Lk0/v;

    move-result-object v0

    check-cast v0, La0/D;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "DerivedState(value="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La0/E;->w:La0/D;

    invoke-static {v1}, Lk0/l;->i(Lk0/v;)Lk0/v;

    move-result-object v1

    check-cast v1, La0/D;

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object v2

    invoke-virtual {v1, p0, v2}, La0/D;->c(La0/E;Lk0/f;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v1, v1, La0/D;->f:Ljava/lang/Object;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_0
    const-string v1, "<Not calculated>"

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")@"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
