.class public abstract synthetic La0/O0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/google/android/gms/internal/play_billing/l;

.field public static final b:Lcom/google/android/gms/internal/play_billing/l;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/google/android/gms/internal/play_billing/l;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/play_billing/l;-><init>(I)V

    sput-object v0, La0/O0;->a:Lcom/google/android/gms/internal/play_billing/l;

    new-instance v0, Lcom/google/android/gms/internal/play_billing/l;

    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/play_billing/l;-><init>(I)V

    sput-object v0, La0/O0;->b:Lcom/google/android/gms/internal/play_billing/l;

    return-void
.end method
