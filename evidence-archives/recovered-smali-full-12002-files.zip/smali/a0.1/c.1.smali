.class public interface abstract La0/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(ILjava/lang/Object;)V
.end method

.method public abstract b(Ljava/lang/Object;)V
.end method

.method public abstract c()V
.end method

.method public abstract f(III)V
.end method

.method public abstract g(II)V
.end method

.method public h(Ljava/lang/Object;Lr7/e;)V
    .locals 1

    invoke-interface {p0}, La0/c;->n()Ljava/lang/Object;

    move-result-object v0

    invoke-interface {p2, v0, p1}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public abstract i()V
.end method

.method public abstract j(ILjava/lang/Object;)V
.end method

.method public m()V
    .locals 0

    return-void
.end method

.method public abstract n()Ljava/lang/Object;
.end method
