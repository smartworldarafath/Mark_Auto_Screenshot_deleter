.class public final La0/K0;
.super Lk0/v;
.source "SourceFile"


# instance fields
.field public c:I


# direct methods
.method public constructor <init>(IJ)V
    .locals 0

    invoke-direct {p0, p2, p3}, Lk0/v;-><init>(J)V

    iput p1, p0, La0/K0;->c:I

    return-void
.end method


# virtual methods
.method public final a(Lk0/v;)V
    .locals 1

    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableIntStateImpl.IntStateStateRecord"

    invoke-static {p1, v0}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, La0/K0;

    iget p1, p1, La0/K0;->c:I

    iput p1, p0, La0/K0;->c:I

    return-void
.end method

.method public final b(J)Lk0/v;
    .locals 2

    new-instance v0, La0/K0;

    iget v1, p0, La0/K0;->c:I

    invoke-direct {v0, v1, p1, p2}, La0/K0;-><init>(IJ)V

    return-object v0
.end method
