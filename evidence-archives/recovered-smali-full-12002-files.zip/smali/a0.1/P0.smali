.class public final La0/P0;
.super Lj7/i;
.source "SourceFile"

# interfaces
.implements Lr7/e;


# instance fields
.field public final synthetic A:La0/Z;

.field public x:I

.field public synthetic y:Ljava/lang/Object;

.field public final synthetic z:Lr7/e;


# direct methods
.method public constructor <init>(Lr7/e;La0/Z;Lh7/c;)V
    .locals 0

    iput-object p1, p0, La0/P0;->z:Lr7/e;

    iput-object p2, p0, La0/P0;->A:La0/Z;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lj7/i;-><init>(ILh7/c;)V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LD7/v;

    check-cast p2, Lh7/c;

    invoke-virtual {p0, p2, p1}, La0/P0;->n(Lh7/c;Ljava/lang/Object;)Lh7/c;

    move-result-object p1

    check-cast p1, La0/P0;

    sget-object p2, Ld7/z;->a:Ld7/z;

    invoke-virtual {p1, p2}, La0/P0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final n(Lh7/c;Ljava/lang/Object;)Lh7/c;
    .locals 3

    new-instance v0, La0/P0;

    iget-object v1, p0, La0/P0;->z:Lr7/e;

    iget-object v2, p0, La0/P0;->A:La0/Z;

    invoke-direct {v0, v1, v2, p1}, La0/P0;-><init>(Lr7/e;La0/Z;Lh7/c;)V

    iput-object p2, v0, La0/P0;->y:Ljava/lang/Object;

    return-object v0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    iget v0, p0, La0/P0;->x:I

    const/4 v1, 0x1

    if-eqz v0, :cond_1

    if-ne v0, v1, :cond_0

    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    invoke-static {p1}, Ld7/a;->e(Ljava/lang/Object;)V

    iget-object p1, p0, La0/P0;->y:Ljava/lang/Object;

    check-cast p1, LD7/v;

    new-instance v0, La0/p0;

    iget-object v2, p0, La0/P0;->A:La0/Z;

    invoke-interface {p1}, LD7/v;->N()Lh7/h;

    move-result-object p1

    invoke-direct {v0, v2, p1}, La0/p0;-><init>(La0/Z;Lh7/h;)V

    iput v1, p0, La0/P0;->x:I

    iget-object p1, p0, La0/P0;->z:Lr7/e;

    invoke-interface {p1, v0, p0}, Lr7/e;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    sget-object v0, Li7/a;->t:Li7/a;

    if-ne p1, v0, :cond_2

    return-object v0

    :cond_2
    :goto_0
    sget-object p1, Ld7/z;->a:Ld7/z;

    return-object p1
.end method
