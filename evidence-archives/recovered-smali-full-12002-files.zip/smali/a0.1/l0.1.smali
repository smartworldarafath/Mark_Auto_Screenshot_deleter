.class public final La0/l0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr7/a;


# instance fields
.field public final synthetic t:La0/m0;


# direct methods
.method public constructor <init>(La0/m0;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/l0;->t:La0/m0;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 12

    iget-object v0, p0, La0/l0;->t:La0/m0;

    iget-object v0, v0, La0/m0;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    new-instance v2, Lp/H;

    invoke-direct {v2, v1}, Lp/H;-><init>(I)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v1, :cond_6

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La0/Q;

    iget-object v6, v5, La0/Q;->b:Ljava/lang/Object;

    iget v7, v5, La0/Q;->a:I

    if-eqz v6, :cond_0

    new-instance v6, La0/P;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    iget-object v8, v5, La0/Q;->b:Ljava/lang/Object;

    invoke-direct {v6, v7, v8}, La0/P;-><init>(Ljava/lang/Integer;Ljava/lang/Object;)V

    goto :goto_1

    :cond_0
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    :goto_1
    invoke-virtual {v2, v6}, Lp/H;->f(Ljava/lang/Object;)I

    move-result v7

    if-gez v7, :cond_1

    const/4 v8, 0x1

    goto :goto_2

    :cond_1
    move v8, v3

    :goto_2
    if-eqz v8, :cond_2

    const/4 v9, 0x0

    goto :goto_3

    :cond_2
    iget-object v9, v2, Lp/H;->c:[Ljava/lang/Object;

    aget-object v9, v9, v7

    :goto_3
    if-nez v9, :cond_3

    goto :goto_4

    :cond_3
    instance-of v10, v9, Lp/D;

    if-eqz v10, :cond_4

    check-cast v9, Lp/D;

    invoke-virtual {v9, v5}, Lp/D;->a(Ljava/lang/Object;)V

    move-object v5, v9

    goto :goto_4

    :cond_4
    sget-object v10, Lp/N;->a:[Ljava/lang/Object;

    new-instance v10, Lp/D;

    const/4 v11, 0x2

    invoke-direct {v10, v11}, Lp/D;-><init>(I)V

    invoke-virtual {v10, v9}, Lp/D;->a(Ljava/lang/Object;)V

    invoke-virtual {v10, v5}, Lp/D;->a(Ljava/lang/Object;)V

    move-object v5, v10

    :goto_4
    if-eqz v8, :cond_5

    not-int v7, v7

    iget-object v8, v2, Lp/H;->b:[Ljava/lang/Object;

    aput-object v6, v8, v7

    iget-object v6, v2, Lp/H;->c:[Ljava/lang/Object;

    aput-object v5, v6, v7

    goto :goto_5

    :cond_5
    iget-object v6, v2, Lp/H;->c:[Ljava/lang/Object;

    aput-object v5, v6, v7

    :goto_5
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_6
    new-instance v0, Lc0/a;

    invoke-direct {v0, v2}, Lc0/a;-><init>(Lp/H;)V

    return-object v0
.end method
