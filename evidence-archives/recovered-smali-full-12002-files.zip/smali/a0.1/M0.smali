.class public final La0/M0;
.super Lk0/v;
.source "SourceFile"


# instance fields
.field public c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(JLjava/lang/Object;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lk0/v;-><init>(J)V

    iput-object p3, p0, La0/M0;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Lk0/v;)V
    .locals 1

    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableStateImpl.StateStateRecord<T of androidx.compose.runtime.SnapshotMutableStateImpl.StateStateRecord>"

    invoke-static {p1, v0}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, La0/M0;

    iget-object p1, p1, La0/M0;->c:Ljava/lang/Object;

    iput-object p1, p0, La0/M0;->c:Ljava/lang/Object;

    return-void
.end method

.method public final b(J)Lk0/v;
    .locals 2

    new-instance p1, La0/M0;

    invoke-static {}, Lk0/l;->k()Lk0/f;

    move-result-object p2

    invoke-virtual {p2}, Lk0/f;->g()J

    move-result-wide v0

    iget-object p2, p0, La0/M0;->c:Ljava/lang/Object;

    invoke-direct {p1, v0, v1, p2}, La0/M0;-><init>(JLjava/lang/Object;)V

    return-object p1
.end method
