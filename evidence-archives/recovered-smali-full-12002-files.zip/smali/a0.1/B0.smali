.class public final La0/B0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:La0/A0;

.field public final b:La0/a;


# direct methods
.method public constructor <init>(La0/A0;La0/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/B0;->a:La0/A0;

    iput-object p2, p0, La0/B0;->b:La0/a;

    return-void
.end method
