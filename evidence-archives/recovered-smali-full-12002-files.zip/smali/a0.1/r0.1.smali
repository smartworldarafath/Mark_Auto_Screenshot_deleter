.class public final La0/r0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:La0/x;

.field public b:I

.field public c:La0/a;

.field public d:Lr7/e;

.field public e:I

.field public f:Lp/C;

.field public g:Lp/H;


# direct methods
.method public constructor <init>(La0/x;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/r0;->a:La0/x;

    return-void
.end method

.method public static a(La0/E;Lp/H;)Z
    .locals 2

    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.DerivedState<kotlin.Any?>"

    invoke-static {p0, v0}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, La0/E;->v:La0/N0;

    if-nez v0, :cond_0

    sget-object v0, La0/U;->y:La0/U;

    :cond_0
    invoke-virtual {p0}, La0/E;->i()La0/D;

    move-result-object v1

    iget-object v1, v1, La0/D;->f:Ljava/lang/Object;

    invoke-virtual {p1, p0}, Lp/H;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    invoke-interface {v0, v1, p0}, La0/N0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    xor-int/lit8 p0, p0, 0x1

    return p0
.end method


# virtual methods
.method public final b()Z
    .locals 2

    iget-object v0, p0, La0/r0;->a:La0/x;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget-object v0, p0, La0/r0;->c:La0/a;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La0/a;->a()Z

    move-result v0

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    if-eqz v0, :cond_1

    const/4 v0, 0x1

    return v0

    :cond_1
    return v1
.end method

.method public final c(Ljava/lang/Object;)La0/O;
    .locals 1

    iget-object v0, p0, La0/r0;->a:La0/x;

    if-eqz v0, :cond_1

    invoke-virtual {v0, p0, p1}, La0/x;->s(La0/r0;Ljava/lang/Object;)La0/O;

    move-result-object p1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    return-object p1

    :cond_1
    :goto_0
    sget-object p1, La0/O;->t:La0/O;

    return-object p1
.end method

.method public final d()V
    .locals 2

    iget-object v0, p0, La0/r0;->a:La0/x;

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    iput-boolean v1, v0, La0/x;->H:Z

    iget-object v0, v0, La0/x;->M:LW2/g;

    invoke-virtual {v0}, LW2/g;->t()V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, La0/r0;->a:La0/x;

    iput-object v0, p0, La0/r0;->f:Lp/C;

    iput-object v0, p0, La0/r0;->g:Lp/H;

    iput-object v0, p0, La0/r0;->d:Lr7/e;

    return-void
.end method

.method public final e(Z)V
    .locals 1

    iget v0, p0, La0/r0;->b:I

    if-eqz p1, :cond_0

    or-int/lit8 p1, v0, 0x20

    goto :goto_0

    :cond_0
    and-int/lit8 p1, v0, -0x21

    :goto_0
    iput p1, p0, La0/r0;->b:I

    return-void
.end method
