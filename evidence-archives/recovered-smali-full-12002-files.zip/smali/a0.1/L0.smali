.class public final La0/L0;
.super Lk0/v;
.source "SourceFile"


# instance fields
.field public c:J


# direct methods
.method public constructor <init>(JJ)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lk0/v;-><init>(J)V

    iput-wide p3, p0, La0/L0;->c:J

    return-void
.end method


# virtual methods
.method public final a(Lk0/v;)V
    .locals 2

    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableLongStateImpl.LongStateStateRecord"

    invoke-static {p1, v0}, Ls7/j;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, La0/L0;

    iget-wide v0, p1, La0/L0;->c:J

    iput-wide v0, p0, La0/L0;->c:J

    return-void
.end method

.method public final b(J)Lk0/v;
    .locals 3

    new-instance v0, La0/L0;

    iget-wide v1, p0, La0/L0;->c:J

    invoke-direct {v0, p1, p2, v1, v2}, La0/L0;-><init>(JJ)V

    return-object v0
.end method
