.class public final La0/B;
.super La0/q0;
.source "SourceFile"


# instance fields
.field public final synthetic b:I

.field public final c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lr7/a;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, La0/B;->b:I

    sget-object v0, La0/U;->y:La0/U;

    .line 1
    invoke-direct {p0, p1}, La0/q0;-><init>(Lr7/a;)V

    .line 2
    iput-object v0, p0, La0/B;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lr7/c;)V
    .locals 2

    const/4 v0, 0x0

    iput v0, p0, La0/B;->b:I

    .line 3
    new-instance v0, LS6/a;

    const/16 v1, 0x16

    invoke-direct {v0, v1}, LS6/a;-><init>(I)V

    .line 4
    invoke-direct {p0, v0}, La0/q0;-><init>(Lr7/a;)V

    .line 5
    new-instance v0, La0/C;

    invoke-direct {v0, p1}, La0/C;-><init>(Lr7/c;)V

    iput-object v0, p0, La0/B;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)LW3/E;
    .locals 13

    iget v0, p0, La0/B;->b:I

    packed-switch v0, :pswitch_data_0

    new-instance v1, LW3/E;

    if-nez p1, :cond_0

    const/4 v0, 0x1

    :goto_0
    move v4, v0

    goto :goto_1

    :cond_0
    const/4 v0, 0x0

    goto :goto_0

    :goto_1
    iget-object v0, p0, La0/B;->c:Ljava/lang/Object;

    move-object v5, v0

    check-cast v5, La0/N0;

    const/4 v6, 0x1

    move-object v2, p0

    move-object v3, p1

    invoke-direct/range {v1 .. v6}, LW3/E;-><init>(La0/q0;Ljava/lang/Object;ZLa0/N0;Z)V

    return-object v1

    :pswitch_0
    move-object v3, p1

    new-instance v7, LW3/E;

    if-nez v3, :cond_1

    const/4 p1, 0x1

    :goto_2
    move v10, p1

    goto :goto_3

    :cond_1
    const/4 p1, 0x0

    goto :goto_2

    :goto_3
    const/4 v11, 0x0

    const/4 v12, 0x1

    move-object v8, p0

    move-object v9, v3

    invoke-direct/range {v7 .. v12}, LW3/E;-><init>(La0/q0;Ljava/lang/Object;ZLa0/N0;Z)V

    return-object v7

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public b()La0/Z0;
    .locals 1

    iget v0, p0, La0/B;->b:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, La0/q0;->b()La0/Z0;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, La0/B;->c:Ljava/lang/Object;

    check-cast v0, La0/C;

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
