.class public final La0/i0;
.super Lj7/c;
.source "SourceFile"


# instance fields
.field public w:Lr7/c;

.field public synthetic x:Ljava/lang/Object;

.field public final synthetic y:LM0/c0;

.field public z:I


# direct methods
.method public constructor <init>(LM0/c0;Lh7/c;)V
    .locals 0

    iput-object p1, p0, La0/i0;->y:LM0/c0;

    invoke-direct {p0, p2}, Lj7/c;-><init>(Lh7/c;)V

    return-void
.end method


# virtual methods
.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iput-object p1, p0, La0/i0;->x:Ljava/lang/Object;

    iget p1, p0, La0/i0;->z:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, La0/i0;->z:I

    iget-object p1, p0, La0/i0;->y:LM0/c0;

    const/4 v0, 0x0

    invoke-virtual {p1, p0, v0}, LM0/c0;->C(Lh7/c;Lr7/c;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
