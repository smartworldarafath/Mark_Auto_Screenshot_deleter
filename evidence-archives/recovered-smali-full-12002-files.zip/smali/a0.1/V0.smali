.class public final La0/V0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Iterable;
.implements Lt7/a;


# instance fields
.field public final t:La0/F0;

.field public final u:I

.field public final v:La0/b;


# direct methods
.method public constructor <init>(La0/F0;ILa0/M;La0/b;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0/V0;->t:La0/F0;

    iput p2, p0, La0/V0;->u:I

    iput-object p4, p0, La0/V0;->v:La0/b;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method


# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .locals 5

    new-instance v0, La0/L;

    const/4 v1, 0x0

    iget-object v2, p0, La0/V0;->v:La0/b;

    iget-object v3, p0, La0/V0;->t:La0/F0;

    iget v4, p0, La0/V0;->u:I

    invoke-direct {v0, v3, v4, v1, v2}, La0/L;-><init>(La0/F0;ILa0/M;La0/b;)V

    return-object v0
.end method
