.class public interface abstract La0/Z0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(La0/n0;)Ljava/lang/Object;
.end method
